from setuptools import find_packages, setup

install_reqs = list()
with open("requirements.txt", "r") as r_file:
    for l in r_file:
        install_reqs.append(l.strip())

extras = dict()
extras['fasttext'] = ['fasttext==0.9.1', 'pybind11']
extras['nlu-kernel'] = ['nlu-kernel @ git+https://github.com/intel-sandbox/applications.ai.spui.nlu-kernel.git@master']
extras['ci'] = ['pylint', 'pytest']
extras['deployment'] = ['minio==7.0.3'] + extras['nlu-kernel']

setup(
    name='hydra',
    version='0.1',
    description='SPUI NLP backend service',
    author='spui-team',
    author_email='',
    long_description=open("README.md", "r", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    extras_require=extras,
    packages=find_packages(),
    install_requires=install_reqs
)
