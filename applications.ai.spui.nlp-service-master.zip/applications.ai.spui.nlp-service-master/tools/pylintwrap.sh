#!/bin/bash
SH_DIR=$(cd "$(dirname "$0")"; pwd)
PRJ_DIR=$(dirname $SH_DIR)
MODULE_NAME="hydra"
# all: scan all py files
SCAN_MODE=$1

cd ${PRJ_DIR}

if [ ! -z ${SCAN_MODE} ] && [ ${SCAN_MODE} == "all" ];
then
    echo "Scan all py files."
    pylint --rcfile=${SH_DIR}/pylintrc ${PRJ_DIR}/${MODULE_NAME}/
else
    echo "Scan latest commit."
    files=$(git diff --name-status HEAD~1 | grep "\.py" | awk '{if($1!="D"){print $2}}' | tr '\n' ' ')
    echo $files
    if [ ! -z "${files}" ]; then
        echo "Scan: ${files}"
        pylint --rcfile=${SH_DIR}/pylintrc ${files}
    fi
fi

