# nlp-service

## Describe
Nlp-service schedules many nlp units based on multiprocessor and async.<br>

1. nlp models
    - [nlu-kernel](https://github.com/intel-sandbox/applications.ai.spui.nlu-kernel)
    - [fasttext](https://fasttext.cc/)
2. connection
    - [thrift](https://thrift.apache.org/)
    - socket
    - [RabbitMQ](https://www.rabbitmq.com/)
    - [RSocket](https://rsocket.io/)

## Requirements

- [nlu-kernel](https://gitlab.devtools.intel.com/speechui/nlu-kernel/-/wikis/Releases)
    ```bash
    # download the whl from nlu-kernel release page
    pip install nlukernel-<version>-py3-none-any.whl
    ```

- nlp-service
    ```bash
    pip install -r requirements.txt
    ```

## Run
- download latest model files into **./run/models/**
    ```bash
    cd ./run
    python3 models_download.py
    ```

- start thrift server
    ```bash
    cd ./run
    ./run.sh
    ```

## Build image
- Download [nlu-kernel](https://gitlab.devtools.intel.com/speechui/nlu-kernel/-/wikis/Releases) whl into hydra folder
- Build
    ```bash
    docker build --rm -t spui/hydra:<tag> .
    ```
- Run
    ```bash
    docker run --gpus all -it --rm -v <model_folder>:/hydra/tests/spui_model -p 9093:9093 spui/hydra:<tag> bash
    cd /hydra
    export PYTHONPATH=/hydra
    python run/nlu_service2.py
    ```

## Test

- thrift client test
    ```bash
    cd ./tests
    ./test_client.sh
    ```

- unit tests
    ```bash
    pytest tests/*
    ```

- train tests with meta-human library
    1. Ensure that rabbitmq and openface services are running before starting the tests.
     ```bash
    docker run -itd --rm --name rabbitmq -p 5672:5672 -p 15672:15672 rabbitmq:3.12-management-alpine
    # openface service is not needed anymore if star to generate landmarks
    # docker run -v <root_workspace>:<root_workspace> -p 9090:9090 -itd --rm --name opfc opfc_thrift:<tag>
    ```
    2. Update the paths in template yml to match your local environment.
    3. Configure MH_WORKSPACE, MH_DATASET, MH_ROOT and BERT_MODEL_PATH environment variables.
    ```bash
    export MH_WORKSPACE=<root_workspace_dir>
    export MH_DATASET=<root_dataset_dir>
    export MH_ROOT=<root_meta_human_lib_dir>
    export BERT_MODEL_PATH=<bert_model_path>
    ```
    4. Execute run.sh script
    ```bash
    cd ./mh_run
    # -t: set task type (tts or face)
    # -s: standalone mode
    # -d: set meta-human library path
    ./run.sh -t tts -s -d /home/user/projects/meta-human
    ```
    5. Run train_send.py to trigger training event
    ```bash
    cd ./mh_run
    # -d: dataset
    # -n: test name (default: "test")
    # -t: task (tts or face)
    # -m: model (BERTVITS, ERNERF or GPTSOVITS)
    python train_send.py -d example.mp4 -t tts -m BERTVITS
    ```