import os
import argparse
from functools import partial

from hydra.core.resource import ResourceManager
from hydra.core.stream import RSocketConfig, RSocketStream, RouteConfig
from hydra.nlunit.common_utils.storage_cache import StorageShared, MetaShared
from common import gen_inference_config, init_env_func, SelectFunc, tts_select
from cosyvoice_inference import preprocess_msg, register_preprocess_msg

MOSS_REGISTER_COUNT = 4


def get_rsocket_config(test: bool, model_name: str):
    host = os.getenv("RSOCKET_HOST", "localhost")
    port = os.getenv("RSOCKET_PORT", 7000)
    route = os.getenv("RSOCKET_ROUTE", "mh-infer")
    register_route = os.getenv("RSOCKET_REGISTER_ROUTE", "create")
    preprocess_msg_ = partial(preprocess_msg, route=route, skip_update=test)
    register_preprocess_msg_ = partial(register_preprocess_msg, route=register_route, skip_update=test, model=model_name)
    return RSocketConfig(host, port, routes=[RouteConfig(route, preprocess_msg_),
                                             RouteConfig(register_route, register_preprocess_msg_, block=False)],
                         nonblock_preprocess_func=preprocess_msg_, init_func=init_env_func), route, register_route


def run_moss_inference_service(test: bool, model_path: str, tokenizer_path: str):
    from hydra.nlunit.tts_register_unit import TTSRegisterUnit
    from hydra.nlunit.moss_ttsd_unit import MossTTSDUnit

    resource_manager = ResourceManager()
    manager = resource_manager.get_root_manager()

    rsocket_config, moss_route, register_route = get_rsocket_config(test, "moss")
    rsocket_stream = RSocketStream.create(rsocket_config)
    manager.set_input(rsocket_stream)

    model_shared = StorageShared(f"moss_model_shared", 16) if not test else None
    inference_config = gen_inference_config(model_shared)
    moss_ttsd_subject = manager.create_subject("MossTTSDUnit", "MossTTSD")
    moss_ttsd_subject.create(model_path, tokenizer_path, inference_config, "cuda", log=not test)

    dataset_shared = StorageShared(f"moss_dataset_shared", 16) if not test else None
    dataset_meta_shared = MetaShared(MOSS_REGISTER_COUNT) if not test else None
    register_config = gen_inference_config(dataset_shared, dataset_meta_shared)
    moss_ttsd_register_subject = manager.create_subject("TTSRegisterUnit", "MossRegister")
    moss_ttsd_register_subject.create(register_config, log=not test)

    @manager.link("Root")
    @manager.from_root_selected(SelectFunc(moss_route))
    @manager.group("MossTTSD_grp", "MossTTSD")
    class MossTTSDGroup:
        pass

    @manager.selected_link([("MossTTSD_grp", tts_select)])
    @manager.from_root_selected(SelectFunc(register_route))
    @manager.group("MossRegister-grp", "MossRegister", count=MOSS_REGISTER_COUNT)
    class MossTTSDRegisterGroup:
        pass

    manager.start()
    text = input("input your command>> ")
    manager.stop()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--test", action="store_true")
    parser.add_argument("-m", "--model_path", type=str, required=True, help="Path to the model")
    parser.add_argument("-t", "--tokenizer_path", type=str, required=True, help="Path to the tokenizer model")
    args = parser.parse_args()
    run_moss_inference_service(args.test, args.model_path, args.tokenizer_path)
