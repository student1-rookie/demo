import os
import platform
from typing import Optional

from hydra.nlunit.mh_utils.config import MHInferenceConfig
from hydra.nlunit.common_utils.env import EnvManager, EnvKey
from hydra.nlunit.mh_utils.utils import MHStatus, MHModel

MODELS = {
    MHModel.TTS: ["bertvits", "gptsovits"],
    MHModel.FACE: ["ernerf", "gaussian"]
}
_TASK_MAP = {d: k for k, v in MODELS.items() for d in v}

TTS_EX_TYPE = ["COSYVOICE", "MOSSTTSD", "VIBEVOICE", "QWENTTS"]


def get_task(model_name):
    return _TASK_MAP[model_name]


def get_models(task: str) -> list:
    assert task in MODELS, f"Cannot find task {task} in MODELS"
    return MODELS[task]


def get_model_pair():
    return [(k, d) for k, v in MODELS.items() for d in v]


def get_xpu_model_pair():
    return [(MHModel.FACE, "ernerf")]


def gen_inference_config(shared=None, meta_shared=None) -> MHInferenceConfig:
    root_workspace = os.getenv("MH_WORKSPACE", "mh_workspace")
    root_dataset = os.getenv("MH_DATASET", "mh_dataset")
    root_output_dir = os.getenv("MH_OUTPUT", "infer")
    root_log_workspace = os.getenv("MH_LOG", "/mh_log_workspace")
    item_output_dir = os.getenv("ITEM_OUTPUT", "temp")
    fail_output_dir = os.getenv("FAIL_OUTPUT", "fail")
    return MHInferenceConfig(root_workspace, root_dataset, root_output_dir, root_log_workspace, item_output_dir, fail_output_dir, shared=shared,
                             meta_shared=meta_shared)


def get_service_name(suffix: Optional[str] = None) -> str:
    service_name = os.getenv("MH_SERVICE", platform.node())
    return f"{service_name}_{suffix}" if suffix else service_name


def init_env_func():
    env_manager = EnvManager()
    env_manager.init()


def get_db_env(data: dict):
    if "env" in data:
        env_manager = EnvManager()
        flush = data.get("env_flush", False)
        ret = env_manager.update(data["env"], flush=flush)
        if not ret:
            print(f"Cannot find env: {data['env']} and skip this task.")
            return None
        else:
            return env_manager.get(data["env"], EnvKey.DB)
    return {}


class SelectFunc:
    def __init__(self, route):
        self._route = route

    def __call__(self, data):
        return self._route == data['route']


def tts_select(data) -> bool:
    if data["status"] == MHStatus.FAILED:
        return False
    return True

def get_sync_name(default=None):
    return os.getenv("MH_SYNC_NAME", default)
