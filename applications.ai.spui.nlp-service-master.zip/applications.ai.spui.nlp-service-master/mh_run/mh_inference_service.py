import os
import json
import argparse
import base64
from functools import partial
from typing import Optional, Union

from hydra.core.resource import ResourceManager
from hydra.core.stream import RabbitMQStream, MQConfig
from hydra.nlunit.mh_utils.config import CustomizedVoiceUnitConfig
from hydra.nlunit.mh_utils.utils import ModelStatus, InferenceType
from hydra.nlunit.mh_utils.db_utils import init_model_status, update_items_status
from hydra.nlunit.mh_utils.rsocket_request import RSocketClientConfig
from common import get_models, gen_inference_config, get_service_name, init_env_func, get_db_env, TTS_EX_TYPE
from hydra.nlunit.mh_utils.redis_logger import RedisLogger, RedisConfig


class InferenceSelectFunc:
    def __init__(self, task, des, exclude=None):
        self._task = task
        self._des = des
        self._exclude = exclude

    def __call__(self, data):
        if "pic_in_pic" in data:
            return False
        model_key = f"{self._task}_model"
        if model_key not in data:
            return False
        if self._exclude and f"{self._exclude}_model" in data:
            return False
        model_type_key = f"{self._task}_model_type"
        if model_type_key not in data or data[model_type_key] is None:
            return False
        model_type = data[model_type_key].lower()
        return self._des == f"{self._task}_{model_type}_grp"


class CustomizedVoiceSelectFunc:
    def __call__(self, data):
        return data.get("tts_model_type") in TTS_EX_TYPE and not data.get("pic_in_pic", False)


class PicInPicInferenceSelectFunc:
    def __call__(self, data):
        return data.get("pic_in_pic", False) and data.get("type") == InferenceType.WHOLE_SUBMIT

class PicInPicInferenceItemSelectFunc:
    def __call__(self, data):
        return data.get("pic_in_pic", False) and data.get("type") == InferenceType.ITEM_SUBMIT


def voice_generate(tts_env):
    if tts_env:
        return CustomizedVoiceUnitConfig(tts_env, local=True)
    tts_env_name = os.getenv("TTS_ENV_NAME", "tts-ex")
    return CustomizedVoiceUnitConfig("", local=False, env_name=tts_env_name)


def ls_generate(non_blocking=False):
    host = os.getenv("LS_HOST", "localhost")
    port = os.getenv("LS_PORT", "7001")
    route = "fire-and-forget" if non_blocking else os.getenv("LS_ROUTE", "mh-infer")
    return RSocketClientConfig(host, port, route)


def get_mq_config(sp_name: Optional[str]) -> MQConfig:
    host = os.getenv("MQ_HOST", "localhost")
    port = int(os.getenv("MQ_PORT", 5672))
    key = "generic" if sp_name is None else sp_name
    return MQConfig(host=host, port=port, exchange="mh-infer", routing_key=f"mh.infer.{key}", queue=f"mh.iq.{key}",
                    delete_queue=sp_name is not None)


def preprocess_msg(data: Union[str, dict], msg_id, skip_update) -> dict:
    if isinstance(data, str):
        ret = json.loads(data)
    else:
        ret = data
    if 'extra' in ret:
        extra_info = json.loads(ret.pop('extra'))
        ret.update(extra_info)
    if not skip_update:
        ret["msg_id"] = msg_id
        ret["id"] = base64.b64decode(msg_id).decode('ascii')
        db_env = get_db_env(ret)
        if db_env is None:
            return {"model": "skip"}
        run_service = get_service_name()
        item_ids = []
        if ret.get("input"):
            for one_input in ret.get("input"):
                item_ids.append(one_input["itemId"])
        if ret["type"] == InferenceType.ITEM_SUBMIT:
                redis_client = RedisLogger(
                    header="mh_inference_service",
                    config=RedisConfig.generate(),
                    enable=True
                )
                res = redis_client.update_json_field(
                        key=ret["input"][0]["itemKey"],
                        field_values={"inferenceStatus": ModelStatus.WAIT},
                        expire_time=86400
                      )
                if res is None:
                    return {"pip_item": "skip"}
        else:
            if ret["type"] == InferenceType.TTS_EXAMPLE:
                init_model_status(ret["id"], run_service, "tts", ModelStatus.CREATE_WAV, **db_env)
                print(f"rabbitmq: update task [{ret['id']}] to: {ModelStatus.CREATE_WAV}")
            else:
                init_model_status(ret["id"], run_service, "infer", ModelStatus.WAIT, **db_env)
                if len(item_ids) > 0:
                    update_items_status(item_ids, ModelStatus.WAIT, "infer", run_service)
                print(f"rabbitmq: update task [{ret['id']}] to: {ModelStatus.WAIT}")
        ret["run_service"] = run_service
        ret["status"] = ModelStatus.WAIT
        ret["infer_item_ids"] = item_ids
    return ret


def run_mh_inference_service(sp_name: Optional[str], tts_env: Optional[str], test: bool):
    from hydra.nlunit.mh_unit import MHTTSUnit, MHFaceUnit, CustomizedVoiceUnit, FaceLatentsyncUnit
    from hydra.nlunit.mh_pip_unit import MHInferPicInPicUnit
    from hydra.nlunit.mh_pip_item_unit import MHInferPicInPicItemUnit

    resource_manager = ResourceManager()
    manager = resource_manager.get_root_manager()

    mq_config = get_mq_config(sp_name)
    rabbitmq_stream = RabbitMQStream.create(mq_config, partial(preprocess_msg, skip_update=test),
                                            init_func=init_env_func)
    manager.set_input(rabbitmq_stream)

    inference_config = gen_inference_config()

    tts_grps = {m: f"tts_{m}_grp" for m in get_models("tts")}
    face_grps = {m: f"face_{m}_grp" for m in [*get_models("face"), "latentsync"]}

    for model, group_name in tts_grps.items():
        tts_subject = manager.create_subject("MHTTSUnit", model)
        device = "cpu" if model == "bertvits" else "cuda"
        tts_subject.create(inference_config, device, True)
        sync_name = None if model == "bertvits" else "mh_infer"

        @manager.selected_link([(g, InferenceSelectFunc("face", g)) for g in face_grps.values()])
        @manager.from_root_selected(InferenceSelectFunc("tts", group_name))
        @manager.group(group_name, model, sync_name=sync_name)
        class TTSGroup:
            pass

    for model, group_name in face_grps.items():
        if model == "latentsync":
            face_subject = manager.create_subject("FaceLatentsyncUnit", model)
            face_subject.create(ls_generate(True), inference_config, True)
            sync_name = None
        else:
            face_subject = manager.create_subject("MHFaceUnit", model)
            face_subject.create(inference_config, "cuda", True)
            sync_name = "mh_infer"

        @manager.from_root_selected(InferenceSelectFunc("face", group_name, exclude="tts"))
        @manager.group(group_name, model, sync_name=sync_name)
        class FaceGroup:
            pass

    customized_voice_subject = manager.create_subject("CustomizedVoiceUnit", "customized_voice")
    customized_voice_subject.create(voice_generate(tts_env), inference_config, True)

    @manager.selected_link([(g, InferenceSelectFunc("face", g)) for g in face_grps.values()])
    @manager.from_root_selected(CustomizedVoiceSelectFunc())
    @manager.group("customized_voice_grp", "customized_voice", count=len(TTS_EX_TYPE))
    class CustomizedVoiceGroup:
        pass

    pic_in_pic_subject = manager.create_subject("MHInferPicInPicUnit", "PicInPic")
    pic_in_pic_subject.create(inference_config, "cuda",
                              voice_generate(tts_env), ls_generate(),
                              os.path.dirname(os.path.abspath(__file__)), True)
    
    pic_in_pic_item_subject = manager.create_subject("MHInferPicInPicItemUnit", "PicInPicItem")
    pic_in_pic_item_subject.create(inference_config, "cuda",
                              voice_generate(tts_env), ls_generate(),
                              os.path.dirname(os.path.abspath(__file__)), True)

    @manager.from_root_selected(PicInPicInferenceSelectFunc())
    @manager.group("pic_in_pic_grp", "PicInPic", sync_name="mh_infer")
    class PicInPicBaseGroup:
        pass

    @manager.from_root_selected(PicInPicInferenceItemSelectFunc())
    @manager.group("pic_in_pic_item_grp", "PicInPicItem", sync_name="mh_infer")
    class PicInPicItemGroup:
        pass

    manager.start()
    text = input("input your command>> ")
    manager.stop()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--test", action="store_true", help="test_mode")
    parser.add_argument("--sp", type=str, default=None, help="specific service name")
    parser.add_argument("--tts", type=str, default=None, help="custom tts service env")
    args = parser.parse_args()
    run_mh_inference_service(args.sp, args.tts, args.test)
