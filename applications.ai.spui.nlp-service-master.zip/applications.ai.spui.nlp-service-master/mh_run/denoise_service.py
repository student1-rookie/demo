import os
import uuid
import shutil
import argparse
from pathlib import Path

from rsocket.helpers import utf8_decode
from rsocket.extensions.composite_metadata import CompositeMetadata

from hydra.core.resource import ResourceManager
from hydra.core.stream import RSocketConfig, RSocketStream, RouteConfig


def preprocess_msg(contents, composite_metadata: CompositeMetadata) -> dict:
    meta = composite_metadata.find_by_mimetype("message/x.rsocket.filename")
    if meta:
        file_name = utf8_decode(meta[0].content)
    else:
        file_name = "temp.mp4"
    temp_dir = os.path.join("/tmp", str(uuid.uuid1()))
    Path(temp_dir).mkdir(parents=True, exist_ok=True)
    input = os.path.join(temp_dir, file_name)

    with open(input, 'wb') as file:
        file.write(contents)
    return {"fileName": file_name, "input": input}


def postprocess_msg(output):
    if output and os.path.exists(output):
        with open(output, 'rb') as file:
            file_bytes = file.read()
        shutil.rmtree(os.path.dirname(output))
        return file_bytes
    else:
        return b''


def get_rsocket_config():
    host = os.getenv("RSOCKET_HOST", "localhost")
    port = os.getenv("RSOCKET_PORT", 7002)
    route = os.getenv("RSOCKET_ROUTE", "denoise")
    return RSocketConfig(host, port, routes=[RouteConfig(route, preprocess_msg, postprocess_msg)],
                         nonblock_preprocess_func=None)


def run_denoise_service(model_path: str):
    from hydra.nlunit.denoise_unit import DenoiseUnit

    resource_manager = ResourceManager()
    manager = resource_manager.get_root_manager()

    rsocket_stream = RSocketStream.create(get_rsocket_config())
    manager.set_input(rsocket_stream)

    denoise_subject = manager.create_subject("DenoiseUnit", "Denoise")
    denoise_subject.create(model_path)

    @manager.link("Root")
    @manager.from_root()
    @manager.group("denoise_grp", "Denoise")
    class DenoiseGroup:
        pass

    manager.start()
    text = input("input your command>> ")
    manager.stop()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("-m", "--model_path", type=str, default="/model/metricgan-plus-voicebank",
                        help="Path to the model")
    args = parser.parse_args()
    run_denoise_service(args.model_path)
