import asyncio
import argparse
import logging
from pathlib import Path

from rsocket.payload import Payload
from rsocket.rsocket_client import RSocketClient
from rsocket.rx_support.rx_rsocket import RxRSocket
from rsocket.transports.tcp import TransportTCP
from rsocket.helpers import single_transport_provider
from rsocket.extensions.composite_metadata import CompositeMetadata, CompositeMetadataItem
from rsocket.extensions.helpers import route as rsocket_route
from rsocket.extensions.mimetypes import WellKnownMimeTypes


async def send_pptx_request(host, port, pptx_path, test_mode=False):
    pptx_path = Path(pptx_path)
    with pptx_path.open("rb") as f:
        pptx_data = f.read()

    connection = await asyncio.open_connection(host, port)

    async with RSocketClient(
            single_transport_provider(TransportTCP(*connection)),
            metadata_encoding=WellKnownMimeTypes.MESSAGE_RSOCKET_COMPOSITE_METADATA.value.name) as client:
        rx_client = RxRSocket(client)

        composite_metadata = CompositeMetadata()
        composite_metadata.append(rsocket_route("parser"))
        composite_metadata.append(CompositeMetadataItem(b"message/x.rsocket.filename", pptx_path.name.encode()))

        if test_mode:
            composite_metadata.append(CompositeMetadataItem(b"message/x.rsocket.test", b"true"))
        payload = Payload(data=pptx_data, metadata=composite_metadata.serialize())

        response = await rx_client.request_response(payload).pipe()
        print("Response received:")
        print(response.data.decode('utf-8', errors='ignore'))


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)

    parser = argparse.ArgumentParser()
    parser.add_argument('--host', type=str, default='localhost')
    parser.add_argument('--port', type=int, default=7001)
    parser.add_argument('--pptx_path', type=str, required=True)
    parser.add_argument('--test', action='store_true', help='Enable test mode')

    args = parser.parse_args()

    asyncio.run(send_pptx_request(args.host, args.port, args.pptx_path, args.test))
