import os
import uuid
from pathlib import Path
from rsocket.helpers import utf8_decode
from rsocket.extensions.composite_metadata import CompositeMetadata

from hydra.core.resource import ResourceManager
from hydra.core.stream import RSocketConfig, RSocketStream, RouteConfig
from hydra.nlunit.ppt_utils.common import ResourceAccess
from common import init_env_func, get_db_env


def _metadata_parser(composite_metadata: CompositeMetadata, key: str, default: str):
    meta = composite_metadata.find_by_mimetype(key)
    if meta:
        return utf8_decode(meta[0].content)
    return default


def preprocess_msg(contents, composite_metadata: CompositeMetadata) -> dict:
    file_name = _metadata_parser(composite_metadata, "message/x.rsocket.filename", "temp.pptx")
    test_mode = _metadata_parser(composite_metadata, "message/x.rsocket.test", "false") == "true"
    account_id = _metadata_parser(composite_metadata, "message/x.rsocket.accountid", "")
    access = _metadata_parser(composite_metadata, "message/x.rsocket.access", ResourceAccess.PRIVATE)
    cluster = _metadata_parser(composite_metadata, "message/x.rsocket.cluster", "false") == "true"
    user_bucket = _metadata_parser(composite_metadata, "message/x.rsocket.userbucket", "")
    dataset_base = _metadata_parser(composite_metadata, "message/x.rsocket.datasetbase", "")
    env = _metadata_parser(composite_metadata, "message/x.rsocket.env", "")
    env_flush = _metadata_parser(composite_metadata, "message/x.rsocket.envflush", "false") == "true"
    if env:
        get_db_env({"env": env, "env_flush": env_flush})

    temp_dir = os.path.join("/tmp", f"pptp_{uuid.uuid1()}")
    Path(temp_dir).mkdir(parents=True, exist_ok=True)
    ppt_path = os.path.join(temp_dir, file_name)

    with open(ppt_path, 'wb') as file:
        file.write(contents)
    extras = {
        "userBucket": user_bucket,
        "workSpace": {
            "datasetBase": dataset_base,
        },
        "env": env if env else None,
        "envFlush": env_flush,
    } if cluster else {}
    return {
        "ppt_path": ppt_path,
        "tmp_dir": temp_dir,
        "test_mode": test_mode,
        "accountID": account_id,
        "access": access,
        "cluster": cluster,
        **extras,
    }


def get_rsocket_config():
    host = os.getenv("RSOCKET_HOST", "localhost")
    port = os.getenv("RSOCKET_PORT", 7002)
    route = os.getenv("RSOCKET_ROUTE", "parser")
    return RSocketConfig(host, port, routes=[RouteConfig(route, preprocess_msg)], nonblock_preprocess_func=None,
                         init_func=init_env_func)


def get_dataset_path():
    return os.getenv("MH_DATASET", "mh_dataset")


def run_mh_inference_service():
    from hydra.nlunit.ppt_parser_unit import PPTParserUnit

    resource_manager = ResourceManager()
    manager = resource_manager.get_root_manager()

    rsocket_stream = RSocketStream.create(get_rsocket_config())
    manager.set_input(rsocket_stream)

    ppt_parser_subject = manager.create_subject("PPTParserUnit", "PPTParser")
    ppt_parser_subject.create(get_dataset_path())

    @manager.link("Root")
    @manager.from_root()
    @manager.group("ppt_parser_grp", "PPTParser", count=4)
    class PPTParserGroup:
        pass

    manager.start()
    text = input("input your command>> ")
    manager.stop()


if __name__ == '__main__':
    run_mh_inference_service()
