import json
import os
import argparse
import base64
import uuid
import pathlib
from functools import partial
from typing import Optional, Union

from hydra.core.resource import ResourceManager
from hydra.core.stream import RabbitMQStream, MQConfig
from hydra.nlunit.common_utils.storage_cache import StorageShared, NoStorageCache
from hydra.nlunit.mh_unit import MHTrainConfig
from hydra.nlunit.mh_utils.utils import ModelStatus, MHModel
from hydra.nlunit.mh_utils.db_utils import update_model_status, init_model_status
from common import get_model_pair, get_service_name, init_env_func, get_db_env, get_task
from hydra.nlunit.common_utils.minio_client import MinioClient


class SelectFunc:
    def __init__(self, des):
        self.des = des

    def __call__(self, data):
        return self.des == f"{data['model'].lower()}_grp"


def preprocess_msg(data: Union[str, dict], msg_id, skip_update) -> dict:
    if isinstance(data, str):
        parsed_data = json.loads(data)
    else:
        parsed_data = data
    if 'extra' in parsed_data:
        extra_info = json.loads(parsed_data.pop('extra'))
        parsed_data.update(extra_info)
    if not skip_update:
        parsed_data["mh_id"] = base64.b64decode(msg_id).decode('ascii')
        parsed_data["id"] = msg_id
        db_env = get_db_env(parsed_data)
        if db_env is None:
            return {"model": "skip"}
        # update model status to wait
        status_key = get_task(parsed_data["model"].lower())
        init_model_status(parsed_data["mh_id"], get_service_name("train_" + status_key), status_key, ModelStatus.WAIT,
                          **db_env)
        print(f"rabbitmq: update task [{parsed_data['mh_id']}] to: {ModelStatus.WAIT}")
    return parsed_data


def control_parser_func(data):
    parsed_data = json.loads(data)
    mh_id = base64.b64decode(parsed_data["id"]).decode('ascii')
    db_env = get_db_env(parsed_data)
    if db_env is None:
        return parsed_data, parsed_data["id"], None
    table_key = get_task(parsed_data["model"].lower())
    return parsed_data, parsed_data["id"], partial(update_model_status, mh_id=mh_id, table_key=table_key,
                                                   status_val=ModelStatus.CANCEL, **db_env)


def get_model_config(task: str, model: str, local_config: bool, shared=None) -> MHTrainConfig:
    root_workspace = os.getenv("MH_WORKSPACE", "mh_workspace")
    root_dataset = os.getenv("MH_DATASET", "mh_dataset")
    root_log_workspace = os.getenv("MH_LOG", "/mh_log_workspace")
    curr_path = pathlib.Path(__file__).parent.resolve()
    config_path = curr_path if local_config else os.path.join(os.getenv("MH_CONFIG"), get_service_name())
    template_config = os.path.join(config_path, f"{task}_{model}_template.yml")
    fail_output_dir = os.getenv("FAIL_OUTPUT", "fail")
    return MHTrainConfig(template_config_path=template_config, root_workspace=root_workspace, root_dataset=root_dataset,
                         task=task, root_log_workspace=root_log_workspace, fail_output_dir=fail_output_dir, shared=shared)


def get_mq_config(sp_name: Optional[str]) -> MQConfig:
    host = os.getenv("MQ_HOST", "localhost")
    port = int(os.getenv("MQ_PORT", 5672))
    key = "generic" if sp_name is None else sp_name
    return MQConfig(host=host, port=port, exchange="mh-train", routing_key=f"mh.train.{key}", queue=f"mh.tq.{key}",
                    delete_queue=sp_name is not None)


def get_yml_local():
    root_config = os.getenv("MH_CONFIG_BUCKET")
    if root_config is not None:
        bucket = os.getenv("MH_CONFIG_BUCKET")
        target_path = os.getenv("MH_CONFIG")
        client = MinioClient(target_path, cache=NoStorageCache())
        client.download_all(bucket, get_service_name())
        return False
    
    return True
       

def run_mh_train_service(sp_name: Optional[str], test: bool):
    from hydra.nlunit.mh_unit import MHTrainUnit, MHTrainConfig

    resource_manager = ResourceManager()
    manager = resource_manager.get_root_manager()

    mq_config = get_mq_config(sp_name)
    rabbitmq_stream = RabbitMQStream.create(mq_config, partial(preprocess_msg, skip_update=test),
                                            control_parser_func, init_env_func)
    manager.set_input(rabbitmq_stream)

    global_shared = StorageShared(f"train_{uuid.uuid1()}_shared", 16) if not test else None

    local_config = get_yml_local()

    for task, model in get_model_pair():
        mh_subject = manager.create_subject("MHTrainUnit", model)
        mh_subject.create(get_model_config(task, model, local_config, global_shared), not test)
        group_name = f"{model}_grp"

        @manager.from_root_selected(SelectFunc(group_name))
        @manager.group(group_name, model, sync_name="mh_train", enable_ctl=True)
        class MHGroup:
            pass

    manager.start()
    text = input("input your command>> ")
    manager.stop()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--sp", type=str, default=None, help="specific service name")
    parser.add_argument("--test", action="store_true", help="test_mode")
    args = parser.parse_args()
    run_mh_train_service(args.sp, args.test)
