import json
import os
import argparse
from typing import Optional, Union

from hydra.core.resource import ResourceManager
from hydra.core.stream import RabbitMQStream, MQConfig
from hydra.nlunit.mh_utils.utils import InferenceType
from common import get_xpu_model_pair, init_env_func, gen_inference_config, TTS_EX_TYPE, get_sync_name
from mh_train_service import preprocess_msg as train_preprocess_msg, control_parser_func, get_yml_local, \
    get_model_config
from mh_inference_service import preprocess_msg as inference_preprocess_msg, voice_generate, ls_generate, \
    PicInPicInferenceSelectFunc, PicInPicInferenceItemSelectFunc, InferenceSelectFunc


class TaskPrefix:
    TRAIN = "train-"
    INFERENCE = "infer-"


class XpuSelectFunc:
    def __init__(self, task, model: Union[str, list], model_key, sp_type=None):
        self._task = task
        self._model = model
        self._model_key = model_key
        self._type = sp_type

    def __call__(self, data: dict) -> bool:
        if data["xpu-task"] == self._task and not data.get("pic_in_pic", False) and self._model_key in data and self._check_type(data):
            if isinstance(self._model, str):
                return data[self._model_key].lower() == self._model
            return data[self._model_key].lower() in self._model
        return False

    def _check_type(self, data) -> bool:
        if self._type is not None:
            return data["type"] == self._type
        return True


def get_mq_config(sp_name: Optional[str]) -> MQConfig:
    host = os.getenv("MQ_HOST", "localhost")
    port = int(os.getenv("MQ_PORT", 5672))
    key = "generic" if sp_name is None else sp_name
    return MQConfig(host=host, port=port, exchange="mh-xpu", routing_key=f"mh.xpu.{key}", queue=f"mh.xpu.tq.{key}",
                    delete_queue=sp_name is not None)


def preprocess_msg(data: str, msg_id) -> dict:
    parsed_data = json.loads(data)
    if msg_id.startswith(TaskPrefix.TRAIN):
        real_id = msg_id[len(TaskPrefix.TRAIN):]
        return {"xpu-task": "train", **train_preprocess_msg(parsed_data, real_id, False)}
    elif msg_id.startswith(TaskPrefix.INFERENCE):
        real_id = msg_id[len(TaskPrefix.INFERENCE):]
        return {"xpu-task": "infer", **inference_preprocess_msg(parsed_data, real_id, False)}
    return {"model": "skip"}


def run_mh_xpu_service(sp_name: Optional[str], tts_env: Optional[str]):
    from hydra.nlunit.mh_unit import MHTrainUnit, MHTrainConfig, MHModel
    from hydra.nlunit.mh_unit import MHFaceUnit, CustomizedVoiceUnit
    from hydra.nlunit.mh_pip_unit import MHInferPicInPicUnit
    from hydra.nlunit.mh_pip_item_unit import MHInferPicInPicItemUnit

    resource_manager = ResourceManager()
    manager = resource_manager.get_root_manager()

    mq_config = get_mq_config(sp_name)
    rabbitmq_stream = RabbitMQStream.create(mq_config, preprocess_msg, control_parser_func, init_env_func)
    manager.set_input(rabbitmq_stream)

    local_config = get_yml_local()
    sync_name = get_sync_name("mh_xpu_sync")

    # er-nerf training
    for task, model in get_xpu_model_pair():
        subject_name = f"train_{model}"
        mh_subject = manager.create_subject("MHTrainUnit", subject_name)
        mh_subject.create(get_model_config(task, model, local_config), True)
        group_name = f"train_{model}_grp"

        @manager.from_root_selected(XpuSelectFunc("train", model, "model"))
        @manager.group(group_name, subject_name, enable_ctl=True)
        class MHGroup:
            pass

    # inference
    inference_config = gen_inference_config()
    face_grps = {m: f"face_{m}_grp" for t, m in get_xpu_model_pair()}
    for model, group_name in face_grps.items():
        subject_name = f"infer_{model}"
        face_subject = manager.create_subject("MHFaceUnit", subject_name)
        face_subject.create(inference_config, "xpu:1", True)

        @manager.from_root_selected(XpuSelectFunc("infer", model, "face_model_type", InferenceType.FACE_ONLY))
        @manager.group(group_name, subject_name, sync_name=sync_name)
        class FaceGroup:
            pass

    customized_voice_subject = manager.create_subject("CustomizedVoiceUnit", "customized_voice")
    customized_voice_subject.create(voice_generate(tts_env), inference_config, True)

    @manager.selected_link([(g, InferenceSelectFunc("face", g)) for g in face_grps.values()])
    @manager.from_root_selected(XpuSelectFunc("infer", [tts.lower() for tts in TTS_EX_TYPE], "tts_model_type"))
    @manager.group("customized_voice_grp", "customized_voice", count=len(TTS_EX_TYPE))
    class CustomizedVoiceGroup:
        pass

    pic_in_pic_subject = manager.create_subject("MHInferPicInPicUnit", "PicInPic")
    pic_in_pic_subject.create(inference_config, "xpu:1",
                              voice_generate(tts_env), ls_generate(),
                              os.path.dirname(os.path.abspath(__file__)), True)

    pic_in_pic_item_subject = manager.create_subject("MHInferPicInPicItemUnit", "PicInPicItem")
    pic_in_pic_item_subject.create(inference_config, "xpu:1",
                                   voice_generate(tts_env), ls_generate(),
                                   os.path.dirname(os.path.abspath(__file__)), True)

    @manager.from_root_selected(PicInPicInferenceSelectFunc())
    @manager.group("pic_in_pic_grp", "PicInPic", sync_name=sync_name)
    class PicInPicBaseGroup:
        pass

    @manager.from_root_selected(PicInPicInferenceItemSelectFunc())
    @manager.group("pic_in_pic_item_grp", "PicInPicItem", sync_name=sync_name)
    class PicInPicItemGroup:
        pass

    manager.start()
    text = input("input your command>> ")
    manager.stop()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--sp", type=str, default=None, help="specific service name")
    parser.add_argument("--tts", type=str, default=None, help="custom tts service env")
    args = parser.parse_args()
    run_mh_xpu_service(args.sp, args.tts)
