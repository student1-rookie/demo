import argparse
import os
import uuid
import base64
from pathlib import Path
from functools import partial
from typing import Optional

from hydra.nlunit.mh_pip_unit import MHInferPicInPicUnit
from hydra.nlunit.mh_unit import MHTTSUnit, MHFaceUnit, MHStatus
from hydra.nlunit.common_utils.minio_client import upload_log_func
from hydra.nlunit.mh_utils.mh_pip import PictureInPictureTask, PictureInPicture
from hydra.nlunit.mh_utils.utils import ModelStatus, InferenceType, switch_env
from hydra.nlunit.mh_utils.db_utils import update_model_status
from hydra.nlunit.mh_utils.mh_workspace import MHWorkspace
from hydra.core.resource import ResourceManager, model
from hydra.core.stream import RabbitMQStream

from mh_inference_service import preprocess_msg, InferenceSelectFunc, PicInPicInferenceSelectFunc, get_mq_config
from mh_run.common import gen_inference_config
from common import get_models, init_env_func

FAIL_TEST = False


def print_x(msg, redis, redis_key):
    if redis and redis_key:
        redis.publish(msg, msg_id=redis_key)


@model("MHInferPicInPicDummyUnit")
class MHInferPicInPicDummyUnit(MHInferPicInPicUnit):
    def __init__(self, infer_config, device, video: str):
        super().__init__(infer_config, device, None, None, None, True)
        self._video = video
        self._pip = PictureInPicture()

    def load(self):
        pass

    def pre_process(self, data) -> dict:
        id = data.get("id")
        status = data.get("status")
        print(f" task [{id}] starts to preprocess")
        print_x(f"[Picture In Picture] \
        tts id: {base64.b64decode(data['tts_model']).decode('ascii')} \
        face id: {base64.b64decode(data['face_model']).decode('ascii')}", self._redis, data.get("id"))

        if id and status == ModelStatus.WAIT:
            update_model_status(data["id"], "infer", ModelStatus.RUN)

        tasks = []

        for index, one_input in enumerate(data.get("input")):
            if one_input.get("text", None) is None:
                tasks.append({
                    "main": os.path.join(self._root_workspace, one_input["media"]) if one_input["media"] else None,
                    "overlay": None,
                    "types": [one_input['type']]
                })
                continue

            wav_file = f"{data['name']}_{index}.wav" if data.get("name") else f"{uuid.uuid1()}_{index}.wav"
            wav_folder = f"{self._infer_bucket}/{data['id']}" if id else data["tts_model"]
            face_file = f"{data['name']}_{index}.mp4" if data.get("name") else f"{uuid.uuid1()}_{index}.mp4"
            face_folder = f"{self._infer_bucket}/{data['id']}" if id else data["face_model"]

            wav_new_model_config_path = os.path.join(self._root_workspace, wav_folder, f"tts_infer_{index}.yml")
            face_new_model_config_path = os.path.join(self._root_workspace, face_folder, f"face_infer_{index}.yml")

            if one_input.get("media") and one_input.get("type") and "is_meta_human_background" in one_input:
                if one_input['is_meta_human_background']:
                    main_path = os.path.join(self._root_workspace, face_folder, face_file)
                    overlay_path = os.path.join(self._root_workspace, one_input["media"])
                    types = ["VIDEO", one_input['type']]
                else:
                    main_path = os.path.join(self._root_workspace, one_input["media"])
                    overlay_path = os.path.join(self._root_workspace, face_folder, face_file)
                    types = [one_input['type'], "VIDEO"]
            else:
                main_path = os.path.join(self._root_workspace, face_folder, face_file)
                overlay_path = None
                types = ["VIDEO"]

            tasks.append({
                "input": one_input["text"].replace('"', '\\"'),
                "main": main_path,
                "overlay": overlay_path,
                "types": types,
                # "media": os.path.join(self._root_workspace, one_input["media"]) if one_input["media"] else None,
                "coordinate": one_input["coordinate"],
                "box": one_input["box"],
                "tts_config": wav_new_model_config_path,
                "wav_output": os.path.join(self._root_workspace, wav_folder, wav_file),
                "face_config": face_new_model_config_path,
                "video_output": self._video,
            })

        if not os.path.exists(self._video) or not all(
                os.path.exists(path["media"]) if path["media"] else True for path in tasks):
            return {
                "id": id,
                "status": MHStatus.FAILED,
                "out": "fail at MHInferPicInPicDummyUnit"
            }

        file_name = f"{data['name']}.mp4" if data.get("name") else f"{uuid.uuid1()}.mp4"
        output = os.path.join(os.path.dirname(self._video), file_name)

        return {
            "status": MHStatus.SUCCESS,
            "id": id,
            "name": data.get("name", None),
            "tasks": tasks,
            "subtitle": data.get("subtitle", False),
            "embedding": False,
            "output": output,
            "background": data.get("background", None),
        }

    def predict(self, data):
        id = data.get("id")

        for index, task in enumerate(data["tasks"]):
            if task.get("input", None):
                print(f"[Picture in Picture]: TTS task_{index} [{id}] succeed")
                print(f"[Picture in Picture]: FACE task_{index} [{id}] succeed")
            else:
                print(f"[Picture in Picture]: A overlay video task_{index} [{id}] Skip...")

        infer_list = [
            PictureInPictureTask(
                main=item.get("main", None),
                overlay=item.get("overlay", None),
                coordinate=item.get("coordinate", None),
                box=item.get("box", None),
                types=item.get('types', None),
                srt=item.get("srt", None),
            )
            for item in data["tasks"]
        ]

        result, info = self._pip.pic_in_pic(infer_list, data["output"])
        print_x(info, self._redis, id)
        if not result:
            update_model_status(id, "infer", ModelStatus.FAIL, redis=self._redis)
            return {
                "status": MHStatus.FAILED,
            }

        update_model_status(id, "infer", ModelStatus.COMPLETE, redis=self._redis)
        return {
            "status": MHStatus.SUCCESS,
            "output": data["output"]
        }


@model("MHTTSDummyUnit")
class MHTTSDummyUnit(MHTTSUnit):

    def __init__(self, config, device, wav_file):
        super().__init__(config, device, True)
        self._ret_wav_file = wav_file

    def pre_process(self, data) -> dict:
        switch_env(data, self._redis, self._db_args)
        print_x(f"TTS recv: {data}", self._redis, data.get("id"))
        if data.get("id") and data.get("status") == ModelStatus.WAIT:
            update_model_status(data["id"], "infer", ModelStatus.RUN, **self._db_args)
        wav_file = f"{data['name']}.wav" if data.get("name") else f"{uuid.uuid1()}.wav"
        wav_folder = f"{self._config.infer_bucket}/{data['id']}" if data.get("id") else data["tts_model"]
        tts_model = self._get_tts_model(data)
        print_x(f"TTS model: {tts_model}", self._redis, data.get("id"))
        return {
            "output": {
                "face_model": data.get("face_model", None),
                "face_model_type": data.get("face_model_type", None),
                # fake wav
                "wav": os.path.join(self._config.root_workspace, wav_folder, wav_file),
                "id": data.get("id", None),
                "name": data.get("name", None),
                "subtitle": data.get("subtitle", False),
                "cluster": data.get("cluster", False),
                "userBucket": data.get("userBucket", None),
                "workSpace": data.get("workSpace", None),
            },
            "cluster": MHWorkspace.initialize(**data)
        }

    def _get_tts_model(self, data):
        if data.get("cluster", False):
            parts = data["tts_model"].split("/", 1)
            zip_file = self._storage_client.download(parts[0], parts[1])
            return os.path.dirname(zip_file)
        return os.path.join(self._config.root_workspace, data["tts_model"])

    def predict(self, data):
        tts_infer_out_msg = f"TTS infer out: {data['output']['wav']}"
        print_x(tts_infer_out_msg, self._redis, data["output"].get("id"))

        if not FAIL_TEST:
            return_value = {
                "status": MHStatus.SUCCESS,
                **data["output"]
            }
        else:
            if data["output"].get("id"):
                update_model_status(data["output"]["id"], "infer", ModelStatus.FAIL, redis=self._redis, **self._db_args)
            return_value = {
                "status": MHStatus.FAILED,
                "out": "fail at MHTTSDummyUnit"
            }
        if data['output'].get("face_model") is None and data['output'].get("id"):
            file_name = f"{data['output']['name']}.wav"
            if data["cluster"]:
                self._storage_client.upload(data["cluster"].bucket,
                                            data["cluster"].gen_infer_object(data["output"]["id"], file_name),
                                            self._ret_wav_file)
            else:
                out_audio_path = os.path.join(self._config.root_workspace, self._config.infer_bucket,
                                              data['output']["id"])
                dest_path = Path(out_audio_path)
                dest_path.mkdir(parents=True, exist_ok=True)
                src_path = Path(self._ret_wav_file)
                file_path = dest_path / file_name
                file_path.symlink_to(src_path)
            update_model_status(data["output"]["id"], "infer", ModelStatus.COMPLETE, redis=self._redis,
                                upload_func=upload_log_func(data["output"]["id"], self._storage_client,
                                                            data["cluster"]), **self._db_args)
            return {}
        print_x(str(return_value), self._redis, data["output"].get("id"))
        return return_value


@model("MHFaceDummyUnit")
class MHFaceDummyUnit(MHFaceUnit):

    def __init__(self, config, device, video_file):
        super().__init__(config, device, True)
        self._ret_video_file = video_file

    def pre_process(self, data) -> dict:
        switch_env(data, self._redis, self._db_args, self._storage_client)
        if "status" not in data and data.get("id"):
            update_model_status(data["id"], "infer", ModelStatus.RUN, redis=self._redis, **self._db_args)
        print_x(f"Face recv: {data}", self._redis, data.get("id"))
        face_model = self._get_face_model(data)
        print_x(f"Face model: {face_model}", self._redis, data.get("id"))
        if data.get("type") == InferenceType.FACE_ONLY:
            wav = self._get_wav(data)
            print_x(f"Wav input: {wav}", self._redis, data.get("id"))
        data["cluster"] = MHWorkspace.initialize(**data)
        return data

    def _get_face_model(self, data):
        if data.get("cluster", False):
            parts = data["face_model"].split("/", 1)
            zip_file = self._storage_client.download(parts[0], parts[1])
            return os.path.dirname(zip_file)
        return os.path.join(self._config.root_workspace, data["face_model"])

    def predict(self, data):
        return_value = data
        if data.get("name") is None:
            return_value = {
                "status": MHStatus.SUCCESS,
                "out": self._ret_video_file
            }
        if data.get("id"):
            # cp video_file to target path
            file_name = f"{data['name']}.mp4"
            if data["cluster"]:
                self._storage_client.upload(data["cluster"].bucket,
                                            data["cluster"].gen_infer_object(data["id"], file_name),
                                            self._ret_video_file)
            else:
                out_video_path = os.path.join(self._config.root_workspace, self._config.infer_bucket, data["id"])
                dest_path = Path(out_video_path)
                dest_path.mkdir(parents=True, exist_ok=True)
                src_path = Path(self._ret_video_file)
                file_path = dest_path / file_name
                file_path.symlink_to(src_path)
            update_model_status(data["id"], "infer", ModelStatus.COMPLETE, redis=self._redis,
                                upload_func=upload_log_func(data["id"], self._storage_client, data["cluster"]),
                                **self._db_args)
        print_x(str(return_value), self._redis, data.get("id"))
        return return_value


def run_mh_inference_dummy(video_file, wav_file, sp_name: Optional[str]):
    resource_manager = ResourceManager()
    manager = resource_manager.get_root_manager()

    mq_config = get_mq_config(sp_name)
    rabbitmq_stream = RabbitMQStream.create(mq_config, partial(preprocess_msg, skip_update=False),
                                            init_func=init_env_func)
    manager.set_input(rabbitmq_stream)

    tts_grps = {m: f"tts_{m}_grp" for m in get_models("tts")}
    face_grps = {m: f"face_{m}_grp" for m in get_models("face")}
    inference_config = gen_inference_config()
    for dummy_model, group_name in tts_grps.items():
        tts_subject = manager.create_subject("MHTTSDummyUnit", dummy_model)
        tts_subject.create(inference_config, "cuda:0", os.path.abspath(wav_file))

        @manager.selected_link([(g, InferenceSelectFunc("face", g)) for g in face_grps.values()])
        @manager.from_root_selected(InferenceSelectFunc("tts", group_name))
        @manager.group(group_name, dummy_model, sync_name="mh_infer")
        class TTSGroup:
            pass

    for dummy_model, group_name in face_grps.items():
        face_subject = manager.create_subject("MHFaceDummyUnit", dummy_model)
        face_subject.create(inference_config, "cuda:1", os.path.abspath(video_file))

        @manager.from_root_selected(InferenceSelectFunc("face", group_name, exclude="tts"))
        @manager.group(group_name, dummy_model, sync_name="mh_infer")
        class FaceGroup:
            pass

    pic_in_pic_subject = manager.create_subject("MHInferPicInPicDummyUnit", "PicInPic")
    pic_in_pic_subject.create(inference_config, "cuda:2", os.path.abspath(video_file))

    @manager.from_root_selected(PicInPicInferenceSelectFunc())
    @manager.group("pic_in_pic_grp", "PicInPic", sync_name="mh_infer")
    class PicInPicGroup:
        pass

    manager.start()
    text = input("input your command>> ")
    manager.stop()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("-v", "--video",
                        default=None, type=str, required=True,
                        help="return video file")
    parser.add_argument("-w", "--wav",
                        default=None, type=str, required=True,
                        help="return wav file")
    parser.add_argument("--sp", type=str, default=None, help="specific service name")
    args = parser.parse_args()
    run_mh_inference_dummy(args.video, args.wav, args.sp)
