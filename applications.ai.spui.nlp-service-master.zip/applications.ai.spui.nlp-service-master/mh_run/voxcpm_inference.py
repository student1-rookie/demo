import argparse

from hydra.core.resource import ResourceManager
from hydra.core.stream import RSocketStream
from hydra.nlunit.common_utils.storage_cache import StorageShared, MetaShared
from common import gen_inference_config, SelectFunc, tts_select
from moss_ttsd_inference import get_rsocket_config

VOX_REGISTER_COUNT = 4


def run_voxcpm_inference_service(test: bool, model_path: str, zipenhancer_model_path: str):
    from hydra.nlunit.tts_register_unit import TTSRegisterUnit
    from hydra.nlunit.voxcpm_unit import VoxCPMUnit

    resource_manager = ResourceManager()
    manager = resource_manager.get_root_manager()

    rsocket_config, vox_route, register_route = get_rsocket_config(test, "voxcpm")
    rsocket_stream = RSocketStream.create(rsocket_config)
    manager.set_input(rsocket_stream)

    model_shared = StorageShared(f"voxcpm_model_shared", 16) if not test else None
    inference_config = gen_inference_config(model_shared)
    voxcpm_subject = manager.create_subject("VoxCPMUnit", "VoxCPM")
    voxcpm_subject.create(model_path, zipenhancer_model_path, inference_config, "cuda", log=not test)

    dataset_shared = StorageShared(f"VoxCPM_dataset_shared", 16) if not test else None
    dataset_meta_shared = MetaShared(VOX_REGISTER_COUNT) if not test else None
    register_config = gen_inference_config(dataset_shared, dataset_meta_shared)
    voxcpm_register_subject = manager.create_subject("TTSRegisterUnit", "VoxCPMRegister")
    voxcpm_register_subject.create(register_config, log=not test)

    @manager.link("Root")
    @manager.from_root_selected(SelectFunc(vox_route))
    @manager.group("VoxCPM_grp", "VoxCPM")
    class VoxCPMGroup:
        pass

    @manager.selected_link([("VoxCPM_grp", tts_select)])
    @manager.from_root_selected(SelectFunc(register_route))
    @manager.group("VoxCPMRegister-grp", "VoxCPMRegister", count=VOX_REGISTER_COUNT)
    class VoxCPMRegisterGroup:
        pass

    manager.start()
    text = input("input your command>> ")
    manager.stop()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--test", action="store_true")
    parser.add_argument("-m", "--model_path", type=str, required=True, help="Path to the model")
    parser.add_argument("-z", "--zipenhancer_path", type=str, required=False,
                        default="iic/speech_zipenhancer_ans_multiloss_16k_base", help="Path to the zipenhancer model")
    args = parser.parse_args()
    run_voxcpm_inference_service(args.test, args.model_path, args.zipenhancer_path)
