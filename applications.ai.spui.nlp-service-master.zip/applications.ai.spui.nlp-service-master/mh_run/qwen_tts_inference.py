import argparse
import time

from hydra.core.resource import ResourceManager
from hydra.core.stream import RSocketStream
from hydra.nlunit.common_utils.storage_cache import StorageShared, MetaShared
from common import gen_inference_config, SelectFunc, tts_select
from moss_ttsd_inference import get_rsocket_config

QWEN_REGISTER_COUNT = 4


def run_qwen_tts_inference_service(test: bool, model_path: str):
    from hydra.nlunit.tts_register_unit import TTSRegisterUnit
    from hydra.nlunit.qwen_tts_unit import QwenTTSUnit

    resource_manager = ResourceManager()
    manager = resource_manager.get_root_manager()

    rsocket_config, qwen_route, register_route = get_rsocket_config(test, "qwen")
    rsocket_stream = RSocketStream.create(rsocket_config)
    manager.set_input(rsocket_stream)

    model_shared = StorageShared("qwen_model_shared", 16) if not test else None
    inference_config = gen_inference_config(model_shared)
    qwen_subject = manager.create_subject("QwenTTSUnit", "QwenTTS")
    qwen_subject.create(model_path, inference_config, "cuda", log=not test)

    dataset_shared = StorageShared("QwenTTS_dataset_shared", 16) if not test else None
    dataset_meta_shared = MetaShared(QWEN_REGISTER_COUNT) if not test else None
    register_config = gen_inference_config(dataset_shared, dataset_meta_shared)
    qwen_register_subject = manager.create_subject("TTSRegisterUnit", "QwenRegister")
    qwen_register_subject.create(register_config, log=not test)

    @manager.link("Root")
    @manager.from_root_selected(SelectFunc(qwen_route))
    @manager.group("QwenTTS_grp", "QwenTTS")
    class QwenTTSGroup:
        pass

    @manager.selected_link([("QwenTTS_grp", tts_select)])
    @manager.from_root_selected(SelectFunc(register_route))
    @manager.group("QwenRegister-grp", "QwenRegister", count=QWEN_REGISTER_COUNT)
    class QwenTTSRegisterGroup:
        pass

    manager.start()
    text = input("input your command>> ")
    manager.stop()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--test", action="store_true")
    parser.add_argument("-m", "--model_path", type=str, required=True, help="Path or ID of Qwen3-TTS model")
    args = parser.parse_args()
    run_qwen_tts_inference_service(args.test, args.model_path)
