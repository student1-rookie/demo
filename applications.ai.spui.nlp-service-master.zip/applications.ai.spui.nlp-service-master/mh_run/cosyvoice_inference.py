import uuid
import os
import json
import argparse
import base64
from functools import partial

from hydra.core.resource import ResourceManager
from hydra.core.stream import RSocketConfig, RSocketStream, RouteConfig
from hydra.nlunit.common_utils.storage_cache import StorageShared, MetaShared
from hydra.nlunit.mh_utils.utils import ModelStatus
from hydra.nlunit.mh_utils.db_utils import init_model_status
from common import gen_inference_config, get_service_name, init_env_func, get_db_env, SelectFunc, tts_select, \
    get_sync_name

CV_REGISTER_COUNT = 4


def preprocess_msg(data, composite_metadata, route, skip_update):
    ret = json.loads(data.decode('utf-8'))
    if ret.get("extra"):
        extra_info = json.loads(ret.pop('extra'))
        ret.update(extra_info)
    if not skip_update:
        # TODO: config table_key
        ret["id"] = base64.b64decode(ret["id"]).decode('ascii')
        db_env = get_db_env(ret)
        if db_env is None:
            return {"route": "skip"}
        init_model_status(ret["id"], get_service_name(), "infer", ModelStatus.WAIT, **db_env)
        ret["status"] = ModelStatus.WAIT
        print(f"rsocket: task [{ret['id']}] updated to: {ModelStatus.WAIT}")
    ret["route"] = route
    # split into multiple tasks
    if isinstance(ret.get("text"), list):
        diff_keys = [k for k in ["text", "output_path", "srt"] if isinstance(ret.get(k, None), list) and len(ret[k])]
        const_keys = [i for i in ret if i not in diff_keys]
        diff_list = [ret[k] for k in diff_keys]
        return [{**{c: ret[c] for c in const_keys}, **{k: v for k, v in zip(diff_keys, values)}}
                for values in zip(*diff_list)]
    return ret


def register_preprocess_msg(data, composite_metadata, route, skip_update, model):
    ret = json.loads(data.decode('utf-8'))
    ret["route"] = route
    ret["tmp_dir"] = os.path.join("/tmp", f"{model}_{uuid.uuid1()}")
    if not skip_update:
        ret["mh_id"] = base64.b64decode(ret["id"]).decode('ascii')
        db_env = get_db_env(ret)
        if db_env is None:
            return {"route": "skip"}
        init_model_status(ret["mh_id"], get_service_name(), "tts", ModelStatus.WAIT, **db_env)
        ret["status"] = ModelStatus.WAIT
        print(f"rsocket: register task [{ret['id']}] updated to: {ModelStatus.WAIT}")
    return ret


def get_rsocket_config(test: bool):
    host = os.getenv("RSOCKET_HOST", "localhost")
    port = os.getenv("RSOCKET_PORT", 7000)
    route = os.getenv("RSOCKET_ROUTE", "mh-infer")
    register_route = os.getenv("RSOCKET_REGISTER_ROUTE", "create")
    preprocess_msg_ = partial(preprocess_msg, route=route, skip_update=test)
    register_preprocess_msg_ = partial(register_preprocess_msg, route=register_route, skip_update=test, model="cv")
    return RSocketConfig(host, port, routes=[RouteConfig(route, preprocess_msg_),
                                             RouteConfig(register_route, register_preprocess_msg_, block=False)],
                         nonblock_preprocess_func=preprocess_msg_, init_func=init_env_func), route, register_route


def run_mh_inference_service(test: bool, use_xpu: bool, model_path: str):
    from hydra.nlunit.tts_register_unit import TTSRegisterUnit
    from hydra.nlunit.cosyvoice_unit import CosyVoiceUnit

    resource_manager = ResourceManager()
    manager = resource_manager.get_root_manager()

    rsocket_config, cv_route, register_route = get_rsocket_config(test)
    rsocket_stream = RSocketStream.create(rsocket_config)
    manager.set_input(rsocket_stream)

    devices = [{"device": "xpu"}] if use_xpu else [{"device": "cpu"}, {"device": "cuda"}]
    model_shared = StorageShared(f"cv_model_shared", 16) if not test and not use_xpu else None
    model_meta_shared = MetaShared(len(devices)) if not test and not use_xpu else None
    inference_config = gen_inference_config(model_shared, model_meta_shared)
    cosy_voice_subject = manager.create_subject("CosyVoiceUnit", "CosyVoice")
    cosy_voice_subject.create(model_path, inference_config, log=not test,
                              sp_param=devices)

    dataset_shared = StorageShared(f"cv_dataset_shared", 16) if not test else None
    dataset_meta_shared = MetaShared(CV_REGISTER_COUNT) if not test else None
    register_config = gen_inference_config(dataset_shared, dataset_meta_shared)
    cosy_voice_register_subject = manager.create_subject("TTSRegisterUnit", "CosyVoiceRegister")
    cosy_voice_register_subject.create(register_config, log=not test)
    sync_name = get_sync_name()
    sync_config = {} if sync_name is None else {"sync_name": sync_name, "sync_anonymous": False}

    @manager.link("Root")
    @manager.from_root_selected(SelectFunc(cv_route))
    @manager.group("CosyVoice_grp", "CosyVoice", count=len(devices), shared_queue=True, **sync_config)
    class CosyVoiceGroup:
        pass

    @manager.selected_link([("CosyVoice_grp", tts_select)])
    @manager.from_root_selected(SelectFunc(register_route))
    @manager.group("CosyVoiceRegister-grp", "CosyVoiceRegister", count=CV_REGISTER_COUNT)
    class CosyVoiceRegisterGroup:
        pass

    manager.start()
    text = input("input your command>> ")
    manager.stop()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--test", action="store_true")
    parser.add_argument("-m", "--model_path", type=str, required=True, help="Path to the model")
    parser.add_argument("--xpu", action="store_true")
    args = parser.parse_args()
    run_mh_inference_service(args.test, args.xpu, args.model_path)
