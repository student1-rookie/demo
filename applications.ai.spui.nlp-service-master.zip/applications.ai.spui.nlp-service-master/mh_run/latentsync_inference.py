import os
import json
import argparse
import base64
from functools import partial

from hydra.core.resource import ResourceManager
from hydra.core.stream import RSocketConfig, RSocketStream, RouteConfig
from hydra.nlunit.common_utils.storage_cache import StorageShared, MetaShared
from hydra.nlunit.mh_utils.utils import ModelStatus
from hydra.nlunit.mh_utils.db_utils import init_model_status
from common import gen_inference_config, get_service_name, init_env_func, get_db_env

HDTR_BATCH_SIZE = 8
LS_REGISTER_COUNT = 4


class SelectFunc:
    def __init__(self, route):
        self._route = route

    def __call__(self, data):
        return self._route == data['route']


def preprocess_msg(data, composite_metadata, route, skip_update):
    ret = json.loads(data.decode('utf-8'))
    if 'extra' in ret:
        extra_info = json.loads(ret.pop('extra'))
        ret.update(extra_info)
    if not skip_update:
        # TODO: config table_key
        ret["id"] = base64.b64decode(ret["id"]).decode('ascii')
        db_env = get_db_env(ret)
        if db_env is None:
            return {"route": "skip"}
        init_model_status(ret["id"], get_service_name(), "infer", ModelStatus.WAIT, **db_env)
        ret["status"] = ModelStatus.WAIT
        print(f"rsocket: infer task [{ret['id']}] updated to: {ModelStatus.WAIT}")
    ret["route"] = route
    # split into multiple tasks
    if isinstance(ret.get("audio_path"), list):
        diff_keys = [k for k in ["audio_path", "output_path", "srt"] if
                     isinstance(ret.get(k, None), list) and len(ret[k])]
        const_keys = [i for i in ret if i not in [*diff_keys, "event_channel"]]
        diff_list = [ret[k] for k in diff_keys]
        if ret.get("event_channel", None):
            diff_keys.append("event_channel")
            # There is a potential bug when starting multiple units.
            diff_list.append([None] * (len(diff_list[0]) - 1) + [ret["event_channel"]])
        return [{**{c: ret[c] for c in const_keys}, **{k: v for k, v in zip(diff_keys, values)}}
                for values in zip(*diff_list)]
    return ret


def register_preprocess_msg(data, composite_metadata, route, skip_update):
    ret = json.loads(data.decode('utf-8'))
    ret["route"] = route
    if not skip_update:
        ret["mh_id"] = base64.b64decode(ret["id"]).decode('ascii')
        db_env = get_db_env(ret)
        if db_env is None:
            return {"route": "skip"}
        init_model_status(ret["mh_id"], get_service_name(), "face", ModelStatus.WAIT, **db_env)
        ret["status"] = ModelStatus.WAIT
        print(f"rsocket: register task [{ret['id']}] updated to: {ModelStatus.WAIT}")
    return ret


def get_rsocket_config(test: bool) -> tuple[RSocketConfig, str, str]:
    host = os.getenv("RSOCKET_HOST", "0.0.0.0")
    port = os.getenv("RSOCKET_PORT", 7001)
    route = os.getenv("RSOCKET_ROUTE", "mh-infer")
    register_route = os.getenv("RSOCKET_REGISTER_ROUTE", "create")
    preprocess_msg_ = partial(preprocess_msg, route=route, skip_update=test)
    register_preprocess_msg_ = partial(register_preprocess_msg, route=register_route, skip_update=test)
    return RSocketConfig(host, port, routes=[RouteConfig(route, preprocess_msg_),
                                             RouteConfig(register_route, register_preprocess_msg_, block=False)],
                         nonblock_preprocess_func=preprocess_msg_, init_func=init_env_func), route, register_route


def generate_ls_config(ls_model_path, hdtr_model_path):
    from hydra.nlunit.latentsync_unit import LatentSyncConfig

    return LatentSyncConfig(ls_model_path, "float16", "cuda", hdtr_model_path, HDTR_BATCH_SIZE, "cuda")


def run_mh_inference_service(ls_model_path: str, hdtr_model_path: str, test: bool):
    from hydra.nlunit.latentsync_unit import LatentSyncUnit, LatentSyncRegisterUnit

    resource_manager = ResourceManager()
    manager = resource_manager.get_root_manager()

    rsocket_config, ls_route, register_route = get_rsocket_config(test)
    rsocket_stream = RSocketStream.create(rsocket_config)
    manager.set_input(rsocket_stream)

    dataset_shared = StorageShared(f"ls_dataset_shared", 16) if not test else None
    meta_shared = MetaShared(LS_REGISTER_COUNT + 1) if not test else None
    inference_config = gen_inference_config(dataset_shared, meta_shared)
    latentSync_subject = manager.create_subject("LatentSyncUnit", "LatentSync")
    latentSync_subject.create(generate_ls_config(ls_model_path, hdtr_model_path), inference_config, not test)

    latentSync_register_subject = manager.create_subject("LatentSyncRegisterUnit", "LatentSyncRegister")
    latentSync_register_subject.create(inference_config, not test)

    @manager.link("Root")
    @manager.from_root_selected(SelectFunc(ls_route))
    @manager.group("LatentSync_grp", "LatentSync")
    class LatentSyncGroup:
        pass

    @manager.from_root_selected(SelectFunc(register_route))
    @manager.group("LatentSyncRegister_grp", "LatentSyncRegister", count=LS_REGISTER_COUNT)
    class LatentSyncRegisterGroup:
        pass

    manager.start()
    text = input("input your command>> ")
    manager.stop()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--test", action="store_true")
    parser.add_argument("-l", "--ls_model_path", type=str, required=True, help="Path to the latentsync model")
    parser.add_argument("-t", "--hdtr_model_path", type=str, required=True, help="Path to the hdtr model")
    args = parser.parse_args()
    run_mh_inference_service(args.ls_model_path, args.hdtr_model_path, args.test)
