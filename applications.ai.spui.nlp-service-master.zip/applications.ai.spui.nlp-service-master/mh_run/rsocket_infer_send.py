import asyncio
import argparse
import logging

from hydra.nlunit.mh_utils.rsocket_request import send_request, RSocketClientConfig

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)

    parser = argparse.ArgumentParser()
    parser.add_argument("--host", type=str, default="localhost", help="RSocket server host")
    parser.add_argument("--port", type=int, default=7000, help="RSocket server port")
    parser.add_argument("--route", type=str, default="mh-infer", help="route")
    parser.add_argument("--message", type=str, required=True, help="msg file")
    parser.add_argument("--nonblocking", action="store_true", help="non-blocking")

    args = parser.parse_args()

    print("send request")
    config = RSocketClientConfig(args.host, args.port, args.route)
    with open(args.message, "r") as f:
        ret = asyncio.run(send_request(config, f.read(), non_blocking=args.nonblocking))
        if args.nonblocking:
            print("send complete")
        else:
            print(ret)
