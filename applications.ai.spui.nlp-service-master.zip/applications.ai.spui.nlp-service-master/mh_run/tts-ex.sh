#!/bin/bash

SH_DIR=$(cd "$(dirname "$0")"; pwd)
PRJ_DIR=$(dirname $SH_DIR)

usage() { echo "Usage: $(basename $0) [-m <moss/vibevoice/voxcpm> -p <model_path> -t <tokenizer for moss>]" 1>&2; exit 1; }

while getopts 'm:p:t:' opt; do
  case "$opt" in
    m)
      model=$OPTARG
      ;;

    p)
      path=$OPTARG
      ;;
    t)
      tokenizer=$OPTARG
      ;;
    *)
      usage
      ;;
  esac
done
shift "$(($OPTIND -1))"

if [ -z "${model}" ] && [ -z "${path}" ]; then
    usage
fi

models=("moss" "vibevoice" "voxcpm")

if [[ " ${models[@]} " =~ " ${model} " ]]; then
  if [ ${model} == "moss" ]; then
    export PYTHONPATH=${PYTHONPATH}:${PRJ_DIR}:${PRJ_DIR}/third_party/MOSS-TTSD
    if [ -z "${tokenizer}" ]; then
      echo "Must to set tokenizer (-t) for moss!"
    fi
    python3 moss_ttsd_inference.py -m ${path} -t ${tokenizer}
    exit
  fi
  if [ ${model} == "vibevoice" ]; then
    export PYTHONPATH=${PYTHONPATH}:${PRJ_DIR}:${PRJ_DIR}/third_party/vibevoice
    if [ -z "${tokenizer}" ]; then
      # used for downloading qwen tokenizer files
      export HF_ENDPOINT=https://hf-mirror.com
      tokenizer=Qwen/Qwen2.5-1.5B
    fi
    python3 vibevoice_inference.py -m ${path} -t ${tokenizer}
    exit
  fi
  if [ ${model} == "voxcpm" ]; then
    export PYTHONPATH=${PYTHONPATH}:${PRJ_DIR}:${PRJ_DIR}/third_party/VoxCPM/src
    if [ -z "${tokenizer}" ]; then
      # download denoiser model
      tokenizer=iic/speech_zipenhancer_ans_multiloss_16k_base
    fi
    python3 voxcpm_inference.py -m ${path} -z ${tokenizer}
    exit
  fi
else
  echo "'$model' is invalid."
fi