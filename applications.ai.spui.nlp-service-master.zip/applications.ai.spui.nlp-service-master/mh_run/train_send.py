import json
import asyncio
import argparse
import random
import string
import sys
from aio_pika import connect, Message, ExchangeType

async def send_message(name, dataset, task, model):
    # Establish connection
    connection = await connect('amqp://guest:guest@localhost/')
    channel = await connection.channel()

    # Declare the exchange
    exchange = await channel.declare_exchange('mh-train', ExchangeType.TOPIC, durable=True)

    # Create the message payload
    json_msg = {
        "name": name,
        "dataset": dataset,
        "task": task,
        "model": model
    }

    # Convert payload to JSON
    message_body = json.dumps(json_msg)

    # Create the message ID
    characters = string.ascii_letters + string.digits
    message_id = ''.join(random.choice(characters) for _ in range(10))

    # Creat routing_key
    routing_key = "mh.train." + task

    # Create the message
    message = Message(
        body=message_body.encode(),
        message_id=message_id
    )

    # Publish the message
    await exchange.publish(
        message,
        routing_key=routing_key
    )

    # Close the connection
    await connection.close()

if __name__ == '__main__':
    # Parse command-line arguments
    parser = argparse.ArgumentParser()
    parser.add_argument('-d', '--dataset', type=str, required=True, help='Specify the dataset')
    parser.add_argument('-n', '--name', default="test", type=str, help='Specify the test name')
    parser.add_argument('-t', '--task', default=None, type=str,  choices=['tts', 'face'], help='Specify the task')
    parser.add_argument('-m', '--model', default=None, type=str, choices=['BERTVITS', 'GPTSOVITS', 'ERNERF', 'GAUSSIAN'], help='Specify the model')
    args = parser.parse_args()

    # Logic check for valid task and model combinations
    if args.task == 'tts' and args.model not in ['BERTVITS', 'GPTSOVITS']:
        print("Error: For 'tts' task, model must be 'BERTVITS' or 'GPTSOVITS'.")
        sys.exit(1)
    elif args.task == 'face' and args.model not in ['ERNERF', 'GAUSSIAN']:
        print("Error: For 'face' task, model must be 'ERNERF' or 'GAUSSIAN'.")
        sys.exit(1)

    # Run the send_message coroutine with the provided arguments
    asyncio.run(send_message(args.name, args.dataset, args.task, args.model))