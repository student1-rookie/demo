import argparse
import time
import json
import os
import shutil
import uuid
from pathlib import Path
from typing import Optional
from functools import partial

from hydra.core.resource import ResourceManager, model
from hydra.core.stream import RabbitMQStream
from hydra.core.shared import Shared
from hydra.core.typing import CtlEvent
from hydra.nlunit.common_utils.storage_cache import StorageShared
from hydra.nlunit.mh_unit import MHTrainUnit
from hydra.nlunit.mh_utils.db_utils import update_model_status, update_model_detail
from hydra.nlunit.mh_utils.utils import ModelStatus
from hydra.nlunit.common_utils.minio_client import upload_log_func
from mh_run.common import init_env_func

from mh_train_service import get_mq_config, preprocess_msg, get_model_config, SelectFunc, control_parser_func
from common import get_model_pair


DUMMY_DETAIL = [
    {"phase": "PRE-PROCESSING"},
    *[{"phase": "TRAINING", "curr": i, "total": 10, "estimated": 2 * (10 - i), "unit": "s"} for i in range(10)],
    {"phase": "POST-PROCESSING"},
]


@model("MHTrainDummyUnit")
class MHTrainDummyUnit(MHTrainUnit):

    def __init__(self, config, log: bool, preview: str, audio: str):
        super().__init__(config, log)
        self._preview = preview
        self._audio = audio

    def predict(self, data):
        mh_id = data.pop("mh_id", None)
        message_str = f"Update {self._config.task} with id: {mh_id}."
        self._redis.publish(message_str, msg_id=mh_id)
        shared = Shared.get()
        is_cancel = False
        for detail in DUMMY_DETAIL:
            if mh_id:
                update_model_detail(mh_id, self._config.task, json.dumps(detail), **self._db_args)
            message_str = f"Update detail {detail}"
            self._redis.publish(message_str, msg_id=mh_id)
            if shared.get_ctl() == CtlEvent.CANCEL:
                self._redis.publish("Cancel training task", msg_id=mh_id)
                is_cancel = True
                break
            time.sleep(2)
        if not is_cancel:
            # create dummy model folder
            model_ws = data["workspace_path"]
            if not os.path.exists(model_ws):
                print(f"Create model path: {model_ws}")
                os.makedirs(model_ws)
            if mh_id is not None and data["cluster"] is not None:
                with open(os.path.join(model_ws, f"dummy_{self._config.task}_model.txt"), "w") as f:
                    f.write(json.dumps({
                        "mh_id": mh_id,
                        "workspace_path": model_ws,
                        "config": data["config"],
                    }))
                root_dir = os.path.dirname(model_ws)
                base_name = os.path.basename(model_ws)
                zip_file = shutil.make_archive(model_ws, "gztar", root_dir, base_name)
                self._dataset_client.upload(data["cluster"].bucket,
                                            data["cluster"].gen_model_object(mh_id, os.path.basename(zip_file)),
                                            zip_file)
                shutil.rmtree(root_dir)
            if self._config.task == "face" and self._preview:
                if data["cluster"]:
                    self._dataset_client.upload(data["cluster"].bucket,
                                                data["cluster"].gen_model_object(mh_id, "avatar/avatar.jpg"),
                                                self._preview)
                    self._dataset_client.upload(data["cluster"].bucket,
                                                data["cluster"].gen_model_object(mh_id, "avatar/preview.jpg"),
                                                self._preview)
                    self._redis.publish(
                        f"Update avatar: {data['cluster'].bucket}/{data['cluster'].dataset}/{mh_id}/avatar",
                        msg_id=mh_id)
                else:
                    avatar_name = "avatar.jpg"
                    preview_name = "preview.jpg"
                    dest_path = Path(os.path.join(self._config.root_workspace, data["id"], "avatar"))
                    dest_path.mkdir(parents=True, exist_ok=True)
                    src_path = Path(self._preview)
                    avatar_file_path = dest_path / avatar_name
                    avatar_file_path.symlink_to(src_path)
                    preview_file_path = dest_path / preview_name
                    preview_file_path.symlink_to(src_path)
                    self._redis.publish(f"Gen avatar: {dest_path}/{avatar_name}", msg_id=mh_id)
            elif self._config.task == "tts" and self._audio:
                if data["cluster"]:
                    self._dataset_client.upload(data["cluster"].bucket,
                                                data["cluster"].gen_model_object(mh_id, "example/example.wav"),
                                                self._audio)
                    self._redis.publish(
                        f"Update wav: {data['cluster'].bucket}/{data['cluster'].dataset}/{mh_id}/example/example.wav",
                        msg_id=mh_id)
                else:
                    wav_name = "example.wav"
                    dest_path = Path(os.path.join(self._config.root_workspace, data["id"], "example"))
                    dest_path.mkdir(parents=True, exist_ok=True)
                    src_path = Path(self._audio)
                    wav_file_path = dest_path / wav_name
                    wav_file_path.symlink_to(src_path)
                    self._redis.publish(f"Gen avatar: {dest_path}/{wav_name}", msg_id=mh_id)
        if mh_id:
            status = ModelStatus.CANCEL if is_cancel else ModelStatus.COMPLETE
            update_model_status(mh_id, self._config.task, status, redis=self._redis, clean_detail=True,
                                upload_func=upload_log_func(mh_id, self._dataset_client, data["cluster"]),
                                **self._db_args)
        return "complete"

    def _pre_process_impl(self, data: dict) -> dict:
        ret = super()._pre_process_impl(data)
        return {**ret, "id": data["id"]}


def run_mh_train_dummy(sp_name: Optional[str], test: bool, preview: Optional[str], audio: Optional[str]):
    resource_manager = ResourceManager()
    manager = resource_manager.get_root_manager()

    mq_config = get_mq_config(sp_name)
    rabbitmq_stream = RabbitMQStream.create(mq_config, partial(preprocess_msg, skip_update=test),
                                            control_parser_func, init_env_func)
    manager.set_input(rabbitmq_stream)
    global_shared = StorageShared(f"{sp_name if sp_name else uuid.uuid1()}_shared", 16) if not test else None

    for task, dummy_model in get_model_pair():
        mh_subject = manager.create_subject("MHTrainDummyUnit", dummy_model)
        mh_subject.create(get_model_config(task, dummy_model, global_shared), not test, preview, audio)
        group_name = f"{dummy_model}_grp"

        @manager.from_root_selected(SelectFunc(group_name))
        @manager.group(group_name, dummy_model, sync_name="mh_train", enable_ctl=True)
        class MHGroup:
            pass

    manager.start()
    text = input("input your command>> ")
    manager.stop()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--sp", type=str, default=None, help="specific service name")
    parser.add_argument("--test", action="store_true", help="skip saving model status and publishing log")
    parser.add_argument("-p", "--preview", default=None, type=str, help="dummy preview avatar img")
    parser.add_argument("-a", "--audio", default=None, type=str, help="dummy preview audio wav")
    args = parser.parse_args()
    # check db config
    assert os.getenv("DB_USER", None), "Must to config env DB_USER before running"
    assert os.getenv("DB_PASSWORD", None), "Must to config env DB_PASSWORD before running"
    run_mh_train_dummy(args.sp, args.test, args.preview, args.audio)
