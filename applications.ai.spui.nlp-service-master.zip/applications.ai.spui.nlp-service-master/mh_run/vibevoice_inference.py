import argparse

from hydra.core.resource import ResourceManager
from hydra.core.stream import RSocketStream
from hydra.nlunit.common_utils.storage_cache import StorageShared, MetaShared
from common import gen_inference_config, SelectFunc, tts_select
from moss_ttsd_inference import get_rsocket_config

VV_REGISTER_COUNT = 4


def run_vibevoice_inference_service(test: bool, model_path: str, tokenizer_path: str):
    from hydra.nlunit.tts_register_unit import TTSRegisterUnit
    from hydra.nlunit.vibevoice_unit import VibeVoiceUnit

    resource_manager = ResourceManager()
    manager = resource_manager.get_root_manager()

    rsocket_config, vv_route, register_route = get_rsocket_config(test, "vibevoice")
    rsocket_stream = RSocketStream.create(rsocket_config)
    manager.set_input(rsocket_stream)

    model_shared = StorageShared(f"vibevoice_model_shared", 16) if not test else None
    inference_config = gen_inference_config(model_shared)
    vibevoice_subject = manager.create_subject("VibeVoiceUnit", "VibeVoice")
    vibevoice_subject.create(model_path, tokenizer_path, inference_config, "cuda", log=not test)

    dataset_shared = StorageShared(f"vibevoice_dataset_shared", 16) if not test else None
    dataset_meta_shared = MetaShared(VV_REGISTER_COUNT) if not test else None
    register_config = gen_inference_config(dataset_shared, dataset_meta_shared)
    vibevoice_register_subject = manager.create_subject("TTSRegisterUnit", "VibeVoiceRegister")
    vibevoice_register_subject.create(register_config, log=not test)

    @manager.link("Root")
    @manager.from_root_selected(SelectFunc(vv_route))
    @manager.group("VibeVoice_grp", "VibeVoice")
    class VibeVoiceGroup:
        pass

    @manager.selected_link([("VibeVoice_grp", tts_select)])
    @manager.from_root_selected(SelectFunc(register_route))
    @manager.group("VibeVoiceRegister-grp", "VibeVoiceRegister", count=VV_REGISTER_COUNT)
    class VibeVoiceRegisterGroup:
        pass

    manager.start()
    text = input("input your command>> ")
    manager.stop()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--test", action="store_true")
    parser.add_argument("-m", "--model_path", type=str, required=True, help="Path to the model")
    parser.add_argument("-t", "--tokenizer_path", type=str, required=False, default="Qwen/Qwen2.5-1.5B",
                        help="Path to the tokenizer of language model")
    args = parser.parse_args()
    run_vibevoice_inference_service(args.test, args.model_path, args.tokenizer_path)
