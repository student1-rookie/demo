import argparse
import platform
if platform.system() == "Windows":
    from hydra.nlunit.ppt_utils.ppt_parser_windows import process_pptx
else:
    from hydra.nlunit.ppt_utils.ppt_parser import process_pptx

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-i','--input', type=str, required=True, help='Input pptx file path')
    parser.add_argument('-o','--output', type=str, required=True, help='Output images path')

    args = parser.parse_args()
    _, output = process_pptx(args.input, args.output)

    for i, data in enumerate(output):
        print(f"slide {i}, path {data.path}")
        print(f"note: {data.note}")
