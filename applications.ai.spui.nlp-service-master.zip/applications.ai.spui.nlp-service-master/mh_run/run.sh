#!/bin/bash

SH_DIR=$(cd "$(dirname "$0")"; pwd)
PRJ_DIR=$(dirname $SH_DIR)

META_HUMAN_LIB=/meta-human

usage() { echo "Usage: $(basename $0) [-i] [-t] [-x] [-s] [-d <meta_human_dir>] [-e <tts_env>]" 1>&2; exit 1; }

while getopts 'tisxd:e:' opt; do
  case "$opt" in
    t)
      train=1
      ;;

    i)
      infer=1
      ;;
    s)
      standalone="--test"
      ;;
    x)
      xpu=1
      ;;
    d)
      META_HUMAN_LIB=$OPTARG
      ;;
    e)
      tts_env="--tts $OPTARG"
      ;;
    *)
      usage
      ;;
  esac
done
shift "$(($OPTIND -1))"

if [ -z "${train}" ] && [ -z "${infer}" ] && [ -z "${xpu}" ] ; then
    usage
fi

export PYTHONPATH=${PYTHONPATH}:${PRJ_DIR}:${META_HUMAN_LIB}

if [ ! -z "${train}" ]; then
    echo "start training service"
    python3 mh_train_service.py ${standalone}
    exit
fi

if [ ! -z "${infer}" ]; then
    echo "start inference service"
    python3 mh_inference_service.py ${standalone} ${tts_env}
    exit
fi

if [ ! -z "${xpu}" ]; then
    echo "start xpu service"
    bash ${META_HUMAN_LIB}/scripts/xpu_setup.sh
    python3 mh_xpu_service.py ${tts_env}
    exit
fi
