group "default" {
  targets = ["mh-service",]
}

target "_common" {
  args = {
    http_proxy = "http://proxy-prc.intel.com:913",
    https_proxy = "http://proxy-prc.intel.com:913",
  }
}

target "mh-service" {
  context = "./"
  dockerfile = "Dockerfile.mh"
  inherits = ["_common"]
  tags = ["spui/mh/service:latest"]
  args = {
      VERSION = "v0.1.1",
      CLASS = "base"
  }
}

target "mh-ls-service" {
  context = "./"
  dockerfile = "Dockerfile.ls"
  inherits = ["_common"]
  tags = ["spui/latentsync-service:latest"]
}

target "mh-cv-service" {
  context = "./"
  dockerfile = "Dockerfile.cv"
  inherits = ["_common"]
  tags = ["spui/cosyvoice-service:latest"]
}

target "mh-cv-xpu-service" {
  context = "./"
  dockerfile = "Dockerfile.cvx"
  inherits = ["_common"]
  tags = ["spui/cosyvoice-service:latest"]
  args = {
      VERSION = "v0.1.1"
  }
}

target "mh-dn-service" {
  context = "./"
  dockerfile = "Dockerfile.dn"
  inherits = ["_common"]
  tags = ["spui/denoise-service:latest"]
}

target "mh-pptp-service" {
  context = "./"
  dockerfile = "Dockerfile.pptp"
  inherits = ["_common"]
  tags = ["spui/ppt-parser-service:latest"]
}

target "mh-tts-ex-service" {
  context = "./"
  dockerfile = "Dockerfile.tts"
  inherits = ["_common"]
  tags = ["spui/tts-ex-service:latest"]
}

target "mh-qwen-tts-service" {
  context = "./"
  dockerfile = "Dockerfile.qwen"
  inherits = ["_common"]
  tags = ["spui/qwen-tts-service:latest"]
}
