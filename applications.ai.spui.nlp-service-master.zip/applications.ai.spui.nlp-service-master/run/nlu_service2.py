from hydra.core.resource import ResourceManager
from hydra.core.stream import DoubleStreamCrossProcess, ThriftStream

def norm_out(result):
    intent = result['nlu_grp']
    if 'intent' in intent:
        norm_cls_name = intent['intent'][0][0].upper()
        top_cls_score = intent['intent'][0][1]
        if top_cls_score < 0.8:
            norm_cls_name = 'SYSTEM.UNKNOWN'
        slots = list()
        if 'slots' in intent:
            # distinct slots
            for slot in intent['slots']:
                if slot not in slots:
                    slots.append(slot)
        return [{'intent': norm_cls_name, 'slots': slots}]
    return [intent]

def run_nlu_server2():
    from hydra.nlunit.bertjoint_unit import BertJointUnit
    resource_manager = ResourceManager()
    manager = resource_manager.get_root_manager()

    thrift_stream = ThriftStream.create(9093)
    model_name = 'released_joint_20210408'
    nlsubject = manager.create_subject("BertJointUnit", "JointUnit")
    nlsubject.create(kernel_folder='/hydra/tests/spui_model/', kernel_name=model_name)

    # root and storage
    manager.set_input(thrift_stream)
    manager.enable_storage(DoubleStreamCrossProcess)

    @manager.from_root()
    @manager.group("nlu_grp", "JointUnit", 1, shadow=4)
    class NLUGroup:
        pass

    manager.out("nlu_grp", func=norm_out)

    manager.start()
    text = input("input to stop >> ")
    manager.stop()

if __name__ == '__main__':
    run_nlu_server2()