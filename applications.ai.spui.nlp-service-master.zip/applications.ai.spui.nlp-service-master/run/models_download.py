from minio import Minio, S3Error
import os

DOWNLOAD_FOLDER = './models/'

MINIO_SERVER = '192.168.1.20'
MINIO_PORT = 9999

ACCESS_KEY = 'intel123'
SECRET_KEY = 'intel123'

MODEL_BUCKET = 'dagennlu'
MODEL_FOLDER_PREFIX = 'released'

client = Minio(MINIO_SERVER + ':' + str(MINIO_PORT),
               access_key=ACCESS_KEY,
               secret_key=SECRET_KEY, secure=False)

try:
    is_exist = client.bucket_exists(MODEL_BUCKET)
    if is_exist:
        objects = client.list_objects(bucket_name=MODEL_BUCKET, recursive=True, prefix=MODEL_FOLDER_PREFIX)
        models = set()
        models_folder = list()
        for obj in objects:
            if '.bin' in obj.object_name or '.json' in obj.object_name or '.txt' in obj.object_name:
                model_name = obj.object_name.split('/')[0]
                model_file_name = obj.object_name.split('/')[1]

                model_folder = os.path.join(DOWNLOAD_FOLDER, model_name, '')
                if not os.path.exists(model_folder):
                    os.mkdir(model_folder)

                model_file_path = os.path.join(model_folder, model_file_name)
                models.add(model_file_path)
                # Get model object
                obj_data = client.get_object(MODEL_BUCKET, obj.object_name)
                with open(model_file_path, 'wb') as file_data:
                    for d in obj_data.stream(32 * 1024):
                        file_data.write(d)
                print('Download file:', model_file_path)
    else:
        print("Can not find {}".format(MODEL_BUCKET))
except S3Error as err:
    print("Connection fail!")
    print(err)
