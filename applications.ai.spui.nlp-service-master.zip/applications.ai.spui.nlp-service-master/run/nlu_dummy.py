import os

from hydra.core.resource import ResourceManager
from hydra.core.stream import DoubleStreamCrossProcess, ThriftStream

ENV_SHM2NLU = "SHM2NLU"
DEFAULT_SHM2NLU = "shm2nlu"


def run_nlu_dummy():
    from hydra.nlunit.dagen_unit import DagenBatchUnit
    resource_manager = ResourceManager()
    manager = resource_manager.get_root_manager()

    shm_name = os.environ.get(ENV_SHM2NLU, DEFAULT_SHM2NLU)
    thrift_stream = ThriftStream.create(9093)
    nl_subject = manager.create_subject("DagenBatchUnit", "DummyUnit")
    nl_subject.create(shm_name=shm_name)

    manager.set_input(thrift_stream)
    manager.enable_storage(DoubleStreamCrossProcess)

    @manager.from_root()
    @manager.group("nlu_grp", "DummyUnit", 1)
    class NLUGroup:
        pass

    manager.out("nlu_grp")

    manager.start()
    text = input("input to stop >> ")
    manager.stop()


if __name__ == '__main__':
    run_nlu_dummy()
