from hydra.core.resource import ResourceManager
from hydra.core.stream import DoubleStreamCrossProcess, ThriftStream


def merge_all_out(results):
    cls_ret = dict()
    ner_ret = dict()
    sys_ret = dict()
    if "cls_grp" in results:
        cls_ret = norm_cls(results["cls_grp"])
    if "ner_grp" in results:
        ner_ret = results["ner_grp"]
    if "sys_grp" in results:
        sys_ret = norm_sys_cls(results["sys_grp"])
    print("Cls ret", cls_ret)
    print("Ner ret", ner_ret)
    print("Sys ret", sys_ret)
    if len(sys_ret) and (sys_ret['intent'] == 'OTHERS' or sys_ret['prob'] < 0.5):
        return {**cls_ret, **ner_ret}
    else:
        if sys_ret['prob'] > 0.8:
            return [{'intent': sys_ret['intent'],
                     'slots': [{'prob': round(sys_ret['prob'], 3)}]}]
        return [{'intent': sys_ret['intent'],
                 'slots': [{'prob': round(sys_ret['prob'], 3)}]
                 },
                {**cls_ret, **ner_ret}]


def norm_cls(intent):
    if 'intent' in intent:
        intent_parts = intent['intent'].split('.')
        norm_cls_name = intent['intent']
        if len(intent_parts) == 3:
            main = intent_parts[0]
            if main == "weather":
                if intent_parts[1] == 'get' and intent_parts[2] == 'weather':
                    norm_cls_name = "weather.weather.check"
                else:
                    norm_cls_name = "{}.{}.{}".format(main, intent_parts[2], intent_parts[1])
            elif main == "map" and intent_parts[1] == "search":
                norm_cls_name = "{}.{}.{}".format(main, intent_parts[2], intent_parts[1])
            elif main == "booking":
                if intent_parts[1] == "trans":
                    norm_cls_name = "{}.{}.{}".format(intent_parts[1], intent_parts[2], main)
                else:
                    norm_cls_name = "{}.{}.{}".format(intent_parts[2], intent_parts[1], main)
        norm_cls_name = norm_cls_name.upper()
        return {'intent': norm_cls_name}
    return intent


def norm_sys_cls(intent):
    if 'intent' in intent:
        intent['intent'] = intent['intent'][9:].upper()
    return intent


def run_nlu_server():
    from hydra.nlunit.nlunit import NLUnit, NluType
    from hydra.nlunit.fasttext_unit import FasttextUnit
    resource_manager = ResourceManager()
    manager = resource_manager.get_root_manager()

    thrift_stream = ThriftStream.create(9093)

    cls_subject = manager.create_subject("NLUnit", "ClsUnit")
    cls_subject.create(kernel_path='./models/kernel.pkl', nlu_type=NluType.CLS)

    ner_subject = manager.create_subject("NLUnit", "NerUnit")
    ner_subject.create(kernel_path='./models/kernel.pkl', nlu_type=NluType.NER)

    ft_subject = manager.create_subject("FTUnit", "SysUnit")
    ft_subject.create(model_path='./models/system_cls.model')

    # root and storage
    manager.set_input(thrift_stream)
    manager.enable_storage(DoubleStreamCrossProcess)

    @manager.from_root()
    @manager.group("cls_grp", "ClsUnit", 1)
    class ClsGroup:
        pass

    @manager.from_root()
    @manager.group("ner_grp", "NerUnit", 1)
    class NerGroup:
        pass

    @manager.from_root()
    @manager.group("sys_grp", "SysUnit", 1)
    class SysGroup:
        pass

    manager.out("cls_grp", "ner_grp", "sys_grp", func=merge_all_out)

    manager.start()
    text = input("input to stop >> ")
    manager.stop()


if __name__ == '__main__':
    run_nlu_server()
