import time
import os
import multiprocessing
from reactivex import Subject
from reactivex import operators as ops

from hydra.core.context import RxContext, Context
from hydra.core.stream.cross_process import StreamCrossProcess
from hydra.core.group import UnitManager, Group


class ContextTest(Context):
    index = 0

    def on_consume(self, data):
        assert data == str(ContextTest.index)
        ContextTest.index += 1
        print("[{}] Consume {}".format(self.pid, data))


class RxContextTest(RxContext):
    ret = 0
    window_count = 2

    def on_consume(self, observable_src):
        def procwrapper():
            def procwindow(window):
                def check_ret(output):
                    assert output == RxContextTest.ret
                    RxContextTest.ret += RxContextTest.window_count

                window.pipe(ops.min()).subscribe(check_ret, lambda ex: print(ex),
                                                 lambda: print("Complete"))

            return procwindow

        proxy = Subject()
        proxy.subscribe(procwrapper(),
                        lambda ex: print(ex),
                        lambda: print("Complete"))
        observable_src.pipe(ops.map(lambda x: int(x)), ops.window_with_count(RxContextTest.window_count)) \
            .subscribe(proxy)


def test_context():
    multiprocessing.set_start_method('spawn', force=True)
    grp = Group("grp", 1)
    unit_manager = UnitManager(grp, stream_cls=StreamCrossProcess)
    context = ContextTest(unit_manager)
    context.start()

    time.sleep(0.5)
    connector = unit_manager.get_stream().get_connector()
    for i in range(20):
        assert context.is_alive()
        if context.is_alive():
            print(os.getpid(), " Gen: ", str(i))
            connector.broadcast(str(i))
            time.sleep(0.01)
        else:
            print("Context stop")
            break
    if context.is_alive():
        time.sleep(1)
        context.stop()


def test_rx_context():
    multiprocessing.set_start_method('spawn', force=True)
    grp = Group("grp", 1)
    unit_manager = UnitManager(grp, stream_cls=StreamCrossProcess)
    context = RxContextTest(unit_manager)
    context.start()

    time.sleep(0.5)
    connector = unit_manager.get_stream().get_connector()
    for i in range(20):
        assert context.is_alive()
        if context.is_alive():
            print(os.getpid(), " Gen: ", str(i))
            connector.broadcast(str(i))
            time.sleep(0.01)
        else:
            print("Context stop")
            break
    if context.is_alive():
        time.sleep(1)
        context.stop()


if __name__ == '__main__':
    test_context()
