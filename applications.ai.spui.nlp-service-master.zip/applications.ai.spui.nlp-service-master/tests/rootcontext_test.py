import time
import os
import pytest

from hydra.core.typing import SingleProcessModel, EventData
from hydra.core.resource import ResourceManager, model
from hydra.core.stream import StreamCrossProcess, DoubleStreamCrossProcess


@model("RootTestModel")
class ModelA(SingleProcessModel):

    def __init__(self, config_file, param):
        self._config_file = config_file
        self._param = param
        print(self._config_file, self._param)

    def load(self):
        print("in load {}".format(self._config_file))

    def pre_process(self, data):
        print(data)
        return data

    def predict(self, data):
        ret = 'predict-' + str(data)
        # raise RuntimeError("BOOM!")
        print('[Model]', ret, time.time())
        # time.sleep(0.1)
        return ret


@model("RootTestModelP")
class ModelB(SingleProcessModel):

    def __init__(self, config_file, param):
        self._config_file = config_file
        self._param = param
        print(self._config_file, self._param)

    def load(self):
        print("in load {}".format(self._config_file))

    def pre_process(self, data):
        # print(type(data))
        return data

    def predict(self, data):
        ret = 'predict-' + str(self._param) + str(data)
        # raise RuntimeError("BOOM!")
        # time.sleep(0.01)
        print(os.getpid(), '[Model]', ret, time.time())
        return ret


def test_request():
    resource_manager = ResourceManager()
    manager = resource_manager.get_root_manager()

    nlsubject = manager.create_subject("RootTestModel")
    nlsubject.create(config_file=1, param=100)

    # root and storage
    manager.set_input(StreamCrossProcess)
    manager.enable_storage(DoubleStreamCrossProcess)

    @manager.link_out()
    @manager.from_root()
    @manager.group("grp1", "RootTestModel", 1)
    class Group1:
        pass

    def proc_ret(rets):
        for r in rets:
            print(r, rets[r])
        return list(rets.values())[0]

    manager.start()
    time.sleep(1)

    error = dict()
    for i in range(5):
        start_t = time.time()
        print(os.getpid(), " Gen: ", str(i), start_t)
        resource_manager.cast('Root', EventData(id=str(i), data=str(i)))
        # print("Main", resource_manager._group_list)
        ret = manager.request(str(i))
        print("Ret:", ret, time.time() - start_t)
        if ret != 'predict-' + str(i):
            error['predict-' + str(i)] = ret
        time.sleep(0.01)

    time.sleep(1)
    manager.stop()
    time.sleep(1)

    def _gen_report(errors):
        err_str = ""
        for err in errors:
            err_str += "Target:{},\tRet:{}\n".format(err, errors[err])
        return err_str

    assert len(error) == 0, _gen_report(error)


def merge_outs(results):
    for ret in results:
        print(ret, results[ret])
    assert len(results) == 2
    return "Got it"


def test_parallel():
    resource_manager = ResourceManager()
    manager = resource_manager.get_root_manager()

    nlsubject = manager.create_subject("RootTestModelP", "Subject1")
    nlsubject.create(config_file=1, param=100)

    nlsubject2 = manager.create_subject("RootTestModelP", "Subject2")
    nlsubject2.create(config_file=2, param=200)

    # root and storage
    manager.set_input(StreamCrossProcess)
    manager.enable_storage(DoubleStreamCrossProcess)

    # @manager.link_out()
    @manager.from_root()
    @manager.group("grp1", "Subject1", 1)
    class Group1:
        pass

    # @manager.link_out()
    @manager.from_root()
    @manager.group("grp2", "Subject2", 1)
    class Group2:
        pass

    manager.out("grp1", "grp2", func=merge_outs)

    manager.start()
    time.sleep(0.1)

    error = dict()
    for i in range(5):
        print(os.getpid(), " Gen: ", str(i))
        start_t = time.time()
        resource_manager.cast('Root', EventData(id=str(i), data=str(i)))
        ret = manager.request(str(i))
        if ret != "Got it":
            error[str(i)] = ret
        print("Ret:", ret, time.time() - start_t)
    time.sleep(1)
    manager.stop()

    def _gen_report(errors):
        err_str = ""
        for err in errors:
            err_str += "Target:{},\tRet:{}\n".format(err, errors[err])
        return err_str

    assert len(error) == 0, _gen_report(error)


if __name__ == '__main__':
    # register_model()
    test_request()
