from functools import partial

import pytest
from rsocket.helpers import utf8_decode

from hydra.core.resource import ResourceManager, model
from hydra.core.stream import RSocketConfig, RSocketStream, RouteConfig
from hydra.core.typing import SingleProcessModel


@model("RootTestModelA")
class ModelA(SingleProcessModel):

    def __init__(self, config_file, param):
        self._config_file = config_file
        self._param = param
        print(self._config_file, self._param)

    def load(self):
        print("in load {}".format(self._config_file))

    def pre_process(self, data):
        print(data)
        return data

    def predict(self, data):
        ret = 'a-' + str(data)
        # raise RuntimeError("BOOM!")
        print('[Model A]', ret)
        # time.sleep(0.1)
        return ret

@model("RootTestModelB")
class ModelB(SingleProcessModel):

    def __init__(self, config_file, param):
        self._config_file = config_file
        self._param = param
        print(self._config_file, self._param)

    def load(self):
        print("in load {}".format(self._config_file))

    def pre_process(self, data):
        print(data)
        return data

    def predict(self, data):
        ret = 'b-' + str(data)
        # raise RuntimeError("BOOM!")
        print('[Model B]', ret)
        # time.sleep(0.1)
        return ret

def preprocess(data, metadata, route):
    return f"[{route}] {utf8_decode(data)}"



@pytest.mark.skip(reason="not unit test")
def test_rsocket_server():
    res_manager = ResourceManager()
    manager = res_manager.get_root_manager()

    nlsubject_a = manager.create_subject("RootTestModelA")
    nlsubject_a.create(config_file=1, param=100)

    nlsubject_b = manager.create_subject("RootTestModelB")
    nlsubject_b.create(config_file=2, param=200)

    routers = list()
    for i in range(3):
        routers.append(RouteConfig(f"route-{i}", partial(preprocess, route=f"route-{i}")))

    rsocket_config = RSocketConfig(host="localhost", port=7000, routes=routers, nonblock_preprocess_func=None)
    rsocket_stream = RSocketStream.create(rsocket_config)

    manager.set_input(rsocket_stream)

    @manager.link("grp2")
    @manager.from_root()
    @manager.group("grp1", "RootTestModelA", 1)
    class Group1:
        pass

    @manager.link("Root")
    @manager.group("grp2", "RootTestModelB", 1)
    class Group2:
        pass

    manager.start()
    text = input("input your command>> ")
    manager.stop()


if __name__ == '__main__':
    test_rsocket_server()
