import pytest
import json

from hydra.core.resource import ResourceManager, model
from hydra.core.stream import RabbitMQStream, MQConfig
from hydra.core.typing import SingleProcessModel


@model("MqRootTestModel")
class ModelA(SingleProcessModel):

    def __init__(self, config_file, param):
        self._config_file = config_file
        self._param = param
        print(self._config_file, self._param)

    def load(self):
        print("in load {}".format(self._config_file))

    def pre_process(self, data):
        print(data)
        return data

    def predict(self, data):
        # ret = 'predict-' + str(data)
        # raise RuntimeError("BOOM!")
        print('[Model]', data)
        # time.sleep(0.1)
        return 'predict-done'


def preprocess_msg(data: str) -> dict:
    return json.loads(data)


@pytest.mark.skip(reason="not unit test")
def start_rabbitmq_server():
    resource_manager = ResourceManager()
    manager = resource_manager.get_root_manager()

    nlsubject = manager.create_subject("MqRootTestModel")
    nlsubject.create(config_file=1, param=100)

    mq_config = MQConfig(host="localhost", port=5672)
    rabbitmq_stream = RabbitMQStream.create(mq_config, preprocess_msg)

    manager.set_input(rabbitmq_stream)

    @manager.from_root()
    @manager.group("grp1", "MqRootTestModel", 1)
    class Group1:
        pass

    manager.start()
    text = input("input your command>> ")
    manager.stop()


if __name__ == '__main__':
    start_rabbitmq_server()
