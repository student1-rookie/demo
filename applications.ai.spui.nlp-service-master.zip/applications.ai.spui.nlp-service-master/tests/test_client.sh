#!/bin/bash

SH_DIR=$(cd "$(dirname "$0")"; pwd)
PRJ_DIR=$(dirname $SH_DIR)

export PYTHONPATH=${PYTHONPATH}:${PRJ_DIR}

python3 nluclient.py