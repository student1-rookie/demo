import os
import time
import asyncio
import pytest

from hydra.core.typing import BatchProcessModel, SingleProcessModel, BatchConfig, AsyncSingleProcessModel
from hydra.core.resource import model, ResourceManager
from hydra.core.stream import StreamCrossProcess
from hydra.core.group import UnitManager, Group


@model("NLTestModel")
class ModelA(SingleProcessModel):

    def __init__(self, config_file, param, func_load=None, func_pre=None, func_pred=None):
        self._config_file = config_file
        self._param = param
        self._func_load = func_load
        self._func_pre = func_pre
        self._func_pred = func_pred
        self._index = 0

    def load(self):
        if self._func_load:
            self._func_load(self._config_file, self._param)

    def pre_process(self, data):
        if self._func_pre:
            return self._func_pre(data)
        return data

    def predict(self, data):
        ret = str(self._param) + 'pred' + str(data)
        if self._func_pred:
            self._func_pred(ret, self._index)
            self._index += 1
        print(ret)
        return ret


@model("NLTestModelB")
class ModelB(BatchProcessModel):
    BATCH_CONFIG = BatchConfig(count=2, interval=1)

    def __init__(self, config_file, param, func_load=None, func_pre=None, func_pred=None):
        self._config_file = config_file
        self._param = param
        self._func_load = func_load
        self._func_pre = func_pre
        self._func_pred = func_pred
        self._index = 0

    def load(self):
        if self._func_load:
            self._func_load(self._config_file, self._param)

    def pre_process(self, data):
        if self._func_pre:
            return self._func_pre(data)
        return data

    def predict(self, data: list):
        if data and len(data) > 0:
            if self._func_pred:
                ret = self._func_pred(data, self._index)
                self._index += len(data)
                return ret
            return data
        return None


@model("NLTestModelC")
class ModelC(AsyncSingleProcessModel):

    def __init__(self, config_file, param, func_load=None, func_pre=None, func_pred=None):
        self._config_file = config_file
        self._param = param
        self._func_load = func_load
        self._func_pre = func_pre
        self._func_pred = func_pred
        self._index = 0

    def load(self):
        if self._func_load:
            self._func_load(self._config_file, self._param)

    def pre_process(self, data):
        if self._func_pre:
            return self._func_pre(data)
        return data

    async def predict(self, data):
        ret = str(self._param) + 'pred' + str(data)
        if self._func_pred:
            self._func_pred(ret, self._index)
            self._index += 1
        print(ret)
        await asyncio.sleep(1)
        return ret


def predict_check(data, index):
    assert data == ("100pred" + str(index))


def predict_check2(data, index):
    print(data)
    for one in data:
        assert one == str(index * 2)
        # print(one)
        index += 1
    return data


def model_pre(data):
    pre_out = int(data) * 2
    return str(pre_out)


@pytest.fixture
def reset_resource():
    ResourceManager.reset()


@pytest.fixture
def single_prc_model():
    res_manager = ResourceManager()
    manager = res_manager.get_root_manager()

    nlsubject = manager.create_subject("NLTestModel")
    nlsubject.create(config_file=1, param=100, func_pred=predict_check)

    grp = Group("grp", 1)
    unit_manager = UnitManager(grp, stream_cls=StreamCrossProcess)
    context = nlsubject._model2unit_cls(unit_manager)

    context.start()
    time.sleep(0.5)
    connector = unit_manager.get_stream().get_connector()

    for i in range(20):
        assert context.is_alive()
        if context.is_alive():
            print(os.getpid(), " Gen: ", str(i))
            connector.broadcast(str(i))
            time.sleep(0.01)
        else:
            break
    if context.is_alive():
        time.sleep(1)
        context.stop()


@pytest.fixture
def async_single_prc_model():
    res_manager = ResourceManager()
    manager = res_manager.get_root_manager()

    nlsubject = manager.create_subject("NLTestModelC")
    nlsubject.create(config_file=1, param=100, func_pred=predict_check)

    grp = Group("grp", 1)
    unit_manager = UnitManager(grp, stream_cls=StreamCrossProcess)
    context = nlsubject._model2unit_cls(unit_manager)

    context.start()
    time.sleep(0.5)
    connector = unit_manager.get_stream().get_connector()

    for i in range(20):
        assert context.is_alive()
        if context.is_alive():
            print(os.getpid(), " Gen: ", str(i))
            connector.broadcast(str(i))
            time.sleep(0.01)
        else:
            break
    if context.is_alive():
        time.sleep(1)
        context.stop()


@pytest.fixture
def batch_prc_model():
    res_manager = ResourceManager()
    manager = res_manager.get_root_manager()

    nlsubject = manager.create_subject("NLTestModelB")
    nlsubject.create(config_file=1, param=100, func_pre=model_pre, func_pred=predict_check2)

    grp = Group("grp", 1)
    unit_manager = UnitManager(grp, stream_cls=StreamCrossProcess)
    context = nlsubject._model2unit_cls(unit_manager)

    context.start()
    time.sleep(0.5)
    connector = unit_manager.get_stream().get_connector()
    for i in range(20):
        assert context.is_alive()
        if context.is_alive():
            print(os.getpid(), " Gen: ", str(i))
            connector.broadcast(str(i))
            time.sleep(0.001)
        else:
            break
    time.sleep(1)
    context.stop()


def test_single_prc_model(single_prc_model):
    pass


def test_async_single_prc_model(async_single_prc_model):
    pass


def test_batch_prc_model(batch_prc_model):
    pass
