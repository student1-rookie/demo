import time
import pytest
from hydra.nlunit.nlunit import NLBatchUnit, NLUnit, NluType
from hydra.core.typing import EventData, BatchConfig
from hydra.core.resource import ResourceManager
from hydra.core.stream import StreamCrossProcess, DoubleStreamCrossProcess

@pytest.mark.skip(reason="not include model file")
def batch_test():
    resource_manager = ResourceManager()
    manager = resource_manager.get_root_manager()
    nlsubject = manager.create_subject("NLBatchUnit", "NLUnitTest", batch_config=BatchConfig(count=2,interval=1000))
    nlsubject.create(kernel_path='./models/sample-kernel.pkl', nlu_type=NluType.NER)

    # root and storage
    manager.set_input(StreamCrossProcess)
    manager.enable_storage(DoubleStreamCrossProcess)

    @manager.link_out()
    @manager.from_root()
    @manager.group("grp1", "NLUnitTest", 1)
    class NLUGroup:
        pass

    manager.start()
    time.sleep(2)
    data = [
        "我要去中关村",
        "我想吃麻辣牛肉面",
        "帮我放一首稻香",
        "明天北京的温度怎样"
    ]

    start_id = 1
    for d in data:
        resource_manager.cast('Root', EventData(id=str(start_id), data=d))
        if start_id % 2 == 0:
            ret = manager.request(str(start_id-1))
            print(start_id-1, ret)
            ret = manager.request(str(start_id))
            print(start_id, ret)
        start_id += 1

    time.sleep(5)
    manager.stop()
    ResourceManager.reset()

@pytest.mark.skip(reason="not include model file")
def single_test():
    resource_manager = ResourceManager()
    manager = resource_manager.get_root_manager()
    nlsubject = manager.create_subject("NLUnit", "NLUnitTest")
    nlsubject.create(kernel_path='./models/sample-kernel.pkl', nlu_type=NluType.ALL)

    # root and storage
    manager.set_input(StreamCrossProcess)
    manager.enable_storage(DoubleStreamCrossProcess)

    @manager.link_out()
    @manager.from_root()
    @manager.group("grp1", "NLUnitTest", 1)
    class NLUGroup:
        pass

    manager.start()
    time.sleep(2)
    data = [
        "我要去中关村",
        "我想吃麻辣牛肉面",
        "帮我放一首稻香",
        "明天北京的温度怎样"
    ]

    start_id = 0
    for d in data:
        resource_manager.cast('Root', EventData(id=str(start_id), data=d))
        ret = manager.request(str(start_id))
        print(ret)
        start_id += 1

    time.sleep(5)
    manager.stop()
    ResourceManager.reset()

if __name__ == '__main__':
    batch_test()

