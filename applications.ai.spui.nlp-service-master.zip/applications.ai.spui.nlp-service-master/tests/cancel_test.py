import time
import subprocess

from hydra.core.typing import SingleProcessModel, EventData, CtlEvent
from hydra.core.resource import model, ResourceManager
from hydra.core.shared import Shared

DUMMY_SCRIPT = [
    "import time",
    "print('start dummy script')",
    "[(time.sleep(1), print('iter', i, flush=True)) for i in range({})]",
    "print('end dummy script')",
]

@model("CancelTestModel")
class CancelTestModel(SingleProcessModel):

    def __init__(self, sleep_time):
        self._sleep_time = sleep_time

    def load(self):
        pass

    def pre_process(self, data):
        return data

    def predict(self, data):
        shared = Shared.get()
        assert shared.get_data() == "123" and shared.get_ctl() == CtlEvent.START

        DUMMY_SCRIPT[2] = DUMMY_SCRIPT[2].format(int(data))
        cmd = "python3 -c \"" + ";".join(DUMMY_SCRIPT) + "\""
        p = subprocess.Popen(['/bin/bash', '-c', cmd],
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=False)
        do_cancel = False
        for c in iter(lambda: p.stdout.read(32), b""):
            print(c)
            if shared.get_ctl() == CtlEvent.CANCEL:
                p.kill()
                do_cancel = True
                break
        p.wait()
        assert do_cancel
        assert shared.get_data() == "123" and shared.get_ctl() == CtlEvent.CANCEL
        return "done"


def test_cancel():
    res_manager = ResourceManager()
    manager = res_manager.get_root_manager()

    nlsubject = manager.create_subject("CancelTestModel")
    nlsubject.create(sleep_time=1)

    @manager.group("grp", "CancelTestModel", 1, enable_ctl=True)
    class Group:
        pass

    manager.start()
    time.sleep(0.5)

    res_manager.cast('grp', EventData(id="123", data=5))
    time.sleep(1)
    grp = res_manager._group_list['grp']
    grp.cancel_ctl("123")
    time.sleep(2)

    manager.stop()
    time.sleep(1)

if __name__ == '__main__':
    test_cancel()
