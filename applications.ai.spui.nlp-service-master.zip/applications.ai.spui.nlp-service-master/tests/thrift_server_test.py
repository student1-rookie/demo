import pytest

from hydra.core.typing import BatchConfig
from hydra.core.resource import ResourceManager
from hydra.core.stream import DoubleStreamCrossProcess, ThriftStream


@pytest.mark.skip(reason="not include model file")
def start_thrift_test():
    from hydra.nlunit.nlunit import NLBatchUnit
    resource_manager = ResourceManager()
    manager = resource_manager.get_root_manager()

    thrift_stream = ThriftStream.create(9093)

    nlsubject = manager.create_subject("NLBatchUnit", "NLUnitTest", batch_config=BatchConfig(count=4096, interval=40))
    nlsubject.create(kernel_path='./models/sample-kernel.pkl')
    # root and storage
    manager.set_input(thrift_stream)
    manager.enable_storage(DoubleStreamCrossProcess)

    @manager.link_out()
    @manager.from_root()
    @manager.group("grp1", "NLUnitTest", 1)
    class Group1:
        pass

    manager.start()
    text = input("input your command>> ")
    manager.stop()


def merge_outs(results):
    cls_ret = dict()
    ner_ret = dict()
    for ret in results:
        print(ret, results[ret])
    if "cls_grp" in results:
        cls_ret = results["cls_grp"]
    if "ner_grp" in results:
        ner_ret = results["ner_grp"]
    print("Cls ret", cls_ret)
    print("Ner ret", ner_ret)
    return {**cls_ret, **ner_ret}


@pytest.mark.skip(reason="not include model file")
def start_parallel_thrift_test():
    from hydra.nlunit.nlunit import NLUnit, NluType
    resource_manager = ResourceManager()
    manager = resource_manager.get_root_manager()

    thrift_stream = ThriftStream.create(9093)

    cls_subject = manager.create_subject("NLUnit", "ClsUnit")
    cls_subject.create(kernel_path='./models/sample-kernel.pkl', nlu_type=NluType.CLS)

    ner_subject = manager.create_subject("NLUnit", "NerUnit")
    ner_subject.create(kernel_path='./models/sample-kernel.pkl', nlu_type=NluType.NER)

    # root and storage
    manager.set_input(thrift_stream)
    manager.enable_storage(DoubleStreamCrossProcess)

    @manager.from_root()
    @manager.group("cls_grp", "ClsUnit", 1)
    class ClsGroup:
        pass

    @manager.from_root()
    @manager.group("ner_grp", "NerUnit", 1)
    class NerGroup:
        pass

    manager.out("cls_grp", "ner_grp", func=merge_outs)

    manager.start()
    text = input("input your command>> ")
    manager.stop()


def merge_all_out(results):
    cls_ret = dict()
    ner_ret = dict()
    sys_ret = dict()
    # for ret in results:
    #    print(ret, results[ret])
    if "cls_grp" in results:
        cls_ret = results["cls_grp"]
    if "ner_grp" in results:
        ner_ret = results["ner_grp"]
    if "sys_grp" in results:
        sys_ret = results["sys_grp"]
    print("Cls ret", cls_ret)
    print("Ner ret", ner_ret)
    print("Sys ret", sys_ret)
    if len(sys_ret) and sys_ret['intent'] == '__label__others':
        return {**cls_ret, **ner_ret}
    else:

        return [{'intent': sys_ret['intent'][9:],
                 'slots': [{'prob': round(sys_ret['prob'], 3)}]
                 },
                {**cls_ret, **ner_ret}]


@pytest.mark.skip(reason="not include model file")
def all_run_thrift_test():
    from hydra.nlunit.nlunit import NLUnit, NluType
    from hydra.nlunit.fasttext_unit import FasttextUnit
    resource_manager = ResourceManager()
    manager = resource_manager.get_root_manager()

    thrift_stream = ThriftStream.create(9093)

    cls_subject = manager.create_subject("NLUnit", "ClsUnit")
    cls_subject.create(kernel_path='./models/sample-kernel.pkl', nlu_type=NluType.CLS)

    ner_subject = manager.create_subject("NLUnit", "NerUnit")
    ner_subject.create(kernel_path='./models/sample-kernel.pkl', nlu_type=NluType.NER)

    ft_subject = manager.create_subject("FTUnit", "SysUnit")
    ft_subject.create(model_path='./models/all_EachLabel_1000_ClassifyModel_fasttext_char_PreEmb.model')

    # root and storage
    manager.set_input(thrift_stream)
    manager.enable_storage(DoubleStreamCrossProcess)

    @manager.from_root()
    @manager.group("cls_grp", "ClsUnit", 1)
    class ClsGroup:
        pass

    @manager.from_root()
    @manager.group("ner_grp", "NerUnit", 1)
    class NerGroup:
        pass

    @manager.from_root()
    @manager.group("sys_grp", "SysUnit", 1)
    class SysGroup:
        pass

    manager.out("cls_grp", "ner_grp", "sys_grp", func=merge_all_out)

    manager.start()
    text = input("input your command>> ")
    manager.stop()


if __name__ == '__main__':
    all_run_thrift_test()
