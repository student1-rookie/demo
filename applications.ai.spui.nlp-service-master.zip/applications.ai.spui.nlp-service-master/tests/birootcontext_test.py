import time
import asyncio
import threading

from hydra.core.typing import SingleProcessModel, EventData
from hydra.core.resource import model, ResourceManager
from hydra.core.stream import StreamCrossProcess


@model("BiTestModel")
class ModelA(SingleProcessModel):

    def __init__(self, config_file, param):
        self._config_file = config_file
        self._param = param
        print(self._config_file, self._param)

    def load(self):
        print("in load {}".format(self._config_file))

    def pre_process(self, data):
        # print(type(data))
        return data

    def predict(self, data):
        ret = 'predict-' + str(data)
        # raise RuntimeError("BOOM!")
        print('[Model]', ret)
        # time.sleep(0.1)
        return ret


class RequestStream(StreamCrossProcess):

    def __init__(self, manager):
        super().__init__(manager)
        self._thread = None

    def get(self):
        if self._thread is None:
            self._thread = threading.Thread(target=self.post_request)
            self._thread.start()
        return super().get()

    def post_request(self):
        time.sleep(1)
        r_manager = self.get_manager()
        asyncio.set_event_loop(r_manager.get_loop())
        print("Start post request")
        for i in range(5):
            self.post(EventData(id=str(i), data=str(i)))
            # No implement blocking request
            r_manager.request_meta(str(i))


def test_biroot():
    res_manager = ResourceManager()
    manager = res_manager.get_root_manager()

    nlsubject = manager.create_subject("BiTestModel")
    nlsubject.create(config_file=1, param=100)

    @manager.link("Root")
    @manager.from_root()
    @manager.group("grp1", "BiTestModel", 1)
    class Group1:
        pass

    bi_node = res_manager.register_biroot(RequestStream, StreamCrossProcess)

    manager.start()
    time.sleep(5)
    manager.stop()
    time.sleep(1)


if __name__ == '__main__':
    test_biroot()
