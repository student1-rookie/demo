import time

from hydra.core.typing import SingleProcessModel, EventData
from hydra.core.resource import ResourceManager, model
from hydra.core.stream import StreamCrossProcess

CHECK_KEY = "ASSERT"


@model("SharedConModel")
class Model(SingleProcessModel):

    def __init__(self, device):
        self._device = device
        self._data = []

    def load(self):
        print("in load {}".format(self._device))

    def pre_process(self, data):
        return data

    def predict(self, data):
        if data == CHECK_KEY:
            assert len(self._data) == 3, f"{data} len is incorrect!"
            return "done"
        ret = 'predict-' + str(data)
        print(f"[Model-{self._device}]: ret")
        self._data.append(ret)
        time.sleep(0.1)
        return ret


def test_shared_con():
    resource_manager = ResourceManager()
    manager = resource_manager.get_root_manager()

    nlsubject = manager.create_subject("SharedConModel", "Subject1")
    nlsubject.create(sp_param=[{"device": "cpu"}, {"device": "cuda"}])

    manager.set_input(StreamCrossProcess)

    @manager.from_root()
    @manager.group("grp", "Subject1", count=2, shared_queue=True)
    class Group1:
        pass

    manager.start()
    time.sleep(0.1)

    for i in range(6):
        resource_manager.cast("grp", EventData(id=str(i), data=str(i)))
    for i in range(2):
        resource_manager.cast("grp", EventData(id=str(i), data=CHECK_KEY))
    time.sleep(1)
    manager.stop()
    time.sleep(1)


if __name__ == "__main__":
    test_shared_con()
