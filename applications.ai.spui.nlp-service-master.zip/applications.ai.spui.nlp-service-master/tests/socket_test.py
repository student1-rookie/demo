import time, os, multiprocessing

from hydra.core.context import Context
from hydra.core.stream import Socket2Stream
from hydra.core.group import UnitManager, Group


class ContextTmp(Context):
    count = 0

    def on_consume(self, data):
        print("[{}] Consume {}".format(self.pid, data))
        assert data == str(ContextTmp.count)
        ContextTmp.count += 1


def test_socket():
    multiprocessing.set_start_method('spawn', force=True)
    grp = Group("grp", 1)
    source = Socket2Stream.create('127.0.0.1', 8888)
    unit_manager = UnitManager(grp, source)
    context = ContextTmp(unit_manager)
    context.start()
    time.sleep(1)

    connector = unit_manager.get_stream().get_connector()
    for i in range(20):
        assert context.is_alive()
        if context.is_alive():
            print(os.getpid(), " Gen: ", str(i))
            connector.broadcast(str(i))
        else:
            break
        time.sleep(0.01)
    time.sleep(1)
    context.stop()


if __name__ == '__main__':
    test_socket()
