import functools
import time

from hydra.core.typing import BatchProcessModel, SingleProcessModel, BatchConfig
from hydra.core.resource import model, ResourceManager


@model("GrpTestModel")
class ModelA(SingleProcessModel):

    def __init__(self, config_file, param, func_load=None, func_pre=None, func_pred=None):
        self._config_file = config_file
        self._param = param
        self._func_load = func_load
        self._func_pre = func_pre
        self._func_pred = func_pred
        self._index = 0

    def load(self):
        if self._func_load:
            self._func_load(self._config_file, self._param)

    def pre_process(self, data):
        if self._func_pre:
            return self._func_pre(data)
        return data

    def predict(self, data):
        ret = str(self._param) + 'pred' + str(data)
        if self._func_pred:
            self._func_pred(ret, self._index)
            self._index += 1
        # print(ret)
        return ret


@model("GrpTestModelB")
class ModelB(BatchProcessModel):
    BATCH_CONFIG = BatchConfig(count=8, interval=5)

    def __init__(self, config_file, param):
        self._config_file = config_file
        self._param = param
        self._count = 0
        print(self._config_file, self._param)

    def load(self):
        print("in load {}".format(self._config_file))

    def pre_process(self, data):
        # print(type(data))
        print(data)
        self._count += 1
        return data + '-b'  # + str(self._count)

    def predict(self, data: list):
        if data and len(data) > 0:
            merge_ret = functools.reduce(lambda x, y: x + ',' + y, data)
            ret = 'predict: ' + str(merge_ret)
            print("ModelB", ret)
            return [ret]
        return None


def check_manager(manager):
    def status_check(status):
        for s in status:
            if status[s].total != status[s].alive:
                return False
        return True

    m_status = status_check(manager.status())
    try:
        assert m_status
    except Exception:
        manager.stop()
        return False
    return m_status


def check_predict(data, index):
    assert data == ("100pred" + str(index))


def test_grp_link():
    res_manager = ResourceManager()
    manager = res_manager.get_root_manager()

    nlsubject = manager.create_subject("GrpTestModel")
    nlsubject.create(config_file=1, param=100, func_pred=check_predict)

    nlsubject2 = manager.create_subject("GrpTestModelB")
    nlsubject2.create(config_file=2, param=200)

    @manager.link("grp2")
    @manager.group("grp1", "GrpTestModel", 1)
    class Group1:
        pass

    @manager.group("grp2", "GrpTestModelB", 1)
    class Group2:
        pass

    manager.start()
    time.sleep(0.5)
    error = False
    for i in range(20):
        res_manager.cast('grp1', str(i))
        if not check_manager(manager):
            error = True
            break

        time.sleep(0.001)
    assert not error
    time.sleep(1)

    manager.stop()
    time.sleep(1)


if __name__ == '__main__':
    test_grp_link()
