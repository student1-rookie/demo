# -*- coding:UTF-8 -*-
from hydra.core.sys_context.vnluservice import NLUOperator

from thrift import Thrift
from thrift.transport import TSocket
from thrift.transport import TTransport
from thrift.protocol import TBinaryProtocol

import time, sys, json


def interative_test():
    # Make socket
    transport = TSocket.TSocket('localhost', 9093)

    # Buffering is critical. Raw sockets are very slow
    transport = TTransport.TBufferedTransport(transport)

    # Wrap in a protocol
    protocol = TBinaryProtocol.TBinaryProtocol(transport)

    # Create a client to use the protocol encoder
    client = NLUOperator.Client(protocol)

    # Connect!
    transport.open()
    while True:
        text = input("input your command>> ")
        if not text:
            break
        content = client.vUnderstand(text, "slime")
        print("Input: {}".format(text))
        print("result:")
        print("\tskill  {}\n\taction  {}\n\tpayload  {}\n\tparent  {}\n".format(
            [i_content.skill for i_content in content], [i_content.action for i_content in content],
            [i_content.payload for i_content in content], [i_content.parent for i_content in content]))


def main(text_list):
    # Make socket
    transport = TSocket.TSocket('localhost', 9093)

    # Buffering is critical. Raw sockets are very slow
    transport = TTransport.TBufferedTransport(transport)

    # Wrap in a protocol
    protocol = TBinaryProtocol.TBinaryProtocol(transport)

    # Create a client to use the protocol encoder
    client = NLUOperator.Client(protocol)

    # Connect!
    transport.open()

    for text in text_list:
        float_time = time.time()
        content = client.vUnderstand(text, "slime")
        print("Input: {}".format(text))
        print("result:")
        for i_content in content:
            print("\tintent  {}\n\tpayload  {}\n".format(
                i_content.intent,
                json.loads(i_content.payload) if len(i_content.payload) else ""))
        print("Time usage: {}\n".format(time.time() - float_time))



if __name__ == '__main__':
    # text = '重复 一遍 播放 音乐'
    if len(sys.argv) > 1 and sys.argv[1] == "-i":
        interative_test()
        exit()
    test_list = []
    # test_list.append('播放周杰伦专辑叶惠美里的稻香')
    test_list.append('我想找天泽苑广场东侧的空位')
    test_list.append('从融科咨询中心到天安门的路线')
    test_list.append('我想听新闻')
    test_list.append('讲个笑话')
    test_list.append('北京天气如何')
    test_list.append('我想找景山公园的东门')
    test_list.append('播放一条国际新闻')
    test_list.append('预定一张去上海的机票')
    test_list.append('停止')
    test_list.append('暂停')
    # text = '我 想 找 天泽苑广场东侧 的 空位'
    # text = '停止'
    # text = '停止'
    # text = '关闭'
    # text = '上 一 首'
    # text = '下 一 首'
    # text = '你 说啥 我 没 听清'
    # text = '播放 周杰伦 的 歌曲'
    # text = '歌曲 不 是 周杰伦 演唱 的 吗'
    # text = '在 清华大学 东门 的 停车场 停车'
    # text = '暂停'
    # text = '等一下'
    # text = '停 一下'
    # text = '乱 序'
    # text = '播放 一条 国际 新闻'
    main(test_list)
    # interative_test()
