import time

from hydra.core.typing import SingleProcessModel, EventData
from hydra.core.resource import model, ResourceManager
from hydra.nlunit.common_utils.storage_cache import StorageShared

@model("StorageCacheTestModel")
class StorageCacheTestModel(SingleProcessModel):

    def __init__(self, shared: StorageShared):
        self._shared = shared

    def load(self):
        pass

    def pre_process(self, data):
        return data

    def predict(self, data):
        for i in range(4):
            out = self._shared.get(f"bucket-{i}", f"object-{i}")
            assert out == f"value-{i}"
        self._shared.put(f"bucket-{data}", f"object-{data}", f"value-{data}")
        return "done"


def test_storage_cache():
    res_manager = ResourceManager()
    manager = res_manager.get_root_manager()

    storage_shared = StorageShared("test-storage", 4)

    s_nlsubject = manager.create_subject("StorageCacheTestModel")
    print(s_nlsubject)
    s_nlsubject.create(storage_shared)

    @manager.group("grp", "StorageCacheTestModel")
    class Group:
        pass

    manager.start()

    for i in range(4):
        storage_shared.put(f"bucket-{i}", f"object-{i}", f"value-{i}")

    res_manager.cast('grp', EventData(id="123", data=5))
    time.sleep(2)

    find_0 = storage_shared.get(f"bucket-0", f"object-0")
    find_5 = storage_shared.get(f"bucket-5", f"object-5")
    assert find_0 is None
    assert find_5 == f"value-5"
    manager.stop()
    time.sleep(1)

if __name__ == '__main__':
    test_storage_cache()
