import time
import os
import multiprocessing

from hydra.core.context import Context
from hydra.core.stream.cross_process import StreamCrossProcess
from hydra.core.group import UnitManager, Group


class ContextTest(Context):
    index = 1

    def on_start(self):
        time.sleep(1)
        print("[{}] start".format(self.pid))

    def on_consume(self, data):
        assert data == str(ContextTest.index)
        ContextTest.index += 2
        print("[{}] Consume {}".format(self.pid, data))

def drain_func(data):
    return int(data) % 2 == 0


def test_drain():
    multiprocessing.set_start_method('spawn', force=True)
    grp = Group("grp", 1)
    unit_manager = UnitManager(grp, stream_cls=StreamCrossProcess)
    context = ContextTest(unit_manager)
    context.start()

    time.sleep(0.5)
    connector = unit_manager.get_stream().get_connector()
    for i in range(20):
        assert context.is_alive()
        if context.is_alive():
            print(os.getpid(), " Gen: ", str(i))
            connector.broadcast(str(i))
            time.sleep(0.01)
        else:
            print("Context stop")
            break
    ret = connector.drain(drain_func)
    assert ret, "drain failed"
    print("[{}] Main process done: {}".format(os.getpid(), ret))
    if context.is_alive():
        time.sleep(2)
        context.stop()


if __name__ == '__main__':
    test_drain()
