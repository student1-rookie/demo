# namespace
namespace java com.flex.external.vnluservice
namespace py hydra.core.sys_context.vnluservice

struct UContent {
    1: string intent,
    2: string payload,
}

service NLUOperator {

    list <UContent> vUnderstand(1:string text, 2:string type)

}
