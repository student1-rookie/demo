#!/bin/bash
thrift -out ../ --gen py vnluservice.thrift
