FROM pytorch/pytorch:2.2.2-cuda12.1-cudnn8-devel

ENV LANG=C.UTF-8 LC_ALL=C.UTF-8

ENV DEBIAN_FRONTEND=noninteractive
ENV PYTHONUNBUFFERED=1
SHELL ["/bin/bash", "--login", "-c"]

ENV http_proxy="http://proxy-prc.intel.com:913"
ENV https_proxy="http://proxy-prc.intel.com:913"

RUN apt-get update && \
    apt-get install -y --no-install-recommends ffmpeg && \
    rm -rf /var/lib/apt/lists/*

# unrecognized option `crf, libx264, preset` with /opt/conda/bin/ffmpeg
RUN ln -sf /usr/bin/ffmpeg /opt/conda/bin/ffmpeg

WORKDIR /ls-hdtr-service    
COPY . /ls-hdtr-service

# need to modify opencv-python to opencv-python-headless for built image
RUN pip install --upgrade pip && \
    pip install -r third_party/LatentSync/requirements.txt && \
    pip install faster_whisper==1.1.1 && \
    pip install ctranslate2==4.4.0 && \
    pip uninstall -y opencv-python && \
    pip install opencv-python-headless==4.9.0.80

RUN pip install -r /ls-hdtr-service/requirements.txt

ENV PYTHONPATH="/ls-hdtr-service:/ls-hdtr-service/third_party/LatentSync:/ls-hdtr-service/third_party/HDTR-Net"

RUN mkdir -p /root/.cache/torch/hub/checkpoints && \
    mkdir -p /usr/share/fonts/opentype/noto-cjk && \
    mv third_party/*.zip /root/.cache/torch/hub/checkpoints/ && \
    mv third_party/*.pth /root/.cache/torch/hub/checkpoints/ && \
    mv third_party/NotoSerifCJKsc-VF.otf /usr/share/fonts/opentype/noto-cjk/

ENTRYPOINT ["/bin/bash", "-c", "exec python3 /ls-hdtr-service/mh_run/latentsync_inference.py \"$@\"", "--"]
