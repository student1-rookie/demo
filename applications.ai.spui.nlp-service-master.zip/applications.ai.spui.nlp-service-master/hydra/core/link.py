from typing import Callable
from functools import partial

from .typing import EventData


def rule(des, event, meta):
    return des, event


def direct_rule(des):
    return partial(rule, des)


class SelectRule:
    def __init__(self, func: Callable[[any], bool], true_des, false_des):
        self._func = func
        self._true_des = true_des
        self._false_des = false_des

    def __call__(self, event, meta):
        if self._func(event.data):
            return self._true_des, event
        return self._false_des, event


def select_rule(func: Callable[[any], bool], true_des, false_des):
    return SelectRule(func, true_des, false_des)


# TODO: enable it?
def filter_rule(func, des):
    def rule(event, meta):
        new_data = func(event.data)
        return des, EventData(id=event.id, data=new_data)

    return rule


class Link:
    def __init__(self, src_name):
        self._src_name = src_name
        self._rules = dict()
        self._map_rule = None

    def add_rule(self, target, rule: Callable):
        if target == self._src_name or len(target) == 0:
            self._map_rule = rule
        elif target not in self._rules:
            self._rules[target] = rule
        else:
            print("repeat target: {}".format(target))

    def get_map_rule(self):
        return self._map_rule

    def exec_rules(self, event, meta, func: Callable[[str, EventData], None]):
        for rule in self._rules:
            target, ret_event = self._rules[rule](event, meta)
            if target:
                func(target, ret_event)

    def get_targets(self, event, meta):
        targets = []
        for rule in self._rules:
            target, _ = self._rules[rule](event, meta)
            if target:
                targets.append(target)
        return targets

    def has_target(self, target):
        if target in self._rules:
            return True
        return False

    def count(self):
        return len(self._rules)

    def path_count(self):
        # TODO: parse link tree
        return self.count()
