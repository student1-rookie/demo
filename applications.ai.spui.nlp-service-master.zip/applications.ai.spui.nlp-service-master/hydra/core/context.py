from multiprocessing import Process, Event
from typing import Optional
import asyncio
import reactivex as rx
from reactivex import Subject
from reactivex import operators as ops

from .typing import EventData, GrpEvent, CmdEvent, CtlEvent


class ServiceProcess(Process):
    def __init__(self):
        super(ServiceProcess, self).__init__()
        self._set_stop = Event()
        self._set_stop.clear()
        self._loop = None
        self._is_forever = False

    def stop(self):
        self._set_stop.set()

    def get_stop(self):
        return self._set_stop.is_set()

    def run(self):
        # need freeze_support?
        # freeze_support()
        self._on_start()
        future = self.schedule(self._loop)
        if future:
            self._loop.run_until_complete(future)
        else:
            self._is_forever = True
            self._loop.run_forever()
        self.on_exit()

    def _on_start(self):
        def _handler(loop, context):
            nonlocal self
            msg = context.get("exception", context["message"])
            print("In exception: {}".format(msg))
            self.stop()
            loop.create_task(self._shut_down())

        self._loop = asyncio.get_event_loop()
        self._loop.set_exception_handler(_handler)
        self.on_start()

    async def _shut_down(self):
        tasks = [t for t in asyncio.all_tasks() if t is not
                 asyncio.current_task()]
        [task.cancel() for task in tasks]
        await asyncio.gather(*tasks, return_exceptions=True)
        if self._is_forever:
            self._loop.stop()

    def on_start(self):
        pass

    def schedule(self, loop: asyncio.AbstractEventLoop) -> Optional[asyncio.Future]:
        pass

    def on_exit(self):
        pass


class Context(ServiceProcess):
    """ Based on asyncio and consume event one by one"""

    def __init__(self, manager):
        super(Context, self).__init__()
        self._async_queue: asyncio.Queue = asyncio.Queue()
        self._manager = manager
        self._stream_source = manager.get_stream()

    def schedule(self, loop: asyncio.AbstractEventLoop):
        future = asyncio.gather(self._get_event(), self._consume())
        self.on_schedule(loop)
        # link stream
        self._stream_source.link()
        return future

    async def _get_event(self):
        while not self.get_stop():
            event = self._stream_source.get()
            if event is None:
                await asyncio.sleep(0.01)
            else:
                await self._async_queue.put(event)
                if self._manager.wait_task_complete():
                    await self._async_queue.join()
        await self._async_queue.put(None)

    async def _consume(self):
        while not self.get_stop():
            event = await self._async_queue.get()
            if event is None:
                break
            elif isinstance(event, GrpEvent):
                event_data = event.e_data
                if isinstance(event_data, CmdEvent):
                    self.on_cmd(event_data.cmd)
                else:
                    ret = await self._on_consume(event_data.data, event_id=event_data.id)
                    self._manager.handle_result(ret, event_id=event_data.id, src=event.grp)
            elif isinstance(event, EventData):
                ret = await self._on_consume(event.data, event_id=event.id)
                self._manager.handle_result(ret, event.id)
            elif isinstance(event, CmdEvent):
                self.on_cmd(event.cmd)
            else:
                ret = await self._on_consume(event)
                self._manager.handle_result(ret)
            if self._manager.wait_task_complete():
                self._async_queue.task_done()

    async def _on_consume(self, data, event_id=None):
        if event_id:
            self._manager.update_ctl(event_id, CtlEvent.START)
        ret = None
        async with self._manager.grp_sync_guard():
            ret = self.on_consume(data)
        if event_id:
            self._manager.update_ctl(event_id, CtlEvent.INIT)
        return ret

    def on_start(self):
        self._manager.update_share_map()

    def on_schedule(self, loop: asyncio.AbstractEventLoop):
        pass

    def on_consume(self, data):
        return data

    def on_cmd(self, cmd):
        pass

    def on_exit(self):
        self._manager.close()
        self._stream_source.close()


class BiContext(Context):
    """Bi-stream: out & internal"""

    def __init__(self, manager):
        super(BiContext, self).__init__(manager)
        self._out_stream = manager.get_outstream()

    def on_schedule(self, loop: asyncio.AbstractEventLoop):
        loop.create_task(self._get_out_event())
        self.other_schedule(loop)

    async def _get_out_event(self):
        while not self.get_stop():
            event = self._out_stream.get()
            if event is None:
                await asyncio.sleep(0.01)
            else:
                self._manager.handle_out_event(event)

    def other_schedule(self, loop: asyncio.AbstractEventLoop):
        pass


class RxContext(ServiceProcess):
    """ Based on asyncio & rx
        consume event stream"""

    def __init__(self, manager):
        super(RxContext, self).__init__()
        self._async_queue: asyncio.Queue = None
        self._manager = manager
        self._stream_source = manager.get_stream()
        self._observable = None
        self._future = None

    def schedule(self, loop: asyncio.AbstractEventLoop):
        def on_subscribe(observer, scheduler):
            async def _consume():
                while not self.get_stop():
                    event = await self._async_queue.get()
                    if event is None:
                        break
                    else:
                        observer.on_next(event)

            consumer_coro = _consume()
            self._future = asyncio.gather(self._get_event(), consumer_coro)

        self._observable = rx.create(on_subscribe)
        self._async_queue = asyncio.Queue()

        def on_cmd_filter(value):
            if isinstance(value, CmdEvent):
                self.on_cmd(value.cmd)
                return False
            if isinstance(value, GrpEvent) and isinstance(value.e_data, CmdEvent):
                self.on_cmd(value.e_data.cmd)
                return False
            return True

        _subject = Subject()
        self._observable.pipe(ops.filter(on_cmd_filter)).subscribe(_subject)

        self.on_consume(_subject)
        # link stream
        self._stream_source.link()
        return self._future

    def on_consume(self, observable_src):
        pass

    def pub_result(self, event):
        if event is None:
            return
        elif isinstance(event, GrpEvent):
            event_data = event.e_data
            self._manager.handle_result(event_data.data,
                                        event_id=event_data.id, src=event.grp)
        elif isinstance(event, EventData):
            self._manager.handle_result(event.data, event.id)
        else:
            self._manager.handle_result(event)

    async def _get_event(self):
        while not self.get_stop():
            event = self._stream_source.get()
            self.on_get_event()
            if event is None:
                await asyncio.sleep(0.01)
            else:
                await self._async_queue.put(event)
        await self._async_queue.put(None)

    def on_get_event(self):
        """
        internal loop operation
        :return: None
        """
        pass

    def on_exit(self):
        self._stream_source.close()

    def on_cmd(self, cmd):
        pass
