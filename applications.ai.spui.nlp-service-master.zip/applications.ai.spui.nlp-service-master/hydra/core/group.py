from collections import namedtuple
import functools
import uuid
from typing import Optional

from .group_sync import GroupSync
from .manager import UnitManager
from .typing import RequestEvent, GrpEvent, CmdEvent, EventData, CtlEvent
from .nlsubject import NLLoad
from .shared import Shared

# useless
UnitEntity = namedtuple('UnitEntity', ['unit', 'con'])


class Group:

    def __init__(self, name: str, units_num: int, grp_src=None, link=None, sync: Optional[GroupSync] = None):
        self._name = name
        self._units_con = list()
        self._units_num = units_num
        self._grp_src = grp_src
        self._link = link
        self._sync = sync
        self._ctls = list()

    def register_units(self, unit_cls, con_cls, ctl: bool = False):
        units = list()
        for i in range(0, self._units_num):
            ctl_shared = Shared(f"{self._name}_{i}") if ctl else None
            unit_manager = UnitManager(self, con_cls, ctl_shared=ctl_shared)
            self._units_con.append(unit_manager.get_stream())
            if ctl_shared:
                self._ctls.append(ctl_shared)
            units.append(unit_cls(unit_manager, index=i))
        return units

    def name(self):
        return self._name

    def get_link(self):
        return self._link

    def get_sync(self):
        return self._sync

    # TODO: add group manager for post_event and target_request
    def post_event(self, target, event):
        if target in self._grp_src:
            target_grp = self._grp_src[target]
            unit_con = target_grp.select_unit(event)
            unit_con.get_connector().broadcast(event)
        else:
            print("Can not find", target)

    def exec_drain(self, target, event_id):
        if target in self._grp_src:
            target_grp = self._grp_src[target]
            return target_grp.drain_event(event_id)
        print("Can not find", target)
        return False

    def try_cancel(self, target, event_id):
        if target in self._grp_src:
            target_grp = self._grp_src[target]
            return target_grp.cancel_ctl(event_id)
        print("Can not find", target)
        return False

    def target_request(self, target, data_id):
        if target in self._grp_src:
            target_grp = self._grp_src[target]
            return target_grp.request(data_id)
        return None

    def request(self, data_id):
        pass

    def drain_event(self, event_id):
        def _drain_event(event):
            if isinstance(event, GrpEvent):
                return isinstance(event.e_data, EventData) and event.e_data.id == event_id
            return False

        ret = False
        for con in self._units_con:
            ret = con.get_connector().drain(_drain_event)
            if ret:
                break
        return ret

    def cancel_ctl(self, event_id):
        for ctl in self._ctls:
            if ctl.get_data() == event_id:
                ctl.write(event_id, CtlEvent.CANCEL)
                return True
        return False

    def select_unit(self, event):
        """
        Get min stream payload
        :return: unit id
        """
        min_unit = functools.reduce(lambda x, y: x if x.get_payload() <= y.get_payload() else y, self._units_con)
        return min_unit


class TwinsGroup(Group):
    def __init__(self, name: str, units_num: int, shadow_num: int, grp_src=None, link=None,
                 sync: Optional[GroupSync] = None):
        super().__init__(name, units_num, grp_src=grp_src, link=link, sync=sync)
        self._main_unit_key = None
        self._shadow_num = shadow_num
        self._shadow_con = list()
        self._shadow_key = list()

    def register_units(self, unit_cls, con_cls, ctl: bool = False):
        units = list()
        self._main_unit_key = unit_cls.get_model_name()
        for i in range(0, self._units_num):
            ctl_shared = Shared(f"{self._name}_{i}") if ctl else None
            unit_manager = UnitManager(self, con_cls, i, ctl_shared=ctl_shared)
            self._units_con.append(unit_manager.get_stream())
            if ctl_shared:
                self._ctls.append(ctl_shared)
            units.append(unit_cls(unit_manager))
        for i in range(0, self._shadow_num):
            ctl_shared = Shared(f"{self._name}_{i + self._units_num}") if ctl else None
            unit_manager = UnitManager(self, con_cls, ctl_shared=ctl_shared)
            self._shadow_con.append(unit_manager.get_stream())
            if ctl_shared:
                self._ctls.append(ctl_shared)
            units.append(unit_cls(unit_manager, shadow=True))
        self._shadow_key.extend([None] * self._shadow_num)
        return units

    def select_unit(self, event):
        if isinstance(event, GrpEvent) and event.u_data and event.u_data != self._main_unit_key:
            return self._select_shadow(event.u_data)
        return super().select_unit(event)

    def _select_shadow(self, name):
        if name in self._shadow_key:
            return self._shadow_con[self._shadow_key.index(name)]
        # find smallest alive_ts
        old_con_index = functools.reduce(lambda x, y: x if x[1].get_alive_ts() < y[1].get_alive_ts() else y,
                                         enumerate(self._shadow_con))[0]
        shadow_con = self._shadow_con[old_con_index]
        self._shadow_key[old_con_index] = name
        # send CmdEvent
        cmd_event = CmdEvent(cmd=NLLoad(model_name=name))
        shadow_con.get_connector().broadcast(cmd_event)
        return shadow_con


class Node(Group):

    def __init__(self, name: str, grp_src=None, link=None, sync: Optional[GroupSync] = None):
        super().__init__(name, 1, grp_src=grp_src, link=link, sync=sync)

    def register_units(self, unit_cls, con_cls, ctl: bool = False):
        if len(self._units_con) == 0:
            ctl_shared = Shared(f"{self._name}_{uuid.uuid1()}") if ctl else None
            unit_manager = UnitManager(self, con_cls, ctl_shared=ctl_shared)
            self._units_con.append(unit_manager.get_stream())
            if ctl_shared:
                self._ctls.append(ctl_shared)
            return [unit_cls(unit_manager)]
        print("Can not register multi-units at Node")
        return []

    def select_unit(self, event):
        return self._units_con[0]


class SpNode(Node):

    # special unit
    def register_units(self, unit_cls, manager, ctl: bool = False):
        if len(self._units_con) == 0:
            self._units_con.append(manager.get_stream())
            return [unit_cls(manager)]
        print("Can not register multi-units at SpNode")
        return []

    def request(self, data_id):
        req_event = RequestEvent(id=data_id, block=True)
        return self._units_con[0].get_connector().request(req_event)

    def select_unit(self, event):
        return self._units_con[0]


class GroupQ(Group):

    def register_units(self, unit_cls, con_cls, ctl: bool = False):
        units = list()
        shared_con = con_cls(None)
        self._units_con = [shared_con]
        for i in range(0, self._units_num):
            ctl_shared = Shared(f"{self._name}_{i}") if ctl else None
            unit_manager = UnitManager(self, shared_con, ctl_shared=ctl_shared, wait_task_complete=True,
                                       stream_obj=True)
            if ctl_shared:
                self._ctls.append(ctl_shared)
            units.append(unit_cls(unit_manager, index=i))
        return units

    def select_unit(self, event):
        return self._units_con[0]
