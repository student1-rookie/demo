import asyncio
import socket
from collections import namedtuple

from ..typing import StreamSource
from .connector import StreamConnector

FutureData = namedtuple('FutureData', ['future', 'data'])


class Socket2Stream(StreamSource):

    def __init__(self, manager, ip_addr, port):
        super().__init__(manager)
        self._connector = SocketConnector(ip_addr, port, self)
        self._future_data = None

    def link(self) -> bool:
        return self._connector.connect()

    def on_post(self, msg):
        self._future_data = FutureData(future=asyncio.Future(), data=msg)
        return self._future_data.future

    def on_get(self):
        if self._future_data and not self._future_data.future.done():
            msg = self._future_data.data
            self._future_data.future.set_result("done")
            return msg
        return None

    def close(self):
        self._connector.close()

    def get_connector(self):
        return self._connector

    def get_payload(self) -> int:
        pass


class SocketConnector(StreamConnector):

    def __init__(self, ip_addr, port, stream: Socket2Stream):
        super(SocketConnector, self).__init__(stream)
        self._ip_addr = ip_addr
        self._port = port
        self._server = None
        self._linked = True

    def on_broadcast(self, stream, data):
        # TODO: need to create singleton for sock
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.connect((self._ip_addr, self._port))
        sock.send(bytearray((str(data)).encode("utf-8")))
        sock.close()

    def close(self):
        self._linked = False

    def connect(self):
        async def listen(reader, writer):
            while self._linked:
                data = await reader.readline()
                data = data.decode("utf-8")
                if not data:
                    break
                await self._stream.post(data)

        loop = asyncio.get_event_loop()
        self._server = asyncio.start_server(listen, self._ip_addr, self._port)
        loop.create_task(self._server)
        return True
