from hydra.core.stream.cross_process import StreamCrossProcess, DoubleStreamCrossProcess
from hydra.core.stream.socket_stream import Socket2Stream
from hydra.core.stream.thrift_stream import ThriftStream
from hydra.core.stream.rabbitmq_stream import RabbitMQStream, MQConfig
from hydra.core.stream.rsocket_stream import RSocketConfig, RSocketStream, RouteConfig

def stream_proxy(stream_cls):
    from ..typing.stream_source import StreamSourceProxy
    if isinstance(stream_cls, StreamSourceProxy):
        return stream_cls
    else:
        return stream_cls.proxy()
