from thrift.transport import TSocket
from thrift.transport import TTransport
from thrift.protocol import TBinaryProtocol
from thrift.server import TServer

from ..typing import StreamSource
from .connector import StreamConnector


class ThriftStream(StreamSource):

    def __init__(self, manager, port):
        super().__init__(manager)
        self._port = port
        self._connector = None

    def init_connector(self, processor):
        self._connector = ThriftConnector(self._port, processor, self)

    def link(self):
        return self._connector.connect()


class ThriftConnector(StreamConnector):
    def __init__(self, port, processor, stream: ThriftStream):
        super().__init__(stream)
        self._port = port
        self._processor = processor
        self._server = None

    def connect(self):
        transport = TSocket.TServerSocket(port=self._port)
        tfactory = TTransport.TBufferedTransportFactory()
        pfactory = TBinaryProtocol.TBinaryProtocolFactory()
        self._server = TServer.TThreadedServer(
            self._processor, transport, tfactory, pfactory
        )
        # blocking
        print("Start thrift server")
        self._server.serve()

    def close(self):
        pass
