from abc import ABC, abstractmethod


class Connector(ABC):

    @abstractmethod
    def connect(self) -> bool:
        raise NotImplementedError

    @abstractmethod
    def broadcast(self, data) -> None:
        raise NotImplementedError

    @abstractmethod
    def drain(self, select_func) -> bool:
        raise NotImplementedError


class StreamConnector(Connector):

    def __init__(self, stream):
        self._stream = stream

    def connect(self) -> bool:
        return True

    def broadcast(self, data):
        self.on_broadcast(self._stream, data)

    def drain(self, select_func) -> bool:
        return self.on_drain(self._stream, select_func)

    def on_broadcast(self, stream, data):
        pass

    def on_drain(self, stream, select_func) -> bool:
        return False

    def request(self, req_event):
        return self._stream.request(req_event)
