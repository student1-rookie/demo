import asyncio
from dataclasses import dataclass
from typing import Callable, Optional, Tuple

from aio_pika import ExchangeType, connect
from aio_pika.abc import AbstractIncomingMessage

from ..typing import StreamSource, EventData
from .connector import StreamConnector


@dataclass
class MQConfig:
    host: str
    port: int
    exchange: str = 'mh-train'
    exchange_type: str = ExchangeType.TOPIC
    queue: str = 'mh-queue'
    routing_key: str = "mh.train.test"
    prefetch_count: int = 1
    ctl_exchange: str = 'mh-ctl'
    delete_queue: bool = False


class RabbitMQStream(StreamSource):

    def __init__(self, manager, config: MQConfig, preprocess_func: Callable, cancel_func: Optional[Callable] = None,
                 init_func: Optional[Callable[[], None]] = None):
        super().__init__(manager)
        self._config = config
        self._preprocess_func = preprocess_func
        self._cancel_func = cancel_func
        self._init_func = init_func
        self._connector = None

    def link(self) -> bool:
        return self._connector is not None

    async def async_get(self):
        await self._connector.get_data()

    def init_connector(self, async_queue, manager):
        self._connector = RabbitMQConnector(self._config, self._preprocess_func, self._cancel_func, self._init_func,
                                            async_queue, manager, self)

    def stop(self):
        self._connector.stop()


class RabbitMQConnector(StreamConnector):

    def __init__(self, config: MQConfig, preprocess_func: Callable,
                 cancel_func: Optional[Callable[[str], Tuple[dict, str, Callable]]],
                 init_func: Optional[Callable[[], None]], async_queue, manager,
                 stream: RabbitMQStream):
        super().__init__(stream)
        self._config = config
        self._manager = manager
        self._async_queue = async_queue
        self._preprocess_func = preprocess_func
        self._cancel_parser_func = cancel_func
        self._init_func = init_func

        self._connection = None
        self._channel = None
        self._queue = None
        self._stop_event = asyncio.Event()

    def stop(self):
        self._stop_event.set()

    async def get_data(self):
        self._connection = await connect(host=self._config.host, port=self._config.port)
        self._channel = await self._connection.channel()
        await self._channel.set_qos(prefetch_count=self._config.prefetch_count)

        topic_exchange = await self._channel.declare_exchange(self._config.exchange, self._config.exchange_type,
                                                              durable=True)
        self._queue = await self._channel.declare_queue(self._config.queue, durable=False)
        await self._queue.bind(topic_exchange, routing_key=self._config.routing_key)
        await self._queue.consume(self._consume_mq_data)

        if self._cancel_parser_func:
            ctl_exchange = await self._channel.declare_exchange(self._config.ctl_exchange, ExchangeType.FANOUT)
            ctl_queue = await self._channel.declare_queue(exclusive=True)
            await ctl_queue.bind(ctl_exchange)
            await ctl_queue.consume(self._consume_ctl_data)

        if self._init_func:
            self._init_func()

        try:
            await self._stop_event.wait()
        finally:
            if self._config.delete_queue:
                await self._queue.delete(if_unused=False)
            await self._connection.close()

    async def _consume_mq_data(self, message: AbstractIncomingMessage):
        async with ((message.process())):
            data = self._preprocess_func(message.body.decode('utf-8'), message.message_id) if self._preprocess_func \
                else message.body.decode('utf-8')
            await self._async_queue.put(EventData(id=message.message_id, data=data))

    async def _consume_ctl_data(self, message: AbstractIncomingMessage):
        async with message.process():
            data, task_id, post_func = self._cancel_parser_func(message.body.decode('utf-8'))
            ret = self._manager.drain_request(data, task_id)
            if not ret:
                self._manager.set_cancel(data, task_id)
            else:
                if post_func:
                    post_func()
