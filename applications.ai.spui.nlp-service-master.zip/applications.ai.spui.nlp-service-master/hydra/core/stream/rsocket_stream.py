import asyncio
import json
from dataclasses import dataclass
from typing import Callable, List, Optional

from rsocket.local_typing import Awaitable
from rsocket.payload import Payload
from rsocket.rsocket_server import RSocketServer
from rsocket.transports.tcp import TransportTCP
from rsocket.frame_helpers import ensure_bytes
from rsocket.helpers import utf8_decode, create_response
from rsocket.routing.request_router import RequestRouter
from rsocket.routing.routing_request_handler import RoutingRequestHandler
from rsocket.extensions.composite_metadata import CompositeMetadata

from ..typing import StreamSource
from .connector import StreamConnector


def _default_preprocess(data, metadata):
    return utf8_decode(data)


def _default_postprocess(response):
    if isinstance(response, str):
        return response
    if isinstance(response, dict) or isinstance(response, list):
        return json.dumps(response)
    return "Cannot postprocess: {}".format(response)


@dataclass
class RouteConfig:
    name: str
    preprocess_func: Callable = _default_preprocess
    postprocess_func: Callable = _default_postprocess
    block: bool = True


@dataclass
class RSocketConfig:
    host: str
    port: int
    routes: List[RouteConfig]
    nonblock_preprocess_func: Optional[Callable]
    init_func: Optional[Callable[[], None]] = None


class RSocketStream(StreamSource):

    def __init__(self, manager, config: RSocketConfig):
        super().__init__(manager)
        self._config = config
        self._connector = None

    def init_connector(self, manager):
        self._connector = RSocketConnector(self._config, manager, self)

    def link(self) -> bool:
        return self._connector.connect()


class RSocketConnector(StreamConnector):

    def __init__(self, config: RSocketConfig, manager, stream: RSocketStream):
        super().__init__(stream)
        self._config = config
        self._manager = manager
        self._server = None

    def _define_router(self, router, name, preprocess_func, postprocess_func):

        @router.response(name)
        async def handle(payload: Payload, composite_metadata: CompositeMetadata) -> Awaitable[Payload]:
            data = preprocess_func(payload.data, composite_metadata)
            if isinstance(data, list):
                meta_id_list = self._manager.handle_inputs(data)
                response = await self._manager.request_outs(meta_id_list)
            else:
                meta_id = self._manager.handle_input(data)
                response = await self._manager.request_out(meta_id)
            if postprocess_func:
                response = postprocess_func(response)

            return create_response(ensure_bytes(response))

    def _define_nonblock_router(self, router, name, preprocess_func):
        @router.fire_and_forget(name)
        async def no_block_request(payload: Payload, composite_metadata: CompositeMetadata):
            data = preprocess_func(payload.data, composite_metadata)
            if isinstance(data, list):
                self._manager.handle_inputs_no_return(data)
            else:
                self._manager.handle_input_no_return(data)

    def handler_factory(self) -> RoutingRequestHandler:
        router = RequestRouter()

        for route_config in self._config.routes:
            if route_config.block:
                self._define_router(router, route_config.name, route_config.preprocess_func,
                                    route_config.postprocess_func)
            else:
                self._define_nonblock_router(router, route_config.name, route_config.preprocess_func)

        if self._config.nonblock_preprocess_func:
            @router.fire_and_forget_unknown()
            async def no_block_request(payload: Payload, composite_metadata: CompositeMetadata):
                data = self._config.nonblock_preprocess_func(payload.data, composite_metadata)
                if isinstance(data, list):
                    self._manager.handle_inputs_no_return(data)
                else:
                    self._manager.handle_input_no_return(data)

        return RoutingRequestHandler(router)

    def connect(self):
        def session(*connection):
            RSocketServer(TransportTCP(*connection), handler_factory=self.handler_factory,
                          fragment_size_bytes=1_000_000)
        if self._config.init_func:
            self._config.init_func()
        self._server = asyncio.start_server(session, self._config.host, self._config.port)
        loop = asyncio.get_event_loop()
        loop.create_task(self._server)
        return True
