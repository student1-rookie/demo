import asyncio

from ..context import ServiceProcess, BiContext
from ..manager import UnitManager
from ..meta import BaseMeta, FutureMeta
from ..typing import EventData, CmdEvent, TestEvent
from .sys_cmd import MetaData, SysName


class RootContext(ServiceProcess):
    def __init__(self, manager):
        super(RootContext, self).__init__()
        self._manager = manager
        self._stream_source = manager.get_stream()

    def schedule(self, loop: asyncio.AbstractEventLoop):
        # link stream
        self._stream_source.link()
        loop.create_task(self._get_event())

    async def _get_event(self):
        while not self.get_stop():
            event = self._stream_source.get()
            if event is None:
                await asyncio.sleep(0.01)
            else:
                self._manager.handle_result(event)
        asyncio.get_event_loop().stop()

    def on_exit(self):
        self._stream_source.close()


class RootManager(UnitManager):
    _grp_name = SysName.ROOT

    def __init__(self, grp, stream_cls):
        super().__init__(grp, stream_cls, enable_meta=False)

    def handle_result(self, ret, event_id=None, src=""):
        print("Root", ret)

        if ret and self._link:
            # handle CmdEvent
            if isinstance(ret, CmdEvent):
                def cmd_schedule_wrapper(target: str, event_data: EventData):
                    self._schedule(target, event_data, ret.cmd.model_name)

                self._link.exec_rules(ret, self._meta, cmd_schedule_wrapper)
                return
            # process TestEvent
            u_data = None
            data = ret
            if isinstance(ret, TestEvent):
                u_data = ret.grp_data
                data = EventData(data=ret.data, id=ret.id)

            def schedule_wrapper(target: str, event_data: EventData):
                self._schedule(target, event_data, u_data)
            # process EventData

            if isinstance(data, EventData) and data.id:
                data = ret.data
                data_id = ret.id
            else:
                data_id = BaseMeta.gen_id()
            # TODO: need to check exist of storage
            # Send to Storage Unit
            meta_event = EventData(id=data_id, data=MetaData(data=data, source=self._link.path_count()))
            self._schedule("Storage", meta_event)

            event = EventData(id=data_id, data=data)
            self._link.exec_rules(event, self._meta, schedule_wrapper)


class BiRootContext(BiContext):

    def on_consume(self, data):
        return data

    def other_schedule(self, loop: asyncio.AbstractEventLoop):
        self._manager.set_loop(loop)


class BiRootManager(UnitManager):
    _grp_name = SysName.ROOT
    _enable_sync = True

    def __init__(self, grp, out_stream_cls, internal_stream_cls):
        super().__init__(grp, internal_stream_cls, enable_meta=True)
        self._loop = None
        self._out_stream = out_stream_cls(self)

    def set_loop(self, loop):
        self._loop = loop

    def get_loop(self):
        return self._loop

    def get_outstream(self):
        return self._out_stream

    def handle_result(self, ret, event_id=None, src=""):
        # store result
        if ret:
            if self._meta.find(event_id):
                self._meta.update(event_id, ret, src)
            else:
                print("Can not find meta {}".format(event_id))

    def handle_out_event(self, event):
        if event and self._link:
            data = event
            if isinstance(event, EventData) and event.id:
                data = event.data
                data_id = event.id
            else:
                data_id = BaseMeta.gen_id()

            if not self._meta.find(data_id):
                meta = self._meta.try_find(data_id)
                source = 1
                if meta is None:
                    if BiRootManager._enable_sync:
                        future_meta = FutureMeta(data, data_id, source_count=source)
                        self._meta.add_meta(future_meta)
                    else:
                        self._meta.add_meta(BaseMeta(data, data_id, source_count=source))
            else:
                print("Duplicate event id {}".format(data_id))

            pub_event = EventData(id=data_id, data=data)

            def schedule_wrapper(target: str, event_data: EventData):
                self._schedule(target, event_data)

            self._link.exec_rules(pub_event, self._meta, schedule_wrapper)

    def request_meta(self, meta_id, wait=True):
        meta = self._meta.try_get_meta(meta_id)
        if meta:
            if wait and BiRootManager._enable_sync:
                async def wait_done():
                    await meta.get_status()
                    print("Wait done", meta_id, meta.get_result())
                    """
                    No request stream
                    if self._link:
                        self.get_stream().set_request_ret(meta_id, meta.get_result(self._link.get_map_rule()))
                    else:
                        self.get_stream().set_request_ret(meta_id, meta.get_result())
                    """

                self._loop.create_task(wait_done())
            else:
                if meta.is_done():
                    self.get_stream().set_request_ret(meta_id, meta.get_result())
        else:
            print("Can not find {}!".format(meta_id))
