import asyncio

from ..manager import UnitManager
from ..context import Context
from .sys_cmd import SysName


class RabbitMQContext(Context):

    def __init__(self, manager):
        super().__init__(manager)
        self._stream_source.init_connector(self._async_queue, manager)

    def on_schedule(self, loop: asyncio.AbstractEventLoop):
        loop.create_task(self._set_stop_event())

    async def _get_event(self):
        await self._stream_source.async_get()
        await self._async_queue.put(None)

    async def _set_stop_event(self):
        while not self.get_stop():
            await asyncio.sleep(0.1)
        self._stream_source.stop()


class RabbitMQRootManager(UnitManager):
    _grp_name = SysName.ROOT
