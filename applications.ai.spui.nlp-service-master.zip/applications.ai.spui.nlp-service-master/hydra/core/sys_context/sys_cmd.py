from collections import namedtuple

EmbeddedData = namedtuple('EmbeddedData', ['data', 'cmd'])


class SysCmd:
    pass


class CreateMeta(SysCmd):
    pass


class RequestMeta(SysCmd):
    pass


MetaData = namedtuple('MetaData', ['data', 'source'])


class SysName:
    ROOT = "Root"
    STORAGE = "Storage"
