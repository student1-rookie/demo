from multiprocessing import Process
import json

from ..manager import UnitManager
from .vnluservice.ttypes import UContent
from .vnluservice.NLUOperator import Processor
from ..meta import BaseMeta
from ..typing import EventData
from .sys_cmd import MetaData, SysName


class ThriftServerContext(Process):
    def __init__(self, manager):
        super().__init__()
        self._manager = manager
        self._stream_source = manager.get_stream()

    def stop(self):
        self.terminate()

    def run(self):
        print("In ThriftServerContext run")
        # start server
        self._stream_source.link()


class ThriftRootManager(UnitManager):
    _grp_name = SysName.ROOT

    def __init__(self, grp, stream_cls):
        super().__init__(grp, stream_cls, enable_meta=False)
        self._handler = VnluHandler(self)
        self._stream.init_connector(Processor(self._handler))

    def handle(self, data, model_name):
        event_id = BaseMeta.gen_id()

        event = EventData(id=event_id, data=MetaData(data=data, source=self._link.path_count()))
        self._schedule("Storage", event)

        u_data = model_name
        if isinstance(u_data, str) and len(u_data) == 0:
            u_data = None

        def schedule_wrapper(target: str, event_data: EventData):
            self._schedule(target, event_data, u_data)

        event = EventData(id=event_id, data=data)
        self._link.exec_rules(event, self._meta, schedule_wrapper)
        # request result
        ret = self._request("Storage", event_id)
        return ret


class VnluHandler:
    def __init__(self, manager: ThriftRootManager):
        self._manager = manager

    def vUnderstand(self, text, type_name):
        """
        Parameters:
         - text
         - type_name
        """
        result = self._manager.handle(text, type_name)
        if result:
            if type(result) == list:
                return [VnluHandler._gen_ucontext(ret) for ret in result]
            else:
                return [VnluHandler._gen_ucontext(result)]
        else:
            content = UContent("system", "error")
            return [content]

    @staticmethod
    def _gen_ucontext(result):
        if 'error' in result:
            return UContent('system', json.dumps(result))
        intent = ""
        payload = ""
        if 'intent' in result:
            intent = result['intent']
        if 'slots' in result and len(result['slots']):
            payload = json.dumps(result['slots'], ensure_ascii=False)
        return UContent(intent, payload)
