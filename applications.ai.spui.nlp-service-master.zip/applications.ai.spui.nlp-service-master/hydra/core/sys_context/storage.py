import asyncio

from ..context import Context
from ..manager import UnitManager
from ..meta import BaseMeta, FutureMeta
from .sys_cmd import MetaData, SysName


class StorageContext(Context):
    def __init__(self, manager):
        super(StorageContext, self).__init__(manager)

    def on_consume(self, data):
        return data

    async def _get_request(self):
        while not self.get_stop():
            request_event = self._stream_source.get_request()
            if request_event is None:
                await asyncio.sleep(0.01)
            else:
                self._manager.request_meta(request_event.id, request_event.block)

    def on_schedule(self, loop: asyncio.AbstractEventLoop):
        loop.create_task(self._get_request())
        self._manager.set_loop(loop)


class StorageManager(UnitManager):
    _grp_name = SysName.STORAGE
    _enable_sync = True

    def __init__(self, grp, stream_cls):
        super().__init__(grp, stream_cls, enable_meta=True)
        self._loop = None
        self._merge_func = None

    def set_loop(self, loop):
        self._loop = loop

    def handle_result(self, ret, event_id=None, src=""):
        # print("Storage", ret, event_id, src)
        # store result
        if ret:
            if self._meta.find(event_id):
                self._meta.update(event_id, ret, src)
            else:
                meta = self._meta.try_find(event_id)
                if meta is None:
                    data = ret
                    source = 1
                    if isinstance(ret, MetaData):
                        data = ret.data
                        source = ret.source
                    if StorageManager._enable_sync:
                        # save FutureMeta
                        future_meta = FutureMeta(data, event_id, source_count=source)
                        self._meta.add_meta(future_meta)
                    else:
                        self._meta.add_meta(BaseMeta(data, event_id, source_count=source))
                else:
                    # update meta
                    if isinstance(ret, MetaData):
                        meta.correct(ret.data, ret.source)

    def request_meta(self, meta_id, wait=True):
        meta = self._meta.try_get_meta(meta_id)
        if meta:
            if wait and StorageManager._enable_sync:
                if not meta.is_done():
                    # TODO: Add timeout!
                    async def wait_done():
                        await meta.get_status()
                        if self._link:
                            self.get_stream().set_request_ret(meta_id, meta.get_result(self._link.get_map_rule()))
                        else:
                            self.get_stream().set_request_ret(meta_id, meta.get_result())

                    self._loop.create_task(wait_done())
                else:
                    if self._link:
                        self.get_stream().set_request_ret(meta_id, meta.get_result(self._link.get_map_rule()))
                    else:
                        self.get_stream().set_request_ret(meta_id, meta.get_result())
            else:
                if meta.is_done():
                    self.get_stream().set_request_ret(meta_id, meta.get_result())
        else:
            # TODO: wait create and timeout
            print("Can not find {}!".format(meta_id))
