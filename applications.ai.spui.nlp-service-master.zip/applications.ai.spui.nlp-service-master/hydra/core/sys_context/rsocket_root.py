import asyncio
from typing import List

from ..context import Context
from ..meta import BaseMeta, FutureMeta
from ..manager import UnitManager
from ..typing import EventData
from .sys_cmd import SysName


class RSocketContext(Context):

    def __init__(self, manager):
        super().__init__(manager)
        self._manager.get_out_stream().init_connector(manager)

    def stop(self):
        self.terminate()

    def on_schedule(self, loop: asyncio.AbstractEventLoop):
        self._manager.get_out_stream().link()


class RSocketManager(UnitManager):
    _grp_name = SysName.ROOT

    def __init__(self, grp, stream_cls, internal_stream_cls):
        super().__init__(grp, internal_stream_cls, enable_meta=True)
        self._out_stream = stream_cls(self)

    def handle_result(self, ret, event_id=None, src=""):
        if ret and self._meta.find(event_id):
            self._meta.update(event_id, ret, src)

    def handle_input(self, data):
        meta_id = BaseMeta.gen_id()
        self._meta.add_meta(FutureMeta(data, meta_id))

        pub_event = EventData(id=meta_id, data=data)

        def schedule_wrapper(target: str, event_data: EventData):
            self._schedule(target, event_data)

        self._link.exec_rules(pub_event, self._meta, schedule_wrapper)
        return meta_id

    def handle_inputs(self, data: List):
        return [self.handle_input(d) for d in data]

    def handle_inputs_no_return(self, data: List):
        [self.handle_input_no_return(d) for d in data]

    def handle_input_no_return(self, data):
        event_id = data.get("id", BaseMeta.gen_id())

        def schedule_wrapper(target: str, event: EventData):
            self._schedule(target, event)

        self._link.exec_rules(EventData(id=event_id, data=data), None, schedule_wrapper)

    def get_out_stream(self):
        return self._out_stream

    async def request_out(self, meta_id, func=None):
        return await self._meta.request(meta_id, func)

    async def request_outs(self, meta_ids, func=None):
        return await self._meta.requests(meta_ids, func)
