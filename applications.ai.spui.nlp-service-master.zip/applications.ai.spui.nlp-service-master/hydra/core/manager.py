import traceback
from typing import Callable, Optional, Tuple, List
from contextlib import asynccontextmanager

from .typing import EventData, GrpEvent, DefaultBatchConfig, CmdEvent, CtlEvent
from .nlsubject import NLSubject
from .stream import StreamCrossProcess, ThriftStream, stream_proxy, RabbitMQStream, RSocketStream
from .meta import MetaResource, BaseMeta
from .link import Link
from .shared import Shared


class Manager:

    def __init__(self, res_manager):
        self._res_manager = res_manager
        self._subjects = dict()

        self._input_stream_cls = None
        self._root_manager = None
        self._bi_direction = False

        self._storage_stream_cls = None
        self._storage_manager = None

    def add_model(self, name, model_cls):
        self._res_manager.register_model(name, model_cls)

    def create_subject(self, model_name, subject_name=None, connector_cls=StreamCrossProcess,
                       batch_config=DefaultBatchConfig):
        model_cls = self._res_manager.get_model(model_name)
        if model_cls:
            if subject_name is None:
                subject_name = model_name
            if subject_name in self._subjects:
                print("Same subject name", subject_name)
                return None
            nl_subject = NLSubject(model_name, subject_name, model_cls, connector_cls, batch_config)
            self._subjects[subject_name] = nl_subject
            return nl_subject
        else:
            print("Can not find model: {}!".format(model_name))
        return None

    def set_input(self, input_cls, bi_direction=False):
        self._bi_direction = bi_direction
        self._input_stream_cls = stream_proxy(input_cls)

    def enable_storage(self, storage_stream_cls=StreamCrossProcess):
        if not self._bi_direction:
            self._storage_stream_cls = stream_proxy(storage_stream_cls)
        else:
            print("Not support storage when enable bi-root")

    def group(self, name: str, bind_subject: str, count=1, shadow=0, sync_name: Optional[str] = None,
              sync_anonymous: bool = True, enable_ctl: bool = False, shared_queue: bool = False):
        if bind_subject in self._subjects:
            def wrapper(cls):
                # Need lazy
                self._res_manager.register_group(name, bind_subject, count, shadow, shared_queue)
                if sync_name:
                    self._res_manager.register_group_sync(sync_name, name, sync_anonymous)
                self._res_manager.register_group_ctl(name, enable_ctl)

                class GroupWrapper(cls):
                    _grp_name = name

                return GroupWrapper

            return wrapper

        print("Can't find subject {}!".format(bind_subject))

        def non_wrapper(cls):
            return cls

        return non_wrapper

    def link(self, *targets):
        def wrapper(cls):
            for target in targets:
                from .link import direct_rule
                real_rule = direct_rule(target)
                self._res_manager.register_link(cls._grp_name, target, real_rule)
            return cls

        return wrapper

    def selected_link(self, targets: List[Tuple[str, Callable[[any], bool]]]):
        def wrapper(cls):
            for target, func in targets:
                from .link import select_rule

                rule = select_rule(func, target, None)
                self._res_manager.register_link(cls._grp_name, target, rule)
            return cls

        return wrapper

    def from_root(self):
        def wrapper(cls):
            from .sys_context import SysName
            from .link import direct_rule
            rule = direct_rule(cls._grp_name)
            self._res_manager.register_link(SysName.ROOT,
                                            cls._grp_name, rule)
            return cls

        return wrapper

    def from_root_selected(self, func: Callable[[any], bool]):
        def wrapper(cls):
            from .sys_context import SysName
            from .link import select_rule

            rule = select_rule(func, cls._grp_name, None)
            self._res_manager.register_link(SysName.ROOT,
                                            cls._grp_name, rule)
            return cls

        return wrapper

    def link_out(self):
        from .sys_context import SysName
        return self.link(SysName.STORAGE)

    def out(self, *sources, func=None):
        from .sys_context import SysName
        from .link import direct_rule
        for src in sources:
            self._res_manager.register_link(src, SysName.STORAGE,
                                            direct_rule(SysName.STORAGE))
        self._res_manager.register_link(SysName.STORAGE, "", func)

    def start(self):
        # compose nlsubjects
        for nl_name in self._subjects:
            self._subjects[nl_name].compose(self._res_manager)
        if self._input_stream_cls:
            # TODO: Implement selector at sys_context!
            if self._bi_direction:
                self._root_manager = self._res_manager.register_biroot(self._input_stream_cls, StreamCrossProcess)
            else:
                if self._input_stream_cls.is_stream(ThriftStream):
                    self._root_manager = self._res_manager.register_thrift_root(self._input_stream_cls)
                elif self._input_stream_cls.is_stream(RabbitMQStream):
                    self._root_manager = self._res_manager.register_rabbitmq_root(self._input_stream_cls)
                elif self._input_stream_cls.is_stream(RSocketStream):
                    self._root_manager = self._res_manager.register_rsocket_root(self._input_stream_cls)
                else:
                    self._root_manager = self._res_manager.register_root(self._input_stream_cls)
        if self._storage_stream_cls and not self._bi_direction:
            self._storage_manager = self._res_manager.register_storage(self._storage_stream_cls)

        self._res_manager.init_group_sync()
        self._res_manager.init_group()
        self._res_manager.start()

    def stop(self):
        self._res_manager.stop()

    def request(self, data_id):
        if self._storage_manager and not self._bi_direction:
            return self._storage_manager.request(data_id)
        return None

    def status(self):
        return self._res_manager.get_grp_status()


class UnitManager:
    def __init__(self, grp, stream_cls, enable_meta=False, ctl_shared=None, wait_task_complete=False, stream_obj=False):
        self._grp = grp
        self._grp_name = self._grp.name()
        self._link: Link = self._grp.get_link()
        self._stream = stream_cls(self) if not stream_obj else stream_cls
        self._wait_task_complete = wait_task_complete
        self._meta = None
        if enable_meta:
            self._meta = MetaResource.get_meta_res(self._grp_name)
        self._ctl_data = None
        if ctl_shared:
            self._ctl_data = ctl_shared

    def handle_result(self, ret, event_id=None, src=""):
        if ret and self._link:
            if event_id:
                ret_meta = EventData(data=ret, id=event_id)
            else:
                ret_meta = UnitManager.gen_event(ret)

            def schedule_wrapper(target: str, event: EventData):
                self._schedule(target, event)

            self._link.exec_rules(ret_meta, self._meta, schedule_wrapper)

    def update_ctl(self, event_id, ctl):
        if self._ctl_data:
            if ctl == CtlEvent.START:
                self._ctl_data.write(str(event_id), CtlEvent.START)
            elif ctl == CtlEvent.INIT:
                self._ctl_data.write("", CtlEvent.INIT)

    def update_share_map(self):
        if self._ctl_data:
            Shared.add_pid_map(self._ctl_data)

    def request_meta(self, *args, **opts):
        pass

    def drain_request(self, ret, drain_id) -> bool:
        drain_ret = False
        if ret and self._link:
            ret_meta = UnitManager.gen_event(ret)
            targets = self._link.get_targets(ret_meta, None)
            for target in targets:
                exec_ret = self._grp.exec_drain(target, drain_id)
                drain_ret = drain_ret or exec_ret
        return drain_ret

    def set_cancel(self, ret, cancel_id) -> bool:
        cancel = False
        if ret:
            ret_meta = UnitManager.gen_event(ret)
            targets = self._link.get_targets(ret_meta, None)
            for target in targets:
                exec_ret = self._grp.try_cancel(target, cancel_id)
                cancel = cancel or exec_ret
        return cancel

    def get_stream(self):
        return self._stream

    def _schedule(self, target, data, u_data=None):
        grp_event = GrpEvent(grp=self._grp_name, e_data=data, u_data=u_data)
        self._grp.post_event(target, grp_event)

    def _request(self, target, data_id):
        return self._grp.target_request(target, data_id)

    @staticmethod
    def gen_event(data):
        if isinstance(data, CmdEvent):
            return data
        return EventData(id=BaseMeta.gen_id(), data=data)

    async def grp_sync_acquire(self):
        sync = self._grp.get_sync()
        if sync:
            await sync.try_acquire()

    def grp_sync_release(self):
        sync = self._grp.get_sync()
        if sync:
            sync.release()

    @asynccontextmanager
    async def grp_sync_guard(self):
        await self.grp_sync_acquire()
        try:
            yield
        except Exception as e:
            print(f"exception in sync guard: {e}")
            traceback.print_exc()
        finally:
            self.grp_sync_release()

    def wait_task_complete(self):
        return self._wait_task_complete

    def close(self):
        sync = self._grp.get_sync()
        if sync:
            sync.close()
