import uuid
import asyncio


class BaseMeta:
    def __init__(self, data, id=None, source_count=1):
        self._id = id
        if self._id is None:
            self._id = self.gen_id()
        self._src_data = data
        self._objects = {}
        self._source_count = source_count
        self._done = False

    def set_result(self, grp_name, data):
        if not self._done:
            self._objects[grp_name] = data
            if len(self._objects) == self._source_count:
                self._done = True

    def is_done(self) -> bool:
        return self._done

    def get_id(self):
        return self._id

    def get_src_data(self):
        return self._src_data

    def get_result(self, func=None):
        if not self._done:
            return None
        if func:
            return func(self._objects)
        # Return first value in default.
        return list(self._objects.values())[0]

    def correct(self, data, source_count):
        self._src_data = data
        self._source_count = source_count

    @staticmethod
    def gen_id():
        return str(uuid.uuid1())


class FutureMeta(BaseMeta):
    def __init__(self, data, id=None, source_count=1):
        super(FutureMeta, self).__init__(data, id=id, source_count=source_count)
        self._status = asyncio.Future()

    def set_result(self, grp_name, data):
        super(FutureMeta, self).set_result(grp_name, data)
        if self.is_done() and not self._status.done():
            self._status.set_result("done")

    def get_status(self):
        return self._status


class MetaResource:
    _unit_list = dict()

    def __init__(self, name):
        self._name = name
        self._meta = dict()
        self._tmp_meta = dict()

    @classmethod
    def get_meta_res(cls, name):
        if name in MetaResource._unit_list:
            return MetaResource._unit_list[name]
        meta_resource = MetaResource(name)
        MetaResource._unit_list[name] = meta_resource
        return meta_resource

    def add_meta(self, meta: BaseMeta):
        if meta.get_id() not in self._meta:
            # print("Add meta", meta.get_id())
            self._meta[meta.get_id()] = meta

    def add_tmp_meta(self, meta: BaseMeta):
        if meta.get_id() not in self._meta and meta.get_id() not in self._tmp_meta:
            self._tmp_meta[meta.get_id()] = meta
        else:
            print("Duplicate meta id {}".format(meta.get_id()))

    def update(self, meta_id, data, src_grp):
        if meta_id in self._meta:
            # print("update meta:", meta_id, data)
            self._meta[meta_id].set_result(src_grp, data)

    def get_meta(self, meta_id):
        if meta_id in self._meta:
            return self._meta[meta_id]
        return None

    def try_get_meta(self, meta_id, future=True):
        if meta_id in self._meta:
            return self._meta[meta_id]
        else:
            if future:
                self.add_tmp_meta(FutureMeta("", meta_id))
            else:
                self.add_tmp_meta(BaseMeta("", meta_id))
            return self._tmp_meta[meta_id]

    async def request(self, meta_id, func=None):
        future_meta = self._meta[meta_id]
        await future_meta.get_status()
        return future_meta.get_result(func)

    async def requests(self, meta_id_list, func=None):
        future_meta_list = [self._meta[meta_id].get_status() for meta_id in meta_id_list]
        await asyncio.wait(future_meta_list, return_when=asyncio.ALL_COMPLETED)
        return [self._meta[meta_id].get_result(func) for meta_id in meta_id_list]

    def find(self, meta_id) -> bool:
        return meta_id in self._meta

    def try_find(self, meta_id):
        if not self.find(meta_id):
            if meta_id in self._tmp_meta:
                self._meta[meta_id] = self._tmp_meta.pop(meta_id)
                return self._meta[meta_id]
        return None
