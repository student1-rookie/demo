from abc import ABC, abstractmethod
from multiprocessing import Semaphore
import asyncio
import posix_ipc


class GroupSync(ABC):

    @abstractmethod
    async def try_acquire(self):
        pass

    @abstractmethod
    def release(self):
        pass

    @abstractmethod
    def close(self):
        pass


class AnonymousGroupSync(GroupSync):

    def __init__(self, value=1):
        self._sem = Semaphore(value)

    async def try_acquire(self):
        while not self._sem.acquire(block=False):
            await asyncio.sleep(0.1)

    def release(self):
        self._sem.release()

    def close(self):
        pass


def _try_create_named_semaphore(sem_name, value):
    try:
        sem = posix_ipc.Semaphore(sem_name, flags=posix_ipc.O_CREX, initial_value=value)
        return sem, True
    except posix_ipc.ExistentialError:  # Semaphore already exists
        sem = posix_ipc.Semaphore(sem_name)
        return sem, False


class NamedGroupSync(GroupSync):
    def __init__(self, name, value=1):
        self._name = name
        self._value = value
        self._sem = None
        self._create = False

    async def try_acquire(self):
        if self._sem is None:
            self._sem, self._create = _try_create_named_semaphore(self._name, self._value)
        while True:
            try:
                self._sem.acquire(timeout=0)
                break
            except posix_ipc.BusyError:
                await asyncio.sleep(0.1)

    def release(self):
        self._sem.release()

    def close(self):
        if self._create:
            self._sem.close()
            posix_ipc.unlink_semaphore(self._name)
