import time
from typing import Callable
from deprecated import deprecated


class StreamSource:

    def __init__(self, manager):
        # TODO: remove manager
        self._manager = manager
        self._alive_ts = time.time()

    @deprecated("will be removed in a future release")
    def get_manager(self):
        return self._manager

    @classmethod
    def proxy(cls):
        return StreamSourceProxy(cls)

    @classmethod
    def create(cls, *args, **opts):
        return StreamSourceProxy(cls, *args, **opts)

    def link(self) -> bool:
        """
        Open link
        :return: link result
        """
        pass

    def close(self) -> None:
        """
        Close stream
        """
        pass

    def post(self, msg):
        self._update_alive_ts()
        return self.on_post(msg)

    def on_post(self, msg):
        pass

    def get(self):
        self._update_alive_ts()
        return self.on_get()

    def on_get(self):
        pass

    def get_connector(self):
        pass

    def get_payload(self) -> int:
        pass

    def request(self, req_event):
        pass

    def get_request(self):
        pass

    def drain(self, select_func: Callable) -> bool:
        return False

    def get_alive_ts(self):
        return self._alive_ts

    def _update_alive_ts(self):
        self._alive_ts = time.time()


class StreamSourceProxy:
    def __init__(self, stream_cls, *args, **kwargs):
        self._stream_cls = stream_cls
        self._args = args
        self._kwargs = kwargs

    def __call__(self, manager):
        return self._stream_cls(manager, *self._args, **self._kwargs)

    def is_stream(self, stream_cls):
        return self._stream_cls is stream_cls
