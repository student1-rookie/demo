from collections import namedtuple

EventData = namedtuple('EventData', ['id', 'data'])

GrpEvent = namedtuple('GrpEvent', ['grp', 'e_data', 'u_data'])

RequestEvent = namedtuple('RequestEvent', ['id', 'block'])

CmdEvent = namedtuple('CmdEvent', ['cmd'])

TestEvent = namedtuple('TestEvent', ['id', 'data', 'grp_data'])


class CtlEvent:
    INIT = 0
    START = 1
    CANCEL = -1
