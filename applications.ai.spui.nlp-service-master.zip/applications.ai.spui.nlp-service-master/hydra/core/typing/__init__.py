from collections import namedtuple

from hydra.core.typing.event import EventData, GrpEvent, RequestEvent, CmdEvent, TestEvent, CtlEvent
from hydra.core.typing.stream_source import StreamSource
from hydra.core.typing.model import SingleProcessModel, BatchProcessModel, AsyncSingleProcessModel

BatchConfig = namedtuple('BatchConfig', ['count', 'interval'])
DefaultBatchConfig = BatchConfig(count=5, interval=1)