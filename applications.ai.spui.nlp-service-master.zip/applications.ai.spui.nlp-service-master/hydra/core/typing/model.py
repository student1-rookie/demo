from abc import ABC, abstractmethod


class BaseModel(ABC):
    __slots__ = ()

    @abstractmethod
    def load(self):
        raise NotImplementedError

    @abstractmethod
    def reload(self, path):
        pass

    @abstractmethod
    def pre_process(self, data):
        raise NotImplementedError

    @abstractmethod
    def predict(self, data):
        raise NotImplementedError

    @abstractmethod
    def get_name(self) -> str:
        pass


class SingleProcessModel(BaseModel):

    @abstractmethod
    def load(self):
        raise NotImplementedError

    def reload(self, path):
        pass

    @abstractmethod
    def pre_process(self, data) -> object:
        raise NotImplementedError

    @abstractmethod
    def predict(self, data) -> object:
        raise NotImplementedError

    def get_name(self) -> str:
        pass


class AsyncSingleProcessModel(BaseModel):

    @abstractmethod
    def load(self):
        raise NotImplementedError

    def reload(self, path):
        pass

    @abstractmethod
    def pre_process(self, data) -> object:
        raise NotImplementedError

    @abstractmethod
    async def predict(self, data) -> object:
        raise NotImplementedError

    def get_name(self) -> str:
        pass

"""
    count: max count for one window
    interval: timespan (ms)
"""


class BatchProcessModel(BaseModel):

    @abstractmethod
    def load(self):
        raise NotImplementedError

    def reload(self, path):
        pass

    @abstractmethod
    def pre_process(self, data) -> object:
        raise NotImplementedError

    @abstractmethod
    def predict(self, data: list) -> list:
        raise NotImplementedError

    def get_name(self) -> str:
        pass

    def loop_process(self):
        pass
