from datetime import timedelta
from typing import Optional, List, Dict

from reactivex import Subject
from reactivex import operators as ops
from dataclasses import dataclass
from deprecated import deprecated

from .context import Context, RxContext
from .typing import SingleProcessModel, BatchProcessModel, AsyncSingleProcessModel, BatchConfig, EventData, GrpEvent, \
    CtlEvent


@dataclass
class NLLoad:
    model_name: str = ""


class NLSubject:

    def __init__(self, model_name, subject_name, model_cls, conn_cls, batch_config):
        self._model_name = model_name
        self._subject_name = subject_name
        self._model_cls = model_cls
        self._conn_cls = conn_cls
        self._batch_config = batch_config

        self._model2unit_cls = None

    def compose(self, res_manager):
        if self._model_cls and self._conn_cls and self._model2unit_cls:
            res_manager.register_unit(self._subject_name,
                                      self._model2unit_cls,
                                      self._conn_cls)

    def set_model_cls(self, model_cls):
        self._model_cls = model_cls

    def create(self, *args, **options):
        if self._model_cls:
            sp_param = options.pop("sp_param", None)
            self._model2unit_cls = INLContext(self._model_cls, (args, options), self._batch_config, sp_param=sp_param)
        else:
            print("Model cls is None")

    def get_name(self):
        return self._subject_name


class INLContext:
    def __init__(self, model_cls, param, batch, sp_param: Optional[List[Dict]] = None):
        self._model_cls = model_cls
        self._param = param
        self._sp_param = sp_param
        self._batch = batch

    @deprecated("cannot work now!")
    def get_model_name(self):
        return self._model.get_name()

    def __call__(self, manager, index=0, shadow=False):
        if self._sp_param and index < len(self._sp_param):
            _model = self._model_cls(*self._param[0], **self._param[1], **self._sp_param[index])
        else:
            _model = self._model_cls(*self._param[0], **self._param[1])
        if isinstance(_model, SingleProcessModel):
            if not shadow:
                return NLContext(manager, _model)
            else:
                return NLShadowContext(manager, _model)
        elif isinstance(_model, AsyncSingleProcessModel):
            return NLAsyncContext(manager, _model)
        elif isinstance(_model, BatchProcessModel):
            if not shadow:
                return NLContextB(manager, _model, self._batch)
            else:
                return NLShadowContextB(manager, _model, self._batch)
        else:
            raise Exception("Error model type!")


class NLContext(Context):

    def __init__(self, manager, model):
        super(NLContext, self).__init__(manager)
        self._model: SingleProcessModel = model

    def on_start(self):
        super().on_start()
        self._model.load()

    def on_consume(self, data):
        input = self._model.pre_process(data)
        return self._model.predict(input)


class NLAsyncContext(Context):

    def __init__(self, manager, model):
        super(NLAsyncContext, self).__init__(manager)
        self._model: AsyncSingleProcessModel = model

    def on_start(self):
        super().on_start()
        self._model.load()

    async def _on_consume(self, data, event_id=None):
        if event_id:
            self._manager.update_ctl(event_id, CtlEvent.START)
        ret = None
        async with self._manager.grp_sync_guard():
            ret = await self.on_consume(data)
        if event_id:
            self._manager.update_ctl(event_id, CtlEvent.INIT)
        return ret

    async def on_consume(self, data):
        input = self._model.pre_process(data)
        return await self._model.predict(input)


class NLShadowContext(NLContext):

    def on_start(self):
        # without model loading
        self._model.set_download(True)

    def on_cmd(self, cmd):
        if isinstance(cmd, NLLoad):
            # check model exist
            self._model.reload(cmd.model_name)
        else:
            print("Cannot handle {}".format(cmd))


class NLContextB(RxContext):
    """
    Batch process
    """

    def __init__(self, manager, model, batch):
        super(NLContextB, self).__init__(manager)
        self._model: BatchProcessModel = model
        self._batch: BatchConfig = batch
        self._subject: Subject = None

    def on_start(self):
        assert isinstance(self._model, BatchProcessModel)
        self._model.load()

    def on_consume(self, observable_src):
        def _pre_process(event):
            if isinstance(event, EventData):
                out = self._model.pre_process(event.data)
                return EventData(id=event.id, data=out)
            elif isinstance(event, GrpEvent):
                event_data = event.e_data
                out = self._model.pre_process(event_data.data)
                return EventData(id=event_data.id, data=out)
            return self._model.pre_process(event)

        self._subject = Subject()
        self._subject.subscribe(self.windows_consume())
        observable_src.pipe(ops.map(lambda x: _pre_process(x)),
                            ops.window_with_time_or_count(
                                timedelta(milliseconds=self._batch.interval),
                                self._batch.count)).subscribe(self._subject)

    def windows_consume(self):
        def wrapper(window):
            def predict(event_list: list):
                if len(event_list) > 0:
                    if isinstance(event_list[0], EventData):
                        id_list = list()
                        data_list = list()
                        for event in event_list:
                            id_list.append(event.id)
                            data_list.append(event.data)
                        out_list = self._model.predict(data_list)
                        for index in range(min(len(out_list), len(id_list))):
                            out_event = EventData(id=id_list[index], data=out_list[index])
                            self.pub_result(out_event)
                    else:
                        out_list = self._model.predict(event_list)
                        for out_data in out_list:
                            self.pub_result(out_data)

            window.pipe(ops.to_list()).subscribe(predict)

        return wrapper

    def on_get_event(self):
        self._model.loop_process()


class NLShadowContextB(NLContextB):

    def on_start(self):
        self._model.set_download(True)

    def on_cmd(self, cmd):
        if isinstance(cmd, NLLoad):
            # check model exist
            self._model.reload(cmd.model_name)
        else:
            print("Cannot handle {}".format(cmd))

    def on_get_event(self):
        self._model.loop_process()
