import os

from multiprocessing import shared_memory, Semaphore
from contextlib import contextmanager


class Shared:

    _pid_map = {}

    def __init__(self, name, create=True):
        self._name = name
        self._shm = shared_memory.ShareableList([' ' * 64, 0], name=self._name) if create else shared_memory.ShareableList(name=self._name)
        self._sem = Semaphore()

    def __del__(self):
        self._shm.shm.unlink()

    def get_data(self) -> str:
        with self._sem_guard():
            return self._shm[0]

    def get_ctl(self) -> int:
        with self._sem_guard():
            return self._shm[1]

    def write(self, data: str, ctl: int):
        with self._sem_guard():
            self._shm[0] = data
            self._shm[1] = ctl

    @contextmanager
    def _sem_guard(self):
        try:
            self._sem.acquire()
            yield
        finally:
            self._sem.release()

    @staticmethod
    def add_pid_map(share):
        Shared._pid_map[os.getpid()] = share

    @staticmethod
    def get():
        pid = os.getpid()
        if pid in Shared._pid_map:
            return Shared._pid_map[pid]
        print(f"Cannot find share for pid: {pid}")
        return None
