import multiprocessing
from collections import namedtuple
from typing import Optional


def model(name):
    def wrapper(cls):
        ResourceManager.register_model(name, cls)
        return cls

    return wrapper


UnitMeta = namedtuple('UnitMeta', ['cls', 'con_cls'])
GroupMeta = namedtuple('GroupMeta', ['unit_id', 'count', 'shadow_count', 'shared_queue'])
GroupStatus = namedtuple('GroupStatus', ['total', 'alive'])
GroupSyncMeta = namedtuple('GroupSyncMeta', ['name', 'anonymous'])


class ResourceManager:
    model_list = dict()

    def __init__(self):
        self._root_manager = None
        self._unit_meta_list = dict()
        self._group_meta_list = dict()
        self._group_sync_meta_list = dict()
        self._group_ctl_meta = dict()
        self._group_list = dict()
        self._link_list = dict()
        self._group_sync_list = dict()

        self._running_unit = dict()
        if multiprocessing.get_start_method(True) != 'spawn':
            multiprocessing.set_start_method('spawn', force=True)

    @staticmethod
    def register_model(model_name, model_cls):
        if model_name not in ResourceManager.model_list:
            ResourceManager.model_list[model_name] = model_cls

    @staticmethod
    def get_model(model_name):
        if model_name in ResourceManager.model_list:
            return ResourceManager.model_list[model_name]
        return None

    def register_unit(self, unit_id, unit_cls, connector_cls):
        if unit_id not in self._unit_meta_list:
            self._unit_meta_list[unit_id] = UnitMeta(cls=unit_cls, con_cls=connector_cls)

    def get_unit(self, unit_id) -> Optional[UnitMeta]:
        if unit_id in self._unit_meta_list:
            return self._unit_meta_list[unit_id]
        return None

    def register_group(self, name, unit_id, count, shadow, shared_queue):
        if name not in self._group_meta_list:
            self._group_meta_list[name] = GroupMeta(unit_id=unit_id, count=count, shadow_count=shadow,
                                                    shared_queue=shared_queue)

    def register_group_sync(self, name, grp_name, anonymous):
        self._group_sync_meta_list[grp_name] = GroupSyncMeta(name=name, anonymous=anonymous)
        # init sync
        self._group_sync_list[name] = None

    def register_group_ctl(self, name: str, ctl: bool):
        self._group_ctl_meta[name] = ctl

    def get_grp_status(self):
        grp_status = dict()
        for grp_name in self._running_unit:
            total = len(self._running_unit[grp_name])
            alive = sum(map(lambda x: 1 if x.is_alive() else 0, self._running_unit[grp_name]))
            grp_status[grp_name] = GroupStatus(total=total, alive=alive)
        return grp_status

    def cast(self, name, event):
        if name in self._group_list:
            group = self._group_list[name]
            group.post_event(name, event)
        else:
            print("Can not find", name)

    def init_group(self):
        from .group import Group, Node, TwinsGroup, GroupQ
        for group_name in self._group_meta_list:
            group_meta = self._group_meta_list[group_name]
            if group_name not in self._group_list:
                if group_meta.count > 1 and group_meta.shadow_count == 0:
                    if group_meta.shared_queue:
                        self._group_list[group_name] = GroupQ(group_name, group_meta.count, self._group_list,
                                                              self.get_link(group_name), self.get_sync(group_name))
                    else:
                        self._group_list[group_name] = Group(group_name, group_meta.count, self._group_list,
                                                             self.get_link(group_name), self.get_sync(group_name))
                elif group_meta.shadow_count > 0:
                    self._group_list[group_name] = TwinsGroup(group_name, group_meta.count, group_meta.shadow_count,
                                                              self._group_list, self.get_link(group_name),
                                                              self.get_sync(group_name))
                else:
                    self._group_list[group_name] = Node(group_name, self._group_list, self.get_link(group_name),
                                                        self.get_sync(group_name))

            group = self._group_list[group_name]

            unit_meta = self.get_unit(group_meta.unit_id)
            if unit_meta:
                self._running_unit[group_name] = group.register_units(unit_meta.cls, unit_meta.con_cls,
                                                                      ctl=self._get_ctl(group_name))

    def init_group_sync(self):
        from .group_sync import AnonymousGroupSync, NamedGroupSync
        for sync_meta in self._group_sync_meta_list.values():
            if sync_meta.anonymous:
                self._group_sync_list[sync_meta.name] = AnonymousGroupSync()
            else:
                self._group_sync_list[sync_meta.name] = NamedGroupSync(sync_meta.name)

    def start(self):
        for grp_name in self._running_unit:
            [unit.start() for unit in self._running_unit[grp_name]]

    def stop(self):
        for grp_name in self._running_unit:
            [unit.stop() for unit in self._running_unit[grp_name]]

    def register_link(self, group: str, target, rule):
        from .link import Link
        if group in self._link_list:
            self._link_list[group].add_rule(target, rule)
        else:
            new_link = Link(group)
            new_link.add_rule(target, rule)
            self._link_list[group] = new_link

    def register_root(self, con_cls):
        from .group import SpNode
        from .sys_context import RootContext, RootManager, SysName
        grp_name = SysName.ROOT
        if grp_name not in self._group_list:
            root_grp = SpNode(grp_name, self._group_list, self.get_link(grp_name))
            root_manager = RootManager(root_grp, con_cls)
            self._group_list[grp_name] = root_grp
            self._running_unit[grp_name] = root_grp.register_units(RootContext, root_manager)
            return root_grp
        return None

    def register_thrift_root(self, con_cls):
        from .group import SpNode
        from .sys_context.thrift_root import ThriftRootManager, ThriftServerContext, SysName
        grp_name = SysName.ROOT
        if grp_name not in self._group_list:
            root_grp = SpNode(grp_name, self._group_list, self.get_link(grp_name))
            root_manager = ThriftRootManager(root_grp, con_cls)
            self._group_list[grp_name] = root_grp
            self._running_unit[grp_name] = root_grp.register_units(ThriftServerContext, root_manager)
            return root_grp
        return None

    def register_rabbitmq_root(self, con_cls):
        from .group import SpNode
        from .sys_context.rabbitmq_root import RabbitMQContext, RabbitMQRootManager, SysName
        grp_name = SysName.ROOT
        if grp_name not in self._group_list:
            root_grp = SpNode(grp_name, self._group_list, self.get_link(grp_name))
            root_manager = RabbitMQRootManager(root_grp, con_cls)
            self._group_list[grp_name] = root_grp
            self._running_unit[grp_name] = root_grp.register_units(RabbitMQContext, root_manager)
            return root_grp
        return None

    def register_rsocket_root(self, con_cls):
        from .group import SpNode
        from .sys_context.rsocket_root import RSocketContext, RSocketManager, SysName
        from .stream import StreamCrossProcess
        grp_name = SysName.ROOT
        if grp_name not in self._group_list:
            root_grp = SpNode(grp_name, self._group_list, self.get_link(grp_name))
            root_manager = RSocketManager(root_grp, con_cls, StreamCrossProcess)
            self._group_list[grp_name] = root_grp
            self._running_unit[grp_name] = root_grp.register_units(RSocketContext, root_manager)
            return root_grp
        return None

    def register_biroot(self, out_con_cls, in_con_cls):
        from .group import SpNode
        from .sys_context import BiRootManager, BiRootContext, SysName
        grp_name = SysName.ROOT
        if grp_name not in self._group_list:
            root_grp = SpNode(grp_name, self._group_list, self.get_link(grp_name))
            root_manager = BiRootManager(root_grp, out_con_cls, in_con_cls)
            self._group_list[grp_name] = root_grp
            self._running_unit[grp_name] = root_grp.register_units(BiRootContext, root_manager)
            return root_grp
        return None

    def register_storage(self, con_cls):
        from .group import SpNode
        from .sys_context import StorageContext, StorageManager, SysName
        grp_name = SysName.STORAGE
        if grp_name not in self._group_list:
            storage_grp = SpNode(grp_name, self._group_list, self.get_link(grp_name))
            storage_manager = StorageManager(storage_grp, con_cls)
            self._group_list[grp_name] = storage_grp
            self._running_unit[grp_name] = storage_grp.register_units(StorageContext, storage_manager)
            return storage_grp
        return None

    def get_link(self, grp_name: str):
        if grp_name in self._link_list:
            return self._link_list[grp_name]
        return None

    def get_sync(self, grp_name: str):
        if grp_name in self._group_sync_meta_list:
            return self._group_sync_list.get(self._group_sync_meta_list[grp_name].name, None)
        return None

    def _get_ctl(self, grp_name: str):
        return self._group_ctl_meta.get(grp_name, False)

    def get_root_manager(self):
        from .manager import Manager
        if self._root_manager is None:
            self._root_manager = Manager(self)
        return self._root_manager

    @staticmethod
    def reset():
        ResourceManager.model_list = dict()
