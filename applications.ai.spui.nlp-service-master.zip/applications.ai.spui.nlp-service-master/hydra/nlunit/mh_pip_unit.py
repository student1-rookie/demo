import os
import uuid
import base64
import traceback
import shutil
import yaml
from pathlib import Path
from typing import Optional
from functools import partial
from dataclasses import dataclass

from hydra.core.resource import model
from hydra.core.typing import SingleProcessModel
from hydra.nlunit.common_utils.env import EnvManager
from hydra.nlunit.mh_unit import MH_ROOT, CustomizedVoiceUnitConfig
from hydra.nlunit.common_utils.minio_client import MinioClient, upload_log_func
from hydra.nlunit.mh_utils.config import MHInferenceConfig
from hydra.nlunit.mh_utils.mh_pip import PictureInPicture, PictureInPictureTask, extend_media, MetaHumanInfer
from hydra.nlunit.mh_utils.utils import (
    ModelStatus, load_yml_configs, LOG_READ_BUFF_LEN, MHStatus,
    find_workspace_replace_prefix, replace_workspace_prefix_in_yml,
    switch_env, ItemType, InferenceType, save_notifications,
    upload_fail_artifacts,
)
from hydra.nlunit.mh_utils.mh_workspace import MHWorkspace, gen_bucket_object
from hydra.nlunit.mh_utils.db_utils import update_model_status, insert_infer, delete_infers, update_infers, find_infer_group, find_infer, find_infer_by_id, update_items_status, find_infer_group
from hydra.nlunit.mh_utils.mh_task import MetaHumanInference, COMMON_MAX_WORKER, VoiceInference, LatentSyncInference
from hydra.nlunit.mh_utils.redis_logger import RedisLogger


@dataclass
class TaskContext:
    cluster: bool
    cluster_ws: Optional[MHWorkspace]
    tts_record_id: str
    item_record_id:str
    wav_path: str
    srt_path: str
    wav_file: str
    srt_file: str
    face_file: str
    subtitle: bool
    one_input: any
    record_output: str
    face_record_id: str = ""
    face_path: str = ""

@model("MHInferPicInPicUnit")
class MHInferPicInPicUnit(SingleProcessModel):
    def __init__(self, config: MHInferenceConfig, device, voice_config: CustomizedVoiceUnitConfig, ls_config,
                 send_script_path, log: bool):
        self._config = config
        self._device = device
        self._enable_log = log
        self._pip = PictureInPicture()
        self._redis: Optional[RedisLogger] = None
        self._voice_config = voice_config
        self._voice_services = None
        self._ls_config = ls_config
        self._send_script_path = send_script_path
        self._storage_client: Optional[MinioClient] = None
        self._db_args = {}

    def load(self):
        logger_name = self.__class__.__name__
        self._redis = RedisLogger(logger_name, root_log_workspace=self._config.root_log_workspace,
                                  enable=self._enable_log)
        self._storage_client = MinioClient(self._config.root_workspace, cache=self._config.shared)
        if self._voice_config.local:
            self._voice_services = self._voice_config.load_from_local()
        else:
            env_manager = EnvManager()
            self._voice_services = env_manager.download(self._voice_config.env_name)
        if self._voice_services is None:
            assert "Cannot find configured voice service!"

    def _dump_model_config(self, data: dict, output_folder: str):
        id = data.get("id")
        switch_env(data, self._redis, self._db_args, self._storage_client)
        abs_output_folder = os.path.join(output_folder, id)
        Path(abs_output_folder).mkdir(parents=True, exist_ok=True)

        wav_new_model_config_path = ''
        if data["tts_model_type"].lower() not in self._voice_services:
            tts_model = self._get_tts_model(data)
            wav_config_path = os.path.join(tts_model, "tts_infer.yml")
            wav_model_config = load_yml_configs(wav_config_path)
            wav_model_config["inference"]["device"] = "cpu" if wav_model_config["model"] == "bertvits2" \
                else self._device
            wav_new_model_config_path = os.path.join(abs_output_folder, f"tts_infer.yml")
            yaml.dump(wav_model_config, open(wav_new_model_config_path, "w"))

        face_new_model_config_path = ''
        if data.get("face_model_type") is not None and data["face_model_type"].lower() != "latentsync":
            face_model = self._get_face_model(data)
            face_config_path = os.path.join(face_model, "face_infer.yml")
            face_model_config = load_yml_configs(face_config_path)
            face_model_config["inference"]["device"] = self._device
            face_new_model_config_path = os.path.join(abs_output_folder, f"face_infer.yml")
            Path(abs_output_folder).mkdir(parents=True, exist_ok=True)
            yaml.dump(face_model_config, open(face_new_model_config_path, "w"))
        
        return wav_new_model_config_path, face_new_model_config_path
    
    def _fill_common_fields(self, result, data: dict, wav_cfg, face_cfg):
        if data["tts_model_type"].lower() in self._voice_services:
            result["tts_type"] = data["tts_model_type"].lower()
            result["customized_prompt"] = data.get("customized_prompt", None)
            result["prompt_cut_duration"] = data.get("cut_duration", None)
            result["prompt_wav_path"] = data.get("wav_path", None)
            result["instruct"] = data.get("instruct", None)
        else:
            result["tts_type"] = "tts"
            result["tts_config"] = wav_cfg
        
        face_model_type = data.get("face_model_type", "")
        if face_model_type.lower() == "latentsync":
            result["face_type"] = "latentsync"
            result["ls_video_path"] = data["video_path"]
            result["hdtr"] = data.get("hdtr", False)
        elif face_model_type:
            result["face_type"] = "face"
            result["face_config"] = face_cfg
        else:
            result["face_type"] = None

    def _gen_output_path(self, output_folder, id, file_name):
        id_output_path = os.path.join(output_folder, id)
        Path(id_output_path).mkdir(parents=True, exist_ok=True)
        return os.path.join(id_output_path, file_name)
    
    def _prepare_task_environment(self, data, output_folder):
        id = data.get("id")
        cluster_ws = MHWorkspace.initialize(**data)
        wav_new_model_config_path, face_new_model_config_path = self._dump_model_config(data, output_folder)
        file_name = f"{data['name']}.mp4" if data.get("name") else f"{uuid.uuid1()}.mp4"
        abs_output_folder = os.path.join(output_folder, id)
        output = self._gen_output_path(output_folder, id, file_name)
        print(f"Picture In Picture task [{id}] starts to preprocess")
        containers = {
            "status": MHStatus.SUCCESS,
            "id": id,
            "name": data.get("name", None),
            "tts_tasks": {},
            "face_tasks": {},
            "extend_media_tasks": [],
            "pip_tasks": [],
            "output": output,
            "subtitle": data.get("subtitle", False),
            "subtitle_styles": data.get("subtitle_styles", {}),
            "pip_settings": data.get("pip_settings", None),
            "seed": data.get("seed", None),
            "cluster": data.get("cluster", False),
            "cluster_ws": cluster_ws,
            "userBucket": data.get("userBucket", None),
            "workSpace": data.get("workSpace", None),
            "tts_task_file": os.path.join(abs_output_folder, "tts.list"),
            "face_task_file": os.path.join(abs_output_folder, "face.list"),
            "groupId": data.get("groupId", None),
            "record_ids": [],
            "tts_infer_tasks": {},
            "face_infer_tasks": {},
            "infer_item_ids": data["infer_item_ids"],
            "item_keys": [],
            "account_id": data.get("account_id", None),
            "infer_ids": []
        }
        self._fill_common_fields(containers, data, wav_new_model_config_path, face_new_model_config_path)
        return containers
    
    def _get_file_names(self, name, one_input):
        item_inference_id = one_input["itemId"]
        tts_key = one_input["ttsKey"]
        face_key = one_input["faceKey"]
        item_infer = find_infer_by_id(item_inference_id)
        item_file = f"{item_infer[0]['name']}.mp4" if item_infer else f"{uuid.uuid1()}.mp4"
        wav_file = f"tts_{tts_key}.wav" if name else f"tts_{tts_key}.wav"
        face_file = f"face_{face_key}.mp4" if name else f"face_{face_key}.mp4"
        srt_file = f"srt_{tts_key}.json" if name else f"srt_{tts_key}.json"
        return item_file, wav_file, srt_file, face_file
    
    def _get_record_ids(self, data, index, wav_file, face_file, infer_ids):
        one_input = data.get("input")[index]
        cluster = data.get("cluster", False)
        face_record_id = ""
        tts_model = data["tts_model"].split("/")[-2] if cluster \
                else base64.b64decode(data["tts_model"]).decode('ascii')
        infer_record_name_tts = os.path.splitext(wav_file)[0]
        infer_record_name_face = os.path.splitext(face_file)[0]
        tts_record_id = self._get_infer_id(one_input['reuseStatus'], infer_record_name_tts, tts_model, None, data["account_id"], data["run_service"], infer_ids, data["groupId"])
        if not one_input["audio_only"]:
            face_model = data["face_model"].split("/")[-2] if cluster \
                else base64.b64decode(data["face_model"]).decode('ascii')   
            face_record_id = self._get_infer_id(one_input['reuseStatus'], infer_record_name_face, None, face_model, data["account_id"], data["run_service"], infer_ids, data["groupId"])
        return tts_record_id, face_record_id

    def _update_item_status_db(self, data, cluster_ws):
        id = data.get("id")
        status = data.get("status")
        update_items_status(data["infer_item_ids"], ModelStatus.RUN, "infer")
        if id and status == ModelStatus.WAIT:
            update_model_status(id, "infer", ModelStatus.RUN,
                                    upload_func=upload_log_func(id, self._storage_client, cluster_ws), **self._db_args)
            
    def _update_item_redis(self, data, index, cluster_ws):
        pass

    def _get_output_path(self):
        return os.path.join(self._config.root_workspace, self._config.infer_bucket)

    def _pre_process_impl(self, data: dict) -> dict:
        output_folder = self._get_output_path()
        containers = self._prepare_task_environment(data, output_folder)
        self._update_item_status_db(data, containers["cluster_ws"])
        infer_ids = find_infer_group(data.get("groupId"))

        for index, one_input in enumerate(data.get("input")): 
            item_inference_id = one_input["itemId"]
            item_key = one_input["itemKey"]
            containers["item_keys"].append(item_key)
            item_file, wav_file, srt_file, face_file = self._get_file_names(data["name"], one_input)
            self._update_item_redis(data, index, containers["cluster_ws"])
            item_path = self._gen_output_path(output_folder, item_inference_id, item_file)
            
            if one_input.get("type") == "VIDEO":
                containers["pip_tasks"].append(PictureInPictureTask(
                    main=self._get_media(containers["cluster"], one_input["media"]) if one_input["media"] else None,
                    overlay=None,
                    coordinate=None,
                    box=None,
                    types=[one_input['type']],
                    srt=None,
                    id=one_input["itemId"],
                    output=item_path,
                ))
                continue
            tts_record_id, face_record_id = self._get_record_ids(data, index, wav_file, face_file, infer_ids)
            wav_path = self._gen_output_path(output_folder, tts_record_id, wav_file)
            srt_path = self._gen_output_path(output_folder, tts_record_id, srt_file)
            containers["record_ids"].append(tts_record_id)

            face_path = ""
            if not one_input["audio_only"]:
                face_path = self._gen_output_path(output_folder, face_record_id, face_file)
                containers["record_ids"].append(face_record_id)

            ctx = TaskContext(
                cluster=containers["cluster"],
                cluster_ws=containers["cluster_ws"],
                tts_record_id=tts_record_id,
                face_record_id= face_record_id,
                item_record_id=item_inference_id,
                wav_path=wav_path,
                srt_path=srt_path,
                face_path=face_path,
                wav_file=wav_file,
                srt_file=srt_file,
                face_file=face_file,
                subtitle=containers["subtitle"],
                one_input=one_input,
                record_output=item_path
            )
            self._gen_pip_tasks(containers["pip_tasks"], ctx)
            self._handle_tts_tasks(one_input, containers, ctx)

            if not one_input["audio_only"]:
                self._handle_face_tasks(one_input, containers, ctx)
                containers["extend_media_tasks"].append((face_path, "video"))
            else:
                containers["extend_media_tasks"].append((wav_path, "audio"))

        containers["infer_ids"] = infer_ids
        return containers
    
    def _handle_tts_tasks(self, one_input, containers, ctx: TaskContext):
        wav_type = "create" if one_input['reuseStatus'] is None or one_input['reuseStatus'] == ItemType.FACE else "re-use"
        self._gen_tts_tasks(containers["tts_tasks"], ctx)
        containers["tts_tasks"].setdefault("wav_type", []).append(wav_type)
        if wav_type == "create":
            self._gen_tts_tasks(containers["tts_infer_tasks"], ctx)
    
    def _handle_face_tasks(self, one_input, containers, ctx: TaskContext):
        video_type = 'create' if one_input['reuseStatus'] is None or one_input['reuseStatus'] == ItemType.TTS else "re-use"
        self._gen_face_tasks(containers["face_tasks"], ctx)
        containers["face_tasks"].setdefault("video_type", []).append(video_type)
        if video_type == 'create':
            self._gen_face_tasks(containers["face_infer_tasks"], ctx)
    
    def _gen_pip_tasks(self, pip_tasks, ctx: TaskContext):
        if ctx.one_input.get("media") is None:
            # none is selected for PicInPic file, only digital human
            main_path = ctx.face_path
            overlay_path = None
            types = ["VIDEO"]
        else:
            # image is selected for PicInPic file
            if ctx.one_input['is_meta_human_background']:
                main_path = ctx.face_path
                overlay_path = self._get_media(ctx.cluster, ctx.one_input["media"])  # type "IMAGE"
                types = ["VIDEO", ctx.one_input['type']]
            else:
                main_path = self._get_media(ctx.cluster, ctx.one_input["media"])
                if ctx.one_input['audio_only']:
                    overlay_path = ctx.wav_path
                    types = [ctx.one_input['type'], "AUDIO"]
                else:
                    overlay_path = ctx.face_path
                    types = [ctx.one_input['type'], "VIDEO"]

        pip_tasks.append(
            PictureInPictureTask(
                main=main_path,
                overlay=overlay_path,
                coordinate=ctx.one_input["coordinate"],
                box=ctx.one_input["box"],
                types=types,
                srt=ctx.srt_path if ctx.subtitle else None,
                id=ctx.item_record_id,
                output=ctx.record_output,
            ))

    def _gen_tts_tasks(self, face_tasks, ctx: TaskContext):
        face_tasks.setdefault("input", []).append(ctx.one_input["text"])

        if ctx.cluster:     
            wav_object = self._gen_record_object(ctx.cluster_ws, ctx.tts_record_id, ctx.wav_file)               
            face_tasks.setdefault("output", []).append(ctx.wav_path)
            face_tasks.setdefault("wav_object", []).append(wav_object)
            if ctx.subtitle:
                # reuse infer entry with wav
                srt_object = self._gen_record_object(ctx.cluster_ws, ctx.tts_record_id, ctx.srt_file)
                face_tasks.setdefault("srt", []).append(ctx.srt_path)
                face_tasks.setdefault("srt_object", []).append(srt_object)
        else:
            face_tasks.setdefault("output", []).append(ctx.wav_path)
            if ctx.subtitle:
                face_tasks.setdefault("srt", []).append(ctx.srt_path)

    def _gen_face_tasks(self, face_tasks, ctx: TaskContext):
        face_tasks.setdefault("input", []).append(ctx.wav_path)
        face_tasks.setdefault("output", []).append(ctx.face_path)
        if ctx.cluster:
            face_object = self._gen_record_object(ctx.cluster_ws, ctx.face_record_id, ctx.face_file) 
            wav_object = self._gen_record_object(ctx.cluster_ws, ctx.tts_record_id, ctx.wav_file)               
            face_tasks.setdefault("wav_object", []).append(wav_object)
            face_tasks.setdefault("face_object", []).append(face_object)

    def pre_process(self, data: dict) -> dict:
        try:
            ret = self._pre_process_impl(data)
        except Exception as e:
            id = data.get("id")
            print(f"Picture in Picture task [{id}] infer pre_process failed: {e}")
            traceback.print_exc()
            if id:
                self._redis.publish(traceback.format_exc(), msg_id=id)
                self._handle_task_data(data, ModelStatus.FAIL)
            return {
                "status": MHStatus.FAILED,
                "error": str(e)
            }
        return ret

    def _select_model(self, type, **kwargs):
        cluster = kwargs["cluster"]
        if type in self._voice_services:
            return VoiceInference(
                kwargs['id'],
                f"{type}_infer",
                self._redis,
                self._enable_log,
                LOG_READ_BUFF_LEN,
                self._send_script_path,
                self._voice_services[type],
                kwargs['task_file'],
                kwargs['prompt_wav_path'],
                kwargs['prompt_text'],
                kwargs['prompt_cut_duration'],
                cluster,
                kwargs['input'],
                kwargs['wav_object'] if cluster else kwargs['output'],
                kwargs['name'],
                kwargs['account_id'],
                kwargs['task_type'],
                srt_file=kwargs.get('srt_object', None) if cluster else kwargs.get('srt', None),
                instruct=kwargs['instruct'],
                seed=kwargs['seed'],
                userBucket=kwargs["userBucket"],
                workspace=kwargs["workSpace"],
                max_workers=COMMON_MAX_WORKER["infer"],
            )
        match type:
            case "latentsync":
                return LatentSyncInference(
                    kwargs['id'],
                    "latentsync_infer",
                    self._redis,
                    self._enable_log,
                    LOG_READ_BUFF_LEN,
                    self._send_script_path,
                    self._ls_config.host,
                    self._ls_config.port,
                    self._ls_config.route_path,
                    kwargs['task_file'],
                    kwargs['ls_video_path'],
                    cluster,
                    kwargs['wav_object'] if cluster else kwargs['input'],
                    kwargs['face_object'] if cluster else kwargs['output'],
                    kwargs['hdtr'],
                    subtitle=False,                    
                    name=kwargs['name'],
                    account_id=kwargs['account_id'],
                    type=kwargs['task_type'],
                    userBucket=kwargs["userBucket"],
                    workspace=kwargs["workSpace"],
                    max_workers=COMMON_MAX_WORKER["infer"],
                )
            case "tts":
                return MetaHumanInference(
                    kwargs['id'],
                    "pip_tts_infer",
                    self._redis,
                    self._enable_log,
                    LOG_READ_BUFF_LEN,
                    MH_ROOT,
                    kwargs['tts_config'],
                    kwargs['task_file'],
                    input=kwargs['input'],
                    output=kwargs['output'],
                    srt_file=kwargs.get('srt', None),
                    max_workers=COMMON_MAX_WORKER["infer"],
                )
            case "face":
                return MetaHumanInference(
                    kwargs['id'],
                    "pip_face_infer",
                    self._redis,
                    self._enable_log,
                    LOG_READ_BUFF_LEN,
                    MH_ROOT,
                    kwargs['face_config'],
                    kwargs['task_file'],
                    input=kwargs['input'],
                    output=kwargs['output'],
                    max_workers=COMMON_MAX_WORKER["infer"],
                )

    def _predict_impl(self, data: dict) -> dict:
        if data["status"] != MHStatus.SUCCESS:
            return data
        id = data.get("id")
        tts_tasks = data.get("tts_tasks")
        tts_infer_tasks = data.get("tts_infer_tasks")
        face_tasks = data.get("face_tasks")
        face_infer_tasks = data.get("face_infer_tasks")

        # tts task
        if tts_tasks:
            if tts_infer_tasks:
                self._execute_tts_tasks(id, data, tts_infer_tasks)
            self._operate_tts_file(data)

        # face task
        if face_tasks:
            if face_infer_tasks:
                self._execute_face_tasks(id, data, face_infer_tasks)
            self._operate_face_file(data)

        for media, type in data["extend_media_tasks"]:
            extend_media(media, type, 0.5)

        self._handle_cancat_video(data)

        if data["cluster"]:
            self._upload_item_video(data)
            infer_object = self._gen_record_object(data["cluster_ws"], id, os.path.basename(data["output"]))               
            self._storage_client.upload(data["cluster_ws"].bucket, infer_object, data["output"])
            data["output"] = gen_bucket_object(data["cluster_ws"].bucket, infer_object)
        print(f"[Picture in Picture]: task [{id}] completes")
        self._handle_task_data(data, ModelStatus.COMPLETE, False)
        return {
            "status": MHStatus.SUCCESS,
            "out": data["output"]
        }

    def _upload_item_video(self, data):
        for pip_task in data["pip_tasks"]:
                infer_record_object = self._gen_record_object(data["cluster_ws"], pip_task.id, os.path.basename(pip_task.output))
                self._storage_client.upload(data["cluster_ws"].bucket, infer_record_object, pip_task.output)
    
    def _execute_tts_tasks(self, id, data, tts_tasks):
        tts_infer_task = self._select_model(
            data["tts_type"],
            id=id,
            tts_config=data.get("tts_config"),
            task_file=data["tts_task_file"],
            prompt_text=data.get("customized_prompt"),
            prompt_wav_path=data.get("prompt_wav_path"),
            prompt_cut_duration=data.get("prompt_cut_duration"),
            instruct=data.get("instruct"),
            seed=data["seed"],
            cluster=data["cluster"],
            userBucket=data["userBucket"],
            workSpace=data["workSpace"],
            name=data["name"],
            account_id=data["account_id"],
            task_type=InferenceType.WHOLE_SUBMIT,
            **tts_tasks
        )
        print(f"[Picture in Picture]: TTS task [{id}] starts to run")
        ret_tts = tts_infer_task.execute_cmd()

        # TTS infer failed
        if ret_tts != 0:
            print(f"[Picture in Picture]: task [{id}] failed: TTS infer: error code: [{ret_tts}]")
            self._handle_task_data(data, ModelStatus.FAIL)
            return {
                "status": MHStatus.FAILED,
            }
    
    def _execute_face_tasks(self, id, data, face_tasks):
        face_infer_task = self._select_model(
            data["face_type"],
            id=id,
            face_config=data.get("face_config"),
            task_file=data["face_task_file"],
            ls_video_path=data.get("ls_video_path"),
            hdtr=data.get("hdtr", False),
            cluster=data["cluster"],
            userBucket=data["userBucket"],
            workSpace=data["workSpace"],
            name=data["name"],
            account_id=data["account_id"],
            task_type=InferenceType.WHOLE_SUBMIT,
            **face_tasks
        )
        print(f"[Picture in Picture]: FACE task [{id}] starts to run")
        ret_face = face_infer_task.execute_cmd()

        # Face infer failed
        if ret_face != 0:
            print(f"[Picture in Picture]: task [{id}] failed: Face infer: error code: [{ret_face}]")
            self._handle_task_data(data, ModelStatus.FAIL)
            return {
                "status": MHStatus.FAILED,
            }
    
    def _operate_tts_file(self, data):
        tts_tasks = data.get("tts_tasks")
        face_tasks = data.get("face_tasks")
        if data["cluster"]:
            if data["tts_type"] == "tts":
                # upload wav and srt to cluster
                for wav, wav_object, wav_type in zip(tts_tasks["output"], tts_tasks["wav_object"], tts_tasks["wav_type"]):
                    if wav_type == "create":
                        self._storage_client.upload(data["cluster_ws"].bucket, wav_object, wav)
                    else:
                        self._storage_client.download_uncache(data["cluster_ws"].bucket, wav_object, wav)
                if tts_tasks.get("srt"):
                    for srt, srt_object, wav_type in zip(tts_tasks["srt"], tts_tasks["srt_object"], tts_tasks["wav_type"]):
                        if wav_type == "create":
                            self._storage_client.upload(data["cluster_ws"].bucket, srt_object, srt)
                        else:
                            self._storage_client.download_uncache(data["cluster_ws"].bucket, srt_object, srt)
                        
            else:
                wav_object = tts_tasks["wav_object"]
                indexes = list(range(len(wav_object)))
                # skip downloading wav output when use latentsync
                if face_tasks and data["face_type"] == "latentsync":
                    indexes = [i for i, item in enumerate(wav_object) if item not in face_tasks["wav_object"]]
                for index in indexes:
                    self._storage_client.download_uncache(data["cluster_ws"].bucket, tts_tasks["wav_object"][index],
                                                            tts_tasks["output"][index])
                if tts_tasks.get("srt"):
                    for srt, srt_object in zip(tts_tasks["srt"], tts_tasks["srt_object"]):
                        self._storage_client.download_uncache(data["cluster_ws"].bucket, srt_object, srt)
        print(f"TTS task [{data.get('id')}] succeeds")
    
    def _operate_face_file(self, data):
        face_tasks = data.get("face_tasks")
        if data["cluster"]:
            if data["face_type"] == "face":
                for video, video_object, video_type in zip(face_tasks["output"], face_tasks["face_object"], face_tasks["video_type"]):
                    if video_type == "create":
                        self._storage_client.upload(data["cluster_ws"].bucket, video_object, video)
                    else:
                        self._storage_client.download_uncache(data["cluster_ws"].bucket, video_object, video)
            else:
                for video, video_object in zip(face_tasks["output"], face_tasks["face_object"]):
                    self._storage_client.download_uncache(data["cluster_ws"].bucket, video_object, video)
        print(f"Face task [{data.get('id')}] succeeds")

    def _handle_cancat_video(self, data):
        id = data.get("id")
        result, info = self._pip.pic_in_pic(data["pip_tasks"], data["output"], data["subtitle"], data["subtitle_styles"],
                                            data["pip_settings"])
        self._redis.publish(info, msg_id=id)
        if not result:
            print(f"[Picture in Picture]: task [{id}] failed: concat video failed")
            self._handle_task_data(data, ModelStatus.FAIL)
            return {
                "status": MHStatus.FAILED,
            }
        
    def _gen_record_object(self, cluster_ws, id, file_name):
        return cluster_ws.gen_infer_object(
            id,
            os.path.basename(file_name)
        ) 

    def predict(self, data: dict) -> dict:
        try:
            ret = self._predict_impl(data)
        except Exception as e:
            id = data.get("id")
            print(f"Picture in Picture task [{id}] infer predict failed: {e}")
            traceback.print_exc()
            if id:
                self._redis.publish(traceback.format_exc(), msg_id=id)
                self._handle_task_data(data, ModelStatus.FAIL)
            return {
                "status": MHStatus.FAILED,
                "error": str(e)
            }
        return ret
    
    def _handle_task_data(self, data, status, clean_infer=True):
        id = data.get("id")
        update_model_status(id, "infer", status, self._redis,
                            upload_func=upload_log_func(id, self._storage_client, MHWorkspace.initialize(**data)),
                            **self._db_args)
        update_items_status(data["infer_item_ids"], status, "infer")
        self._post_task_cleanup(data, status, clean_infer)
        save_notifications(data["account_id"], InferenceType.WHOLE_SUBMIT, status, data["name"], redis=self._redis, **self._db_args)

    def _on_model_downloaded(self, zip_file, yml_name, model_type):
        print(f"PIP Model downloaded: {zip_file}")
        extract_dir = os.path.dirname(zip_file)
        shutil.unpack_archive(zip_file, extract_dir=extract_dir)
        os.remove(zip_file)
        config_file = os.path.join(extract_dir, yml_name)
        old_prefix, model_folder, concat = find_workspace_replace_prefix(config_file)
        replace_workspace_prefix_in_yml(config_file, old_prefix, extract_dir, concat)
        if model_type.lower() == "gaussian":
            diffspeaker_yml = os.path.join(extract_dir, model_folder, "diffspeaker_inference.yml")
            replace_workspace_prefix_in_yml(diffspeaker_yml, old_prefix, extract_dir, concat)

    def _get_tts_model(self, data):
        if data.get("cluster", False):
            parts = data["tts_model"].split("/", 1)
            zip_file = self._storage_client.download(parts[0], parts[1],
                                                     callback=partial(self._on_model_downloaded,
                                                                      yml_name="tts_infer.yml",
                                                                      model_type=data["tts_model_type"]))
            return os.path.dirname(zip_file)
        return os.path.join(self._config.root_workspace, data["tts_model"])

    def _get_face_model(self, data):
        if data.get("cluster", False):
            parts = data["face_model"].split("/", 1)
            zip_file = self._storage_client.download(parts[0], parts[1],
                                                     callback=partial(self._on_model_downloaded,
                                                                      yml_name="face_infer.yml",
                                                                      model_type=data["face_model_type"]))
            return os.path.dirname(zip_file)
        return os.path.join(self._config.root_workspace, data["face_model"])

    def _get_media(self, cluster, media):
        if cluster:
            parts = media.split("/", 1)
            return self._storage_client.download(parts[0], parts[1])
        return os.path.join(self._config.root_dataset, media)

    def _create_infer(self, file_name, account_id, tts_model, face_model, run_service):
        name = os.path.splitext(file_name)[0]
        infer = MetaHumanInfer(
            name=name,
            accountID=account_id,
            ttsModel=tts_model,
            faceModel=face_model,
            runService=run_service,
        )
        return insert_infer(infer, **self._db_args)
    
    def _get_infer_id(self, reuse_status, infer_name, tts_model, face_model, account_id, run_service, infer_ids, group_id) -> str:
        if reuse_status == ItemType.ALL or (reuse_status == ItemType.TTS and tts_model is not None) or (reuse_status == ItemType.FACE and face_model is not None):
            infer_record = find_infer(infer_name, account_id, group_id)
            record_id = infer_record[0]['id']
            infer_ids.remove(record_id)
        else:
            record_id = self._create_infer(infer_name, account_id, tts_model, face_model, run_service)        
        return record_id

    def _post_task_cleanup(self, data, status, clean_infer=True):
        # If no infer group is found, we should clean the infer table and storage
        if clean_infer == False and len(find_infer_group(data["groupId"], **self._db_args)) == 0:
            clean_infer = True

        record_ids = data.get("record_ids", [])
        infer_item_ids = data.get("infer_item_ids", [])
        delete_infer_ids = data.get("infer_ids", [])
        cluster_ws = MHWorkspace.initialize(**data)
        if delete_infer_ids:
            lock_key = f"lock:infer_group:{data.get('groupId')}"
            with self._redis.redis_lock(lock_key):
                delete_infers(delete_infer_ids, **self._db_args)
                if cluster_ws:
                    for delete_infer_id in delete_infer_ids:
                        self._storage_client.remove_objects(cluster_ws.bucket, cluster_ws.gen_infer_prefix(delete_infer_id))
                else:
                    for delete_infer_id in delete_infer_ids:
                        dir_path = os.path.join(self._config.root_workspace, self._config.infer_bucket, delete_infer_id)
                        if os.path.exists(dir_path):
                            shutil.rmtree(dir_path)                           
        dirs = []
        for record_id in record_ids:
            dir_path = os.path.join(self._config.root_workspace, self._config.infer_bucket, record_id)
            if os.path.exists(dir_path):
                dirs.append(dir_path)
        for infer_item_id in infer_item_ids:
            dir_path = os.path.join(self._config.root_workspace, self._config.infer_bucket, infer_item_id)
            if os.path.exists(dir_path):
                dirs.append(dir_path)
        current_task_dir = os.path.join(self._config.root_workspace, self._config.infer_bucket, data["id"])
        if os.path.exists(current_task_dir):
            dirs.append(current_task_dir)
        id = data.get("id")
        if status == MHStatus.FAILED and id and dirs:
            upload_fail_artifacts(
                self._storage_client,
                id,
                dirs,
                cluster_ws,
                self._config.root_workspace,
                self._config.fail_output_dir
            )

        if cluster_ws or clean_infer:
            for dir in dirs:
                shutil.rmtree(dir)

        if clean_infer:
            if cluster_ws:
                for record_id in record_ids:
                    self._storage_client.remove_objects(cluster_ws.bucket, cluster_ws.gen_infer_prefix(record_id))
            if record_ids:
                delete_infers(record_ids, **self._db_args)
        else:
            if record_ids:
                update_infers(record_ids, data["groupId"], **self._db_args)
