from __future__ import annotations

import abc
import os
import shutil
import traceback
import uuid
import json

from hydra.core.typing import SingleProcessModel
from hydra.nlunit.common_utils.minio_client import MinioClient, upload_log_func
from hydra.nlunit.mh_utils.config import MHInferenceConfig
from hydra.nlunit.mh_utils.mh_workspace import MHWorkspace
from hydra.nlunit.mh_utils.redis_logger import RedisLogger
from hydra.nlunit.mh_utils.utils import (
    InferenceType,
    MHModel,
    MHStatus,
    ModelStatus,
    switch_env,
    upload_fail_artifacts,
    save_notifications,
)
from hydra.nlunit.mh_utils.subtitle import generate_subtitle_entries, generate_subtitle_content
from hydra.nlunit.mh_utils.db_utils import update_model_status, update_tts_model, \
    update_tts_model_params

class BaseCustomizedTtsUnit(SingleProcessModel, abc.ABC):

    def __init__(self,config: MHInferenceConfig, device: str, log: bool, service_name: str):
        self._device = device
        self._config = config
        self._enable_log = log
        self._db_args = {}
        self._service_name = service_name
        self._redis = None
        self._storage_client = None

    def load(self):
        self._storage_client = MinioClient(self._config.root_workspace, cache=self._config.shared,
                                               meta_cache=self._config.meta_shared)
        self._redis = RedisLogger(self._service_name, root_log_workspace=self._config.root_log_workspace,
                                      enable=self._enable_log)
        self._load_model()

    @abc.abstractmethod
    def _load_model(self):
        raise NotImplementedError

    def _pre_process_impl(self, data: dict) -> dict:
        id = data.get("id")
        status = data.get("status")
        infer_type = data.get("type")
        print(f"{self._service_name} task [{id}] starts to preprocess")
        switch_env(data, self._redis, self._db_args, self._storage_client)
        if id and status == ModelStatus.WAIT and infer_type != InferenceType.TTS_EXAMPLE:
            print(f"{self._service_name}: update task {id} to RUN")
            update_model_status(id, "infer", ModelStatus.RUN, **self._db_args)
        prompt_wav_path = self._get_wav(data)
        if infer_type == InferenceType.TTS_EXAMPLE:
            abs_output_folder = os.path.dirname(prompt_wav_path)
        elif id:
            abs_output_folder = os.path.join(self._config.root_workspace, self._config.infer_bucket, id)
        else:
            abs_output_folder = os.path.join(self._config.root_workspace, self._config.infer_bucket)
        output_object = None
        srt = data.get("srt", None)
        srt_object = None
        wav_file = f"{data['name']}.wav" if data.get("name") else f"{uuid.uuid1()}.wav"
        if "output_path" in data:
            output_path = data["output_path"]
            if data.get("model_bucket") or data.get("cluster", False):
                output_object = data["output_path"]
                output_path = os.path.join(abs_output_folder, wav_file)
                if srt:
                    srt_object = srt
                    srt_file = f"{data['name']}.json" if data.get("name") else f"{uuid.uuid1()}.json"
                    srt = os.path.join(abs_output_folder, srt_file)
        else:
            output_path = os.path.join(abs_output_folder, wav_file)
        ret = {
            "status": MHStatus.SUCCESS,
            "id": data.get("id", None),
            "type": infer_type,
            "text": data["text"],
            "prompt_wav_path": prompt_wav_path,
            "prompt_text": data["customized_prompt"],
            "seed": data.get("seed", 37),
            "original": data.get("text"),
            "cluster": MHWorkspace.initialize(**data),
            "output_path": output_path,
            "output_object": output_object,
            "srt": srt,
            "srt_object": srt_object,
            "update_status": data.get('type', "") == InferenceType.TTS_ONLY,
            "name": data.get("name", None),
            "account_id": data.get("account_id", None),
            "notify_status": infer_type in [InferenceType.TTS_ONLY, InferenceType.TTS_EXAMPLE]
        }
        if infer_type == InferenceType.TTS_EXAMPLE:
            ret.update(data.get("example_parameter", {}))
        return ret

    def pre_process(self, data: dict) -> dict:
        try:
            ret = self._pre_process_impl(data)
        except Exception as e:
            id = data.get("id")
            print(f"{self._service_name} task [{id}] infer pre_process failed: {e}")
            traceback.print_exc()
            if id:
                self._redis.publish(traceback.format_exc(), msg_id=id)
                table_key = "infer" if data["type"] != InferenceType.TTS_EXAMPLE else "tts"
                update_model_status(id, table_key, ModelStatus.FAIL, self._redis,
                                    upload_func=upload_log_func(id, self._storage_client,
                                                                MHWorkspace.initialize(**data)), **self._db_args)
                if data["type"] in [InferenceType.TTS_ONLY, InferenceType.TTS_EXAMPLE]:
                    save_notifications(data["account_id"], data.get("type"), ModelStatus.FAIL, data['name'], redis=self._redis, **self._db_args)
            return {
                "status": MHStatus.FAILED,
                "error": str(e)
            }
        return ret

    @abc.abstractmethod
    def _predict_impl(self, data: dict) -> None:
        raise NotImplementedError

    def predict(self, data: dict) -> dict:
        if data["status"] != MHStatus.SUCCESS:
            return data
        try:
            self._predict_impl(data)
            ret = self.upload_artifacts(data)
        except Exception as e:
            id = data.get('id')
            print(f"{self._service_name} task [{id}] infer predict failed: {e}")
            traceback.print_exc()
            if id:
                self._redis.publish(traceback.format_exc(), msg_id=id)
                table_key = "infer" if data["type"] != InferenceType.TTS_EXAMPLE else "tts"
                update_model_status(id, table_key, ModelStatus.FAIL, self._redis,
                                    upload_func=upload_log_func(id, self._storage_client, data["cluster"]),
                                    **self._db_args)
                abs_output_folder = os.path.join(self._config.root_workspace, self._config.infer_bucket, id)
                if os.path.exists(abs_output_folder):
                    upload_fail_artifacts(self._storage_client, id, abs_output_folder, data.get("cluster"), self._config.root_workspace, self._config.fail_output_dir)
                if data["notify_status"]:
                    save_notifications(data["account_id"], data.get("type"), ModelStatus.FAIL, data['name'], redis=self._redis, **self._db_args)
            return {
                "status": MHStatus.FAILED,
                "error": str(e)
            }
        return ret

    def upload_artifacts(self, data: dict) -> dict:
        id = data.get("id")
        if data.get("type") == InferenceType.TTS_EXAMPLE:
            self._redis.publish(f"{self._service_name} generates example wav done.", msg_id=id)
            if data["model_bucket"]:
                self._storage_client.upload(data["model_bucket"], data["output_object"], data["output_path"])
                shutil.rmtree(os.path.dirname(data["output_path"]))
            # update model data
            if data["update"]:
                parameter = {'cut_duration': data["cut_duration"], 'customized_prompt': data["prompt_text"]}
                update_tts_model_params(id, ModelStatus.COMPLETE, data["dataset_id"], parameter,
                                        redis=self._redis,
                                        upload_func=upload_log_func(id, self._storage_client, data["cluster"]),
                                        **self._db_args)
            else:
                update_tts_model(id, ModelStatus.COMPLETE, data["dataset_id"], redis=self._redis,
                                 upload_func=upload_log_func(id, self._storage_client, data["cluster"]),
                                 **self._db_args)
            save_notifications(data["account_id"], MHModel.TTS, ModelStatus.COMPLETE, data['name'],
                               redis=self._redis, **self._db_args)
            return {"status": MHStatus.SUCCESS, }

        if data["srt"]:
            if data.get("text_duration_pairs"):
                subtitle_entries = generate_subtitle_entries(data["original"], data["text_duration_pairs"])
                with open(data["srt"], "w", encoding="utf-8") as f:
                    json.dump(subtitle_entries, f, ensure_ascii=False, indent=2)
            else:
                generate_subtitle_content(data["original"], data["output_path"], data["srt"])

        print(f"{self._service_name} task [{id}] succeed")
        if id:
            self._redis.publish(f"{self._service_name} task done", msg_id=id)
        if id and data["cluster"]:
            # upload wav
            infer_object = data.get("output_object") or data["cluster"].gen_infer_object(id, os.path.basename(data["output_path"]))
            self._storage_client.upload(data["cluster"].bucket, infer_object, data["output_path"])
            # upload srt
            if data["srt"]:
                srt_object = data.get("srt_object") or data["cluster"].gen_infer_object(id, os.path.basename(data["srt"]))
                self._storage_client.upload(data["cluster"].bucket, srt_object, data["srt"])
            shutil.rmtree(os.path.dirname(data["output_path"]))
        if id and data["update_status"]:
            print(f"{self._service_name}: update task {id} to COMPLETE")
            update_model_status(id, "infer", ModelStatus.COMPLETE, self._redis,
                                upload_func=upload_log_func(id, self._storage_client, data["cluster"]), **self._db_args)
            if data["notify_status"]:
                save_notifications(data["account_id"], data.get("type"), ModelStatus.COMPLETE, data['name'], redis=self._redis, **self._db_args)
        return {"status": MHStatus.SUCCESS, "output_wav_path": data["output_path"]}

    def _get_wav(self, data):
        if data.get("type") == InferenceType.TTS_EXAMPLE:
            return data["wav_path"]
        if data.get("cluster", False):
            parts = data["wav_path"].split("/", 1)
            return self._storage_client.download(parts[0], parts[1])
        return os.path.join(self._config.root_workspace, data.get("wav_path"))