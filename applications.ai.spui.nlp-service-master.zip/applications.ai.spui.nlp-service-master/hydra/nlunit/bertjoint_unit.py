import logging
import os

from ..core.resource import model
from ..core.typing import BatchProcessModel, SingleProcessModel
from .common import NotFoundError, ProcessError


@model("BertJointBatchUnit")
class BertJointBatchUnit(BatchProcessModel):

    def __init__(self, kernel_folder, kernel_name, download=False):
        self._kernel_folder = kernel_folder
        self._kernel_name = kernel_name
        self._nlu_kernel = None
        self._enable_download = download

    def load(self):
        from nlukernel import NLUKernel
        status = True
        if self._enable_download:
            from .utils import download_model
            status = download_model(self._kernel_folder, self._kernel_name)
        if status:
            _kernel_path = os.path.join(self._kernel_folder, self._kernel_name, "")
            self._nlu_kernel = NLUKernel.from_saved(_kernel_path, local_tokenizer=True, log_level=logging.WARNING)
        else:
            self._nlu_kernel = None

    def reload(self, name):
        if name != self._kernel_name:
            if self._nlu_kernel is not None:
                pass
            self._kernel_name = name
            self.load()

    def pre_process(self, data) -> object:
        return data

    def predict(self, data: list) -> list:
        if self._nlu_kernel:
            return self._nlu_kernel.predict(data)
        return [NotFoundError for i in range(len(data))]

    def get_name(self):
        return self._kernel_name

    def set_download(self, download: bool):
        self._enable_download = download

@model("BertJointUnit")
class BertJointUnit(SingleProcessModel):

    def __init__(self, kernel_folder, kernel_name, download=False):
        self._kernel_folder = kernel_folder
        self._kernel_name = kernel_name
        self._nlu_kernel = None
        self._enable_download = download

    def load(self):
        from nlukernel import NLUKernel
        # TODO: handle error during download
        status = True
        if self._enable_download:
            status = download_model(self._kernel_folder, self._kernel_name)
        if status:
            _kernel_path = os.path.join(self._kernel_folder, self._kernel_name, "")
            self._nlu_kernel = NLUKernel.from_saved(_kernel_path, local_tokenizer=True, log_level=logging.WARNING)
        else:
            self._nlu_kernel = None

    def reload(self, name):
        if name != self._kernel_name:
            if self._nlu_kernel is not None:
                pass
            self._kernel_name = name
            self.load()

    def pre_process(self, data) -> object:
        return data

    def predict(self, data):
        if self._nlu_kernel:
            ret = self._nlu_kernel.predict([data])
            if len(ret):
                return ret[0]
            return ProcessError
        return NotFoundError

    def get_name(self):
        return self._kernel_name

    def set_download(self, download: bool):
        self._enable_download = download
