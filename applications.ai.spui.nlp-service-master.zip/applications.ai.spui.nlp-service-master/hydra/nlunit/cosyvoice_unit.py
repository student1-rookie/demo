import os
import re
import uuid
from pathlib import Path

from hydra.core.resource import model
from hydra.nlunit.base_customized_tts_unit import BaseCustomizedTtsUnit
from hydra.nlunit.mh_utils.config import MHInferenceConfig
from hydra.nlunit.mh_utils.mh_workspace import MHWorkspace
from hydra.nlunit.mh_utils.utils import (
    ModelStatus, MHStatus, save_audio, InferenceType, set_seed, switch_env
)
from hydra.nlunit.mh_utils.subtitle import contains_chinese
from hydra.nlunit.mh_utils.db_utils import update_model_status


def _uppercase_converter(text):
    brackets = {
        True: ('《', '》'),
        False: ('(', ')')
    }
    open_bracket, close_bracket = brackets[contains_chinese(text)]

    def _replace(word):
        uppercase_count = sum(1 for c in word if c.isupper())
        if uppercase_count > 1:
            return open_bracket + ' '.join(word) + close_bracket
        return word

    def _process_word(word):
        sub_words = re.split(r'([A-Za-z]+)', word)
        processed_sub_words = [_replace(sub_word) if sub_word.isalpha() else sub_word for sub_word in sub_words]
        return ''.join(processed_sub_words)

    words = re.split(r'(\W+)', text)
    processed_words = [_process_word(word) for word in words]
    framed_text = ''.join(processed_words)
    return framed_text


def _restore_uppercase(text: str) -> str:
    pattern = re.compile(r'[《(]\s*([A-Za-z](?:\s[A-Za-z])+)[》)]')

    def _unframe(match: re.Match) -> str:
        return match.group(1).replace(' ', '')

    return pattern.sub(_unframe, text)


def _generate_instruction(is_chinese: bool, instruct: dict) -> str:
    emotion = instruct.get("emotion")
    speed = instruct.get("speed_rate")

    emotion_map = {
        "happy": "高兴", "sad": "悲伤", "surprised": "惊讶",
        "angry": "愤怒", "fearful": "恐惧", "disgusted": "厌恶",
        "calm": "冷静", "serious": "严肃",
    }

    speed_map = {
        "fast": "快速", "very fast": "非常快速",
        "slow": "慢速", "very slow": "非常慢速",
    }

    if is_chinese:
        parts = []
        if emotion:
            parts.append(emotion_map.get(emotion, emotion))
        if speed:
            parts.append(speed_map.get(speed, speed))
        return f"请用{'、'.join(parts)}的语气说。" if parts else "请正常说。"
    else:
        parts = []
        if emotion:
            parts.append(emotion)
        if speed:
            parts.append(speed)
        return f"Please speak in a {' and '.join(parts)} tone." if parts else "Please speak normally."


@model("CosyVoiceUnit")
class CosyVoiceUnit(BaseCustomizedTtsUnit):

    def __init__(self, kernel_path: str, config: MHInferenceConfig, device: str, log: bool):
        super().__init__(config=config, device=device, log=log, service_name="CosyVoice")
        self._kernel_path = kernel_path
        self._cosyvoice = None

    def _load_model(self):
        from cosyvoice.cli.cosyvoice import CosyVoice2
        self._cosyvoice = CosyVoice2(self._kernel_path, load_jit=False, load_trt=False, fp16=False, device=self._device)
        print("cosyvoice_unit loaded under", self._device)

    def _pre_process_impl(self, data: dict) -> dict:
        from cosyvoice.utils.file_utils import load_wav
        id = data.get("id")
        status = data.get("status")
        infer_type = data.get("type")
        print(f"CosyVoice task [{id}] starts to preprocess")
        switch_env(data, self._redis, self._db_args, self._storage_client)
        if id and status == ModelStatus.WAIT and infer_type != InferenceType.TTS_EXAMPLE:
            print(f"cosyvoice: update task {id} to RUN")
            update_model_status(id, "infer", ModelStatus.RUN, **self._db_args)

        prompt_wav_path = self._get_wav(data)
        prompt_speech_16k = load_wav(prompt_wav_path, 16000)
        prompt_text = data.get("customized_prompt")
        text = data.get("text")
        text_input = _uppercase_converter(text)
        if id:
            self._redis.publish(f"text: {text}", msg_id=id)
            self._redis.publish(f"pre-processed text: {text_input}", msg_id=id)

        if infer_type == InferenceType.TTS_EXAMPLE:  # after register
            abs_output_folder = os.path.dirname(prompt_wav_path)
        elif id:
            abs_output_folder = os.path.join(self._config.root_workspace, self._config.infer_bucket, id)
        else:
            abs_output_folder = os.path.join(self._config.root_workspace, self._config.infer_bucket)

        srt = data.get("srt", None)
        srt_object = None
        output_object = None
        wav_file = f"{data['name']}.wav" if data.get("name") else f"{uuid.uuid1()}.wav"
        if "output_path" in data:
            output_path = data["output_path"]
            if data.get("model_bucket") or data.get("cluster", False):
                output_object = data["output_path"]
                output_path = os.path.join(abs_output_folder, wav_file)
                if srt:
                    srt_object = srt
                    srt_file = f"{data['name']}.json" if data.get("name") else f"{uuid.uuid1()}.json"
                    srt = os.path.join(abs_output_folder, srt_file)
        else:
            output_path = os.path.join(abs_output_folder, wav_file)

        result = {
            "status": MHStatus.SUCCESS,
            "id": data.get("id", None),
            "type": infer_type,
            "prompt_wav": prompt_speech_16k,
            "prompt_text": prompt_text,
            "seed": data.get("seed", 37),
            "input": text_input,
            "original": data.get("text"),
            "output_path": output_path,
            "output_object": output_object,
            "srt": srt,
            "srt_object": srt_object,
            "instruct": data.get("instruct"),
            "update_status": infer_type == InferenceType.TTS_ONLY,
            "cluster": MHWorkspace.initialize(**data),
            "name": data.get("name", None),
            "account_id": data.get("account_id", None),
            "notify_status": infer_type in [InferenceType.TTS_ONLY, InferenceType.TTS_EXAMPLE]
        }
        if infer_type == InferenceType.TTS_EXAMPLE:
            result.update(data.get("example_parameter", {}))
        return result

    def _predict_impl(self, data: dict) -> None:
        id = data.get("id")
        print(f"CosyVoice task [{id}] starts to run", self._device, os.getpid())
        set_seed(data["seed"])
        res = []
        text_duration_pairs = []

        text = data["input"]
        prompt_text = data["prompt_text"]
        instruct = data.get("instruct")
        prompt_wav = data["prompt_wav"]
        input_is_cn = contains_chinese(text)
        prompt_is_cn = contains_chinese(prompt_text)

        if instruct:
            generated_instruct = _generate_instruction(input_is_cn, instruct)
            if id:
                self._redis.publish(f"call inference_instruct2: {generated_instruct}", msg_id=id)
            iterator = self._cosyvoice.inference_instruct2(text, generated_instruct, prompt_wav, stream=False)
        elif input_is_cn == prompt_is_cn:
            if id:
                self._redis.publish("call inference_zero_shot", msg_id=id)
            iterator = self._cosyvoice.inference_zero_shot(text, prompt_text, prompt_wav, stream=False)
        else:
            if id:
                self._redis.publish("call inference_cross_lingual", msg_id=id)
            iterator = self._cosyvoice.inference_cross_lingual(text, prompt_wav, stream=False)

        for j in iterator:
            res.append(j["tts_speech"])
            text_duration_pairs.append((_restore_uppercase(j["text"]), j["speech_len"]))

        Path(os.path.dirname(data["output_path"])).mkdir(parents=True, exist_ok=True)
        save_audio(res, self._cosyvoice.sample_rate, data["output_path"])
        data["text_duration_pairs"] = text_duration_pairs