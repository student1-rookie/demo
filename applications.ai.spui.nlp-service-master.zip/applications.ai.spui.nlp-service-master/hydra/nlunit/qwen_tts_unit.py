from pathlib import Path
import os

import numpy as np

from hydra.core.resource import model
from hydra.nlunit.base_customized_tts_unit import BaseCustomizedTtsUnit
from hydra.nlunit.mh_utils.subtitle import contains_chinese
from hydra.nlunit.mh_utils.utils import save_audio_by_sf, set_seed

QWEN3_TTS_SAMPLE_RATE = 24000
QWEN3_TTS_STREAM_CHUNK_SIZE = 240
QWEN3_TTS_STREAM_OVERLAP_SIZE = 48


@model("QwenTTSUnit")
class QwenTTSUnit(BaseCustomizedTtsUnit):

    def __init__(self, model_path: str, config, device: str, log: bool):
        super().__init__(config=config, device=device, log=log, service_name="QwenTTS")
        self._model_path = model_path
        self._model = None

    def _load_model(self):
        import torch
        from qwen_tts import Qwen3TTSModel

        self._model = Qwen3TTSModel.from_pretrained(
            self._model_path, 
            device_map=self._device,
            dtype=torch.bfloat16,
            attn_implementation="flash_attention_2",
        )
        
    def _predict_impl(self, data: dict) -> None:
        set_seed(data["seed"])
        language = "Chinese" if contains_chinese(data["text"]) else "English"

        clone_prompt = self._model.create_voice_clone_prompt(
            ref_audio=data["prompt_wav_path"],
            ref_text=data["prompt_text"]
        )

        stream_gen = self._model.generate_voice_clone(
            ref_audio=data["prompt_wav_path"],
            ref_text=data["prompt_text"],
            text=data["text"],
            prompt=clone_prompt,
            language=language,
            stream=True,
            stream_chunk_size=QWEN3_TTS_STREAM_CHUNK_SIZE,
            stream_overlap_size=QWEN3_TTS_STREAM_OVERLAP_SIZE
        )
        audio_chunks = []
        for chunk in stream_gen:
            if not isinstance(chunk, np.ndarray):
                chunk = np.asarray(chunk)
            if chunk.ndim == 0:
                chunk = chunk.reshape(1)
            elif chunk.ndim == 2:
                if 1 in chunk.shape:
                    chunk = chunk.reshape(-1)
                else:
                    raise ValueError(f"Unsupported audio chunk shape: {chunk.shape}")
            elif chunk.ndim > 2:
                raise ValueError(f"Unexpected audio chunk dimension: {chunk.ndim}, shape={chunk.shape}")
            audio_chunks.append(chunk.astype(np.float32, copy=False))
        if not audio_chunks:
            raise ValueError("Audio generator produced no valid data")
        audio_data = np.concatenate(audio_chunks, axis=0)
    
        Path(os.path.dirname(data["output_path"])).mkdir(parents=True, exist_ok=True)
        save_audio_by_sf(audio_data, QWEN3_TTS_SAMPLE_RATE, data["output_path"])
