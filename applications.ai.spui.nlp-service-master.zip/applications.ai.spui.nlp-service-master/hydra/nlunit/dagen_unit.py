from .common import NotFoundError
from ..core.resource import model
from ..core.typing import BatchProcessModel, SingleProcessModel

from dagen.modules.smm import SharedMemoryClient, Action


@model("DagenBatchUnit")
class DagenBatchUnit(BatchProcessModel):

    def __init__(self, shm_name):
        self._name = shm_name
        self._smc = SharedMemoryClient(shm_name)
        self._ground_truth: dict = {}

    def load(self):
        pass

    def get_name(self) -> str:
        return self._name

    def pre_process(self, data) -> object:
        return data

    def predict(self, data: list) -> list:
        return [self._ground_truth.get(d, NotFoundError) for d in data]

    def loop_process(self):
        action, data = self._smc.get_ctl()
        if action == Action.CREATE:
            self._ground_truth = data
        elif action == Action.ADD:
            self._ground_truth.update(data)
        elif action == Action.CLOSE:
            self._smc.close()
