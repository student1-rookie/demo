from ..core.resource import model
from ..core.typing import BatchProcessModel, SingleProcessModel
from . import NluType


@model("NLBatchUnit")
class NLBatchUnit(BatchProcessModel):

    def __init__(self, kernel_path, nlu_type=NluType.ALL):
        self._kernel_path = kernel_path
        self._nlu_kernel = None
        self._nlu_type = nlu_type

    def load(self):
        from kernel import NLUKernel
        self._nlu_kernel = NLUKernel(self._kernel_path)

    def pre_process(self, data) -> object:
        return data

    def predict(self, data: list) -> list:
        from kernel.utils import get_slots
        if self._nlu_type == NluType.CLS:
            results = self._nlu_kernel.predict_cls(data)
            return list(map(lambda x: {"intent": x}, results))
        elif self._nlu_type == NluType.NER:
            ner_results = self._nlu_kernel.predict_ner(data)
            results = [
                {
                    "slots": get_slots(text, ret)
                } for text, ret in zip(data, ner_results)
            ]
            return results
        else:
            results = self._nlu_kernel.predict(data)
            return results


@model("NLUnit")
class NLUnit(SingleProcessModel):

    def __init__(self, kernel_path, nlu_type=NluType.ALL):
        self._kernel_path = kernel_path
        self._nlu_kernel = None
        self._nlu_type = nlu_type

    def load(self):
        from kernel import NLUKernel
        self._nlu_kernel = NLUKernel(self._kernel_path)

    def pre_process(self, data) -> object:
        return data

    def predict(self, data):
        from kernel.utils import get_slots
        if self._nlu_type == NluType.CLS:
            results = self._nlu_kernel.predict_cls([data])
            return {"intent": results[0]}
        elif self._nlu_type == NluType.NER:
            results = self._nlu_kernel.predict_ner([data])
            return {"slots": get_slots(data, results[0])}
        else:
            results = self._nlu_kernel.predict([data])
            return results[0]
