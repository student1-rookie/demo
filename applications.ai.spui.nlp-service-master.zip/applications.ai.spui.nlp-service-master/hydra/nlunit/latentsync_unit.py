import shutil
from dataclasses import dataclass
from typing import Optional
import os
import os.path
import uuid
import traceback
import json
from pathlib import Path

from hydra.core.resource import model
from hydra.core.typing import SingleProcessModel
from hydra.nlunit.common_utils.minio_client import MinioClient, upload_log_func
from hydra.nlunit.mh_utils.config import MHInferenceConfig
from hydra.nlunit.mh_utils.mh_workspace import MHWorkspace
from hydra.nlunit.mh_utils.utils import (
    ModelStatus, InferenceType, get_root_path, extract_first_frame, MHStatus, switch_env, save_notifications, MHModel, upload_fail_artifacts
)
from hydra.nlunit.mh_utils.subtitle import add_subtitles
from hydra.nlunit.mh_utils.db_utils import update_model_status
from hydra.nlunit.mh_utils.redis_logger import RedisLogger


@dataclass
class LatentSyncModelConfig:
    scheduler: str
    unet: str = ""
    unet_config: str = ""
    whisper: str = ""
    vae: str = ""

    def load_model_path(self, model_path):
        self.unet = os.path.join(model_path, "latentsync_unet.pt")
        self.whisper = os.path.join(model_path, "whisper/tiny.pt")
        self.vae = os.path.join(model_path, "sd-vae-ft-mse")
        self.unet_config = os.path.join(self.scheduler, "unet/second_stage.yaml")


@dataclass
class LatentSyncConfig:
    ls_model_path: str
    ls_model_precision: str
    ls_device: str
    hdtr_model_path: str
    hdtr_batch_size: int
    hdtr_device: str
    ls_infer_steps: int = 20
    ls_guidance_scale: float = 0.1


@model("LatentSyncUnit")
class LatentSyncUnit(SingleProcessModel):

    def __init__(self, ls_config: LatentSyncConfig, config: MHInferenceConfig, log: bool):
        self._config = config
        self._ls_config = ls_config
        self._enable_log = log
        self._ls_pipeline = None
        self._ls_model_config = LatentSyncModelConfig(
            scheduler=os.path.join(get_root_path(), "third_party/LatentSync/configs"))
        self._ls_model_config.load_model_path(self._ls_config.ls_model_path)
        self._ls_pipeline_config = None
        self._hdtr_model = None
        self._redis: Optional[RedisLogger] = None
        self._storage_client: Optional[MinioClient] = None
        self._db_args = {}

    def load(self):
        from hydra.nlunit.mh_utils.latentsync_utils import load_latentsync_model, load_hdtr_model
        self._ls_pipeline, self._ls_pipeline_config = load_latentsync_model(self._ls_model_config,
                                                                            self._ls_config.ls_model_precision,
                                                                            self._ls_config.ls_device)
        self._hdtr_model = load_hdtr_model(self._ls_config.hdtr_model_path, self._ls_config.hdtr_device)
        self._redis = RedisLogger("LatentSyncUnit", root_log_workspace=self._config.root_log_workspace,
                                  enable=self._enable_log)
        self._storage_client = MinioClient(self._config.root_dataset, cache=self._config.shared,
                                           meta_cache=self._config.meta_shared)

    def _pre_process_impl(self, data: dict) -> dict:
        id = data.get("id")
        status = data.get("status")
        print(f"LatentSync task [{id}] starts to preprocess")
        task_type = data.get("type", None)
        switch_env(data, self._redis, self._db_args, self._storage_client)
        if id and status == ModelStatus.WAIT:
            update_model_status(data["id"], "infer", ModelStatus.RUN, **self._db_args)

        if id:
            abs_output_folder = os.path.join(self._config.root_workspace, self._config.infer_bucket, id)
        else:
            abs_output_folder = os.path.join(self._config.root_workspace, self._config.infer_bucket)
        Path(abs_output_folder).mkdir(parents=True, exist_ok=True)

        cluster_ws = MHWorkspace.initialize(**data)
        video_path = self._get_video(data)
        srt = data.get("srt")
        if task_type == InferenceType.FACE_ONLY:
            audio_path = self._get_audio(data)
        elif data.get("cluster", False):
            audio_path = self._get_uncached_object(cluster_ws.bucket, data["audio_path"], abs_output_folder)
            srt = self._get_uncached_object(cluster_ws.bucket, srt, abs_output_folder) if srt else None
        else:
            audio_path = data["audio_path"]

        num_inference_steps = data.get("num_inference_steps", self._ls_config.ls_infer_steps)
        guidance_scale = data.get("guidance_scale", self._ls_config.ls_guidance_scale)

        output_object = None
        video_file = f"{data['name']}.mp4" if data.get("name") else f"{uuid.uuid1()}.mp4"
        if "output_path" in data:
            output_path = data["output_path"]
            if data.get("cluster", False):
                output_object = data["output_path"]
                output_path = os.path.join(abs_output_folder, video_file)
        else:
            output_path = os.path.join(abs_output_folder, video_file)

        res = {
            "status": MHStatus.SUCCESS,
            "id": data.get("id", None),
            "hdtr": data.get("hdtr", False),
            "video_path": video_path,
            "audio_path": audio_path,
            "output_path": output_path,
            "output_object": output_object,
            "update_status": data.get("type", "") == InferenceType.FACE_ONLY or data.get("update_status", False),
            "subtitle": data.get("subtitle", False),
            "srt": srt,
            "subtitle_styles": data.get("subtitle_styles", {}),
            "ls_extra": {
                "num_inference_steps": num_inference_steps,
                "guidance_scale": guidance_scale,
            },
            "cluster": cluster_ws,
            "event_channel": data.get("event_channel", None),
            "name": data.get("name", None),
            "account_id": data.get("account_id", None),
            "type": data.get("type", ""),
            "notify_status": data.get("type", "") in [InferenceType.FACE_ONLY, InferenceType.WHOLE]
        }

        return res

    def pre_process(self, data: dict) -> dict:
        try:
            ret = self._pre_process_impl(data)
        except Exception as e:
            id = data.get("id")
            print(f"LatentSync task [{id}] infer pre_process failed: {e}")
            traceback.print_exc()
            if id:
                self._redis.publish(traceback.format_exc(), msg_id=id)
                update_model_status(id, "infer", ModelStatus.FAIL, self._redis,
                                    upload_func=upload_log_func(id, self._storage_client,
                                                                MHWorkspace.initialize(**data)), **self._db_args)
                abs_output_folder = os.path.join(self._config.root_workspace, self._config.infer_bucket, id)
                if os.path.exists(abs_output_folder):
                    upload_fail_artifacts(self._storage_client, id, abs_output_folder, data.get("cluster"), self._config.root_workspace, self._config.fail_output_dir)
                if data.get("type", "") in [InferenceType.FACE_ONLY, InferenceType.WHOLE]:
                    save_notifications(data["account_id"], data["type"], ModelStatus.FAIL, data['name'],
                                       redis=self._redis, **self._db_args)
            return {
                "status": MHStatus.FAILED,
                "error": str(e)
            }
        return ret

    def _predict_impl(self, data: dict) -> dict:
        from hydra.nlunit.mh_utils.latentsync_utils import latentsync_inference
        if data["status"] != MHStatus.SUCCESS:
            return data
        id = data.get("id")
        print(f"LatentSync task [{id}] starts to run")
        subtitle = data["subtitle"]
        hdtr = data["hdtr"]
        final_video_output = data["output_path"]
        if subtitle:
            ls_video_output = os.path.join(os.path.dirname(final_video_output), f"ls_{uuid.uuid1()}.mp4")
            hdtr_video_output = os.path.join(os.path.dirname(final_video_output), f"hdtr_{uuid.uuid1()}.mp4")
        elif hdtr:
            ls_video_output = os.path.join(os.path.dirname(final_video_output), f"ls_{uuid.uuid1()}.mp4")
            hdtr_video_output = final_video_output
        else:
            ls_video_output = final_video_output

        ret = latentsync_inference(self._ls_pipeline, self._ls_pipeline_config, data["video_path"],
                                   data["audio_path"], ls_video_output, self._ls_config.ls_model_precision,
                                   data["ls_extra"])
        if ret != 0:
            update_model_status(id, "infer", ModelStatus.FAIL, self._redis, **self._db_args)
            return {
                "status": MHStatus.FAILED,
            }

        self._redis.publish("LatentSync inference completed!", msg_id=id)
        if hdtr:
            # preprocess for hdtr
            print(f"HDTR task [{id}] starts to run")
            from hydra.nlunit.mh_utils.latentsync_utils import hdtr_inference

            hdtr_inference(self._hdtr_model, self._ls_config.hdtr_batch_size, ls_video_output,
                           hdtr_video_output, self._ls_config.hdtr_device)
            os.remove(ls_video_output)
            print(f"HDTR task [{id}] succeed")
            self._redis.publish("HDTR inference completed!", msg_id=id)

        if subtitle:
            input_video = hdtr_video_output if hdtr else ls_video_output
            add_subtitles(input_video, data["audio_path"], data["srt"], final_video_output, data["subtitle_styles"])
            os.remove(input_video)
            if id:
                self._redis.publish("Add subtitle completed!", msg_id=id)

        print(f"LatentSync task [{id}] succeed")
        if id and data["cluster"]:
            infer_object = data.get("output_object") or data["cluster"].gen_infer_object(id, os.path.basename(final_video_output))
            self._storage_client.upload(data["cluster"].bucket, infer_object, final_video_output)
            shutil.rmtree(os.path.dirname(final_video_output))
        if id and data["update_status"]:
            update_model_status(id, "infer", ModelStatus.COMPLETE, self._redis,
                                upload_func=upload_log_func(id, self._storage_client, data["cluster"]), **self._db_args)
            if data["notify_status"]:
                save_notifications(data["account_id"], data["type"], ModelStatus.COMPLETE, data['name'],
                                   redis=self._redis, **self._db_args)
        return {
            "status": MHStatus.SUCCESS,
            "output_video_path": final_video_output
        }

    def predict(self, data):
        try:
            ret = self._predict_impl(data)
        except Exception as e:
            id = data.get("id")
            print(f"LatentSync task [{id}] infer predict failed: {e}")
            traceback.print_exc()
            if id:
                self._redis.publish(traceback.format_exc(), msg_id=id)
                update_model_status(id, "infer", ModelStatus.FAIL, self._redis,
                                    upload_func=upload_log_func(id, self._storage_client, data["cluster"]),
                                    **self._db_args)
                abs_output_folder = os.path.join(self._config.root_workspace, self._config.infer_bucket, id)
                if os.path.exists(abs_output_folder):
                    upload_fail_artifacts(self._storage_client, id, abs_output_folder, data.get("cluster"), self._config.root_workspace, self._config.fail_output_dir)
                if data["notify_status"]:
                    save_notifications(data["account_id"], data["type"], ModelStatus.FAIL, data['name'],
                                       redis=self._redis, **self._db_args)
            ret = {
                "status": MHStatus.FAILED,
                "error": str(e)
            }
        if data.get("event_channel"):
            self._redis.set_event(data["event_channel"], json.dumps(ret))
        return ret

    def _get_video(self, data):
        if data.get("cluster", False):
            parts = data["video_path"].split("/", 1)
            return self._storage_client.download(parts[0], parts[1])
        return os.path.join(self._config.root_dataset, data["video_path"])

    def _get_audio(self, data):
        if data.get("cluster", False):
            parts = data["audio_path"].split("/", 1)
            return self._storage_client.download(parts[0], parts[1])
        return os.path.join(self._config.root_workspace, data["audio_path"])

    def _get_uncached_object(self, bucket, object, target_folder):
        target_path = os.path.join(target_folder, os.path.basename(object))
        self._storage_client.download_uncache(bucket, object, target_path)
        return target_path


@model("LatentSyncRegisterUnit")
class LatentSyncRegisterUnit(SingleProcessModel):
    def __init__(self, config: MHInferenceConfig, log: bool):
        self._config = config
        self._storage_client: Optional[MinioClient] = None
        self._redis: Optional[RedisLogger] = None
        self._db_args = {}
        self._enable_log = log

    def load(self):
        self._storage_client = MinioClient(self._config.root_dataset, cache=self._config.shared,
                                           meta_cache=self._config.meta_shared)
        self._redis = RedisLogger("LatentSyncRegisterUnit", root_log_workspace=self._config.root_log_workspace,
                                  enable=self._enable_log)

    def pre_process(self, data):
        switch_env(data, None, self._db_args, self._storage_client)
        data["cluster"] = MHWorkspace.initialize(**data)
        return data

    def predict(self, data):
        mh_id = data.get("mh_id")
        avatar_path = self._get_avatar_path(data)
        Path(avatar_path).mkdir(parents=True, exist_ok=True)
        avatar_file_path = os.path.join(avatar_path, "avatar.jpg")
        preview_file_path = os.path.join(avatar_path, "preview.jpg")
        video_path = self._get_video(data)
        try:
            extract_first_frame(video_path, avatar_file_path)
            extract_first_frame(video_path, preview_file_path, scale=False)
            if mh_id:
                if data["cluster"]:
                    self._storage_client.upload(data["cluster"].bucket,
                                                data["cluster"].gen_model_object(mh_id, "avatar/avatar.jpg"),
                                                avatar_file_path)
                    self._storage_client.upload(data["cluster"].bucket,
                                                data["cluster"].gen_model_object(mh_id, "avatar/preview.jpg"),
                                                preview_file_path)
                    shutil.rmtree(avatar_path)
                update_model_status(mh_id, "face", ModelStatus.COMPLETE, **self._db_args)
                self._save_notifications(data, ModelStatus.COMPLETE)
        except Exception as e:
            print(e)
            if mh_id:
                update_model_status(mh_id, "face", ModelStatus.FAIL, **self._db_args)
                self._save_notifications(data, ModelStatus.FAIL)
        return "done"

    def _get_avatar_path(self, data):
        if data["cluster"]:
            return os.path.join("/tmp", data["id"])
        return os.path.join(self._config.root_workspace, data["id"], "avatar")

    def _get_video(self, data):
        if data["cluster"]:
            parts = data["dataset"].split("/", 1)
            return self._storage_client.download(parts[0], parts[1])
        return os.path.join(self._config.root_dataset, data["dataset"])

    def _save_notifications(self, data, status):
        save_notifications(data["account_id"], MHModel.FACE, status, data['name'], redis=self._redis, **self._db_args)
