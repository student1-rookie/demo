import os
from minio import Minio, S3Error

MINIO_SERVER = '192.168.1.20'
MINIO_PORT = 9999

ACCESS_KEY = 'intel123'
SECRET_KEY = 'intel123'

MODEL_BUCKET = 'dagennlu'


def download_model(folder_path: str, model_name: str) -> bool:
    client = Minio(MINIO_SERVER + ':' + str(MINIO_PORT),
                   access_key=ACCESS_KEY,
                   secret_key=SECRET_KEY, secure=False)
    # start_ts = time.time()
    model_folder = os.path.join(folder_path, model_name, '')
    if validate_model_files(model_folder):
        return True
    if not os.path.exists(model_folder):
        os.mkdir(model_folder)
    try:
        is_exist = client.bucket_exists(MODEL_BUCKET)
        if is_exist:
            objects = client.list_objects(bucket_name=MODEL_BUCKET, recursive=True, prefix=model_name)
            for obj in objects:
                if '.bin' in obj.object_name or '.json' in obj.object_name or '.txt' in obj.object_name:
                    model_file_name = obj.object_name.split('/')[1]
                    model_file_path = os.path.join(model_folder, model_file_name)
                    # Get model object
                    obj_data = client.get_object(MODEL_BUCKET, obj.object_name)
                    with open(model_file_path, 'wb') as file_data:
                        for d in obj_data.stream(32 * 1024):
                            file_data.write(d)
                    # print('Download file:', model_file_path)
            # print("timing: ", time.time() - start_ts)
            return validate_model_files(model_folder)
        print("Can not find {}".format(MODEL_BUCKET))
        return False
    except S3Error as err:
        print("Connection fail!")
        print(err)
        return False


MODEL_FILES = ['config.json', 'labels.bin', 'model_configs.json', 'pytorch_model.bin', 'tokenizer_config.json',
               'tokenizer.json', 'vocab.txt']


def validate_model_files(model_dir: str) -> bool:
    if not os.path.exists(model_dir):
        return False
    for f in MODEL_FILES:
        model_file = os.path.join(model_dir, f)
        if not os.path.isfile(model_file):
            return False
    return True
