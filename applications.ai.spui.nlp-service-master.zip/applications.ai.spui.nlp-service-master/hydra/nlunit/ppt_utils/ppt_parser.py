import os
import subprocess
import shlex
from collections import namedtuple

from pptx import Presentation

SlideInfo = namedtuple(
    'SlideInfo', ['path', 'note'])


def _convert_pptx_to_pdf(pptx_path, output_dir):
    cmd = ' '.join(['libreoffice', '--headless', '--convert-to', 'pdf', shlex.quote(pptx_path), '--outdir',
                    shlex.quote(output_dir)])
    p = subprocess.run(['/bin/bash', '-c', cmd], capture_output=True, shell=False)
    if p.returncode != 0:
        raise Exception(f"Failed to convert pptx to pdf: {p.stdout}\n stderr: {p.stderr}")


def _convert_pdf_to_images(pdf_file, output_image_path):
    cmd = ' '.join(
        ['magick', '-density', '288', shlex.quote(pdf_file), '-quality', '90', shlex.quote(output_image_path)])
    p = subprocess.run(['/bin/bash', '-c', cmd], capture_output=True, shell=False)
    if p.returncode != 0:
        raise Exception(f"Failed to convert pdf to images: {p.stdout}\n stderr: {p.stderr}")


def _extract_slide_notes(pptx_path, output_image_path):
    prs = Presentation(pptx_path)
    notes = []
    for i, slide in enumerate(prs.slides):
        if slide.has_notes_slide:
            notes_text = slide.notes_slide.notes_text_frame.text
        else:
            notes_text = ""
        image_path = output_image_path % i
        if os.path.isfile(image_path):
            notes.append(SlideInfo(image_path, notes_text))
        else:
            print(f"Missing slide img for {i}!")
    return notes


def process_pptx(pptx_path, output_dir):
    os.makedirs(output_dir, exist_ok=True)

    _convert_pptx_to_pdf(pptx_path, output_dir)

    file_prefix = os.path.splitext(os.path.basename(pptx_path))[0]
    pdf_path = os.path.join(output_dir, f"{file_prefix}.pdf")
    output_image_path = os.path.join(output_dir, f'{file_prefix}_%03d.png')
    _convert_pdf_to_images(pdf_path, output_image_path)
    os.remove(pdf_path)

    return file_prefix, _extract_slide_notes(pptx_path, output_image_path)
