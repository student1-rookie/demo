import os
import re
import winreg
import comtypes.client
from pptx import Presentation
from collections import namedtuple

SlideInfo = namedtuple('SlideInfo', ['path', 'note'])

REG_KEY_NAME = "ExportBitmapResolution"
OFFICE_VERSIONS = ["16.0", "15.0", "14.0", "12.0"]
REG_PATH_TEMPLATE = r"Software\\Microsoft\\Office\\{version}\\PowerPoint\\Options"

def _detect_office_version():
    for version in OFFICE_VERSIONS:
        path = REG_PATH_TEMPLATE.format(version=version)
        try:
            winreg.OpenKey(winreg.HKEY_CURRENT_USER, path)
            return version
        except FileNotFoundError:
            continue
    raise Exception("No installed Office version detected")

def _set_registry_dpi(version, dpi_value):
    reg_path = REG_PATH_TEMPLATE.format(version=version)
    key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, reg_path)
    winreg.SetValueEx(key, REG_KEY_NAME, 0, winreg.REG_DWORD, dpi_value)
    winreg.CloseKey(key)

def _get_current_registry_dpi(version):
    reg_path = REG_PATH_TEMPLATE.format(version=version)
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, reg_path, 0, winreg.KEY_READ)
        value, _ = winreg.QueryValueEx(key, REG_KEY_NAME)
        winreg.CloseKey(key)
        return value
    except FileNotFoundError as e:
        return f"Registry key not found: {reg_path}"
    except Exception as e:
        return f"Error reading registry: {str(e)}"

def _delete_registry_dpi(version):
    reg_path = REG_PATH_TEMPLATE.format(version=version)
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, reg_path, 0, winreg.KEY_SET_VALUE)
        winreg.DeleteValue(key, REG_KEY_NAME)
        winreg.CloseKey(key)
        return None
    except FileNotFoundError as e:
        return f"Registry key or value not found: {reg_path}\\{REG_KEY_NAME}"
    except Exception as e:
        return f"Error deleting registry value: {str(e)}"

def _extract_slide_number(filename):
    match = re.search(r'slide(\d+)', filename.lower())
    return int(match.group(1)) if match else -1

def _convert_pptx_to_images_windows(pptx_path, output_dir, image_format="png"):
    abs_pptx_path = os.path.abspath(pptx_path)
    abs_output_dir = os.path.abspath(output_dir)

    powerpoint = comtypes.client.CreateObject("Powerpoint.Application")
    powerpoint.Visible = 1
    presentation = powerpoint.Presentations.Open(abs_pptx_path)

    if not os.path.exists(abs_output_dir):
        os.makedirs(abs_output_dir)

    format_code = 18 if image_format == "png" else 17
    try:
        presentation.SaveAs(abs_output_dir, format_code)
    finally:
        presentation.Close()
        powerpoint.Quit()

    prefix = os.path.splitext(os.path.basename(pptx_path))[0]

    files = [
        f for f in os.listdir(output_dir)
        if f.lower().startswith("slide") and f.lower().endswith(f".{image_format}")
    ]
    files.sort(key=_extract_slide_number)

    for i, file in enumerate(files):
        old_path = os.path.join(output_dir, file)
        new_name = f"{prefix}_{i:03d}.{image_format}"
        new_path = os.path.join(output_dir, new_name)
        os.rename(old_path, new_path)

    print("PPTX to Image conversion completed")

def process_pptx(pptx_path, output_dir, dpi=288, image_format="png"):
    os.makedirs(output_dir, exist_ok=True)
    file_prefix = os.path.splitext(os.path.basename(pptx_path))[0]

    version = _detect_office_version()
    original_dpi = _get_current_registry_dpi(version)
    registry_key_exists = original_dpi is not None
    try:
        if not registry_key_exists or original_dpi != dpi:
            _set_registry_dpi(version, dpi)

        _convert_pptx_to_images_windows(pptx_path, output_dir, image_format)
    finally:
        if registry_key_exists and original_dpi != dpi:
            _set_registry_dpi(version, original_dpi)
        elif not registry_key_exists:
            _delete_registry_dpi(version)

    notes = []
    for i, slide in enumerate(Presentation(pptx_path).slides):
        image_path = os.path.join(output_dir, f"{file_prefix}_{i:03d}.{image_format}")
        note_text = slide.notes_slide.notes_text_frame.text if slide.has_notes_slide else ""
        if os.path.isfile(image_path):
            notes.append(SlideInfo(image_path, note_text))
        else:
            print(f"Missing slide image: {image_path}")
    return file_prefix, notes
