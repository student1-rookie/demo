from dataclasses import dataclass, field
from typing import List, Optional
from enum import Enum


class ResourceType(Enum):
    VIDEO = "VIDEO"
    IMAGE = "IMAGE"


@dataclass
class PicInPicDto:
    text: str
    media: str
    coordinate: Optional[List[float]] = None
    box: Optional[List[int]] = None
    is_meta_human_background: bool = False
    type: Optional[ResourceType] = "IMAGE"
    audio_only: bool = False


@dataclass
class InferencePicInPicDto:
    name: str
    input: List[PicInPicDto]
    models: dict[str, str] = field(default_factory=lambda: {"TTS": "", "FACE": ""})
    type: str = "PIC_IN_PIC"
    backgroundImage: Optional[str] = None
    subtitle: bool = False
    hdtr: bool = False


class ResourceAccess:
    PUBLIC = "PUBLIC"
    PRIVATE = "PRIVATE"


@dataclass
class MetaHumanDataset:
    name: str
    type: str
    fileName: str
    identifier: str
    accountID: str
    fileType: str = "IMAGE"
    internal: bool = False
    groupID: Optional[str] = None
