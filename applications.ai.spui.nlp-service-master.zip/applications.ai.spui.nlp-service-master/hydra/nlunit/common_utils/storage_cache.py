from abc import ABC, abstractmethod
from collections import OrderedDict
import os
from multiprocessing import shared_memory, Semaphore, Condition
from contextlib import contextmanager


class StorageCacheInference(ABC):

    @abstractmethod
    def get(self, bucket: str, object_path: str):
        pass

    @abstractmethod
    def put(self, bucket: str, object_path: str, value):
        pass


def _rm_item(storage_dict):
    _, vals = storage_dict.popitem(last=False)
    if isinstance(vals, list):
        for v in vals:
            if os.path.isfile(v):
                os.remove(v)
    elif isinstance(vals, str):
        if os.path.isfile(vals):
            os.remove(vals)


class NoStorageCache(StorageCacheInference):

    def get(self, bucket: str, object_path: str):
        pass

    def put(self, bucket: str, object_path: str, value):
        pass


class StorageCache(StorageCacheInference):

    def __init__(self, capacity: int):
        # TODO: amend to space size
        self._capacity = capacity
        self._storage = OrderedDict()

    def get(self, bucket: str, object_path: str):
        key = f"{bucket}/{object_path}"
        if key not in self._storage:
            return None
        else:
            self._storage.move_to_end(key)
            return self._storage[key]

    def put(self, bucket: str, object_path: str, value):
        key = f"{bucket}/{object_path}"
        self._storage[key] = value
        self._storage.move_to_end(key)
        if len(self._storage) > self._capacity:
            _rm_item(self._storage)

    def __del__(self):
        while len(self._storage) > 0:
            _rm_item(self._storage)


KEY_LENGTH = 256
VALUE_LENGTH = 512


class StorageShared(StorageCacheInference):
    def __init__(self, name: str, capacity: int):
        self._capacity = capacity
        self._name = name
        self._shm = shared_memory.ShareableList([' ' * KEY_LENGTH, ' ' * VALUE_LENGTH] * self._capacity,
                                                name=self._name)
        self._sem = Semaphore()

    def __del__(self):
        with self._sem_guard():
            storage_dict = self._read_shm()
            while len(storage_dict) > 0:
                _rm_item(storage_dict)
        self._shm.shm.unlink()

    def get(self, bucket: str, object_path: str):
        target_key = f"{bucket}/{object_path}"

        with self._sem_guard():
            storage_dict = self._read_shm()
            if target_key not in storage_dict:
                return None
            storage_dict.move_to_end(target_key)
            self._update_shm(storage_dict)
            return storage_dict[target_key]

    def put(self, bucket: str, object_path: str, value):
        new_key = f"{bucket}/{object_path}"

        with self._sem_guard():
            storage_dict = self._read_shm()
            storage_dict[new_key] = value
            storage_dict.move_to_end(new_key)
            if len(storage_dict) > self._capacity:
                _rm_item(storage_dict)
            self._update_shm(storage_dict)

    def _read_shm(self) -> OrderedDict:
        storage_dict = OrderedDict()

        for index in range(self._capacity):
            key = self._shm[index * 2]
            if len(key.strip()) == 0:
                break
            storage_dict[key] = self._shm[index * 2 + 1]
            storage_dict.move_to_end(key)
        return storage_dict

    def _update_shm(self, storage_dict):
        for index, pairs in enumerate(storage_dict.items()):
            self._shm[index * 2] = pairs[0]
            self._shm[index * 2 + 1] = pairs[1]

    @contextmanager
    def _sem_guard(self):
        try:
            self._sem.acquire()
            yield
        finally:
            self._sem.release()


class MetaShared:
    def __init__(self, capacity: int):
        self._capacity = capacity
        self._shm = shared_memory.ShareableList([' ' * KEY_LENGTH] * self._capacity)
        self._sem = Semaphore()
        self._event = [Condition() for _ in range(capacity)]

    def __del__(self):
        self._shm.shm.unlink()

    def get(self, bucket: str, object_path: str):
        key = f"{bucket}/{object_path}"
        target_index = -1
        with self._sem_guard():
            for index, data in enumerate(self._shm):
                if key == data:
                    target_index = index
                    break
        if target_index != -1:
            with self._event[target_index]:
                self._event[target_index].wait()
        return target_index

    def put(self, bucket: str, object_path: str):
        key = f"{bucket}/{object_path}"
        ret = -1
        with self._sem_guard():
            for index, data in enumerate(self._shm):
                if len(data.strip()) == 0:
                    self._shm[index] = key
                    ret = index
                    break
        return ret

    def clean(self, index):
        with self._sem_guard():
            self._shm[index] = ""
        with self._event[index]:
            self._event[index].notify_all()

    @contextmanager
    def _sem_guard(self):
        try:
            self._sem.acquire()
            yield
        finally:
            self._sem.release()
