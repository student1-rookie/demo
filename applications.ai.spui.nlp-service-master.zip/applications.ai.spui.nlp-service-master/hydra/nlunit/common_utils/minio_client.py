import os
from dataclasses import dataclass
from typing import Optional

from minio import Minio, S3Error
from urllib3.exceptions import MaxRetryError
from minio.deleteobjects import DeleteObject

from hydra.nlunit.common_utils.storage_cache import StorageCache, StorageCacheInference, MetaShared


def upload_log_func(mh_id, client, workspace):
    def _upload(file_path):
        client.upload(workspace.bucket, workspace.gen_log_object(mh_id), file_path)

    return _upload if client and workspace else None


@dataclass
class MinioConfig:
    endpoint: str
    access_key: str
    secret_key: str

    @staticmethod
    def generate():
        endpoint = os.environ.get("MINIO_ENDPOINT", "localhost:9000")
        access_key = os.environ.get("MINIO_ACCESS_KEY", "")
        secret_key = os.environ.get("MINIO_SECRET_KEY", "")
        return MinioConfig(endpoint, access_key, secret_key)


class MinioClient:
    def __init__(self, root_path: str, cache: Optional[StorageCacheInference] = None,
                 meta_cache: Optional[MetaShared] = None):
        self._root_path = root_path
        self._cache = cache
        self._config = MinioConfig.generate()
        self._client = None
        self._meta_cache = meta_cache
        self._init()

    def _init(self):
        try:
            self._client = Minio(**self._config.__dict__, secure=False)
            self._client.list_buckets()
            print("Minio Connection fine.")
            os.makedirs(os.path.dirname(self._root_path), exist_ok=True)
            if self._cache is None:
                self._cache = StorageCache(16)
        except (S3Error, MaxRetryError) as e:
            self._client = None
            print("Minio Connection error: {}".format(e))

    def switch_env(self, config: dict):
        if config["endpoint"] != self._config.endpoint or config["access_key"] != self._config.access_key:
            try:
                new_client = Minio(**config, secure=False)
                new_client.list_buckets()
                print("Switch Minio Connection fine.")
                self._client = new_client
            except (S3Error, MaxRetryError) as e:
                print("Switch Minio Connection error: {}".format(e))

    def is_available(self):
        return self._client is not None

    def download_uncache(self, bucket: str, object_path: str, target_path: str):
        exist = self._check_bucket(bucket)
        if exist:
            return self._download(bucket, object_path, target_path)
        raise FileNotFoundError(object_path)

    def download(self, bucket: str, object_path: str, callback=None) -> str:
        target_path = self._cache.get(bucket, object_path)
        if target_path:
            return target_path
        exist = self._check_bucket(bucket)
        if exist:
            meta_index = -1
            if self._meta_cache:
                meta_index = self._meta_cache.get(bucket, object_path)
                if meta_index != -1:
                    # this object has downloaded by others.
                    return self._cache.get(bucket, object_path)
                else:
                    meta_index = self._meta_cache.put(bucket, object_path)
            target_path = self._gen_target_path(object_path)
            self._download(bucket, object_path, target_path)
            self._cache.put(bucket, object_path, target_path)
            if self._meta_cache and meta_index != -1:
                self._meta_cache.clean(meta_index)
            if callback:
                callback(target_path)
            return target_path
        raise FileNotFoundError(object_path)

    def download_all(self, bucket: str, folder_path: str):
        target_folder = self._cache.get(bucket, folder_path)
        if target_folder:
            return target_folder
        exist = self._check_bucket(bucket)
        if exist:
            meta_index = -1
            if self._meta_cache:
                meta_index = self._meta_cache.get(bucket, folder_path)
                if meta_index != -1:
                    # Objects has downloaded by others.
                    return self._cache.get(bucket, folder_path)
                else:
                    meta_index = self._meta_cache.put(bucket, folder_path)
            objects = self._client.list_objects(bucket, prefix=folder_path, recursive=True)
            target_folder = os.path.join(self._root_path, folder_path.split("/")[-1])
            target_objects = []
            for obj in objects:
                # skip directory placeholder
                if obj.object_name.endswith("/"):
                    continue
                target_path = os.path.join(target_folder, obj.object_name.split("/")[-1])
                self._download(bucket, obj.object_name, target_path)
                target_objects.append(target_path)
                self._cache.put(bucket, folder_path, target_objects)

                if self._meta_cache and meta_index != -1:
                    self._meta_cache.clean(meta_index)
            return target_objects
        raise FileNotFoundError(folder_path)

    def upload(self, bucket: str, object_path: str, file_path: str):
        exist = self._check_bucket(bucket)
        if exist:
            self._client.fput_object(bucket, object_path, file_path)

    def _download(self, bucket: str, object_path: str, target_path: str):
        self._client.fget_object(bucket, object_path, target_path)

    def _check_bucket(self, bucket: str) -> bool:
        return self._client.bucket_exists(bucket)

    def _gen_target_path(self, object_path: str) -> str:
        parts = object_path.split('/')
        match len(parts):
            case 1:
                return os.path.join(self._root_path, parts[0])
            case _:
                os.makedirs(os.path.join(self._root_path, parts[-2]), exist_ok=True)
                return os.path.join(self._root_path, parts[-2], parts[-1])

    def remove_objects(self, bucket: str, folder_path: str):
        exist = self._check_bucket(bucket)
        if exist:
            objects = self._client.list_objects(bucket, prefix=folder_path, recursive=True)
            delete_objects = [DeleteObject(obj.object_name) for obj in objects]
            if not delete_objects:
                return

            errors = self._client.remove_objects(bucket, delete_objects)
            for error in errors:
                print(f"delete failed: {error.object_name}, error: {error.message}")
            return
        raise FileNotFoundError(folder_path)
