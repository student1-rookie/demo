import os
import uuid
import yaml
from typing import Optional

from hydra.nlunit.common_utils.minio_client import MinioClient


class EnvKey:
    DB = "db"
    REDIS = "redis"
    MINIO = "minio"


class EnvManager:
    _instance = None
    _disabled = False

    def __init__(self, root_path: Optional[str] = None, env_bucket: Optional[str] = None):
        self._root_path = os.getenv("MH_ENV") if root_path is None else root_path
        self._env_bucket = os.getenv("MH_ENV_BUCKET") if env_bucket is None else env_bucket
        self._env_cache = {}

    @classmethod
    def disable(cls):
        cls._disabled = True

    def __call__(self, *args, **kwargs):
        if EnvManager._instance is None and not EnvManager._disabled:
            instance = super().__class__(*args, **kwargs)
            EnvManager._instance = instance
        return EnvManager._instance

    def init(self):
        client = MinioClient(self._root_path)
        if not client.is_available():
            EnvManager._disabled = True
        else:
            try:
                client.download_all(self._env_bucket, "")
            except Exception as e:
                print("Error downloading environments: {}".format(e))

    def update(self, name, flush: bool = False) -> bool:
        out = self.try_get(name)
        env_file = f"{name}.env"
        if out is None or flush:
            client = MinioClient(self._root_path)
            try:
                client.download_uncache(self._env_bucket, env_file, os.path.join(self._root_path, env_file))
                return True
            except Exception as e:
                print(e)
                return False
        return True

    def try_get(self, name):
        env_file = os.path.join(self._root_path, f"{name}.env")
        if os.path.isfile(env_file):
            return env_file
        return None

    def get(self, name, key, flush: bool = False):
        if flush or name not in self._env_cache:
            env_file = self.try_get(name)
            if env_file:
                with open(env_file, "r", encoding="utf-8") as f:
                    envs = yaml.safe_load(f)
                self._env_cache[name] = envs
                return envs.get(key, {})
            return {}
        return self._env_cache[name].get(key, {})

    def download(self, name):
        client = MinioClient("/tmp")
        target_path = os.path.join("/tmp", f"{name}_{uuid.uuid1()}.env")
        try:
            client.download_uncache(self._env_bucket, f"{name}.env", target_path)
        except Exception as e:
            print(e)
            return None

        with open(target_path, "r", encoding="utf-8") as f:
            envs = yaml.safe_load(f)
        os.remove(target_path)
        return envs
