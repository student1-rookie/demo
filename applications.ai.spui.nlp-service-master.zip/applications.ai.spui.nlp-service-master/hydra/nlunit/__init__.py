
class NluType:
    ALL = 0
    CLS = 1
    NER = 2