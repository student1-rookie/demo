import functools
from ..core.resource import model
from ..core.typing import BatchProcessModel, SingleProcessModel


@model("FTBatchUnit")
class FasttextBatchUnit(BatchProcessModel):

    def __init__(self, model_path):
        self._model_path = model_path
        self._ft_cls = None

    def load(self):
        import fasttext
        self._ft_cls = fasttext.load_model(self._model_path)

    def pre_process(self, data) -> object:
        return functools.reduce(lambda x, y: x + ' ' + y, data)

    def predict(self, data: list) -> list:
        labels, probs = self._ft_cls.predict(data)
        results = [
            {
                "intent": label[0],
                "prob": prob[0]
            } for label, prob in zip(labels, probs)
        ]
        return results


@model("FTUnit")
class FasttextUnit(SingleProcessModel):

    def __init__(self, model_path):
        self._model_path = model_path
        self._ft_cls = None

    def load(self):
        import fasttext
        self._ft_cls = fasttext.load_model(self._model_path)

    def pre_process(self, data) -> object:
        return functools.reduce(lambda x, y: x + ' ' + y, data)

    def predict(self, data):
        label, probs = self._ft_cls.predict(data)
        r_label = ""
        r_prob = 1
        if label:
            r_label = label[0]
        if probs and len(probs) > 0:
            r_prob = probs[0]
        return {"intent": r_label, "prob": r_prob}
