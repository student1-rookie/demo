import os
import uuid
import torch
import shlex

from torch.utils.data import DataLoader

_LATENTSYNC_AVAILABLE = True
try:
    from diffusers import AutoencoderKL, DDIMScheduler
    from latentsync.models.unet import UNet3DConditionModel
    from latentsync.pipelines.lipsync_pipeline import LipsyncPipeline
    from diffusers.utils.import_utils import is_xformers_available
    from latentsync.whisper.audio2feature import Audio2Feature
    from omegaconf import OmegaConf
except ImportError:
    _LATENTSYNC_AVAILABLE = False

_HDTR_AVAILABLE = True
try:
    import face_alignment
    from networks.models import Generator
    from inference import cutting_mouth, get_mask
    from dataset.inference_dataset import InferenceDataset
    import numpy as np
    import cv2
    import pickle
    import shutil
except ImportError:
    _HDTR_AVAILABLE = False


class HDTRModelConfig:
    lipnet: str = "lip-clarity-model.pth"
    mask_channel: int = 6
    ref_channel: int = 3
    mouth_size: int = 96


class HDTRDataConfig:
    full_frame_path: str = "full_frame"
    wav_path: str = 'audio.wav'
    align_crop_image_path: str = 'align_crop_image'
    model_out_path: str = 'model_out'
    test_workers: int = 0
    image_config_path: str = 'image_config/image_config.pkl'


def load_latentsync_model(model_config, precision: str, device="cuda"):
    assert _LATENTSYNC_AVAILABLE, "Missing some dependencies for latentsync."
    dtype = torch.float16 if precision == "float16" else torch.float32
    unet_config = OmegaConf.load(model_config.unet_config)
    scheduler = DDIMScheduler.from_pretrained(model_config.scheduler)
    audio_encoder = Audio2Feature(model_path=model_config.whisper, device=device,
                                  num_frames=unet_config.data.num_frames)
    vae = AutoencoderKL.from_pretrained(model_config.vae, torch_dtype=dtype, local_files_only=True)
    vae.config.scaling_factor = 0.18215
    vae.config.shift_factor = 0

    unet, _ = UNet3DConditionModel.from_pretrained(
        OmegaConf.to_container(unet_config.model),
        model_config.unet,  # load checkpoint
    )

    unet = unet.to(dtype=dtype)

    # set xformers
    if is_xformers_available():
        unet.enable_xformers_memory_efficient_attention()

    pipeline = LipsyncPipeline(
        vae=vae,
        audio_encoder=audio_encoder,
        unet=unet,
        scheduler=scheduler,
    ).to(device)

    return pipeline, unet_config


def latentsync_inference(pipeline, config, video_path, audio_path, video_out_path, precision, extra):
    return pipeline(
        video_path,
        audio_path,
        video_out_path,
        weight_dtype=torch.float16 if precision == "float16" else torch.float32,
        num_frames=config.data.num_frames,
        width=config.data.resolution,
        height=config.data.resolution,
        **extra
    )

def load_hdtr_model(model_path, device="cuda"):
    assert _HDTR_AVAILABLE, "Missing some dependencies for HDTR."
    model = Generator(HDTRModelConfig)
    lipnet_ckpt_path = os.path.join(model_path, HDTRModelConfig.lipnet)

    checkpoint = torch.load(lipnet_ckpt_path)
    s = checkpoint["state_dict"]
    new_s = {}
    for k, v in s.items():
        new_s[k.replace('module.', '')] = v

    model.load_state_dict(new_s)
    return model.to(device).eval()


def _hdtr_prepare_data(input_video, temp_dir, device):
    def prepare_data(full_frame_path, temp_dir, fa_3d):
        # Detect face landmarks
        print(f'==> detect face landmarks ...')
        frame_list = sorted(os.listdir(full_frame_path))

        landmarks_dict = {}
        for index in frame_list:
            # index_base = index.replace('.jpg', '')
            image = cv2.imread(os.path.join(full_frame_path, index))
            try:
                preds = fa_3d.get_landmarks(image)
            except Exception as e:
                print(f'Catched the following error: {e}')
                preds = None
                continue
            lmark = preds[0][:, :2]
            landmarks_dict[index] = lmark

        landmarks_path = os.path.join(temp_dir, 'landmarks')
        os.makedirs(landmarks_path, exist_ok=True)

        if os.path.exists(os.path.join(landmarks_path, 'landmarks.pkl')):
            os.remove(os.path.join(landmarks_path, 'landmarks.pkl'))

        with open(os.path.join(landmarks_path, 'landmarks.pkl'), 'wb') as f:
            pickle.dump(landmarks_dict, f)

        # Crap based on landmarks
        align_crop_image_path = os.path.join(temp_dir, 'align_crop_image')
        os.makedirs(align_crop_image_path, exist_ok=True)

        print(f'==> face align ...')
        with open(os.path.join(landmarks_path, 'landmarks.pkl'), 'rb') as f:
            read_landmarks = pickle.load(f)

        image_config = {}
        image_coor = {}
        image_hw = {}
        image_config_path = os.path.join(temp_dir, 'image_config')
        os.makedirs(image_config_path, exist_ok=True)
        if os.path.exists(os.path.join(image_config_path, 'image_config.pkl')):
            os.remove(os.path.join(image_config_path, 'image_config.pkl'))

        with open(os.path.join(image_config_path, 'image_config.pkl'), 'wb') as config:
            for i in frame_list:
                # pdb.set_trace()
                landmark = read_landmarks[i]

                image_path = os.path.join(full_frame_path, i)
                image = cv2.imread(image_path)

                in_mask, in_mean_mask, cut_image = get_mask(image, landmark)

                x0, y0, x1, y1 = cutting_mouth(landmark)
                image_coor[i] = (x0, y0, x1, y1)

                h, w, _ = image.shape
                if x0 < 0: x0 = 0
                if y0 < 0: y0 = 0
                if x1 > w: x1 = w - 1
                if y1 > h: y1 = h - 1

                base_image = i.replace('.png', '')
                cv2.imwrite(os.path.join(align_crop_image_path, base_image + '_mask.png'), in_mask[y0:y1, x0:x1, :])
                cv2.imwrite(os.path.join(align_crop_image_path, base_image + '_mean_mask.png'),
                            in_mean_mask[y0:y1, x0:x1, :])
                cv2.imwrite(os.path.join(align_crop_image_path, base_image + '_image.png'), cut_image[y0:y1, x0:x1, :])
                image_hw[i] = (y1 - y0, x1 - x0)
            image_config['image_hw'] = image_hw
            image_config['image_coor'] = image_coor
            pickle.dump(image_config, config)
        return frame_list

    split_image_cmd = 'ffmpeg -hide_banner -loglevel warning -y -i {} -r 25 {}/%05d.png'
    split_wav_cmd = 'ffmpeg -hide_banner -loglevel warning -y -i {} -async 1 -ac 1 -vn -acodec pcm_s16le -ar 16000 {}'
    fa_3d = face_alignment.FaceAlignment(face_alignment.LandmarksType.THREE_D, flip_input=False, device=device)

    full_frame_path = os.path.join(temp_dir, HDTRDataConfig.full_frame_path)
    os.makedirs(full_frame_path, exist_ok=True)
    wav_path = os.path.join(temp_dir, HDTRDataConfig.wav_path)
    ret = os.system(split_image_cmd.format(shlex.quote(input_video), full_frame_path))
    if ret == 0:
        ret = os.system(split_wav_cmd.format(shlex.quote(input_video), shlex.quote(wav_path)))
    if ret != 0:
        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)
        raise RuntimeError(f"Command failed: prepare latentsync data error, return code {ret}")

    frame_list = prepare_data(full_frame_path, temp_dir, fa_3d)
    align_crop_image_path = os.path.join(temp_dir, HDTRDataConfig.align_crop_image_path)

    return frame_list, wav_path, align_crop_image_path


def hdtr_inference(model, batch_size, input_video, out_path, device):
    temp_dir = os.path.join("/tmp", str(uuid.uuid1()))
    if os.path.exists(temp_dir):
        shutil.rmtree(temp_dir)
    os.makedirs(temp_dir, exist_ok=True)

    frame_list, wav_path, align_crop_image_path = _hdtr_prepare_data(input_video, temp_dir, device)

    def _save_results(SR_images, path, index, data_config):
        save_path = os.path.join(path, data_config.model_out_path)
        os.makedirs(save_path, exist_ok=True)

        for ind in range(SR_images.shape[0]):
            pred_hq = SR_images[ind, :].numpy() * 255.
            pred_hq = np.transpose(pred_hq.astype(int), (1, 2, 0))

            cv2.imwrite(os.path.join(save_path, '{}.png'.format(str(index + ind).zfill(5))), pred_hq)

    dataset = InferenceDataset(frame_list, align_crop_image_path, HDTRModelConfig.mouth_size)
    dataloader = DataLoader(dataset,
                            batch_size=batch_size,
                            shuffle=False,
                            num_workers=int(HDTRDataConfig.test_workers),
                            drop_last=False)
    start_index = 1
    for mouth_mask, mouth_contour, reference in dataloader:
        print(f'[info]: Processing cropped image to clear mouth region : {start_index}-{start_index + batch_size}')

        with torch.no_grad():
            pred_hq = model(mouth_mask, mouth_contour, reference).cpu()

        _save_results(pred_hq, temp_dir, index=start_index, data_config=HDTRDataConfig)
        start_index += batch_size

    image_config_path = os.path.join(temp_dir, HDTRDataConfig.image_config_path)
    with open(image_config_path, 'rb') as f:
        image_config = pickle.load(f)

    save_path = os.path.join(temp_dir, HDTRDataConfig.model_out_path)
    full_frame_path = os.path.join(temp_dir, HDTRDataConfig.full_frame_path)
    finout_image_path = os.path.join(temp_dir, 'fin_out')
    os.makedirs(finout_image_path, exist_ok=True)
    for index in frame_list:
        full_image = cv2.imread(os.path.join(full_frame_path, index))

        # paste bask
        h, w = image_config['image_hw'][index]

        out_image = cv2.imread(os.path.join(save_path, index))
        out_image = cv2.resize(out_image, (w, h))

        x0, y0, x1, y1 = image_config['image_coor'][index]

        # create mouth mask
        mask = np.zeros(full_image.shape[:2], dtype=np.uint8)
        souce_img = full_image.copy()
        souce_img[y0:y1, x0:x1, :] = out_image
        mask[y0:y1, x0:x1] = 255

        # seamless
        mixed_image = cv2.seamlessClone(souce_img, full_image, mask, (x0 + w // 2, y0 + h // 2), cv2.NORMAL_CLONE)

        cv2.imwrite(os.path.join(finout_image_path, index), mixed_image)

    synthesis_cmd = "ffmpeg -y -loglevel warning " + \
                    "-thread_queue_size 8192 -i {} " + \
                    "-thread_queue_size 8192 -i {}/%05d.png " + \
                    "-vcodec libx264 -preset slower -profile:v high -crf 18 -pix_fmt yuv420p -shortest {}"
    ret = os.system(synthesis_cmd.format(shlex.quote(wav_path), shlex.quote(finout_image_path), shlex.quote(out_path)))
    if os.path.exists(temp_dir):
        shutil.rmtree(temp_dir)

    if ret != 0:
        raise RuntimeError(f"Command failed: synthesis_cmd, return code {ret}")
    print(f"[info]: Result videos is saved in {out_path}")