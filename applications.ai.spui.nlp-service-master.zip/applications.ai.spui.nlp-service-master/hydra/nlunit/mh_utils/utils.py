import os
import uuid
from typing import Callable, Tuple, Optional
import yaml
import re
import gc
import errno
import traceback
from typing import Dict, Iterable
import ffmpeg
import random
import time
import subprocess
import shutil

from hydra.core.shared import Shared
from hydra.core.typing import CtlEvent
from hydra.nlunit.common_utils.env import EnvManager, EnvKey
from hydra.nlunit.mh_utils.db_utils import insert_notification

_TORCH_AVAILABLE = True
try:
    import torch
    import torchaudio
except ImportError:
    _TORCH_AVAILABLE = False

ffmpeg_path = os.getenv('FFMPEG_PATH', 'ffmpeg')


class InferenceType:
    WHOLE = "WHOLE"
    FACE_ONLY = "FACE_ONLY"
    TTS_ONLY = "TTS_ONLY"
    TTS_EXAMPLE = "TTS_EXAMPLE"
    WHOLE_SUBMIT = 'PIC_IN_PIC'
    ITEM_SUBMIT = 'ITEM_PIC_IN_PIC'


class MHModel:
    TTS = "tts"
    FACE = "face"


_TASK_TO_NOTIFY = {
    InferenceType.WHOLE: "Inference-whole",
    InferenceType.FACE_ONLY: "Inference-face",
    InferenceType.TTS_ONLY: "Inference-tts",
    InferenceType.TTS_EXAMPLE: "Train-tts",
    InferenceType.WHOLE_SUBMIT: "Pic-In-Pic",
    InferenceType.ITEM_SUBMIT: "Pic-In-Pic-Item",
    MHModel.TTS: "Train-tts",
    MHModel.FACE: "Train-face",
}


def get_task_title(infer_type: str) -> str:
    return _TASK_TO_NOTIFY[infer_type]


class ModelStatus:
    TRAIN = "TRAIN"
    COMPLETE = "COMPLETE"
    RUN = "RUN"
    WAIT = "WAIT"
    FAIL = "FAIL"
    CANCEL = "CANCEL"
    CREATE_WAV = "CREATE_WAV"


class MHStatus:
    SUCCESS = "SUCCESS"
    FAILED = "FAIL"


class ItemType:
    ALL = "ALL"
    TTS = "TTS"
    FACE = "FACE"


LOG_READ_BUFF_LEN = 256


def read_pipe(pipe_fd: int, byte_num: int = 32):
    try:
        return os.read(pipe_fd, byte_num)
    except OSError as e:
        if e.errno == errno.EAGAIN:
            pass


class ByteLogsCollector:
    def __init__(self):
        self.logs: list[bytes] = []
        self.temp_log: bytes = b""

    def collect(self, input: bytes):
        bytes_read = input.split(b"\n")
        bytes_read[0] = self.temp_log + bytes_read[0]
        self.temp_log = bytes_read[-1]
        self.logs.extend(bytes_read[:-1])

    def consume(self):
        logs = self.logs
        self.logs = []
        return logs


def handle_stream(stream: Iterable, consumer: Callable, name: str = ""):
    collector = ByteLogsCollector()
    print(f"start to run handle_stream: {name}")
    for c in stream:
        collector.collect(c)
        for log in collector.consume():
            consumer(log)


def handle_blocking_pipe(pipe_path: str, byte_num: int, consumer: Callable, name: str) -> Callable:
    def _func():
        try:
            print(f"open named pipe: {pipe_path}")
            pipe_read = os.open(pipe_path, os.O_RDONLY)
            handle_stream(iter(lambda: read_pipe(pipe_read, byte_num), b""), consumer, name)
        except Exception as e:
            print(f"handle_blocking_pipe error: pipe_path: {pipe_path}")
            print(traceback.format_exc())
            raise e
        finally:
            if os.path.exists(pipe_path) and pipe_read:
                os.close(pipe_read)
                os.remove(pipe_path)
                print(f"clean pipe: {pipe_path}")

    return _func


def handle_control(process):
    shared = Shared.get()
    while True:
        poll = process.poll()
        if poll is not None:
            break
        if shared.get_ctl() == CtlEvent.CANCEL:
            process.kill()
            print("kill process")
            break
        time.sleep(1)


# porting from meta-human https://github.com/intel-sandbox/meta-human/blob/enhance/input-args/metahuman/utils/utils.py#L14
def get_yaml_safe_loader():
    loader = yaml.SafeLoader
    loader.add_implicit_resolver(
        u'tag:yaml.org,2002:float',
        re.compile(u'''^(?:
         [-+]?(?:[0-9][0-9_]*)\\.[0-9_]*(?:[eE][-+]?[0-9]+)?
        |[-+]?(?:[0-9][0-9_]*)(?:[eE][-+]?[0-9]+)
        |\\.[0-9_]+(?:[eE][-+][0-9]+)?
        |[-+]?[0-9][0-9_]*(?::[0-5]?[0-9])+\\.[0-9_]*
        |[-+]?\\.(?:inf|Inf|INF)
        |\\.(?:nan|NaN|NAN))$''', re.X),
        list(u'-+0123456789.'))
    return loader


def load_yml_configs(path) -> Dict:
    loader = get_yaml_safe_loader()
    configs = None
    for data in yaml.load_all(open(path, "r"), Loader=loader):
        if 'task' in data:
            configs = data
    assert configs is not None, "must config task at yml!"
    return configs


def clean_cuda_cache(device: str):
    gc.collect()
    if _TORCH_AVAILABLE and device.startswith('cuda') and torch.cuda.is_available():
        torch.cuda.empty_cache()


def save_audio(res, sample_rate, output_path, cat=True):
    res_tensor = torch.cat(res, dim=1) if cat else res
    torchaudio.save(output_path, res_tensor, sample_rate)


def save_audio_by_sf(res, sample_rate, output_path):
    import soundfile as sf
    sf.write(output_path, res, sample_rate)


def convert_video_to_audio(video_path, audio_path, sample_rate=16000):
    ffmpeg.input(video_path) \
        .output(audio_path, vn=None, ar=sample_rate, ac=1, f='wav') \
        .global_args("-loglevel", "error") \
        .run(cmd=ffmpeg_path, overwrite_output=True)
    print(f"video convert to audio success: {audio_path}")


def video_add_audio(input_video: str, input_audio: str, output_video: str):
    input_video_stream = ffmpeg.input(input_video)
    input_audio_stream = ffmpeg.input(input_audio)
    ffmpeg.output(input_video_stream.video, input_audio_stream.audio, output_video, vcodec='copy', acodec='aac',
                  shortest=None).run(cmd=ffmpeg_path, overwrite_output=True)


def cut_audio(audio_path, cut_duration, output_path):
    assert _TORCH_AVAILABLE
    audio, sr = torchaudio.load(audio_path)
    cut_samples = int(cut_duration * sr)
    ret_audio = audio[:, :cut_samples]
    torchaudio.save(output_path, ret_audio, sr)
    return output_path


def is_video(input):
    try:
        media_info = ffmpeg.probe(input)
        return any(stream['codec_type'] == 'video' for stream in media_info['streams'])
    except Exception as e:
        return False


def extract_first_frame(video_path, image_path, scale: bool = True):
    cmd = ["ffmpeg", "-hide_banner", "-i", video_path, "-frames:v", "1"]
    if scale:
        cmd += ["-vf", "scale=512:-1"]
    cmd.append(image_path)
    subprocess.run(cmd, check=True)


def get_root_path():
    file_path = os.path.dirname(__file__)
    return os.path.abspath(file_path[:file_path.rindex("hydra")])


def set_seed(seed):
    import numpy as np
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def find_workspace_replace_prefix(config_file: str) -> Tuple[str, str, bool]:
    with open(config_file, "r", encoding="utf-8") as f:
        config = yaml.safe_load(f)

    workspace_path = config["data"]["workspace_path"]
    base_name = os.path.basename(workspace_path)
    return os.path.dirname(workspace_path), base_name, len(base_name) == 0


def replace_workspace_prefix_in_yml(config_file: str, old_prefix: str, new_prefix: str, concat: bool):
    with open(config_file, "r", encoding="utf-8") as f:
        raw_text = f.read()
    new_prefix_ = os.path.join(new_prefix, old_prefix) if concat else new_prefix
    updated_text = raw_text.replace(old_prefix, new_prefix_)
    with open(config_file, "w", encoding="utf-8") as f:
        f.write(updated_text)


def switch_env(data: dict, redis: Optional["RedisLogger"], db_args: dict, client: Optional["MinioClient"]):
    if data.get("env", None):
        flush = data.get("env_flush", False)
        env_manager = EnvManager()
        db_env = env_manager.get(data["env"], EnvKey.DB, flush=flush)
        if redis:
            redis.switch_env(data["env"], **env_manager.get(data["env"], EnvKey.REDIS))
        if db_env:
            db_args.update(db_env)
        else:
            # TODO: handle this case
            print("Cannot get db env from", data["env"])
            db_args.clear()
        if client:
            client.switch_env(env_manager.get(data["env"], EnvKey.MINIO))
    else:
        # restore
        if redis:
            redis.switch_env("")
        db_args.clear()


def save_notifications(account_id, task_type, status, detail, redis, **kwargs):
    title = get_task_title(task_type)
    msg = f"[{title}] {detail} is {status.lower()}"
    insert_notification(account_id, status, msg, redis, **kwargs)


def upload_fail_artifacts(client, task_id, file_path, cluster, workspace_root, fail_output_dir) -> None:
    is_multi = isinstance(file_path, (list, tuple))
    aggregate_dir = None
    try:
        if is_multi:
            dirs = list(file_path)
            base_parent = os.path.dirname(dirs[0])
            aggregate_dir = os.path.join(base_parent, f"{task_id}")
            os.makedirs(aggregate_dir, exist_ok=True)
            for d in dirs:
                if not os.path.exists(d):
                    continue
                target = os.path.join(aggregate_dir, os.path.basename(d))
                shutil.copytree(d, target, dirs_exist_ok=True)
        compress_root = aggregate_dir if is_multi else file_path
        if cluster:
            zip_base = os.path.join(os.path.dirname(compress_root), task_id)
            fail_zip_file = shutil.make_archive(zip_base, "zip", compress_root)
            fail_object = cluster.gen_fail_object(task_id, f"{task_id}.zip")
            client.upload(cluster.bucket, fail_object, fail_zip_file)
            if isinstance(file_path, str) and os.path.exists(file_path):
                shutil.rmtree(file_path)
            if os.path.exists(fail_zip_file):
                os.remove(fail_zip_file)
        else:
            fail_dir = os.path.join(workspace_root, fail_output_dir, task_id)
            os.makedirs(fail_dir, exist_ok=True)
            target_zip_path = os.path.join(fail_dir, f"{task_id}.zip")
            base_name = os.path.splitext(target_zip_path)[0]
            shutil.make_archive(base_name, "zip", root_dir=os.path.dirname(compress_root), base_dir=os.path.basename(compress_root))
    except Exception as e:
        print(f"upload fail artifacts failed for task [{task_id}]: {e}")
    finally:
        if aggregate_dir and os.path.exists(aggregate_dir):
            shutil.rmtree(aggregate_dir)
