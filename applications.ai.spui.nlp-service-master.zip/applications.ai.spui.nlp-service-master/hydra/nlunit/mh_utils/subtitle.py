import re
import os
import json
import ffmpeg
import difflib

ffmpeg_path = os.getenv('FFMPEG_PATH', 'ffmpeg')
font_dir = os.getenv("FONT_DIR", "/usr/share/fonts/opentype/noto-cjk")
asr_model_path = os.getenv("ASR_MODEL_PATH", "/model/faster-whisper-large-v3")


def _format_time(seconds):
    minutes, seconds = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    milliseconds = (seconds - int(seconds)) * 1000
    return f"{int(hours):02d}:{int(minutes):02d}:{int(seconds):02d},{int(milliseconds):03d}"


def _color_to_ffmpeg_hex(color, alpha=0) -> str:
    named_colors = {
        "black": (0, 0, 0),
        "white": (255, 255, 255),
        "red": (255, 0, 0),
        "green": (0, 255, 0),
        "blue": (0, 0, 255),
        "yellow": (255, 255, 0),
        "cyan": (0, 255, 255),
        "magenta": (255, 0, 255),
        "gray": (128, 128, 128),
    }
    r, g, b = named_colors[color]
    return f"&H{alpha:02X}{b:02X}{g:02X}{r:02X}"


def contains_chinese(text):
    chinese_char_pattern = re.compile(r'[\u4e00-\u9fff]')
    return bool(chinese_char_pattern.search(text))


def format_srt_file(srt_in, srt_out):
    with open(srt_in, "r", encoding="utf-8") as f:
        timestamps = json.load(f)
    arrow = "-->"
    punctuation_pattern = re.compile(r'([.,!?;:，。！？；：])')

    with open(srt_out, "w", encoding="utf-8") as f:
        for i, segment in enumerate(timestamps):
            segment_id = i
            start_time = _format_time(segment["start"])
            end_time = _format_time(segment["end"])
            text = segment["text"]
            chinese = contains_chinese(text)
            if chinese:
                text = punctuation_pattern.sub(
                    r'\1 ', segment["text"]).rstrip()

            f.write(
                f"{segment_id}\n{start_time} {arrow} {end_time}\n{text.lstrip()}\n\n")


def _transcribe_video(input_file, srt_file, device=None):
    from faster_whisper import WhisperModel
    import torch
    if device is None and torch.cuda.is_available():
        device = "cuda"

    if device == "cuda":
        compute_type = "float16"
    else:
        compute_type = "float32"
    model = WhisperModel(
        asr_model_path,
        device=device,
        compute_type=compute_type,
    )
    segments, _ = model.transcribe(input_file, beam_size=5, vad_filter=True)
    arrow = "-->"
    with open(srt_file, "w", encoding="utf-8") as srt_file:
        for segment in segments:
            start_time = _format_time(segment.start)
            end_time = _format_time(segment.end)
            segment_id = segment.id

            text = segment.text
            srt_file.write(
                f"{segment_id}\n{start_time} {arrow} {end_time}\n{text.lstrip()}\n\n"
            )


def _get_subtitle(input_file):
    import requests
    files = {
        "file": open(input_file, "rb")
    }
    data = {
        "type": "audio",
        "lang": "auto",
    }
    asr_url = os.getenv("ASR_URL", "http://localhost:5000/api/v1/asr-1")
    response = requests.post(asr_url, files=files, data=data, proxies={"http": None, "https": None})
    return json.loads(response.text)


def filter_styled_subtitles(input_stream, input_srt, subtitle_styles={}):
    font_size = subtitle_styles.get("fontSize", 20)
    color = subtitle_styles.get("color", "black")
    bold = subtitle_styles.get("bold", 0)
    margin_v = subtitle_styles.get("margin_v", 2)
    color_hex = _color_to_ffmpeg_hex(color)  # fully opaque
    style = (
        f"FontName=Noto Serif CJK SC,"
        f"FontSize={font_size},"
        f"PrimaryColour={color_hex},"
        f"Outline=0.1,"
        f"OutlineColour={color_hex},"
        f"Shadow=0,"
        f"Bold={bold},"
        f"MarginV={margin_v},"
        f"Alignment=2"  # bottom center
    )
    return input_stream.filter("subtitles", input_srt, fontsdir=font_dir, force_style=style)


def add_subtitles(input_video, audio_path, srt_file, output_video, subtitle_styles={}, device=None):
    """
    Add subtitles to a video and save the output.

    Parameters:
        input_video (str): Path to the input video file.
        audio_path (str): Path to the audio file, used for ASR if srt_file is not provided.
        srt_file (str): Path to the Json format subtitle, convert to SRT format.
        output_video (str): Path to save the output video file.
        subtitle_styles (dict): Dictionary containing subtitle styles such as fontSize, color, bold, margin_v.
        device (str, optional): Device to use for ASR transcription.
    """
    srt_name = os.path.splitext(os.path.basename(output_video))[0] + ".srt"
    formatted_srt = os.path.join(os.path.dirname(output_video), srt_name)
    if srt_file and os.path.exists(srt_file):
        format_srt_file(srt_file, formatted_srt)
    else:
        _transcribe_video(audio_path, formatted_srt, device)
    input_stream = ffmpeg.input(input_video)
    video_with_subtitles = filter_styled_subtitles(input_stream.video, formatted_srt, subtitle_styles)
    output_stream = ffmpeg.concat(video_with_subtitles, input_stream.audio, v=1, a=1
                                  ).output(output_video).global_args('-loglevel', 'error')
    ffmpeg.run(output_stream, cmd=ffmpeg_path, overwrite_output=True)


# ================================= COSYVOICE SUBTITLE ==============================
# This part is used to restore original text from the normalized text.
def _extract_context(text: str, start_idx: int, max_len: int, is_chinese: bool) -> str:
    separators = {
        '。', '？', '！', '；', '：', '、', '，',
        '.', '?', '!', ';', ':', ',', '\n'
    }
    if is_chinese:
        separators.add(' ')
    context = ""
    count = 0
    i = start_idx - 1

    if text[start_idx] in ['\n'] and i > 0:
        context = text[i]
        count += 1
        i -= 1

    while i >= 0:
        ch = text[i]
        if ch in separators:
            break
        context = ch + context
        count += 1
        if count >= max_len:
            break
        i -= 1

    return context


def _extract_replacement_list(original: str, normalized: str) -> list[tuple[str, str, str]]:
    is_chinese = contains_chinese(original)
    if is_chinese:
        context_len = 5
    else:
        context_len = 15

    matcher = difflib.SequenceMatcher(None, original, normalized)
    replacements = []
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag in {"replace", "delete"}:
            orig = original[i1:i2]
            norm = normalized[j1:j2]

            context = _extract_context(original, i1, context_len, is_chinese)
            replacements.append((norm, orig, context))
    return replacements


def _reverse_replacement(text: str, replacements: list[tuple[str, str, str]]) -> str:
    while replacements:
        norm, orig, context = replacements[0]
        if norm == "":
            if context == "":  # For this case, we don't have any useful info, so we just remove it.
                replacements.pop(0)
                continue
            start_search = 0
            found_valid_pos = False
            while True:
                idx = text.find(context, start_search)
                if idx == -1:
                    break
                insert_pos = idx + len(context)
                if text[insert_pos:insert_pos + len(orig)] == orig:
                    start_search = idx + 1
                    continue
                text = text[:insert_pos] + orig + text[insert_pos:]
                replacements.pop(0)
                found_valid_pos = True
                break
            if not found_valid_pos:
                break

        else:
            found = False
            search_start = 0
            while True:
                idx = text.find(norm, search_start)
                if idx == -1:
                    break
                if not context:  # a replacement error may occur in rare cases
                    found = True
                    break
                start_context_pos = idx - len(context)
                if start_context_pos >= 0 and text[start_context_pos:idx] == context:
                    found = True
                    break
                search_start = idx + 1

            if not found:
                break
            text = text[:idx] + orig + text[idx + len(norm):]
            replacements.pop(0)
    return text


def generate_subtitle_entries(tts_text: str, text_duration_pairs: list) -> list:
    subtitle_entries = []
    current_time = 0.0

    replacements = _extract_replacement_list(tts_text, ''.join(pair[0] for pair in text_duration_pairs))
    for text, duration in text_duration_pairs:
        reversed_text = _reverse_replacement(text, replacements)
        start_time = current_time
        end_time = current_time + duration
        subtitle_entries.append({
            "text": reversed_text,
            "start": start_time,
            "end": end_time
        })
        current_time = end_time
    return subtitle_entries


def generate_subtitle_content(tts_text: str, input_audio, srt_file):
    asr_results = _get_subtitle(input_audio)
    subtitle_entries = []
    replacements = _extract_replacement_list(tts_text, ''.join(ret["text"] for ret in asr_results))
    for ret in asr_results:
        reversed_text = _reverse_replacement(ret["text"], replacements)
        subtitle_entries.append({
            "text": reversed_text,
            "start": ret["start"],
            "end": ret["end"]
        })
    with open(srt_file, "w", encoding="utf-8") as f:
        json.dump(subtitle_entries, f, ensure_ascii=False, indent=2)
