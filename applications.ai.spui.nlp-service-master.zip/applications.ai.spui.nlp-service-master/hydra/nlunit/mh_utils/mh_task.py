import os
import shlex
import json
import base64
import subprocess
import sys
from abc import ABC, abstractmethod
from functools import partial
from concurrent.futures import ThreadPoolExecutor
from typing import Optional, Callable, Union, List
from deprecated import deprecated

from hydra.nlunit.mh_utils.utils import (
    handle_stream, handle_blocking_pipe, handle_control, MHStatus, InferenceType
)
from hydra.nlunit.mh_utils.db_utils import update_model_detail


def _get_python_executable():
    return sys.executable


def _update_train_status_with_json(detail: Union[bytes, str], mh_id, task, db_args: dict):
    if isinstance(detail, bytes):
        detail = detail.decode('utf-8', errors='replace')
    print(f"task {mh_id}: update train status with json: {detail}")
    update_model_detail(mh_id, task, detail, **db_args)


def _generate_train_cmd(
        root_path: str,
        config: str,
        gen_infer_yml: str,
        pipe: Optional[str] = None,
) -> str:
    cmd = [
        _get_python_executable(), shlex.quote(os.path.join(root_path, "metahuman_demo.py")),
        "train",
        "-c", shlex.quote(config),
        "-g", shlex.quote(gen_infer_yml),
    ]

    if pipe:
        cmd.extend(["-p", shlex.quote(pipe)])

    return " ".join(cmd)


def _generate_infer_cmd(
        root_path: str,
        config: str,
        task_file: str,
        input: List[str],
        output: List[str],
        srt_file: Optional[List[str]] = None,
) -> str:
    srt_file = srt_file or [None] * len(input)

    with open(task_file, 'w', encoding='utf-8') as f:
        for inp, outp, srt in zip(input, output, srt_file):
            entry = {"input": inp}
            entry["output"] = outp
            if srt:
                entry["srt"] = srt
            f.write(json.dumps(entry, ensure_ascii=False) + '\n')

    cmd = [
        _get_python_executable(), shlex.quote(os.path.join(root_path, "metahuman_demo.py")),
        "inference",
        "-c", shlex.quote(config),
        "-f", shlex.quote(task_file)
    ]

    return " ".join(cmd)


def _generate_voice_cmd(
        root_path: str,
        config,
        msg_file: str,
        id: str,
        prompt_wav_path: str,
        prompt_text: str,
        prompt_cut_duration: float,
        cluster: bool,
        text: List[str],
        wav_output: List[str],
        name: str,
        account_id: str,
        type: Optional[InferenceType],
        srt_file: Optional[List[str]] = None,
        instruct: Optional[dict] = None,
        seed: Optional[int] = None,
        user_bucket: Optional[str] = None,
        workspace: Optional[dict] = None,
) -> str:
    message = {
        "id": base64.b64encode(id.encode('ascii')).decode('ascii'),
        "wav_path": prompt_wav_path,
        "customized_prompt": prompt_text,
        "cut_duration": prompt_cut_duration,
        "instruct": instruct,
        "text": text,
        "output_path": wav_output,
        "cluster": cluster,
        "userBucket": user_bucket,
        "workSpace": workspace,
        "srt": srt_file,
        "seed": seed,
        "name": name,
        "account_id": account_id,
        "type": type
    }

    with open(msg_file, 'w', encoding='utf-8') as f:
        json.dump({k: v for k, v in message.items() if v is not None}, f, ensure_ascii=False)
    cmd = [
        _get_python_executable(), os.path.join(root_path, 'rsocket_infer_send.py'),
        "--host", config["host"],
        "--port", config["port"],
        "--route", config["route_path"],
        "--message", shlex.quote(msg_file),
    ]
    return " ".join(cmd)


def _generate_latentsync_cmd(
        root_path: str,
        host: str,
        port: int,
        route: str,
        msg_file: str,
        id: str,
        reference_video: str,
        cluster: bool,
        audio_input: List[str],
        video_output: List[str],
        hdtr: bool,
        subtitle: bool,
        name: str,
        account_id: str,
        type: Optional[InferenceType],
        srt_file: Optional[List[str]] = None,
        subtitle_styles: Optional[dict] = None,
        user_bucket: Optional[str] = None,
        workspace: Optional[dict] = None,
        inference_steps: int = 20,
        guidance_scale: float = 1.0,
        event_channel: Optional[str] = None,
) -> str:
    message = {
        "id": base64.b64encode(id.encode('ascii')).decode('ascii'),
        "video_path": reference_video,
        "audio_path": audio_input,
        "output_path": video_output,
        "cluster": cluster,
        "userBucket": user_bucket,
        "workSpace": workspace,
        "hdtr": hdtr,
        "subtitle": subtitle,
        "srt": srt_file,
        "subtitle_styles": subtitle_styles,
        "num_inference_steps": inference_steps,
        "guidance_scale": guidance_scale,
        "event_channel": event_channel,
        "name": name,
        "account_id": account_id,
        "type": type
    }

    with open(msg_file, 'w', encoding='utf-8') as f:
        json.dump({k: v for k, v in message.items() if v is not None}, f, ensure_ascii=False)
    cmd = [
        _get_python_executable(), os.path.join(root_path, 'rsocket_infer_send.py'),
        "--host", host,
        "--port", str(port),
        "--route", route,
        "--message", shlex.quote(msg_file),
        "--nonblocking",
    ]

    return " ".join(cmd)


@deprecated(version="0.3.2", reason="use MetaHumanTrain or MetaHumanInference instead")
def execute_cmd(cmd: str, output_fn: Callable, byte_num=32):
    p = subprocess.Popen(['/bin/bash', '-c', cmd],
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=False)
    for c in iter(lambda: p.stdout.read(byte_num), b""):
        output_fn(c)
    p.wait()
    return p.returncode


COMMON_MAX_WORKER = {
    "train": 3,
    "infer": 1,
    "default": 1,
}


class MetaHumanTask(ABC):
    cmd: str
    max_workers: int

    def __init__(self, *args, **kwargs):
        max_workers = kwargs.pop("max_workers", COMMON_MAX_WORKER["default"])
        self._max_workers = max_workers
        self.cmd = self.compose_command(*args, **kwargs)

    @abstractmethod
    def compose_command(self, *args, **kwargs) -> str:
        raise NotImplementedError(f"compose_command not implemented in {self.__class__.__name__}")

    def execute_cmd(self, log_redirect_fn: Callable, byte_num: int = 32,
                    callbacks: Optional[list[tuple]] = None, enable_ctl: bool = False) -> int:
        p = subprocess.Popen(
            ['/bin/bash', '-c', self.cmd],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=False
        )

        with ThreadPoolExecutor(max_workers=self._max_workers) as executor:
            executor.submit(handle_stream, iter(lambda: p.stdout.read(byte_num), b""), log_redirect_fn, "log_redirect")
            if callbacks:
                for callback in callbacks:
                    if len(callback) > 1:
                        executor.submit(callback[0], *callback[1:])
                        continue
                    executor.submit(callback[0])
            if enable_ctl:
                executor.submit(handle_control, p)

        p.wait()
        return p.returncode


class MetaHumanTrain(MetaHumanTask):
    def __init__(
            self,
            mh_id: Optional[str],
            task: Optional[str],
            redis,
            enable_log: bool,
            byte_num: int,
            root_path: str,
            config: str,
            gen_yml: str,
            pipe_path: str,
            db_args: dict,
            max_workers: int = COMMON_MAX_WORKER["default"],
    ):
        super().__init__(
            root_path,
            config,
            gen_yml,
            pipe_path,
            max_workers=max_workers,
        )
        if mh_id and enable_log:
            self.log_redirect_fn = partial(redis.publish, msg_id=mh_id)
        else:
            self.log_redirect_fn = print
        self.mh_id = mh_id
        self.task = task
        self.byte_num = byte_num
        self.pipe_path = pipe_path
        self.db_args = db_args
        try:
            os.mkfifo(self.pipe_path)
        except FileExistsError:
            # If the FIFO already exists, ignore the error
            pass

    def compose_command(self,
                        root_path: str,
                        config: str,
                        gen_yml: str,
                        pipe_path: str,
                        ) -> str:
        return _generate_train_cmd(root_path, config, gen_yml, pipe_path)

    def execute_cmd(self) -> int:
        print(f"{self.task} train: task {self.mh_id} start to run: cmd: {self.cmd}")
        return super().execute_cmd(
            self.log_redirect_fn,
            self.byte_num,
            callbacks=[(
                handle_blocking_pipe(
                    self.pipe_path,
                    self.byte_num,
                    partial(_update_train_status_with_json, mh_id=self.mh_id, task=self.task, db_args=self.db_args),
                    "train_status_pipe"
                ),
            ), ],
            enable_ctl=True,
        )


class MetaHumanInference(MetaHumanTask):
    def __init__(
            self,
            mh_id: Optional[str],
            task: Optional[str],
            redis,
            enable_log: bool,
            byte_num: int,
            root_path: str,
            config: str,
            task_file: str,
            input: List[str],
            output: List[str],
            srt_file: Optional[List[str]] = None,
            max_workers: int = COMMON_MAX_WORKER["default"],
    ):
        super().__init__(
            root_path,
            config,
            task_file,
            input,
            output,
            srt_file,
            max_workers=max_workers,
        )
        if mh_id and enable_log:
            self.log_redirect_fn = partial(redis.publish, msg_id=mh_id)
        else:
            self.log_redirect_fn = print
        self.mh_id = mh_id
        self.task = task
        self.byte_num = byte_num

    def compose_command(
            self,
            root_path: str,
            config: str,
            task_file: str,
            input: List[str],
            output: List[str],
            srt_file: Optional[List[str]] = None,
    ) -> str:
        return _generate_infer_cmd(root_path, config, task_file, input, output, srt_file)

    def execute_cmd(self) -> int:
        print(f"{self.task} inference: task {self.mh_id} start to run: cmd: {self.cmd}")
        return super().execute_cmd(self.log_redirect_fn, self.byte_num)


class VoiceInference(MetaHumanTask):
    def __init__(
            self,
            mh_id: Optional[str],
            task: Optional[str],
            redis,
            enable_log: bool,
            byte_num: int,
            root_path: str,
            config,
            msg_file: str,
            prompt_wav_path: str,
            prompt_text: str,
            prompt_cut_duration: float,
            cluster: bool,
            text: List[str],
            output_path: List[str],
            name: str,
            account_id: str,
            type: Optional[InferenceType],
            srt_file: Optional[List[str]] = None,
            instruct: Optional[dict] = None,
            seed: Optional[int] = None,
            userBucket: Optional[str] = None,
            workspace: Optional[dict] = None,
            max_workers: int = COMMON_MAX_WORKER["default"],
    ):
        super().__init__(
            root_path,
            config,
            msg_file,
            mh_id,
            prompt_wav_path,
            prompt_text,
            prompt_cut_duration,
            cluster,
            text,
            output_path,
            name,
            account_id,
            type,
            srt_file,
            instruct,
            seed,
            userBucket,
            workspace,
            max_workers=max_workers
        )
        if mh_id and enable_log:
            self.log_redirect_fn = partial(redis.publish, msg_id=mh_id)
        else:
            self.log_redirect_fn = print
        self.mh_id = mh_id
        self.byte_num = byte_num
        self.task = task

    def compose_command(
            self,
            root_path: str,
            config,
            msg_file: str,
            mh_id: str,
            prompt_wav_path: str,
            prompt_text: str,
            prompt_cut_duration: float,
            cluster: bool,
            text: List[str],
            wav_output: List[str],
            name: str,
            account_id: str,
            type: Optional[InferenceType],
            srt_file: Optional[List[str]] = None,
            instruct: Optional[dict] = None,
            seed: Optional[int] = None,
            userBucket: Optional[str] = None,
            workspace: Optional[dict] = None,
    ) -> str:
        return _generate_voice_cmd(root_path, config, msg_file, mh_id, prompt_wav_path, prompt_text,
                                   prompt_cut_duration, cluster, text, wav_output, name, account_id, type, srt_file, instruct, seed,
                                   userBucket, workspace)

    def execute_cmd(self) -> int:
        print(f"{self.task} inference: task {self.mh_id} start to run: cmd: {self.cmd}")
        return super().execute_cmd(self.log_redirect_fn, self.byte_num)


class LatentSyncInference(MetaHumanTask):
    def __init__(
            self,
            mh_id: Optional[str],
            task: Optional[str],
            redis,
            enable_log: bool,
            byte_num: int,
            root_path: str,
            host: str,
            port: int,
            route: str,
            msg_file: str,
            reference_video: str,
            cluster: bool,
            audio_input: List[str],
            video_output: List[str],
            hdtr: bool,
            subtitle: bool,
            name: str,
            account_id: str,
            type: Optional[InferenceType],
            srt_file: Optional[List[str]] = None,
            subtitle_styles: Optional[dict] = None,
            userBucket: Optional[str] = None,
            workspace: Optional[dict] = None,
            max_workers: int = COMMON_MAX_WORKER["default"],
    ):
        self.event_channel = f"ls-channel-{mh_id}" if mh_id else None
        super().__init__(
            root_path,
            host,
            port,
            route,
            msg_file,
            mh_id,
            reference_video,
            cluster,
            audio_input,
            video_output,
            hdtr,
            subtitle,
            name,
            account_id,
            type,
            srt_file,
            subtitle_styles,
            userBucket,
            workspace,
            max_workers=max_workers
        )
        if mh_id and enable_log:
            self.log_redirect_fn = partial(redis.publish, msg_id=mh_id)
        else:
            self.log_redirect_fn = print
        self.redis = redis
        self.mh_id = mh_id
        self.byte_num = byte_num
        self.task = task

    def compose_command(
            self,
            root_path: str,
            host: str,
            port: int,
            route: str,
            msg_file: str,
            mh_id: str,
            reference_video: str,
            cluster: bool,
            audio_input: List[str],
            video_output: List[str],
            hdtr: bool,
            subtitle: bool,
            name: str,
            account_id: str,
            type: Optional[InferenceType],
            srt_file: Optional[List[str]] = None,
            subtitle_styles: Optional[dict] = None,
            userBucket: Optional[str] = None,
            workspace: Optional[dict] = None,
    ) -> str:
        return _generate_latentsync_cmd(root_path, host, port, route, msg_file, mh_id, reference_video, cluster,
                                        audio_input, video_output, hdtr, subtitle, name, account_id, type, srt_file, 
                                        subtitle_styles, userBucket, workspace, event_channel=self.event_channel)

    def execute_cmd(self) -> int:
        print(f"{self.task} inference: task {self.mh_id} start to run: cmd: {self.cmd}")
        ret = super().execute_cmd(self.log_redirect_fn, self.byte_num)
        if self.event_channel:
            ret_msg = self.redis.wait_event(self.event_channel)
            ret = json.loads(ret_msg)
            if ret["status"] != MHStatus.SUCCESS:
                return -1
            return 0
        return ret
