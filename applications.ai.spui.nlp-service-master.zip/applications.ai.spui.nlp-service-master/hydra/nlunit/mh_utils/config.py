import dataclasses
import os
import yaml
from typing import Optional

from hydra.nlunit.common_utils.storage_cache import StorageShared, MetaShared


@dataclasses.dataclass
class MHInferenceConfig:
    root_workspace: str
    root_dataset: str
    infer_bucket: str
    root_log_workspace: str
    item_bucket: str
    fail_output_dir: str
    shared: Optional[StorageShared] = None
    meta_shared: Optional[MetaShared] = None


@dataclasses.dataclass
class CustomizedVoiceUnitConfig:
    path: str
    local: bool
    env_name: str = "tts-ex"

    def load_from_local(self):
        if os.path.exists(self.path):
            with open(self.path, "r", encoding="utf-8") as f:
                config = yaml.safe_load(f)
            return config
        return None
