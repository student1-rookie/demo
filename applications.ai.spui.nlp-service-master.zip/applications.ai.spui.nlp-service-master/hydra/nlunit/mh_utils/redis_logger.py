import os
import time
import uuid
from dataclasses import dataclass, asdict
from contextlib import contextmanager, nullcontext
from typing import Optional

from hydra.nlunit.mh_utils.utils import ModelStatus
import json

_REDIS_AVAILABLE = True
try:
    from redis import StrictRedis
except ImportError:
    _REDIS_AVAILABLE = False


@dataclass
class RedisConfig:
    host: str
    port: int
    db: int
    username: Optional[str] = None
    password: str = ""

    @staticmethod
    def generate(**kwargs):
        if kwargs:
            return RedisConfig(**kwargs)
        host = os.getenv("RDS_HOST", "localhost")
        port = os.getenv("RDS_PORT", 6379)
        db = os.getenv("RDS_DB", 0)
        username = os.getenv("RDS_USER", None)
        password = os.getenv("RDS_PASSWORD", "")
        return RedisConfig(host=host, port=port, db=db, username=username, password=password)


class RedisLogger:
    def __init__(self, header, config: RedisConfig = RedisConfig.generate(), root_log_workspace=None, enable=True):
        assert _REDIS_AVAILABLE, "redis is not available."
        self._header = header
        self._redis = StrictRedis(**asdict(config)) if enable else None
        self._env: Optional[str] = None
        self._root_log_workspace = root_log_workspace

    def publish(self, message, msg_id):
        if isinstance(message, bytes):
            message = message.decode('utf-8', errors='replace')
        if len(self._header):
            message = f"{self._header}: {message}"
        if self._redis is None or msg_id is None:
            print(message)
            return
        self._redis.xadd(msg_id, {'log': message + '\n'})

    def switch_env(self, env, **kwargs):
        if self._env != env:
            self._env = env
            self._redis = StrictRedis(**asdict(RedisConfig.generate(**kwargs)))

    def wait_event(self, channel):
        if self._redis is None:
            return None
        p = self._redis.pubsub()
        p.subscribe(channel)
        ret = None
        for msg in p.listen():
            if msg["type"] == "message":
                ret = msg["data"].decode()
                break
        p.unsubscribe()
        p.close()
        return ret

    def set_event(self, channel, msg):
        if self._redis is not None:
            self._redis.publish(channel, msg)

    def _save_logs(self, msg_id, file_dir, upload_func):
        logs = self._redis.xrange(msg_id, min='-', max='+')
        file_path = os.path.join(file_dir, f"{msg_id}.log")
        with open(file_path, 'w', encoding='utf-8') as file:
            for log_id, log_data in logs:
                log_message = log_data.get(b'log', b'').decode('utf-8')
                file.write(log_message)
        print(f"Logs have been saved to {file_path}")
        if upload_func:
            upload_func(file_path)
            os.remove(file_path)

    def _delete_logs(self, msg_id):
        self._redis.delete(msg_id)
        print(f"id as {msg_id}'s log has been deleted in redis")

    @contextmanager
    def log_operations(self, status, id, upload_func=None):
        if (status not in [ModelStatus.COMPLETE, ModelStatus.FAIL, ModelStatus.CANCEL] or
                self._redis is None or id is None):
            yield
            return
        log_dir = self._root_log_workspace
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)
        try:
            self._save_logs(id, log_dir, upload_func)
            yield
        except Exception as e:
            print(f"An error occurred: {e}")
        finally:
            self._delete_logs(id)

    def update_json_field(self, key: str, field_values: dict, expire_time=None):
        if self._redis is None:
            raise RuntimeError("Redis not initialized")

        try:
            value = self._redis.get(key)
            if value is None:
                print(f"key: {key} not exist")
                return None

            if isinstance(value, bytes):
                value = value.decode('utf-8')
            data = json.loads(value)
            
            for name in field_values:
                old_value = data.get(name)
                data[name] = field_values[name]
                print(f"updated key='{key}' '{name}': {old_value} → {field_values[name]}")

            new_json = json.dumps(data)
            self._redis.set(key, new_json, expire_time)

            return data

        except Exception as e:
            print(f"redis update failed")
            return None
    
    def save_stream_message(self, stream_key: str, fields):
        entry_id = self._redis.xadd(
            stream_key,
            fields,
            id="*",
            maxlen=100,
            approximate=True
        )

        return entry_id

    @contextmanager
    def redis_lock(
        self,
        lock_key: str,
        lock_value: str | None = None,
        expire: int = 300,
        retry_interval: float = 1,
        max_wait: int = 360
    ):
        if self._redis is None:
            with nullcontext():
                yield
            return

        if lock_value is None:
            lock_value = str(uuid.uuid4())

        start = time.time()
        acquired = False

        try:
            while not acquired:
                acquired = self._redis.set(
                    lock_key,
                    lock_value,
                    nx=True,
                    ex=expire
                )

                if acquired:
                    break

                if time.time() - start > max_wait:
                    raise TimeoutError(f"Failed to acquire lock: {lock_key}")

                time.sleep(retry_interval)

            yield

        finally:
            if acquired:
                lua_script = """
                if redis.call("get", KEYS[1]) == ARGV[1] then
                    return redis.call("del", KEYS[1])
                else
                    return 0
                end
                """
                try:
                    self._redis.eval(lua_script, 1, lock_key, lock_value)
                except Exception as e:
                    print(f"release redis lock failed: {e}")



