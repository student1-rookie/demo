import os
import psycopg2
from psycopg2.extras import DictCursor
import hashlib
import base64
from dataclasses import dataclass, asdict
from contextlib import nullcontext
import json
from datetime import datetime

from hydra.nlunit.mh_utils.mh_pip import MetaHumanInfer
from hydra.nlunit.ppt_utils.common import InferencePicInPicDto, MetaHumanDataset


@dataclass
class DbConfig:
    host: str
    database: str
    user: str
    password: str

    @staticmethod
    def generate(**kwargs):
        if kwargs:
            return DbConfig(**kwargs)
        host = os.getenv("DB_HOST", "localhost")
        database = os.getenv("DB_DATABASE", "flex_mh")
        user = os.getenv("DB_USER", "<USER>")
        password = os.getenv("DB_PASSWORD", "<PASSWORD>")
        return DbConfig(host, database, user, password)


def init_model_status(mh_id: str, service_name: str, table_key: str, status_val: str, **kwargs):
    sql = f"UPDATE meta_human_{table_key} SET status = %(status)s, run_service = %(service)s WHERE id = %(id)s"
    updated_row_count = _update_db(sql, {"status": status_val, "service": service_name, "id": mh_id}, **kwargs)
    if updated_row_count == 0:
        print(f"Update meta_human_{table_key} status WAIT fail!")
    return updated_row_count

def update_items_status(item_ids: list, status_val: str, table_key: str, service_name: str = None):
    if service_name is not None:
        sql = f"UPDATE meta_human_{table_key} SET status = %(status)s, run_service = %(service)s WHERE id in %(ids)s"
        updated_row_count = _update_db(sql, {"status": status_val, "service": service_name, "ids": tuple(item_ids)})
    else:
        sql = f"UPDATE meta_human_{table_key} SET status = %(status)s WHERE id in %(ids)s"
        updated_row_count = _update_db(sql, {"status": status_val, "ids": tuple(item_ids)})

    if updated_row_count == 0:
        print(f"Update meta_human_{table_key} status WAIT fail!")
    return updated_row_count

def update_model_status(mh_id: str, table_key: str, status_val: str, redis=None, clean_detail: bool = False,
                        upload_func=None, **kwargs):
    if clean_detail:
        sql = f"UPDATE meta_human_{table_key} SET status = %(status)s, detail = NULL WHERE id = %(id)s"
    else:
        sql = f"UPDATE meta_human_{table_key} SET status = %(status)s WHERE id = %(id)s"
    context_manager = redis.log_operations(status_val, mh_id, upload_func) if redis else nullcontext()
    with context_manager:
        updated_row_count = _update_db(sql, {"status": status_val, "id": mh_id}, **kwargs)
    if updated_row_count == 0:
        print(f"Update meta_human_{table_key} status {status_val} fail!")
    return updated_row_count


def update_model_detail(mh_id: str, table_key: str, detail: str, **kwargs):
    sql = f"UPDATE meta_human_{table_key} SET detail = %(detail)s WHERE id = %(id)s"
    updated_row_count = _update_db(sql, {"detail": detail, "id": mh_id}, **kwargs)
    if updated_row_count == 0:
        print(f"Update meta_human_{table_key} detail fail: mh_id: {mh_id}, detail: {detail}")


def update_tts_model(mh_id: str, status_val: str, dataset_id: str, redis=None, upload_func=None, **kwargs):
    sql = f"UPDATE meta_human_tts SET status = %(status)s, dataset_id = %(dataset_id)s WHERE id = %(id)s"
    context_manager = redis.log_operations(status_val, mh_id, upload_func) if redis else nullcontext()
    with context_manager:
        updated_row_count = _update_db(sql, {"status": status_val, "id": mh_id, "dataset_id": dataset_id}, **kwargs)
    if updated_row_count == 0:
        print(f"Update meta_human_tts cv model fail: mh_id: {mh_id}, status: {status_val}, dataset_id: {dataset_id}")


def update_tts_model_params(mh_id: str, status_val: str, dataset_id: str, params: dict, redis=None, upload_func=None,
                            **kwargs):
    sql = f"UPDATE meta_human_tts SET status = %(status)s, dataset_id = %(dataset_id)s, parameters = %(parameters)s WHERE id = %(id)s"
    context_manager = redis.log_operations(status_val, mh_id, upload_func) if redis else nullcontext()
    with context_manager:
        updated_row_count = _update_db(sql, {"status": status_val, "id": mh_id, "dataset_id": dataset_id,
                                             "parameters": json.dumps(params, ensure_ascii=False)}, **kwargs)
    if updated_row_count == 0:
        print(f"Update meta_human_tts cv model fail: mh_id: {mh_id}, status: {status_val}, dataset_id: {dataset_id}")


def create_dataset_group(name, access_type, account_id, **kwargs):
    sql = """
          INSERT INTO meta_human_dataset_group (name, type, account_id)
          VALUES (%s, %s, %s) RETURNING id \
          """
    updated_row_count, returned_id = _update_db(sql, (name, access_type, account_id), **kwargs)
    if updated_row_count == 0:
        print(f"Insert meta_human_dataset_group fail!")
        return None
    return returned_id


def find_dataset(identifier, **kwargs):
    sql = f"SELECT id FROM meta_human_dataset WHERE identifier = %(identifier)s"
    return _search_db(sql, {"identifier": identifier}, **kwargs)


def insert_dataset(dataset: MetaHumanDataset, **kwargs):
    """
    Inserts a new meta_human_dataset row and returns the newly generated id.
    """
    sql = """
          INSERT INTO meta_human_dataset
          (name, type, file_name, identifier, file_type, internal, account_id, group_id)
          VALUES (%s, %s, %s, %s, %s, %s, %s, %s) RETURNING id \
          """
    params = (
        dataset.name,
        dataset.type,
        dataset.fileName,
        dataset.identifier,
        dataset.fileType,
        dataset.internal,
        dataset.accountID,
        dataset.groupID
    )
    updated_row_count, returned_id = _update_db(sql, params, **kwargs)
    if updated_row_count == 0:
        print(f"Insert meta_human_dataset fail!")
        return None
    return returned_id


def insert_infer(infer: MetaHumanInfer, **kwargs):
    """
    Inserts a new meta_human_infer row and returns the newly generated id.
    """
    sql = """
          INSERT INTO meta_human_infer
              (name, account_id, tts_model, face_model, type, run_service)
          VALUES (%s, %s, %s, %s, %s, %s) RETURNING id \
          """
    params = (
        infer.name,
        infer.accountID,
        infer.ttsModel,
        infer.faceModel,
        infer.type,
        infer.runService
    )

    updated_row_count, returned_id = _update_db(sql, params, **kwargs)
    if updated_row_count == 0:
        print(f"Insert meta_human_dataset fail!")
        return None
    return returned_id


def delete_infers(ids, **kwargs):
    sql = "DELETE FROM meta_human_infer WHERE id IN %(ids)s"
    _update_db(sql, {"ids": tuple(ids)}, **kwargs)


def update_infers(ids, group_id, **kwargs):
    sql = "UPDATE meta_human_infer SET group_id = %(group_id)s WHERE id IN %(ids)s"
    _update_db(sql, {"group_id": group_id, "ids": tuple(ids)}, **kwargs)


def find_infer_group(groupId, **kwargs):
    sql = f"SELECT id FROM meta_human_infer WHERE (status in ('COMPLETE', 'FAIL') OR status IS NULL) AND type = 'PIP_ITEM' AND group_id = %(groupId)s "
    rows = _search_db(sql, {"groupId": groupId}, **kwargs)
    return [row[0] for row in rows]


def find_infer_ids(id, **kwargs):
    sql = f"SELECT id FROM meta_human_infer_group WHERE id = %(id)s"
    return _search_db(sql, {"id": id}, **kwargs)


def insert_pic_in_pic_template(template: InferencePicInPicDto, account_id: str, **kwargs):
    """
    Inserts a new meta_human_pic_template row and returns the newly generated id.
    """
    sql = """
          INSERT INTO meta_human_pic_template
              (name, details, account_id)
          VALUES (%s, %s, %s) RETURNING id \
          """
    params = (
        template.name,
        json.dumps(asdict(template), ensure_ascii=False),
        account_id
    )
    updated_row_count, returned_id = _update_db(sql, params, **kwargs)
    if updated_row_count == 0:
        print(f"Insert meta_human_pic_template fail!")
        return None
    return returned_id


def find_pic_in_pic_template(name: str, account_id: str, **kwargs):
    sql = f"SELECT COUNT(*) FROM meta_human_pic_template WHERE name SIMILAR TO %(name)s AND account_id = %(account_id)s"
    return _search_db(sql, {"name": name, "account_id": account_id}, **kwargs)


def _update_db(sql, vars, **kwargs):
    config = DbConfig.generate(**kwargs)
    with psycopg2.connect(**config.__dict__) as conn:
        with conn.cursor() as cur:
            cur.execute(sql, vars)
            updated_row_count = cur.rowcount
            returned_id = None
            if cur.description and 'RETURNING' in sql.upper():
                returned_id = cur.fetchone()[0]
        conn.commit()
    return updated_row_count, returned_id


def _search_db(sql, vars, **kwargs):
    config = DbConfig.generate(**kwargs)
    with psycopg2.connect(**config.__dict__) as conn:
        with conn.cursor() as cur:
            cur.execute(sql, vars)
            return cur.fetchall()

def _search_db_dict(sql, vars):
    config = DbConfig.generate()
    with psycopg2.connect(**config.__dict__) as conn:
        with conn.cursor(cursor_factory=DictCursor) as cur:
            cur.execute(sql, vars)
            return cur.fetchall()


def generate_identifier(account_id, file_md5):
    combined = account_id + file_md5
    combined = hashlib.md5(combined.encode("utf-8")).digest()
    # without padding
    return base64.urlsafe_b64encode(combined).decode("utf-8").rstrip("=")

def find_infer(name, accountId, groupId):
    sql = f"SELECT * FROM meta_human_infer WHERE name = %(name)s and account_id = %(accountId)s and group_id = %(groupId)s"
    return _search_db_dict(sql, {"name": name, "accountId": accountId, "groupId": groupId})

def delete_infer(id):
    sql = "DELETE FROM meta_human_infer WHERE id = %(id)s"
    _update_db(sql, {"id": id})

def find_infer_by_id(id):
    sql = f"SELECT * FROM meta_human_infer WHERE id = %(id)s"
    return _search_db_dict(sql, {"id": id})

def insert_notification(account_id, status, message, redis=None, **kwargs):
    sql = """
          INSERT INTO meta_human_notify (status, message, account_id)
          VALUES (%s, %s, %s) RETURNING id \
          """
    if redis is not None:
        streamKey = f"notifications:{account_id}"
        fields = {
            "userId": account_id,
            "status": status,
            "message": message,
            "timestamp": datetime.utcnow().isoformat()
        }
        redis.save_stream_message(streamKey, fields)
    updated_row_count, returned_id = _update_db(sql, (status, message, account_id), **kwargs)
    if updated_row_count == 0:
        print(f"Insert meta_human_notify fail!")