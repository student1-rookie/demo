from dataclasses import dataclass


@dataclass
class MHWorkspace:
    bucket: str
    dataset: str = ""
    model: str = ""
    log: str = ""
    inference: str = ""
    temp: str = ""
    fail: str = ""

    @staticmethod
    def initialize(**kwargs):
        if kwargs.get("cluster", False):
            bucket = kwargs.get("userBucket")
            workspace = kwargs["workSpace"]
            dataset = workspace.get("datasetBase", "")
            model = workspace.get("modelBase", "")
            log = workspace.get("logBase", "")
            inference = workspace.get("inferenceBase", "")
            temp = workspace.get("tempBase", "")
            fail = workspace.get("failBase", "")
            return MHWorkspace(bucket, dataset, model, log, inference, temp, fail)
        return None

    def to_dict(self):
        return {
            "cluster": True,
            "userBucket": self.bucket,
            "workSpace": {
                "datasetBase": self.dataset,
                "modelBase": self.model,
                "logBase": self.log,
                "inferenceBase": self.inference,
            }
        }

    def gen_model_object(self, model_id, file_name):
        return f"{self.model}/{model_id}/{file_name}"

    def gen_infer_object(self, infer_id, file_name):
        return f"{self.inference}/{infer_id}/{file_name}"
    
    def gen_item_object(self, item_id, file_name):
        return f"{self.temp}/{item_id}/{file_name}"

    def gen_dataset_object(self, dataset_id, file_name):
        return f"{self.dataset}/{dataset_id}/{file_name}"

    def gen_log_object(self, log_id):
        return f"{self.log}/{log_id}.log"

    def gen_infer_prefix(self, infer_id):
        return f"{self.inference}/{infer_id}"
    
    def gen_item_prefix(self, infer_id):
        return f"{self.temp}/{infer_id}"

    def gen_fail_object(self, fail_id, file_name):
        return f"{self.fail}/{fail_id}/{file_name}"


def gen_bucket_object(bucket, object):
    return f"{bucket}/{object}"
