import asyncio
import dataclasses
import json

from rsocket.helpers import single_transport_provider
from rsocket.payload import Payload
from rsocket.rsocket_client import RSocketClient
from rsocket.frame_helpers import ensure_bytes
from rsocket.transports.tcp import TransportTCP
from rsocket.extensions.helpers import route, composite
from rsocket.extensions.mimetypes import WellKnownMimeTypes


@dataclasses.dataclass
class RSocketClientConfig:
    host: str
    port: str
    route_path: str


async def send_request(config: RSocketClientConfig, message, non_blocking=False):
    connection = await asyncio.open_connection(config.host, config.port)

    async with RSocketClient(
            single_transport_provider(TransportTCP(*connection)),
            metadata_encoding=WellKnownMimeTypes.MESSAGE_RSOCKET_COMPOSITE_METADATA
    ) as client:
        payload = Payload(
            ensure_bytes(message),
            composite(route(config.route_path))
        )
        if non_blocking:
            return await client.fire_and_forget(payload)
        else:
            result = (await client.request_response(payload)).data
            return json.loads(result.decode('utf-8'))
