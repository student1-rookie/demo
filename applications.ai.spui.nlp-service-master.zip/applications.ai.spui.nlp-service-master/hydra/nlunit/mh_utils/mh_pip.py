
import os
import ffmpeg
from typing import List
from pathlib import Path
from dataclasses import dataclass
from typing import List, Optional

from hydra.nlunit.mh_utils.subtitle import format_srt_file, filter_styled_subtitles


ffmpeg_path = os.getenv('FFMPEG_PATH', 'ffmpeg')


@dataclass
class MetaHumanInfer:
    name: str
    accountID: str
    runService: str
    type: str = "PIP_ITEM"
    ttsModel: Optional[str] = None
    faceModel: Optional[str] = None

def extend_media(input_file, media_type, extend_duration=1):
    if media_type not in ['audio', 'video']:
        raise ValueError("media_type must be 'audio' or 'video'")

    file_root, file_ext = os.path.splitext(input_file)
    temp_file = file_root + '_temp' + file_ext

    if media_type == 'video':
        # Extend video by cloning the last frame
        video = ffmpeg.input(input_file).video
        video = video.filter('tpad', stop_mode='clone', stop_duration=extend_duration)

        # Extend audio by padding with silence (if audio exists)
        audio = ffmpeg.input(input_file).audio
        audio = audio.filter('apad', pad_dur=extend_duration)

        # Combine extended video and audio
        ffmpeg.output(video, audio, temp_file).global_args("-loglevel", "error").run(
            cmd=ffmpeg_path,
            overwrite_output=True
        )

    elif media_type == 'audio':
        # Extend audio by padding with silence
        audio = ffmpeg.input(input_file).audio
        audio = audio.filter('apad', pad_dur=extend_duration)
        # Output extended audio
        ffmpeg.output(audio, temp_file).global_args("-loglevel", "error").run(
            cmd=ffmpeg_path,
            overwrite_output=True
        )

    os.replace(temp_file, input_file)
    print(f"Media {input_file} extended by {extend_duration} seconds")


@dataclass
class PictureInPictureTask:
    main: str
    overlay: str
    coordinate: List[float]
    box: List[float]
    types: List[str]
    srt: str
    id: str
    output: str


class PictureInPicture:
    def __init__(self, sample_rate=44100) -> None:
        self._origin_resolution_map = {}
        self._base_sar = "1/1"
        self._sample_rate = sample_rate
        self._size_limit = 3840

    def _get_audio_info(self, path):
        probe = ffmpeg.probe(path)
        audio_stream_info = next((stream for stream in probe['streams'] if stream['codec_type'] == 'audio'),
                                 None)
        return audio_stream_info

    def _get_video_info(self, path):
        probe = ffmpeg.probe(path)
        video_stream_info = next((stream for stream in probe['streams'] if stream['codec_type'] == 'video'),
                                 None)
        return video_stream_info

    def _get_resolution_width_height(self, res_name):
        resolutions = {
            "4k": [3840, 2160],
            "2k": [2560, 1440],
            "1080p": [1920, 1080],
            "720p": [1280, 720],
        }
        return resolutions[res_name.lower()]

    def _get_video_width_height(self, path):
        stream_info = self._get_video_info(path)
        height = int(stream_info['height'])
        width = int(stream_info['width'])
        return width, height

    def _get_duration(self, path):
        audio_stream_info = self._get_audio_info(path)
        if audio_stream_info:
            return float(audio_stream_info['duration'])
        video_stream_info = self._get_video_info(path)
        if video_stream_info:
            return float(video_stream_info['duration'])
        return None

    def _calculate_axis(self, video_resolution, resolution, default_position='top-right'):
        x = 0
        y = 0
        match default_position:
            case 'center':
                x = (resolution[0] - video_resolution[0]) // 2
                y = (resolution[1] - video_resolution[1]) // 2
            case 'top-left':
                x = 0
                y = 0
            case 'top-right':
                x = resolution[0] - video_resolution[0]
                y = 0
            case 'bottom-left':
                x = 0
                y = resolution[1] - video_resolution[1]
            case 'bottom-right':
                x = resolution[0] - video_resolution[0]
                y = resolution[1] - video_resolution[1]
        return x, y

    def _calculate_scale_resolution(self, origin_resolution, target_resolution):
        scale_width = target_resolution[0] / origin_resolution[0]
        scale_height = target_resolution[1] / origin_resolution[1]

        scale = min(scale_width, scale_height)

        width = int((origin_resolution[0] * scale // 2) * 2)
        height = int((origin_resolution[1] * scale // 2) * 2)

        return width, height

    def _calculate_adaptive_global_resolution(self, video_list):
        # use the max resolution as global base_resolution
        max_area = 0
        max_resolution = []
        for video in video_list:
            if video.main:
                resolution = self._origin_resolution_map[video.main]
                # set a limit to the base resolution to save resources
                if (resolution[0] > self._size_limit or resolution[1] > self._size_limit):
                    resolution = self._calculate_scale_resolution(resolution, [self._size_limit, self._size_limit])
                area = resolution[0] * resolution[1]
                if area > max_area or (area == max_area and resolution[0] > max_resolution[0]):
                    max_area = area
                    max_resolution = resolution

        return [(max_resolution[0] // 2) * 2, (max_resolution[1] // 2) * 2]

    def _reframe_overlay_resolution(self, video_info):
        overlay = video_info.overlay
        box = video_info.box
        coordinate = video_info.coordinate
        overlay_resolution = self._origin_resolution_map[overlay]

        def calculate_default_video_info(resolution):
            split_width = resolution[0] // 2
            split_height = resolution[1] // 2
            scale_resolution = self._calculate_scale_resolution(overlay_resolution, [split_width, split_height])
            new_coordinate = self._calculate_axis(scale_resolution, resolution, default_position='top-right')
            return scale_resolution, new_coordinate

        # recalculate box and coordinate according to box/coordinate
        if box and coordinate:
            scale_resolution = self._calculate_scale_resolution(overlay_resolution, box)
            video_info.box = scale_resolution
            return video_info

        media = video_info.main
        # calulate box and coordinate according to media resolution and position
        media_resolution = self._origin_resolution_map[media]
        video_info.box, video_info.coordinate = calculate_default_video_info(media_resolution)
        return video_info

    def _calculate_origin_resolution(self, video_list):
        for item in video_list:
            overlay_path = item.overlay
            media_path = item.main
            types = item.types
            if overlay_path and os.path.exists(overlay_path) and types[1] != "AUDIO":
                resolution = self._get_video_width_height(overlay_path)
                self._origin_resolution_map[overlay_path] = resolution
            if media_path and os.path.exists(media_path):
                resolution = self._get_video_width_height(media_path)
                self._origin_resolution_map[media_path] = resolution

    def _overlay_video(self, overlay_info, base_resolution, subtitle_styles, final_base_resolution):
        overlay_path = overlay_info.overlay
        main_path = overlay_info.main
        main_resolution = self._origin_resolution_map[main_path]

        types = overlay_info.types
        srt = overlay_info.srt
        background_color = subtitle_styles.get("extendColor", "white")

        def process_audio(path, duration):
            audio_stream_info = self._get_audio_info(path)
            if audio_stream_info:
                audio_stream = ffmpeg.input(path).audio
            else:
                audio_stream = ffmpeg.input(f'anullsrc=r={self._sample_rate}:cl=stereo', f='lavfi', t=duration).audio
            return audio_stream

        def process_main_scale(main_stream):
            adaptive_resolution = self._calculate_scale_resolution(main_resolution, base_resolution)
            main_stream = main_stream.filter('scale', adaptive_resolution[0], adaptive_resolution[1])

            final_w = final_base_resolution[0]
            final_h = final_base_resolution[1]
            pad_y = (base_resolution[1] - adaptive_resolution[1]) // 2
            main_stream = (main_stream.filter('setsar', sar=self._base_sar)
                            .filter('pad', final_w, final_h, '(ow-iw)/2', pad_y, color=background_color))
            return main_stream, adaptive_resolution

        def add_subtitles(main_stream, srt):
            formatted_srt = os.path.join(os.path.dirname(srt), os.path.splitext(os.path.basename(srt))[0] + '.srt')
            format_srt_file(srt, formatted_srt)
            return filter_styled_subtitles(main_stream, formatted_srt, subtitle_styles)

        def process_single_media(path):
            main_stream = ffmpeg.input(path).video
            duration = self._get_duration(path)
            video_stream, _ = process_main_scale(main_stream)
            audio_stream = process_audio(path, duration)
            if srt and os.path.exists(srt):
                video_stream = add_subtitles(video_stream, srt)
            return video_stream, audio_stream

        def overlay(main_stream, adaptive_resolution, base_resolution):
            scale = adaptive_resolution[0] / main_resolution[0]
            x = (base_resolution[0] - adaptive_resolution[0]) / 2 + overlay_info.coordinate[0] * scale
            y = (base_resolution[1] - adaptive_resolution[1]) / 2 + overlay_info.coordinate[1] * scale
            scale_width = int(overlay_info.box[0] * scale)
            scale_height = int(overlay_info.box[1] * scale)
            overlay_stream = (
                ffmpeg.input(overlay_path)
                .filter('scale', scale_width, scale_height)
                .filter('setsar', sar=self._base_sar)
            )
            return ffmpeg.overlay(main_stream, overlay_stream, x=x, y=y)
        
        def process_overlay():
            if types[0] == 'IMAGE':
                duration = self._get_duration(overlay_path)
                main_stream = ffmpeg.input(main_path)
                audio_stream = process_audio(overlay_path, duration)
            else:
                duration = self._get_duration(main_path)
                main_stream = ffmpeg.input(main_path).video
                audio_stream = process_audio(main_path, duration)

            main_stream, adaptive_resolution = process_main_scale(main_stream)

            if (types[1] == 'AUDIO'):
                main_stream = (main_stream.filter('loop', loop=-1, size=1).filter('trim', duration=duration))
            else:
                main_stream = overlay(main_stream, adaptive_resolution, base_resolution)

            if srt and os.path.exists(srt):
                main_stream = add_subtitles(main_stream, srt)

            return main_stream, audio_stream

        if len(types) == 1:
            return process_single_media(main_path)
        elif len(types) == 2:
            return process_overlay()

        return None, None

    def _concatenate_videos(self, video_list, output, subtitle, subtitle_styles, pip_settings=None):
        try:
            self._calculate_origin_resolution(video_list)

            # base_resolution is the target resolution for whole PicInPic output
            if pip_settings and "default_resolution" in pip_settings:
                default_resolution = pip_settings["default_resolution"]
                base_resolution = self._get_resolution_width_height(default_resolution)
            else:
                base_resolution = self._calculate_adaptive_global_resolution(video_list)

            extend_ratio = float(subtitle_styles.get("extendRatio", 0.1))
            if subtitle and extend_ratio > 0:
                panel_h = int(base_resolution[1] * extend_ratio)
                panel_h = (panel_h // 2) * 2
            else:
                panel_h = 0

            final_base_resolution = [base_resolution[0], base_resolution[1] + panel_h]
            concat_list = []
            for index, video_info in enumerate(video_list):
                overlay = video_info.overlay
                if overlay and video_info.types[1] != "AUDIO":
                    video_info = self._reframe_overlay_resolution(video_info)

                video_stream, audio_stream = self._overlay_video(video_info, base_resolution, subtitle_styles, final_base_resolution)
                if video_stream and audio_stream:
                    temp_file = video_info.output
                    Path(os.path.dirname(temp_file)).mkdir(parents=True, exist_ok=True)
                    print(f"output video stream {index}")
                    print(f"output video path {temp_file}")
                    ffmpeg.output(video_stream, audio_stream, temp_file, format='mp4', vcodec='libx264',
                                  acodec='aac', pix_fmt='yuv420p').global_args("-loglevel", "error"
                                  ).run(
                                      cmd=ffmpeg_path,
                                      overwrite_output=True
                                  )
                    if output is None:
                        return True, "ffmpeg process picture in picture done!"
                    concat_list.append(temp_file)

            input_streams = [ffmpeg.input(concat_video) for concat_video in concat_list]
            video_streams = []
            audio_streams = []

            for stream in input_streams:
                video_streams.append(stream['v'])
                audio_streams.append(stream['a'])

            concat_video_stream = ffmpeg.concat(*video_streams, v=1, a=0)
            concat_audio_stream = ffmpeg.concat(*audio_streams, v=0, a=1)

            print("concat video and audio streams")
            ffmpeg.output(concat_video_stream, concat_audio_stream, output, format='mp4', vcodec='libx264',
                          acodec='aac', pix_fmt='yuv420p').global_args("-loglevel", "error"
                          ).run(
                              cmd=ffmpeg_path,
                              overwrite_output=True
                          )

            return True, "ffmpeg process picture in picture done!"
        except ffmpeg.Error as e:
            return False, str(e)

    def pic_in_pic(self, data: List[PictureInPictureTask], output, subtitle, subtitle_styles, pip_settings=None):
        Path(os.path.dirname(output)).mkdir(parents=True, exist_ok=True)
        res, info = self._concatenate_videos(data, output, subtitle, subtitle_styles, pip_settings)
        return res, info