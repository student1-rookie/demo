import os
import uuid
import shutil

from hydra.core.resource import model
from hydra.nlunit.common_utils.minio_client import upload_log_func
from hydra.nlunit.mh_utils.mh_pip import extend_media
from hydra.nlunit.mh_utils.utils import (
    ModelStatus, MHStatus
)
from hydra.nlunit.mh_utils.mh_workspace import MHWorkspace
from hydra.nlunit.mh_pip_unit import MHInferPicInPicUnit, TaskContext


@model("MHInferPicInPicItemUnit")
class MHInferPicInPicItemUnit(MHInferPicInPicUnit):
    def _get_file_names(self, name, one_input):
        wav_file = f"{name}_tts.wav" if name else f"{uuid.uuid1()}_tts.wav"
        face_file = f"{name}_face.mp4" if name else f"{uuid.uuid1()}_face.mp4"
        srt_file = f"{name}_srt.json" if name else f"{uuid.uuid1()}_srt.json"
        item_file = f"{name}_item.mp4" if name else f"{uuid.uuid1()}.mp4"
        return item_file, wav_file, srt_file, face_file
    
    def _get_output_path(self):
        return os.path.join(self._config.root_workspace, self._config.item_bucket)
    
    def _get_record_ids(self, data, index, wav_file, face_file, infer_ids):
        one_input = data.get("input")[index]
        item_inference_id = one_input["itemId"]
        return item_inference_id, item_inference_id
    
    def _update_item_status_db(self, data, cluster_ws):
        pass

    def _update_item_redis(self, data, index, cluster_ws):
        one_input = data.get("input")[index]
        item_file, wav_file, srt_file, face_file = self._get_file_names(data["name"], one_input) 
        update_fields = {"itemFileName": item_file, "ttsFileName": wav_file, "faceFileName": face_file, "srtFileName": srt_file, "inferenceStatus": ModelStatus.RUN}
        self._update_item_status_redis(one_input["itemKey"], id, update_fields, ModelStatus.RUN, upload_func=upload_log_func(id, self._storage_client, cluster_ws))

    def _handle_tts_tasks(self, one_input, containers, ctx: TaskContext):
        self._gen_tts_tasks(containers["tts_tasks"], ctx) 
        containers["tts_tasks"].setdefault("wav_type", []).append("create")
    
    def _handle_face_tasks(self, one_input, containers, ctx: TaskContext):
        self._gen_face_tasks(containers["face_tasks"], ctx)
        containers["face_tasks"].setdefault("video_type", []).append("create")

    def _predict_impl(self, data: dict) -> dict:
        if data["status"] != MHStatus.SUCCESS:
            return data
        id = data.get("id")
        tts_tasks = data.get("tts_tasks")
        face_tasks = data.get("face_tasks")

        # tts task
        if tts_tasks:
            self._execute_tts_tasks(id, data, tts_tasks)
            if data["cluster"]:
                self._operate_tts_file(data)

        # face task
        if face_tasks:
            self._execute_face_tasks(id, data, face_tasks)
            if data["cluster"]:
                self._operate_face_file(data)

        for media, type in data["extend_media_tasks"]:
            extend_media(media, type, 0.5)

        self._handle_cancat_video(data)

        if data["cluster"]:
            self._upload_item_video(data)
        self._handle_task_data(data, ModelStatus.COMPLETE, False)
        return {
            "status": MHStatus.SUCCESS,
            "out": data["output"]
        }

    def _gen_record_object(self, cluster_ws, id, file_name):
        return cluster_ws.gen_item_object(
            id,
            os.path.basename(file_name)
        )

    def _handle_task_data(self, data, status, clean_infer=True):
        id = data.get("id")
        self._update_item_status_redis(data.get("item_keys")[0], id, {"inferenceStatus": status}, status, upload_func=upload_log_func(id, self._storage_client, data["cluster_ws"]))
        self._post_item_task_clear(data, clean_infer)
    
    def _post_item_task_clear(self, data, clean_infer=True):
        infer_item_ids = data["infer_item_ids"]
        cluster_ws = MHWorkspace.initialize(**data)
        if cluster_ws or clean_infer:
             for item_id in infer_item_ids:
                dir_path = os.path.join(self._config.root_workspace, self._config.item_bucket, item_id)
                if os.path.exists(dir_path):
                    shutil.rmtree(dir_path)
        if clean_infer:
            if cluster_ws:
                 for item_id in infer_item_ids:
                    self._storage_client.remove_objects(cluster_ws.bucket, cluster_ws.gen_item_prefix(item_id))
    
    def _update_item_status_redis(self, key, id, field_values, status, upload_func=None):
        context_manager = self._redis.log_operations(status, id, upload_func)
        with context_manager:
            # redis expire value one day
            self._redis.update_json_field(key, field_values, 86400)

