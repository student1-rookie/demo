from pathlib import Path
import os

from hydra.core.resource import model
from hydra.nlunit.base_customized_tts_unit import BaseCustomizedTtsUnit
from hydra.nlunit.mh_utils.utils import (
    set_seed, save_audio_by_sf
)
from hydra.nlunit.mh_utils.config import MHInferenceConfig


@model("VoxCPMUnit")
class VoxCPMUnit(BaseCustomizedTtsUnit):

    def __init__(self, model_path: str, zipenhancer_model_path: str, config: MHInferenceConfig, device: str, log: bool):
        super().__init__(config=config, device=device, log=log, service_name="VoxCPM")
        self._model_path = model_path
        self._zipenhancer_model_path = zipenhancer_model_path

        self._model = None

    def _load_model(self):
        from voxcpm import VoxCPM

        self._model = VoxCPM.from_pretrained(self._model_path, zipenhancer_model_id=self._zipenhancer_model_path)

    def _predict_impl(self, data: dict) -> None:
        set_seed(data["seed"])
        # TODO: support config normalize, denoise at FE
        audio_data = self._model.generate(
            text=data["text"],
            prompt_wav_path=data["prompt_wav_path"],
            prompt_text=data["prompt_text"],
            cfg_value=2.0,
            inference_timesteps=10,
            normalize=False,
            denoise=False,
            retry_badcase=True,
            retry_badcase_max_times=3,
            retry_badcase_ratio_threshold=6.0,
        )
        Path(os.path.dirname(data["output_path"])).mkdir(parents=True, exist_ok=True)
        save_audio_by_sf(audio_data, self._model.tts_model.sample_rate, data["output_path"])
