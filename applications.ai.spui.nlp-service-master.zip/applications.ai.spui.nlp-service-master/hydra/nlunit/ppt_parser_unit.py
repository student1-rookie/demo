import os
import traceback
import shutil
import hashlib
import platform
from typing import Optional

from hydra.core.resource import model
from hydra.core.typing import SingleProcessModel
from hydra.nlunit.common_utils.minio_client import MinioClient
from hydra.nlunit.mh_utils.utils import switch_env
from hydra.nlunit.mh_utils.db_utils import insert_dataset, insert_pic_in_pic_template, find_dataset, \
    find_pic_in_pic_template, generate_identifier, create_dataset_group
from hydra.nlunit.mh_utils.mh_workspace import MHWorkspace
from hydra.nlunit.ppt_utils.common import PicInPicDto, InferencePicInPicDto, MetaHumanDataset

if platform.system() == "Windows":
    from hydra.nlunit.ppt_utils.ppt_parser_windows import process_pptx
else:
    from hydra.nlunit.ppt_utils.ppt_parser import process_pptx


@model("PPTParserUnit")
class PPTParserUnit(SingleProcessModel):

    def __init__(self, root_dataset):
        self._root_dataset = root_dataset
        self._storage_client: Optional[MinioClient] = None
        self._db_args = {}

    def load(self):
        self._storage_client = MinioClient(self._root_dataset)

    def pre_process(self, data: dict) -> dict:
        switch_env(data, None, self._db_args, self._storage_client)
        data["cluster"] = MHWorkspace.initialize(**data)
        return data

    def _predict_impl(self, data: dict) -> dict:
        print(f"PPTParserUnit task: ", data)
        name, slide_info = process_pptx(data["ppt_path"], data["tmp_dir"])

        if data.get("test_mode", False):
            return {
                "code": 0,
                "msg": "success",
                "slides": [
                    {"image": os.path.basename(info.path), "note": info.note}
                    for info in slide_info
                ],
                "info": slide_info
            }

        account_id = data["accountID"]
        access = data.get("access", "PRIVATE")

        count = find_pic_in_pic_template(name + '(\\([0-9]+\\))?', account_id, **self._db_args)[0][0]
        if count > 0:
            name = f"{name}({count})"
        # create group
        # TODO: delete grp if doesn't use.
        grp_id = create_dataset_group(name, access, account_id, **self._db_args)

        items = []
        for info in slide_info:
            print("slide info:", info)
            image_file = os.path.basename(info.path)
            with open(info.path, 'rb') as f:
                file_md5 = hashlib.md5(f.read()).hexdigest()

            identifier = generate_identifier(account_id, file_md5)

            datasets = find_dataset(identifier, **self._db_args)
            create_new = False
            if len(datasets) == 0:
                dataset_entry = MetaHumanDataset(
                    name=os.path.splitext(image_file)[0],
                    type=access,
                    fileName=image_file,
                    identifier=identifier,
                    accountID=account_id,
                    groupID=grp_id
                )
                record_id = insert_dataset(dataset_entry, **self._db_args)
                create_new = True
            else:
                record_id = datasets[0][0]

            if record_id:
                if create_new:
                    if data["cluster"]:
                        dataset_obj = data["cluster"].gen_dataset_object(record_id, image_file)
                        self._storage_client.upload(data["cluster"].bucket, dataset_obj, info.path)
                        os.remove(info.path)
                    else:
                        dest_dir = os.path.join(self._root_dataset, str(record_id))
                        os.makedirs(dest_dir, exist_ok=True)
                        dest_path = os.path.join(dest_dir, image_file)
                        shutil.move(info.path, dest_path)
                pic_dto = PicInPicDto(
                    text=info.note,
                    media=str(record_id),
                )
                items.append(pic_dto)
                print(f"insert Dataset ID: {record_id}")

        pip_template = InferencePicInPicDto(name=name, input=items)
        insert_pic_in_pic_template(pip_template, account_id, **self._db_args)

        return {"code": 0, "msg": "success", "groupId": grp_id}

    def predict(self, data: dict) -> dict:
        try:
            ret = self._predict_impl(data)
        except Exception as e:
            id = data.get("id")
            print(f"PPTParserUnit task [{id}] predict failed: {e}")
            traceback.print_exc()
            return {
                "code": -1,
                "msg": str(e)
            }
        finally:
            # clean data
            if os.path.exists(data["tmp_dir"]):
                shutil.rmtree(data["tmp_dir"])
        return ret
