import hashlib
import os
import shutil
import traceback
from pathlib import Path
from typing import Optional

from hydra.core.resource import model
from hydra.core.typing import SingleProcessModel
from hydra.nlunit.common_utils.minio_client import MinioClient, upload_log_func
from hydra.nlunit.mh_utils.config import MHInferenceConfig
from hydra.nlunit.mh_utils.db_utils import update_model_status, generate_identifier, find_dataset, insert_dataset
from hydra.nlunit.mh_utils.mh_workspace import MHWorkspace
from hydra.nlunit.mh_utils.utils import switch_env, ModelStatus, is_video, convert_video_to_audio, cut_audio, MHStatus, \
    InferenceType, save_notifications, upload_fail_artifacts
from hydra.nlunit.ppt_utils.common import MetaHumanDataset
from hydra.nlunit.mh_utils.redis_logger import RedisLogger


@model("TTSRegisterUnit")
class TTSRegisterUnit(SingleProcessModel):

    def __init__(self, config: MHInferenceConfig, log: bool):
        self._config = config
        self._enable_log = log
        self._redis: Optional[RedisLogger] = None
        self._storage_client: Optional[MinioClient] = None
        self._db_args = {}

    def load(self):
        self._storage_client = MinioClient(self._config.root_dataset, cache=self._config.shared,
                                           meta_cache=self._config.meta_shared)
        self._redis = RedisLogger("TTSRegisterUnit", root_log_workspace=self._config.root_log_workspace,
                                  enable=self._enable_log)

    def pre_process(self, data):
        switch_env(data, self._redis, self._db_args, self._storage_client)
        if data.get("mh_id", None):
            update_model_status(data["mh_id"], "tts", ModelStatus.TRAIN, **self._db_args)
        data["cluster"] = MHWorkspace.initialize(**data)
        return data

    def _predict_impl(self, data: dict):
        mh_id = data.get("mh_id")
        account_id = data["account_id"]
        src_path = self._get_wav(data)

        target_wav_name = data["name"] + "-dataset" + ".wav"
        target_wav_path = os.path.join(data["tmp_dir"], target_wav_name)

        if is_video(src_path):
            self._redis.publish(f"src {src_path} is video.", msg_id=mh_id)
            wav_file = data["name"] + "-extract" + ".wav"
            audio_output_path = os.path.join(data["tmp_dir"], wav_file)
            Path(os.path.dirname(audio_output_path)).mkdir(parents=True, exist_ok=True)
            convert_video_to_audio(src_path, audio_output_path)
            src_path = audio_output_path

        cut_duration = data["parameter"]["cut_duration"]
        self._redis.publish(f"cut duration is {cut_duration}.", msg_id=mh_id)
        Path(os.path.dirname(target_wav_path)).mkdir(parents=True, exist_ok=True)
        cut_audio(src_path, cut_duration, target_wav_path)

        with open(target_wav_path, 'rb') as f:
            file_md5 = hashlib.md5(f.read()).hexdigest()
        identifier = generate_identifier(account_id, file_md5)
        datasets = find_dataset(identifier, **self._db_args)
        if len(datasets) == 0:
            # create new dataset for model
            dataset_entry = MetaHumanDataset(
                name=data["name"] + "-dataset",
                type=data.get("access", "PRIVATE"),
                fileName=target_wav_name,
                identifier=identifier,
                accountID=account_id,
                fileType="AUDIO",
                internal=True,
            )
            record_id = insert_dataset(dataset_entry, **self._db_args)
            self._redis.publish(f"create new internal dataset {record_id}.", msg_id=mh_id)
            # update / write audio file
            if data["cluster"]:
                self._storage_client.upload(data["cluster"].bucket,
                                            data["cluster"].gen_dataset_object(record_id, target_wav_name),
                                            target_wav_path)
            else:
                dest_dir = os.path.join(self._config.root_dataset, str(record_id))
                os.makedirs(dest_dir, exist_ok=True)
                dest_path = os.path.join(dest_dir, target_wav_name)
                shutil.move(target_wav_path, dest_path)
                target_wav_path = dest_path
                shutil.rmtree(data["tmp_dir"])
        else:
            record_id = datasets[0][0]

        print("generate preview wav path for tts model")
        if data["cluster"]:
            output_path = data["cluster"].gen_model_object(mh_id, "example/example.wav")
        else:
            output_path = os.path.join(os.path.join(self._config.root_workspace, data["id"], "example/example.wav"))
            Path(os.path.dirname(output_path)).mkdir(parents=True, exist_ok=True)
        cluster_args = data["cluster"].to_dict() if data["cluster"] else {}
        return {
            "status": MHStatus.SUCCESS,
            "id": mh_id,
            "env": data.get("env", None),
            "env_flush": data.get("env_flush", False),
            "type": InferenceType.TTS_EXAMPLE,
            "text": data["exampleText"],
            "wav_path": target_wav_path,
            "output_path": output_path,
            "customized_prompt": data["parameter"].get("customized_prompt"),
            "example_parameter": {
                "update": data["update"],
                "model_bucket": data["cluster"].bucket if data["cluster"] else None,
                "dataset_id": record_id,
                **data["parameter"],
            },
            "name": data.get("name", None),
            "account_id": data.get("account_id", None),
            **cluster_args,
        }

    def predict(self, data: dict):
        try:
            return self._predict_impl(data)
        except Exception as e:
            mh_id = data.get("mh_id")
            print(f"TTSRegisterUnit task [{mh_id}] predict failed: {e}")
            if mh_id:
                self._redis.publish(traceback.format_exc(), msg_id=mh_id)
                update_model_status(mh_id, "tts", ModelStatus.FAIL, redis=self._redis,
                                    upload_func=upload_log_func(mh_id, self._storage_client, data["cluster"]),
                                    **self._db_args)
                save_notifications(data["account_id"], InferenceType.TTS_EXAMPLE, ModelStatus.FAIL, data['name'], redis=self._redis, **self._db_args)
            if os.path.exists(data["tmp_dir"]):
                upload_fail_artifacts(self._storage_client, mh_id, data["tmp_dir"], data["cluster"], self._config.root_workspace, self._config.fail_output_dir)
            traceback.print_exc()
            return {
                "status": MHStatus.FAILED,
            }

    def _get_wav(self, data):
        if data["cluster"]:
            parts = data["dataset"].split("/", 1)
            return self._storage_client.download(parts[0], parts[1])
        return os.path.join(self._config.root_dataset, data["dataset"])
