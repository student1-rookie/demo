import os
from pathlib import Path

from hydra.core.resource import model
from hydra.nlunit.base_customized_tts_unit import BaseCustomizedTtsUnit
from hydra.nlunit.mh_utils.utils import set_seed
from hydra.nlunit.mh_utils.config import MHInferenceConfig

CFG_SCALE = 1.3


@model("VibeVoiceUnit")
class VibeVoiceUnit(BaseCustomizedTtsUnit):

    def __init__(self, model_path: str, language_model_path: str, config: MHInferenceConfig, device: str, log: bool):
        super().__init__(config=config, device=device, log=log, service_name="VibeVoice")
        self._model_path = model_path
        self._model = None
        self._language_model_path = language_model_path
        self._processor = None

    def _load_model(self):
        import torch
        from vibevoice.modular.modeling_vibevoice_inference import VibeVoiceForConditionalGenerationInference
        from vibevoice.processor.vibevoice_processor import VibeVoiceProcessor

        self._model = VibeVoiceForConditionalGenerationInference.from_pretrained(
            self._model_path,
            torch_dtype=torch.bfloat16,
            device_map="cuda",
            attn_implementation="flash_attention_2"
        )
        self._model.eval()
        self._model.set_ddpm_inference_steps(num_steps=10)
        self._processor = VibeVoiceProcessor.from_pretrained(self._model_path,
                                                             language_model_pretrained_name=self._language_model_path)

    def _predict_impl(self, data: dict) -> None:
        prompt_wav_path = data["prompt_wav_path"]
        inputs = self._processor(
            text=[f"Speaker 1: {data['text']}"],
            voice_samples=[prompt_wav_path],  # Wrap in list for batch processing
            padding=True,
            return_tensors="pt",
            return_attention_mask=True,
        )
        set_seed(data["seed"])
        outputs = self._model.generate(**inputs,
                                       max_new_tokens=None,
                                       cfg_scale=CFG_SCALE,
                                       tokenizer=self._processor.tokenizer,
                                       # generation_config={'do_sample': False, 'temperature': 0.95, 'top_p': 0.95, 'top_k': 0},
                                       generation_config={'do_sample': False},
                                       verbose=True,
                                       )
        Path(os.path.dirname(data["output_path"])).mkdir(parents=True, exist_ok=True)
        self._processor.save_audio(
            outputs.speech_outputs[0],  # First (and only) batch item
            output_path=data["output_path"],
        )
