from pathlib import Path
import os

from hydra.core.resource import model
from hydra.nlunit.base_customized_tts_unit import BaseCustomizedTtsUnit
from hydra.nlunit.mh_utils.utils import set_seed, save_audio
from hydra.nlunit.mh_utils.config import MHInferenceConfig

MOSS_TTSD_SYSTEM_PROMPT = "You are a speech synthesizer that generates natural, realistic, and human-like conversational audio from dialogue text."


def _get_tokenizer_config():
    file_path = os.path.dirname(__file__)
    base_path = os.path.abspath(file_path[:file_path.rindex("hydra")])
    return os.path.join(base_path, "third_party", "MOSS-TTSD", "XY_Tokenizer", "config", "xy_tokenizer_32k_config.yaml")


@model("MossTTSDUnit")
class MossTTSDUnit(BaseCustomizedTtsUnit):

    def __init__(self, model_path: str, tokenizer_path: str, config: MHInferenceConfig, device: str, log: bool):
        super().__init__(config=config, device=device, log=log, service_name="MossTTSD")
        self._model_path = model_path
        self._tokenizer_path = tokenizer_path

        self._tokenizer = None
        self._model = None
        self._spt = None

    def _load_model(self):
        from hydra.nlunit.patches.moss_ttsd_transformers_compat import apply_patch as _apply_moss_patch
        _apply_moss_patch()

        from generation_utils import load_model
        import torch

        self._tokenizer, self._model, self._spt = load_model(
            self._model_path,
            _get_tokenizer_config(),
            self._tokenizer_path,
            torch_dtype=torch.bfloat16,
            attn_implementation="flash_attention_2",
        )
        self._model.to(self._device)
        self._spt.to(self._device)

    def _predict_impl(self, data: dict) -> None:
        from generation_utils import process_batch
        # convert to dict:
        # {"text": "xxx", "prompt_audio": "<wav_path>", "prompt_text": "<prompt_text>"}
        batch_items = [
            {"text": data["text"], "prompt_text": data["prompt_text"], "prompt_audio": data["prompt_wav_path"]}
        ]
        set_seed(data["seed"])
        texts_data, audio_data = process_batch(
            batch_items=batch_items,
            tokenizer=self._tokenizer,
            model=self._model,
            spt=self._spt,
            device=self._device,
            system_prompt=MOSS_TTSD_SYSTEM_PROMPT,
            start_idx=0,
            use_normalize=True,
            silence_duration=data.get("silence_duration", 0),
        )
        audio_ret = audio_data[0]
        Path(os.path.dirname(data["output_path"])).mkdir(parents=True, exist_ok=True)
        save_audio(audio_ret["audio_data"], audio_ret["sample_rate"], data["output_path"], cat=False)
