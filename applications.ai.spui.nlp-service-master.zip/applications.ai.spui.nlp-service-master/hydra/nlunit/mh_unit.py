import os
import os.path
import uuid
import traceback
import dataclasses
import yaml
import copy
import shutil
import json
from pathlib import Path
from typing import Optional
from functools import partial

from hydra.core.resource import model
from hydra.core.typing import SingleProcessModel, AsyncSingleProcessModel
from hydra.nlunit.common_utils.env import EnvManager
from hydra.nlunit.common_utils.minio_client import MinioClient, upload_log_func
from hydra.nlunit.common_utils.storage_cache import StorageShared
from hydra.nlunit.mh_utils.config import MHInferenceConfig, CustomizedVoiceUnitConfig
from hydra.nlunit.mh_utils.utils import (
    ModelStatus, MHStatus, load_yml_configs,
    InferenceType, LOG_READ_BUFF_LEN,
    find_workspace_replace_prefix, replace_workspace_prefix_in_yml, switch_env, MHModel, save_notifications, upload_fail_artifacts
)
from hydra.nlunit.mh_utils.mh_workspace import MHWorkspace
from hydra.nlunit.mh_utils.subtitle import add_subtitles
from hydra.nlunit.mh_utils.db_utils import update_model_status
from hydra.nlunit.mh_utils.mh_task import MetaHumanTrain, MetaHumanInference, COMMON_MAX_WORKER
from hydra.nlunit.mh_utils.rsocket_request import send_request, RSocketClientConfig
from hydra.nlunit.mh_utils.redis_logger import RedisLogger

MH_ROOT = os.environ.get("MH_ROOT", "/meta-human")

PARAM_MAP = {
    'BERTVITS': {
        'batch_size': ['train', 'batch_size'],
        'epochs': ['train', 'epochs'],
        'learning_rate': ['train', 'learning_rate']
    },
    'GPTSOVITS': {
        's1_batch_size': ['train', 's1_batch_size'],
        's2_batch_size': ['train', 's2_batch_size'],
        's1_epochs': ['train', 's1_epochs'],
        's2_epochs': ['train', 's2_epochs']
    },
    'ERNERF': {
        'padding_ratio': ['preprocess', 'padding_ratio'],
        'base_steps': ['train', 'iters'],
        'lips_steps': ['train', 'iters2'],
        'learning_rate': ['train', 'lr'],
        'learning_rate_net': ['train', 'lr_net']
    }
}


@dataclasses.dataclass
class MHTrainConfig:
    template_config_path: str
    root_workspace: str
    root_dataset: str
    task: str
    root_log_workspace: str
    fail_output_dir: str
    shared: Optional[StorageShared] = None


@model("MHTrainUnit")
class MHTrainUnit(SingleProcessModel):

    def __init__(self, config: MHTrainConfig, log: bool):
        self._config = config
        self._base_model_config = None
        self._pre_process_func = self._gen_tts_config_data if self._config.task == MHModel.TTS \
            else self._gen_face_config_data
        self._infer_file = f"{self._config.task}_infer.yml"
        self._enable_log = log
        self._redis: Optional[RedisLogger] = None
        self._dataset_client: Optional[MinioClient] = None
        self._db_args = {}

    def load(self):
        self._base_model_config = load_yml_configs(self._config.template_config_path)
        if self._base_model_config["task"] == MHModel.FACE and self._base_model_config["model"] == "gaussian":
            config_dir = os.path.dirname(self._config.template_config_path)
            self._base_model_config["train"]["diffspeaker"]["base_config"] = os.path.join(config_dir,
                                                                                          "diffspeaker_base.yml")
            self._base_model_config["train"]["diffspeaker"]["vocaset_config"] = os.path.join(config_dir,
                                                                                             "diffspeaker_vocaset.yml")
        self._redis = RedisLogger(f"TrainUnit-{self._config.task}-{self._base_model_config['model']}",
                                  root_log_workspace=self._config.root_log_workspace, enable=self._enable_log)
        self._dataset_client = MinioClient(self._config.root_dataset, cache=self._config.shared)

    def _pre_process_impl(self, data: dict) -> dict:
        switch_env(data, self._redis, self._db_args, self._dataset_client)
        if data.get("mh_id", None):
            update_model_status(data["mh_id"], self._config.task, ModelStatus.TRAIN, **self._db_args)
        train_config = self._pre_process_func(data)
        workspace_path = train_config["data"]["workspace_path"]
        new_model_config_path = os.path.join(workspace_path, f"{self._config.task}_train.yml")
        Path(os.path.dirname(new_model_config_path)).mkdir(parents=True, exist_ok=True)
        yaml.dump(train_config, open(new_model_config_path, "w"))
        return {
            "mh_id": data.get("mh_id", None),
            "config": new_model_config_path,
            "workspace_path": workspace_path,
            "cluster": MHWorkspace.initialize(**data),
            "example_text": data.get("exampleText", None),
            "name": data.get("name", None),
            "account_id": data.get("account_id", None)
        }

    def pre_process(self, data: dict) -> dict:
        try:
            ret = self._pre_process_impl(data)
        except Exception as e:
            mh_id = data.get("mh_id")
            print(f"task [{mh_id}] train pre_process failed: {e}")
            traceback.print_exc()
            if mh_id:
                self._redis.publish(traceback.format_exc(), msg_id=mh_id)
                update_model_status(mh_id, self._config.task, ModelStatus.FAIL, self._redis,
                                    upload_func=upload_log_func(mh_id, self._dataset_client,
                                                                MHWorkspace.initialize(**data)), **self._db_args)
                save_notifications(data["account_id"], self._config.task, ModelStatus.FAIL, data['name'], redis=self._redis, **self._db_args)
            return {
                "status": MHStatus.FAILED,
                "error": str(e)
            }
        return ret

    def _predict_impl(self, data: dict) -> dict:
        mh_id = data.get("mh_id")
        workspace_path = data["workspace_path"]
        root_dir = os.path.dirname(workspace_path)
        gen_infer_file = os.path.join(root_dir, self._infer_file)
        pipe_path = os.path.join("/tmp", f"{mh_id if mh_id else uuid.uuid1()}_status_pipe")
        train_task = MetaHumanTrain(
            mh_id,
            self._config.task,
            self._redis,
            self._enable_log,
            LOG_READ_BUFF_LEN,
            MH_ROOT,
            data["config"],
            gen_infer_file,
            pipe_path,
            self._db_args,
            max_workers=COMMON_MAX_WORKER["train"],
        )
        print(f"start to train {self._config.task} task [{mh_id}]")
        ret = train_task.execute_cmd()

        if mh_id:
            if ret == 0 and self._config.task == MHModel.TTS:
                print("generate preview wav for tts model")
                task_file = os.path.join("/tmp", f"{mh_id}_task.list")
                output_path = os.path.join(root_dir, "example/example.wav")
                Path(os.path.dirname(output_path)).mkdir(parents=True, exist_ok=True)
                infer_task = MetaHumanInference(
                    mh_id,
                    "tts_infer",
                    self._redis,
                    self._enable_log,
                    LOG_READ_BUFF_LEN,
                    MH_ROOT,
                    gen_infer_file,
                    task_file,
                    input=[data["example_text"]],
                    output=[output_path],
                    max_workers=COMMON_MAX_WORKER["infer"],
                )
                ret = infer_task.execute_cmd()
                os.remove(task_file)

            if ret == 0 and data["cluster"]:
                # upload <model_name>.tar.gz
                zip_file = shutil.make_archive(workspace_path, "gztar", root_dir, None)
                print("start to upload model: {}".format(zip_file))
                self._dataset_client.upload(data["cluster"].bucket,
                                            data["cluster"].gen_model_object(mh_id, os.path.basename(zip_file)),
                                            zip_file)
                if self._config.task == MHModel.FACE:
                    avatar_path = os.path.join(root_dir, "avatar")
                    self._dataset_client.upload(data["cluster"].bucket,
                                                data["cluster"].gen_model_object(mh_id, "avatar/avatar.jpg"),
                                                os.path.join(avatar_path, "avatar.jpg"))
                    self._dataset_client.upload(data["cluster"].bucket,
                                                data["cluster"].gen_model_object(mh_id, "avatar/preview.jpg"),
                                                os.path.join(avatar_path, "preview.jpg"))
                else:
                    self._dataset_client.upload(data["cluster"].bucket,
                                                data["cluster"].gen_model_object(mh_id, "example/example.wav"),
                                                os.path.join(root_dir, "example/example.wav"))

            status = ModelStatus.FAIL if ret != 0 else ModelStatus.COMPLETE
            print(f"update task [{mh_id}] to: {status}")
            update_model_status(mh_id, self._config.task, status, self._redis, clean_detail=True,
                                upload_func=upload_log_func(mh_id, self._dataset_client, data["cluster"]),
                                **self._db_args)
            save_notifications(data["account_id"], self._config.task, status, data['name'], redis=self._redis, **self._db_args)
            if ret != 0 and os.path.exists(workspace_path):
                upload_fail_artifacts(self._dataset_client, mh_id, os.path.dirname(workspace_path), data["cluster"], self._config.root_workspace, self._config.fail_output_dir)
            elif data["cluster"]:
                shutil.rmtree(os.path.dirname(workspace_path))
        return {
            "status": MHStatus.SUCCESS if ret == 0 else MHStatus.FAILED,
        }

    def predict(self, data: dict) -> dict:
        mh_id = data.get("mh_id")
        try:
            ret = self._predict_impl(data)
        except Exception as e:
            print(f"task [{mh_id}] train failed: {e}")
            traceback.print_exc()
            if mh_id:
                if os.path.exists(data.get("workspace_path")):
                    upload_fail_artifacts(self._dataset_client, mh_id, os.path.dirname(data.get("workspace_path")), data["cluster"], self._config.root_workspace, self._config.fail_output_dir)
                self._redis.publish(traceback.format_exc(), msg_id=mh_id)
                update_model_status(mh_id, self._config.task, ModelStatus.FAIL, self._redis,
                                    upload_func=upload_log_func(mh_id, self._dataset_client, data["cluster"]),
                                    **self._db_args)
                save_notifications(data["account_id"], self._config.task, ModelStatus.FAIL, data['name'], redis=self._redis, **self._db_args)
            return {
                "status": MHStatus.FAILED,
                "error": str(e)
            }
        return ret

    def _get_workspace_path(self, input_data: dict) -> str:
        if "id" in input_data:
            return os.path.join(self._config.root_workspace, input_data["id"],
                                f"{input_data['name']}_{self._config.task}")
        return os.path.join(self._config.root_workspace, f"{input_data['name']}_{self._config.task}")

    def _gen_face_config_data(self, input_data: dict) -> dict:
        workspace_path = self._get_workspace_path(input_data)
        update_copy_config = copy.deepcopy(self._base_model_config)
        self._update_train_config(input_data, update_copy_config)
        data_part = {
            "input": self._get_input_path(input_data),
            "workspace_path": workspace_path,
            "avatar_path": os.path.join(os.path.dirname(workspace_path), "avatar"),
        }
        return {"data": data_part, **update_copy_config}

    def _gen_tts_config_data(self, input_data: dict) -> dict:
        workspace_path = self._get_workspace_path(input_data)
        update_copy_config = copy.deepcopy(self._base_model_config)
        # update preprocess.asr.sensevoice_url
        if update_copy_config.get("preprocess") and update_copy_config["preprocess"].get("asr") and \
                "sensevoice_url" in update_copy_config["preprocess"]["asr"]:
            if os.environ.get("ASR_URL", None):
                update_copy_config["preprocess"]["asr"]["sensevoice_url"] = os.environ["ASR_URL"]
            else:
                # back to whisper
                update_copy_config["preprocess"]["asr"]["backend"] = "whisper"

        self._update_train_config(input_data, update_copy_config)
        data_part = {
            "input": self._get_input_path(input_data),
            "workspace_path": workspace_path,
        }
        return {"data": data_part, **update_copy_config}

    def _get_input_path(self, input_data: dict) -> str:
        if input_data.get("cluster", False):
            # download dataset
            parts = input_data["dataset"].split("/", 1)
            return self._dataset_client.download(parts[0], parts[1])
        return os.path.join(self._config.root_dataset, input_data["dataset"])

    def _update_config_param(self, config: dict, input_data: dict, param_path: list, param: str) -> None:
        if param in input_data and input_data[param] is not None:
            sub_config = config
            for key in param_path[:-1]:
                sub_config = sub_config.setdefault(key, {})
            sub_config[param_path[-1]] = input_data[param]

    def _update_train_config(self, data: dict, config: dict) -> None:
        model = data['model']
        if model in PARAM_MAP:
            for param, path in PARAM_MAP[model].items():
                self._update_config_param(config, data, path, param)


@model("MHTTSUnit")
class MHTTSUnit(SingleProcessModel):

    def __init__(self, config: MHInferenceConfig, device, log: bool):
        self._config = config
        self._device = device
        self._enable_log = log
        self._redis: Optional[RedisLogger] = None
        self._storage_client: Optional[MinioClient] = None
        self._db_args = {}

    def load(self):
        self._redis = RedisLogger("MHTTSUnit", root_log_workspace=self._config.root_log_workspace,
                                  enable=self._enable_log)
        self._storage_client = MinioClient(self._config.root_workspace, cache=self._config.shared)

    def _pre_process_impl(self, data: dict) -> dict:
        id = data.get("id")
        status = data.get("status")
        print(f"TTS task [{id}] starts to preprocess")
        switch_env(data, self._redis, self._db_args, self._storage_client)
        if id and status == ModelStatus.WAIT:
            update_model_status(data["id"], "infer", ModelStatus.RUN, **self._db_args)

        wav_file = f"{data['name']}.wav" if data.get("name") else f"{uuid.uuid1()}.wav"
        srt_file = os.path.splitext(wav_file)[0] + ".json"
        if id:
            if data.get("type", None) == InferenceType.TTS_EXAMPLE:
                wav_folder = os.path.join(self._config.root_workspace, "model", id)
            else:
                wav_folder = os.path.join(self._config.root_workspace, self._config.infer_bucket, id)
        else:
            wav_folder = os.path.join(self._config.root_workspace, data["tts_model"])

        # update config
        tts_model = self._get_tts_model(data)
        config_path = os.path.join(tts_model, "tts_infer.yml")
        model_config = load_yml_configs(config_path)
        model_config["inference"]["device"] = self._device
        new_model_config_path = os.path.join(wav_folder, "tts_infer.yml")
        Path(os.path.dirname(new_model_config_path)).mkdir(parents=True, exist_ok=True)
        yaml.dump(model_config, open(new_model_config_path, "w"))
        task_file = os.path.join(wav_folder, "tts.list")

        subtitle = data.get("subtitle", False)
        return {
            "status": MHStatus.SUCCESS,
            "config": new_model_config_path,
            "type": data.get("type", None),
            "task_file": task_file,
            "input": data["text"],
            "output": {
                "tts_model_type": data.get("tts_model_type", None),
                "tts_model": data.get("tts_model", None),
                "face_model": data.get("face_model", None),
                "face_model_type": data.get("face_model_type", None),
                "wav": os.path.join(wav_folder, wav_file),
                "video_path": data.get("video_path", None),
                "id": data.get("id", None),
                "msg_id": data.get("msg_id", None),
                "name": data.get("name", None),
                "hdtr": data.get("hdtr", False),
                "subtitle": subtitle,
                "srt": os.path.join(wav_folder, srt_file) if subtitle else None,
                "subtitle_styles": data.get("subtitle_styles", {}),
                "cluster": data.get("cluster", False),
                "userBucket": data.get("userBucket", None),
                "workSpace": data.get("workSpace", None),
                "env": data.get("env", None),
                "env_flush": data.get("env_flush", False),
                "account_id": data.get("account_id", None),
                "type": data.get("type", "")
            },
            "cluster": MHWorkspace.initialize(**data),
        }

    def pre_process(self, data: dict) -> dict:
        try:
            ret = self._pre_process_impl(data)
        except Exception as e:
            id = data.get("id")
            print(f"TTS task [{id}] infer pre_process failed: {e}")
            traceback.print_exc()
            if data.get("type") == InferenceType.TTS_EXAMPLE and id:
                self._redis.publish(traceback.format_exc(), msg_id=id)
                update_model_status(id, "tts", ModelStatus.FAIL, self._redis,
                                    upload_func=upload_log_func(id, self._storage_client,
                                                                MHWorkspace.initialize(**data)), **self._db_args)
            elif id:
                self._redis.publish(traceback.format_exc(), msg_id=id)
                update_model_status(id, "infer", ModelStatus.FAIL, self._redis,
                                    upload_func=upload_log_func(id, self._storage_client,
                                                                MHWorkspace.initialize(**data)), **self._db_args)
            if id and data.get("type"):
                save_notifications(data["account_id"], data['type'], ModelStatus.FAIL, data['name'], redis=self._redis, **self._db_args)
            return {
                "status": MHStatus.FAILED,
                "error": str(e)
            }
        return ret

    def _predict_impl(self, data: dict) -> dict:
        if data["status"] != MHStatus.SUCCESS:
            return data
        id = data["output"].get("id")
        subtitle = data["output"]["subtitle"]
        infer_task = MetaHumanInference(
            id,
            "tts_infer",
            self._redis,
            self._enable_log,
            LOG_READ_BUFF_LEN,
            MH_ROOT,
            data["config"],
            data["task_file"],
            input=[data["input"]],
            output=[data["output"]["wav"]],
            srt_file=[data["output"]["srt"]] if subtitle else None,
            max_workers=COMMON_MAX_WORKER["infer"],
        )
        print(f"TTS task [{id}] starts to run")
        ret = infer_task.execute_cmd()
        if ret == 0:
            print(f"TTS task [{id}] succeed")
            if id and data.get("type") == InferenceType.TTS_EXAMPLE:
                    if data["cluster"]:
                        model_object = data["cluster"].gen_model_object(id, "example/example.wav")
                        self._storage_client.upload(data["cluster"].bucket, model_object, data["output"]["wav"])
                    else:
                        model_object = os.path.join(self._config.root_workspace, data["output"]["tts_model"], "example/example.wav")
                        os.makedirs(os.path.dirname(model_object), exist_ok=True)
                        shutil.move(data["output"]["wav"], model_object)
                    update_model_status(id, "tts", ModelStatus.COMPLETE, self._redis,
                                        upload_func=upload_log_func(id, self._storage_client, data["cluster"]),
                                        **self._db_args)
                    save_notifications(data["output"]["account_id"], data["output"]["type"], ModelStatus.COMPLETE, data["output"]["name"], redis=self._redis, **self._db_args)
                    return {
                        "status" : MHStatus.SUCCESS
                    }
            if id and data["cluster"]:
                infer_object = data["cluster"].gen_infer_object(id, os.path.basename(data["output"]["wav"]))
                self._storage_client.upload(data["cluster"].bucket, infer_object, data["output"]["wav"])
                if subtitle:
                    srt_object = data["cluster"].gen_infer_object(id, os.path.basename(data["output"]["srt"]))
                    self._storage_client.upload(data["cluster"].bucket, srt_object, data["output"]["srt"])

            # TTS inference only
            if data['output'].get("face_model") is None:
                if id:
                    update_model_status(id, "infer", ModelStatus.COMPLETE, self._redis,
                                        upload_func=upload_log_func(id, self._storage_client, data["cluster"]),
                                        **self._db_args)
                    if data["cluster"]:
                        shutil.rmtree(os.path.dirname(data["output"]["wav"]))
                    save_notifications(data["output"]["account_id"], data["output"]["type"], ModelStatus.COMPLETE, data["output"]["name"], redis=self._redis, **self._db_args)
                print(f"TTS task [{id}] succeed")
                return {
                    "status": MHStatus.SUCCESS
                }

            if id and data["cluster"] and data["output"]["face_model_type"].lower() == "latentsync":
                shutil.rmtree(os.path.dirname(data["output"]["wav"]))
                data["output"]["wav"] = infer_object
                data["output"]["srt"] = srt_object if subtitle else None

            print(f"TTS task [{id}] succeed")
            return {
                "status": MHStatus.SUCCESS,
                **data["output"]
            }

        print(f"TTS task [{id}] failed")
        if data.get("type") == InferenceType.TTS_EXAMPLE and id:
            update_model_status(id, "tts", ModelStatus.FAIL, self._redis,
                                upload_func=upload_log_func(id, self._storage_client, data["cluster"]), **self._db_args)
        elif id:
            update_model_status(id, "infer", ModelStatus.FAIL, self._redis,
                                upload_func=upload_log_func(id, self._storage_client, data["cluster"]), **self._db_args)
        if id:
            wav_path = os.path.dirname(data["output"]["wav"])
            if os.path.exists(wav_path):
                upload_fail_artifacts(self._storage_client, id, wav_path, data["cluster"], self._config.root_workspace, self._config.fail_output_dir)
            save_notifications(data['output']["account_id"], data['output']['type'], ModelStatus.FAIL, data['output']['name'], redis=self._redis, **self._db_args)
        return {
            "status": MHStatus.FAILED,
        }

    def predict(self, data: dict) -> dict:
        try:
            ret = self._predict_impl(data)
        except Exception as e:
            out = data.get("output", {})
            id = out.get('id')
            print(f"TTS task [{id}] infer predict failed: {e}")
            traceback.print_exc()
            if data.get("type") == InferenceType.TTS_EXAMPLE and id:
                self._redis.publish(traceback.format_exc(), msg_id=id)
                update_model_status(id, "tts", ModelStatus.FAIL, self._redis,
                                    upload_func=upload_log_func(id, self._storage_client, data["cluster"]), 
                                    **self._db_args)
            elif id:
                self._redis.publish(traceback.format_exc(), msg_id=id)
                update_model_status(id, "infer", ModelStatus.FAIL, self._redis,
                                    upload_func=upload_log_func(id, self._storage_client, data["cluster"]),
                                    **self._db_args)
            if id:
                if os.path.exists(os.path.dirname(out.get('wav'))):
                    upload_fail_artifacts(self._storage_client, id, os.path.dirname(out.get('wav')), data["cluster"], self._config.root_workspace, self._config.fail_output_dir)
                save_notifications(data['output']['account_id'], data['output']['type'], ModelStatus.FAIL,
                                   data['output']['name'], redis=self._redis, **self._db_args)
            return {
                "status": MHStatus.FAILED,
                "error": str(e)
            }
        return ret

    def _on_model_downloaded(self, zip_file):
        print(f"TTS model downloaded: {zip_file}")
        extract_dir = os.path.dirname(zip_file)
        shutil.unpack_archive(zip_file, extract_dir=extract_dir)
        os.remove(zip_file)
        config_file = os.path.join(extract_dir, "tts_infer.yml")
        old_prefix, _, concat = find_workspace_replace_prefix(config_file)
        replace_workspace_prefix_in_yml(config_file, old_prefix, extract_dir, concat)

    def _get_tts_model(self, data):
        if data.get("cluster", False):
            parts = data["tts_model"].split("/", 1)
            zip_file = self._storage_client.download(parts[0], parts[1], callback=self._on_model_downloaded)
            return os.path.dirname(zip_file)
        return os.path.join(self._config.root_workspace, data["tts_model"])


@model("MHFaceUnit")
class MHFaceUnit(SingleProcessModel):

    def __init__(self, config: MHInferenceConfig, device, log: bool):
        self._config = config
        self._device = device
        self._enable_log = log
        self._redis: Optional[RedisLogger] = None
        self._storage_client: Optional[MinioClient] = None
        self._db_args = {}

    def load(self):
        self._redis = RedisLogger("MHFaceUnit", root_log_workspace=self._config.root_log_workspace,
                                  enable=self._enable_log)
        self._storage_client = MinioClient(self._config.root_workspace, cache=self._config.shared)

    def _pre_process_impl(self, data: dict) -> dict:
        id = data.get("id")
        status = data.get("status")
        print(f"Face task [{id}] starts to preprocess")
        switch_env(data, self._redis, self._db_args, self._storage_client)
        if id and status == ModelStatus.WAIT:
            update_model_status(id, "infer", ModelStatus.RUN, **self._db_args)

        if id:
            face_folder = os.path.join(self._config.root_workspace, self._config.infer_bucket, id)
        else:
            face_folder = os.path.join(self._config.root_workspace, data["face_model"])

        srt = data.get("srt")
        cluster_ws = MHWorkspace.initialize(**data)
        if data.get("type") == InferenceType.FACE_ONLY:
            wav = self._get_wav(data)
        elif data["cluster"] and data.get("tts_output_download", False):
            wav = self._get_uncached_object(cluster_ws.bucket, data["wav"], face_folder)
            srt = self._get_uncached_object(cluster_ws.bucket, srt, face_folder) if srt else None
        else:
            wav = data["wav"]

        # update config
        face_model = self._get_face_model(data)
        config_path = os.path.join(face_model, "face_infer.yml")
        model_config = load_yml_configs(config_path)
        if data["face_model_type"].lower() == "ernerf":
            model_config["inference"]["device"] = self._device
            model_config["preprocess"]["hubert"]["device"] = self._device
            if "xpu" in self._device:
                model_config["inference"]["ir_inference"] = False
        else:
            model_config["inference"]["gaussian_avatars"]["device"] = self._device
        new_model_config_path = os.path.join(face_folder, "face_infer.yml")
        Path(os.path.dirname(new_model_config_path)).mkdir(parents=True, exist_ok=True)
        yaml.dump(model_config, open(new_model_config_path, "w"))
        task_file = os.path.join(face_folder, "face.list")

        video_file = f"{data['name']}.mp4" if data.get("name") else f"{uuid.uuid1()}.mp4"
        return {
            "status": MHStatus.SUCCESS,
            "config": new_model_config_path,
            "task_file": task_file,
            "wav": wav,
            "output": os.path.join(face_folder, video_file),
            "id": data.get("id", None),
            "name": data.get("name", None),
            "subtitle": data.get("subtitle", False),
            "srt": srt,
            "subtitle_styles": data.get("subtitle_styles", {}),
            "cluster": cluster_ws,
            "account_id": data.get("account_id", None),
            "type": data.get("type")
        }

    def pre_process(self, data: dict) -> dict:
        try:
            ret = self._pre_process_impl(data)
        except Exception as e:
            id = data.get("id")
            print(f"Face task [{id}] infer pre_process failed: {e}")
            traceback.print_exc()
            if id:
                self._redis.publish(traceback.format_exc(), msg_id=id)
                update_model_status(id, "infer", ModelStatus.FAIL, self._redis,
                                    upload_func=upload_log_func(id, self._storage_client,
                                                                MHWorkspace.initialize(**data)), **self._db_args)
                save_notifications(data["account_id"], data["type"], ModelStatus.FAIL, data["name"], redis=self._redis, **self._db_args)
            return {
                "status": MHStatus.FAILED,
                "error": str(e)
            }
        return ret

    def _predict_impl(self, data: dict) -> dict:
        if data["status"] != MHStatus.SUCCESS:
            return data

        id = data.get("id")
        subtitle = data["subtitle"]

        out_video = data["output"]
        if subtitle:
            mh_out_video = os.path.join(os.path.dirname(out_video), f"mh_{uuid.uuid1()}.mp4")
        else:
            mh_out_video = out_video

        infer_task = MetaHumanInference(
            id,
            "face_infer",
            self._redis,
            self._enable_log,
            LOG_READ_BUFF_LEN,
            MH_ROOT,
            data["config"],
            data["task_file"],
            input=[data["wav"]],
            output=[mh_out_video],
            max_workers=COMMON_MAX_WORKER["infer"],
        )
        print(f"Face task [{id}] starts to run")
        ret = infer_task.execute_cmd()
        if ret == 0:
            if subtitle:
                add_subtitles(mh_out_video, data["wav"], data.get("srt"), out_video, data["subtitle_styles"], self._device)
                os.remove(mh_out_video)
                if id:
                    self._redis.publish(f"Add subtitle completed", msg_id=id)

            if id and data["cluster"]:
                infer_object = data["cluster"].gen_infer_object(id, os.path.basename(out_video))
                self._storage_client.upload(data["cluster"].bucket, infer_object, out_video)
                shutil.rmtree(os.path.dirname(out_video))

            if id:
                update_model_status(id, "infer", ModelStatus.COMPLETE, self._redis,
                                    upload_func=upload_log_func(id, self._storage_client, data["cluster"]),
                                    **self._db_args)
                save_notifications(data["account_id"], data["type"], ModelStatus.COMPLETE, data["name"], redis=self._redis, **self._db_args)
            print(f"Face task [{id}] succeed")
            return {
                "status": MHStatus.SUCCESS,
                "out": out_video
            }

        print(f"Face task [{id}] failed")
        if id:
            update_model_status(id, "infer", ModelStatus.FAIL, self._redis,
                                upload_func=upload_log_func(id, self._storage_client, data["cluster"]), **self._db_args)
            if os.path.exists(os.path.dirname(out_video)):
                upload_fail_artifacts(self._storage_client, id, os.path.dirname(out_video), data["cluster"], self._config.root_workspace, self._config.fail_output_dir)
            save_notifications(data["account_id"], data["type"], ModelStatus.FAIL, data["name"], redis=self._redis, **self._db_args)
        return {
            "status": MHStatus.FAILED,
        }

    def predict(self, data):
        try:
            ret = self._predict_impl(data)
        except Exception as e:
            id = data.get("id")
            print(f"Face task [{id}] infer predict failed: {e}")
            traceback.print_exc()
            if id:
                self._redis.publish(traceback.format_exc(), msg_id=id)
                update_model_status(id, "infer", ModelStatus.FAIL, self._redis,
                                    upload_func=upload_log_func(id, self._storage_client, data["cluster"]),
                                    **self._db_args)
                save_notifications(data["account_id"], data["type"], ModelStatus.FAIL, data["name"], redis=self._redis, **self._db_args)
                if os.path.exists(os.path.dirname(data["output"])):
                    upload_fail_artifacts(self._storage_client, id, os.path.dirname(data["output"]), data["cluster"], self._config.root_workspace, self._config.fail_output_dir)
            return {
                "status": MHStatus.FAILED,
                "error": str(e)
            }
        return ret

    def _on_model_downloaded(self, zip_file, model_type):
        print(f"Face model downloaded: {zip_file}")
        extract_dir = os.path.dirname(zip_file)
        shutil.unpack_archive(zip_file, extract_dir=extract_dir)
        os.remove(zip_file)
        config_file = os.path.join(extract_dir, "face_infer.yml")
        old_prefix, model_folder, concat = find_workspace_replace_prefix(config_file)
        replace_workspace_prefix_in_yml(config_file, old_prefix, extract_dir, concat)
        if model_type.lower() == "gaussian":
            diffspeaker_yml = os.path.join(extract_dir, model_folder, "diffspeaker_inference.yml")
            replace_workspace_prefix_in_yml(diffspeaker_yml, old_prefix, extract_dir, concat)

    def _get_face_model(self, data):
        if data.get("cluster", False):
            parts = data["face_model"].split("/", 1)
            zip_file = self._storage_client.download(parts[0], parts[1],
                                                     callback=partial(self._on_model_downloaded,
                                                                      model_type=data["face_model_type"]))
            return os.path.dirname(zip_file)
        return os.path.join(self._config.root_workspace, data["face_model"])

    def _get_wav(self, data):
        if data.get("cluster", False):
            parts = data["wav"].split("/", 1)
            return self._storage_client.download(parts[0], parts[1])
        return os.path.join(self._config.root_workspace, data["wav"])

    def _get_uncached_object(self, bucket, object, target_folder):
        target_path = os.path.join(target_folder, os.path.basename(object))
        self._storage_client.download_uncache(bucket, object, target_path)
        return target_path


@model("CustomizedVoiceUnit")
class CustomizedVoiceUnit(AsyncSingleProcessModel):
    def __init__(self, ms_config: CustomizedVoiceUnitConfig, config: MHInferenceConfig, log: bool):
        self._ms_config = ms_config
        self._config = config
        self._enable_log = log
        self._redis: Optional[RedisLogger] = None
        self._voice_services = None
        self._db_args = {}

    def load(self):
        self._redis = RedisLogger("CustomizedVoiceUnit", enable=self._enable_log)
        if self._ms_config.local:
            self._voice_services = self._ms_config.load_from_local()
        else:
            env_manager = EnvManager()
            self._voice_services = env_manager.download(self._ms_config.env_name)
        if self._voice_services is None:
            assert "Cannot find configured voice service!"

    def pre_process(self, data):
        id = data.get("id")
        status = data.get("status")
        print(f"TTS task [{id}] starts to preprocess")
        switch_env(data, self._redis, self._db_args, None)
        if id and status == ModelStatus.WAIT:
            update_model_status(id, "infer", ModelStatus.RUN, **self._db_args)

        wav_file = f"{data['name']}.wav" if data.get("name") else f"{uuid.uuid1()}.wav"
        srt_file = os.path.splitext(wav_file)[0] + ".json"
        subtitle = data.get("subtitle", False)
        if data.get("cluster", False):
            cluster_ws = MHWorkspace.initialize(**data)
            data["wav_output"] = cluster_ws.gen_infer_object(id, wav_file)
            data["srt"] = cluster_ws.gen_infer_object(id, srt_file) if subtitle else None
        else:
            if id:
                data["wav_output"] = os.path.join(self._config.root_workspace, self._config.infer_bucket, id, wav_file)
                data["srt"] = os.path.join(self._config.root_workspace, self._config.infer_bucket, id,
                                           srt_file) if subtitle else None
            else:
                data["wav_output"] = os.path.join(self._config.root_workspace, self._config.infer_bucket, wav_file)
                data["srt"] = os.path.join(self._config.root_workspace, self._config.infer_bucket,
                                           srt_file) if subtitle else None
        return data

    async def predict(self, data):
        model_type = data.get("tts_model_type", "").lower()
        if model_type not in self._voice_services:
            return {
                "status": MHStatus.FAILED
            }

        message = {
            "id": data.get("msg_id"),
            "wav_path": data["wav_path"],
            "customized_prompt": data["customized_prompt"],
            "instruct": data.get("instruct"),
            "text": data["text"],
            "output_path": data["wav_output"],
            "cluster": data.get("cluster", False),
            "userBucket": data.get("userBucket"),
            "workSpace": data.get("workSpace"),
            "srt": data["srt"],
            "seed": data.get("seed", None),
            "env": data.get("env", None),
            "env_flush": data.get("env_flush", False),
            "type": data.get("type", None),
            "name": data.get("name", None),
            "account_id": data.get("account_id", None),
        }

        message_json = json.dumps({k: v for k, v in message.items() if v is not None}, ensure_ascii=False)

        print(f"TTS task [{message['id']}] starts to run")
        ret = await send_request(RSocketClientConfig(**self._voice_services[model_type]), message_json)
        if ret.get("status") == MHStatus.SUCCESS:
            print(f"TTS task [{message['id']}] succeed")
            return {
                "status": MHStatus.SUCCESS,
                "tts_model_type": data.get("tts_model_type", None),
                "tts_output_download": data.get("cluster", False),
                "face_model": data.get("face_model", None),
                "face_model_type": data.get("face_model_type", None),
                "wav": data.get("wav_output", None),
                "id": data.get("id", None),
                "msg_id": data.get("msg_id", None),
                "name": data.get("name", None),
                "hdtr": data.get("hdtr", False),
                "video_path": data.get("video_path", None),
                "subtitle": data.get("subtitle", False),
                "srt": data.get("srt", None),
                "subtitle_styles": data.get("subtitle_styles", {}),
                "cluster": data.get("cluster", False),
                "userBucket": data.get("userBucket", None),
                "workSpace": data.get("workSpace", None),
                "env": data.get("env", None),
                "env_flush": data.get("env_flush", False),
                "type": data.get("type", None),
                "account_id": data.get("account_id", None),
            }
        print(f"TTS task [{message['id']}] failed")
        return {
            "status": MHStatus.FAILED
        }


@model("FaceLatentsyncUnit")
class FaceLatentsyncUnit(AsyncSingleProcessModel):
    def __init__(self, ms_config, config: MHInferenceConfig, log: bool):
        self._ms_config = ms_config
        self._config = config
        self._enable_log = log
        self._redis: Optional[RedisLogger] = None
        self._db_args = {}

    def load(self):
        self._redis = RedisLogger("FaceLatentsyncUnit", root_log_workspace=self._config.root_log_workspace,
                                  enable=self._enable_log)

    def pre_process(self, data):
        id = data.get("id")
        status = data.get("status")
        print(f"Face task [{id}] starts to preprocess")
        switch_env(data, self._redis, self._db_args, None)

        if id and status == ModelStatus.WAIT:
            update_model_status(id, "infer", ModelStatus.RUN, **self._db_args)
        return data

    async def predict(self, data):
        id = data.get("id")
        file_name = f"{data['name']}.mp4" if data.get("name") else f"{uuid.uuid1()}.mp4"
        if data["cluster"]:
            cluster_ws = MHWorkspace.initialize(**data)
            out_video = cluster_ws.gen_infer_object(id, file_name)
        else:
            if id:
                out_video = os.path.join(self._config.root_workspace, self._config.infer_bucket, id, file_name)
            else:
                out_video = os.path.join(self._config.root_workspace, self._config.infer_bucket, file_name)

        message = {
            "id": data.get("msg_id"),
            "video_path": data["video_path"],
            "audio_path": data["wav"],
            "output_path": out_video,
            "cluster": data["cluster"],
            "userBucket": data["userBucket"],
            "workSpace": data["workSpace"],
            "hdtr": data["hdtr"],
            "subtitle": data["subtitle"],
            "srt": data["srt"] if data["subtitle"] else None,
            "subtitle_styles": data["subtitle_styles"],
            "num_inference_steps": 20,
            "guidance_scale": 1.0,
            "update_status": True,
            "env": data.get("env", None),
            "env_flush": data.get("env_flush", False),
            "name": data.get("name", None),
            "account_id": data.get("account_id", None),
            "type": data.get("type", ""),
        }
        message_json = json.dumps({k: v for k, v in message.items() if v is not None}, ensure_ascii=False)
        await send_request(self._ms_config, message_json, non_blocking=True)

        return {
            "status": MHStatus.SUCCESS,
            "out": out_video
        }
