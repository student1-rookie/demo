import os
import torch
import torchaudio


from hydra.core.resource import model
from hydra.core.typing import SingleProcessModel
from hydra.nlunit.mh_utils.utils import is_video, video_add_audio

from speechbrain.inference.enhancement import SpectralMaskEnhancement


@model("DenoiseUnit")
class DenoiseUnit(SingleProcessModel):

    def __init__(self, model_path):
        self._model_path = model_path
        self._model = None

    def load(self):
        # Only support metricgan-plus-voicebank，mtl-mimic-voicebank is another choice
        self._model = SpectralMaskEnhancement.from_hparams(source=self._model_path)

    def pre_process(self, data: dict) -> dict:
        return data

    def _predict_impl(self, data:dict):
        input = data.get("input")
        file_name = data.get("fileName")

        temp_dir = os.path.dirname(input)
        file_base, _ = os.path.splitext(file_name)
        enhanced_audio = os.path.join(temp_dir, f"enhanced_{file_base}.wav")
        is_video_input = is_video(input)

        noisy = self._model.load_audio(input).unsqueeze(0)
        enhanced = self._model.enhance_batch(noisy, lengths=torch.tensor([1.]))
        torchaudio.save(enhanced_audio, enhanced.cpu(), 16000)

        output = enhanced_audio
        if is_video_input:
            enhanced_video = os.path.join(temp_dir, f"enhanced_{file_name}")
            video_add_audio(input, enhanced_audio, enhanced_video)
            output = enhanced_video

        return output

    def predict(self, data:dict):
        try:
            ret = self._predict_impl(data)
        except Exception as e:
            return None
        return ret
