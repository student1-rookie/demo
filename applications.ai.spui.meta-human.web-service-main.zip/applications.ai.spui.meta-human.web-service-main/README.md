# meta-human.web-service

## Requirements
- openjdk (version 17)
- gradle (version 8.7)
- postgres (version 16+)
    ```bash
    # pull image
    docker pull postgres:16.2-alpine3.19
    # run
    docker run -itd -e POSTGRES_USER=<user_name> -e POSTGRES_PASSWORD=<user_pw> -p 5432:5432 -v <data_path>:/var/lib/postgresql/data --name postgresql postgres:16.2-alpine3.19
    # create dbs
    docker exec -it postgresql ash
    psql -U <user>
    <user>=# CREATE DATABASE flex_mh;
    # test db
    <user>=# CREATE DATABASE flex_mh_test;
    ```

## Before Run
- generate test cert into `resources/keystore`
  ```bash
  keytool -genkeypair -alias <alias> -keyalg RSA -keysize 2048 -storetype PKCS12 -keystore <cert-file> -validity 3650
  ```
- modify [application.properties.template](src/main/resources/application.properties.template) to application.properties.

## Before Test
- modify [application.properties.template](src/test/resources/application.properties.template) to application.properties for test.

## Building with Frontend

```
cd meta-human.web/
npm install
npm run build
mkdir -p ../src/main/resources/static && cp -r dist/* ../src/main/resources/static
cd ..
gradle clean build -Dhttps.proxyHost=proxy-prc.intel.com -Dhttps.proxyPort=913  -x test
```

## Start microservices using compose
- modify [.env.template](docker-compose/.env.template) to .env.
- start the microservices:
  ```bash
  cd docker-compose/
  docker compose up -d
  ```
