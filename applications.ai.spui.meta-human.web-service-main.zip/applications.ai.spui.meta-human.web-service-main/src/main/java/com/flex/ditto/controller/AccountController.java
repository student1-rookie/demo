package com.flex.ditto.controller;

import com.flex.ditto.common.ModelType;
import com.flex.ditto.config.security.UserPrincipal;
import com.flex.ditto.controller.utils.IdUtils;
import com.flex.ditto.dto.AccountDto;
import com.flex.ditto.dto.ModelInfoDto;
import com.flex.ditto.dto.UserDto;
import com.flex.ditto.service.AccountService;
import com.flex.ditto.service.ModelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClient;
import org.springframework.security.oauth2.client.annotation.RegisteredOAuth2AuthorizedClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.UUID;

@RestController
@RequestMapping("/user")
public class AccountController {

    @Autowired
    ModelService modelService;

    @Autowired
    AccountService accountService;

    @GetMapping("/info")
    public Mono<ResponseEntity<AccountDto>> getInfo(@AuthenticationPrincipal UserPrincipal user) {
        return Mono.just(new AccountDto(user.getName(), user.getEmail(), user.isAdmin())).map(ResponseEntity::ok);
    }

    @GetMapping("/id")
    public Mono<ResponseEntity<?>> getId(@AuthenticationPrincipal UserPrincipal user) {
        return Mono.just(IdUtils.filterClaims(user)).map(ResponseEntity::ok);
    }

    @GetMapping("/token")
    public Mono<ResponseEntity<?>> getToken(@RegisteredOAuth2AuthorizedClient("azure") OAuth2AuthorizedClient client) {
        return Mono.just(client.getAccessToken()).map(ResponseEntity::ok);
    }

    @GetMapping("/models")
    public Flux<ModelInfoDto> getModels(@RequestParam("type") ModelType modelType, @AuthenticationPrincipal UserPrincipal user) {
        UUID sid = user.getSid();
        return modelService.getModelInfo(sid, modelType);
    }

    @GetMapping("/list")
    public Flux<UserDto> getList(@AuthenticationPrincipal UserPrincipal user) {
        if (user.isAdmin()) {
            return accountService.listAccounts();
        }
        return Flux.empty();
    }
}
