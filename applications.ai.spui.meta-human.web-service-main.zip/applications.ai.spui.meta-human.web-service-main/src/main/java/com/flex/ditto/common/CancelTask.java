package com.flex.ditto.common;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonSerialize
public record CancelTask(String id, String model) {
}
