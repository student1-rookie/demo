package com.flex.ditto.config;

import com.flex.ditto.common.ProtocolType;
import com.flex.ditto.config.property.CustomizedServicesProperties;
import com.flex.ditto.config.property.DynamicServiceConfigLoader;
import com.flex.ditto.config.property.ServiceProperties;
import io.rsocket.frame.decoder.PayloadDecoder;
import io.rsocket.metadata.WellKnownMimeType;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.rsocket.RSocketRequester;
import org.springframework.messaging.rsocket.RSocketStrategies;
import org.springframework.util.MimeTypeUtils;
import reactor.util.retry.Retry;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Configuration
public class RSocketConfig {

    @Value("${service.denoise.host}")
    private String denoiseHost;

    @Value("${service.denoise.port}")
    private Integer denoisePort;

    @Value("${service.parser.host}")
    private String parserHost;

    @Value("${service.parser.port}")
    private Integer parserPort;

    private final CustomizedServicesProperties properties;
    private final DynamicServiceConfigLoader loader;

    public RSocketConfig(CustomizedServicesProperties properties, DynamicServiceConfigLoader loader) {
        this.properties = properties;
        this.loader = loader;
    }

    @Bean
    public Map<String, RSocketRequester> customizedServiceRequesters(RSocketStrategies strategies) {
        Map<String, RSocketRequester> result = new HashMap<>();
        addRequestersForNames(result, properties.getTts(), strategies);
        addRequestersForNames(result, properties.getFace(), strategies);
        return result;
    }

    private void addRequestersForNames(Map<String, RSocketRequester> result,
                                           List<String> names,
                                           RSocketStrategies strategies) {
        if (names == null) {
            return;
        }
        for (String name : names) {
            ServiceProperties loadService = loader.load(name);
            if (loadService == null || !ProtocolType.RSOCKET.name().equals(loadService.getProtocol().toUpperCase())) {
                continue;
            }
            RSocketRequester requester = RSocketRequester.builder()
                    .rsocketConnector(
                            rSocketConnector ->
                                    rSocketConnector.reconnect(Retry.fixedDelay(5, Duration.ofSeconds(1)))
                    )
                    .dataMimeType(MimeTypeUtils.APPLICATION_JSON)
                    .rsocketStrategies(strategies)
                    .tcp(loadService.getHost(), loadService.getPort());
            result.put(loadService.getService(), requester);
        }
    }

    @Bean
    public RSocketRequester denoiseRSocketRequester(RSocketStrategies strategies) {
        return RSocketRequester.builder()
                .rsocketConnector(
                        rSocketConnector ->
                                rSocketConnector.reconnect(Retry.fixedDelay(5, Duration.ofSeconds(1)))
                                        .payloadDecoder(PayloadDecoder.ZERO_COPY)
                                        .fragment(1_000_000)
                )
                .dataMimeType(MimeTypeUtils.APPLICATION_OCTET_STREAM)
                .metadataMimeType(MimeTypeUtils.parseMimeType(WellKnownMimeType.MESSAGE_RSOCKET_COMPOSITE_METADATA.getString()))
                .rsocketStrategies(strategies)
                .tcp(denoiseHost, denoisePort);
    }

    @Bean
    public RSocketRequester parserRSocketRequester(RSocketStrategies strategies) {
        return RSocketRequester.builder()
                .rsocketConnector(
                        rSocketConnector ->
                                rSocketConnector.reconnect(Retry.fixedDelay(5, Duration.ofSeconds(1)))
                                        .payloadDecoder(PayloadDecoder.ZERO_COPY)
                                        .fragment(1_000_000)
                                        .keepAlive(Duration.ofSeconds(20L), Duration.ofMinutes(10L))
                )
                .dataMimeType(MimeTypeUtils.APPLICATION_JSON)
                .metadataMimeType(MimeTypeUtils.parseMimeType(WellKnownMimeType.MESSAGE_RSOCKET_COMPOSITE_METADATA.getString()))
                .rsocketStrategies(strategies)
                .tcp(parserHost, parserPort);
    }
}
