package com.flex.ditto.controller;

import com.flex.ditto.common.*;
import com.flex.ditto.config.security.UserPrincipal;
import com.flex.ditto.dto.*;
import com.flex.ditto.service.ModelService;
import com.flex.ditto.service.TrainService;
import com.flex.ditto.service.utils.ConvertUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Map;
import java.util.UUID;


@RestController
@RequestMapping("/mh")
public class MetaHumanController {

    @Autowired
    ModelService modelService;

    @Autowired
    TrainService trainService;

    @PostMapping("/train")
    public Mono<ResponseEntity<?>> train(@RequestBody TrainMetaDto trainMetaDto,
                                         @AuthenticationPrincipal UserPrincipal user) {
        UUID userId = user.getSid();
        // 1. get dataset by name
        // 2. create model task
        // 3. pub request
        return modelService.getDatasetByIdentifier(trainMetaDto.getDataset(), userId).flatMapMany(
                        dataset -> modelService.createModel(trainMetaDto, userId, dataset))
                .flatMap(trainTask -> trainService.pubTrainTask(trainTask))
                .then(Mono.just(ResponseEntity.ok().build()));
    }

    @PutMapping("/train/cancel/{id}")
    public Mono<Void> cancelTrainTask(@PathVariable String id, @RequestParam("type") ModelType type,
                                      @AuthenticationPrincipal UserPrincipal user) {
        var taskId = UUID.fromString(id);
        return modelService.getDetailModelType(user.getSid(), taskId, type, user.isAdmin()).flatMap(
                genericModel -> {
                    if (genericModel.getStatus().equals(ModelStatus.TRAIN) ||
                            genericModel.getStatus().equals(ModelStatus.WAIT)) {
                        if (genericModel.getModel().isCustomized()) {
                            // amend task status to cancel for latentsync or customized tts
                            return modelService.updateModelStatus(taskId, type, ModelStatus.CANCEL);
                        }
                        return trainService.cancelTrainTask(ConvertUtils.toCancelTask(genericModel));
                    } else if (genericModel.getStatus().equals(ModelStatus.INIT)) {
                        return modelService.updateModelStatus(taskId, type, ModelStatus.CANCEL);
                    }
                    return Mono.empty();
                }
        );
    }

    @PostMapping("/cv-prompt")
    public Mono<ResponseEntity<?>> generatePrompt(@RequestBody PromptDto promptDto,
                                                  @AuthenticationPrincipal UserPrincipal user) {
        UUID userId = user.getSid();
        return modelService.getDatasetByIdentifier(promptDto.getDataset(), userId)
                .flatMap(dataset -> modelService.generatePrompt(promptDto.getCutDuration(), userId, dataset))
                .map(ResponseEntity::ok);
    }

    @PostMapping("/status")
    public Mono<ModelDetailsDto> getModelStatus(@RequestBody ModelDto modelDto,
                                                @AuthenticationPrincipal UserPrincipal user) {
        return modelService.getModelStatus(modelDto);
    }

    @GetMapping("/type")
    public Mono<ResponseEntity<?>> trainModelType(@AuthenticationPrincipal UserPrincipal user) {
        return Mono.just(ResponseEntity.ok().body(Map.of(ModelType.FACE.name().toLowerCase(), FaceModelType.values(),
                ModelType.TTS.name().toLowerCase(), TTSModelType.values())));
    }

    @GetMapping("/training")
    public Flux<TrainingModelsDto> trainingModels(@AuthenticationPrincipal UserPrincipal user) {
        UUID userId = user.getSid();
        return modelService.getMyTrainingModels(userId);
    }
}
