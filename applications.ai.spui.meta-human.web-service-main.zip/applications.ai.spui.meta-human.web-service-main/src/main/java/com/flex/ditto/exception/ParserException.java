package com.flex.ditto.exception;

public class ParserException extends RuntimeException {
    public ParserException(String message) {
        super(message);
    }
}
