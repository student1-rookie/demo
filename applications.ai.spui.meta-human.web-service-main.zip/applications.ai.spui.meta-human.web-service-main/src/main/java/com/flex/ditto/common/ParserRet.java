package com.flex.ditto.common;

public record ParserRet(Integer code, String msg, String groupId) {
}
