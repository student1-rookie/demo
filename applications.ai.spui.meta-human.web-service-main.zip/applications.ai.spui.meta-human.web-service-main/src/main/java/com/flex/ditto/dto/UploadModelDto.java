package com.flex.ditto.dto;

import com.flex.ditto.common.MetaHumanModelType;
import com.flex.ditto.common.ResourceAccess;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.ZonedDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UploadModelDto {
    private String name;
    private ZonedDateTime created;
    private ResourceAccess access;
    private MetaHumanModelType subType;
}
