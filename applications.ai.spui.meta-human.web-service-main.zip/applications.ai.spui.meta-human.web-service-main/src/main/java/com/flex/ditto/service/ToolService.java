package com.flex.ditto.service;

import com.flex.ditto.common.ResourceAccess;
import com.flex.ditto.domain.AccountRepository;
import com.flex.ditto.domain.MetaHumanDataset;
import com.flex.ditto.domain.MetaHumanDatasetRepository;
import com.flex.ditto.dto.DenoiseMetaDto;
import com.flex.ditto.dto.UserActivityCountDto;
import com.flex.ditto.exception.ToolException;
import com.flex.ditto.service.utils.ConvertUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;


import java.time.*;
import java.util.UUID;

@Service
public class ToolService {

    private static final Logger logger = LoggerFactory.getLogger(ToolService.class);

    @Autowired
    private MetaHumanDatasetRepository datasetRepository;

    @Autowired
    private ResourceService resourceService;

    @Autowired
    private StorageService storageService;

    @Autowired
    private DenoiseService denoiseService;

    @Autowired
    AccountRepository accountRepository;

    public Mono<Resource> denoiseResource(DenoiseMetaDto denoiseMetaDto, UUID userId) {
        logger.debug("Processing resource for dataset: {}", denoiseMetaDto.getDataset());

        return datasetRepository.findByIdentifierAndAccountId(denoiseMetaDto.getDataset(), userId)
                .next()
                .flatMap(dataset -> storageService.loadDatasetBytes(userId, dataset)
                        .flatMap(fileBytes -> denoiseService.denoise(dataset.getFileName(), fileBytes)
                                .flatMap(denoisedBytes -> {
                                    if (denoisedBytes.length == 0) {
                                        return Mono.error(new ToolException("Denoised Failed"));
                                    }
                                    String fileExtension = ConvertUtils.getFileExtension(dataset.getFileName());
                                    String outputName = denoiseMetaDto.getOutputName();
                                    String outputFileName = outputName + fileExtension;

                                    if (denoiseMetaDto.getNewResource()) {
                                        saveNewResourceCopy(dataset, denoisedBytes, outputName, outputFileName, userId).subscribe();
                                    }

                                    return Mono.just(new ByteArrayResource(denoisedBytes) {
                                        @Override
                                        public String getFilename() {
                                            return outputFileName;
                                        }
                                    });
                                })));
    }

    private Mono<Void> saveNewResourceCopy(MetaHumanDataset dataset, byte[] denoisedBytes, String outputName, String outputFilename, UUID userId) {
        String md5 = ConvertUtils.computeMD5(denoisedBytes);
        String newIdentifier = ConvertUtils.generateCombineIdentifier(userId, md5);

        return datasetRepository.findByIdentifier(newIdentifier)
                .flatMap(existingDataset -> resourceService.deleteResource(existingDataset.getId(), userId, false)
                        .then(Mono.defer(() -> {
                            existingDataset.setName(outputName);
                            existingDataset.setFileName(outputFilename);
                            existingDataset.setType(dataset.getType());
                            existingDataset.setFileType(dataset.getFileType());
                            logger.debug("Updating resource copy with identifier: {}", newIdentifier);
                            return datasetRepository.save(existingDataset);
                        })))
                .switchIfEmpty(Mono.defer(() -> {
                    MetaHumanDataset newDataset = new MetaHumanDataset(
                            outputName,
                            ZonedDateTime.now(),
                            dataset.getType(),
                            outputFilename,
                            newIdentifier,
                            dataset.getFileType(),
                            userId
                    );
                    logger.debug("Saving new resource copy with identifier: {}", newIdentifier);
                    return datasetRepository.save(newDataset);
                }))
                .flatMap(savedDataset -> storageService.store(userId, savedDataset.getId(), savedDataset.getFileName(), savedDataset.getType().equals(ResourceAccess.PUBLIC), denoisedBytes));
    }

    public Flux<UserActivityCountDto> getUserActivityCount(Long startDate, Long endDate) {
        OffsetDateTime startTime = OffsetDateTime.ofInstant(Instant.ofEpochSecond(startDate), ZoneOffset.UTC);
        OffsetDateTime endTime = OffsetDateTime.ofInstant(Instant.ofEpochSecond(endDate), ZoneOffset.UTC);
        return accountRepository.queryByTimeRange(startTime, endTime);
    }
}
