package com.flex.ditto.dto;

import com.flex.ditto.common.InferenceResult;
import com.flex.ditto.common.InferenceStatus;
import com.flex.ditto.common.InferenceType;
import lombok.Data;

import java.time.ZonedDateTime;
import java.util.UUID;

@Data
public class InferenceInfoDto {
    private UUID id;
    private String name;
    private ZonedDateTime date;
    private InferenceStatus status;
    private UUID accountId;
    private UUID faceModelId;
    private UUID ttsModelId;
    private String faceModelName;
    private String ttsModelName;
    private InferenceResult type;
}
