package com.flex.ditto.exception;

public class PicTemplateException extends RuntimeException {

    public PicTemplateException(String message) {
        super(message);
    }
}
