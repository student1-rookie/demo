package com.flex.ditto.service;

import java.nio.ByteBuffer;
import java.time.Duration;
import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.flex.ditto.common.ModelStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.connection.stream.Consumer;
import org.springframework.data.redis.connection.stream.MapRecord;
import org.springframework.data.redis.connection.stream.ReadOffset;
import org.springframework.data.redis.connection.stream.StreamOffset;
import org.springframework.data.redis.connection.stream.StreamReadOptions;
import org.springframework.data.redis.core.ReactiveRedisTemplate;
import org.springframework.data.redis.core.ReactiveStreamOperations;
import org.springframework.data.redis.core.script.RedisScript;
import org.springframework.stereotype.Service;

import io.lettuce.core.RedisCommandExecutionException;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class RedisCacheService {

    private final int chunkSize = 10;

    @Autowired
    private ReactiveRedisTemplate<String, String> reactiveRedisTemplate;

    Flux<MapRecord<String, String, String>> readStreamRecord(String streamKey, String consumer, String group) {
        ReactiveStreamOperations<String, String, String> ops = reactiveRedisTemplate.opsForStream();
        
        // pending queue messages
        Flux<MapRecord<String, String, String>> pending =
                ops.read(
                    Consumer.from(group, consumer),
                    StreamReadOptions.empty().count(chunkSize),
                    StreamOffset.create(streamKey, ReadOffset.lastConsumed())
                );

        // new messages
        Flux<MapRecord<String, String, String>> fresh =
                Flux.defer(() -> ops.read(
                        Consumer.from(group, consumer),
                        StreamReadOptions.empty()
                                .block(Duration.ofSeconds(10))
                                .count(chunkSize),
                        StreamOffset.create(streamKey, ReadOffset.lastConsumed())
                ))
                .repeat()
                .flatMap(record -> ops.acknowledge(streamKey, group, record.getId())
                                            .thenReturn(record));
        
        return pending.concatWith(fresh);
    }

    public Mono<Boolean> createGroup(String streamKey, String group) {
        ReactiveStreamOperations<String, String, String> ops = reactiveRedisTemplate.opsForStream();

        return reactiveRedisTemplate.execute(connection ->
                connection.streamCommands().xInfoGroups(ByteBuffer.wrap(streamKey.getBytes()))
                        .onErrorResume(e -> {
                                if (e instanceof RedisCommandExecutionException &&
                                    e.getMessage() != null &&
                                    e.getMessage().contains("no such key")) {
                                    return Flux.empty();
                                }
                                return Flux.error(e);
                            })
        )
        .any(info -> group.equals(info.groupName()))
        .flatMap(exists -> {
            if (exists) return Mono.just(true);
            // create blank stream and create group
            return ops.createGroup(streamKey, ReadOffset.latest(), group)
                    .thenReturn(true)
                    .onErrorResume(e -> {
                        if (e.getMessage() != null && e.getMessage().contains("BUSYGROUP")) {
                            return Mono.just(true);
                        }
                        return Mono.error(e);
                    });
        });
    }

    public Mono<Boolean> tryLock(String key, String value, Duration ttl) {
        return reactiveRedisTemplate.opsForValue().setIfAbsent(key, value, ttl);
    }

    public Mono<Void> publishNotify(UUID userId, String message, ModelStatus status) {
        ReactiveStreamOperations<String, String, String> ops = reactiveRedisTemplate.opsForStream();

        String streamKey = "notifications:" + userId;

        Map<String, String> fields = new HashMap<>();
        fields.put("message", message == null ? "" : message);
        fields.put("status", status.name());
        fields.put("date", ZonedDateTime.now().toString());
        fields.put("accountId", userId.toString());

        return ops.add(MapRecord.create(streamKey, fields)).then();
    }

    private static final RedisScript<Long> UNLOCK_SCRIPT =
        RedisScript.of(
            "if redis.call('get', KEYS[1]) == ARGV[1] then " +
            "   return redis.call('del', KEYS[1]) " +
            "else " +
            "   return 0 " +
            "end",
            Long.class
        );

    public Mono<Void> unlock(String key, String value) {
        return reactiveRedisTemplate
            .execute(
                UNLOCK_SCRIPT,
                List.of(key),
                List.of(value)
            )
            .then();
    }

}
