package com.flex.ditto.config.security;

import com.flex.ditto.common.SecurityEntry;
import com.flex.ditto.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableReactiveMethodSecurity;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.oauth2.client.oidc.userinfo.OidcReactiveOAuth2UserService;
import org.springframework.security.oauth2.client.oidc.userinfo.OidcUserRequest;
import org.springframework.security.oauth2.client.userinfo.ReactiveOAuth2UserService;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.security.web.server.SecurityWebFilterChain;
import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatchers;
import reactor.core.publisher.Mono;

@Configuration
@EnableWebFluxSecurity
@EnableReactiveMethodSecurity
public class SecurityConfig {

    @Autowired
    AccountService accountService;
    @Autowired
    AuthenticationManager authenticationManager;
    @Autowired
    SecurityContextRepository securityContextRepository;
    @Autowired
    MHLogoutSuccessHandler logoutSuccessHandler;
    @Autowired
    MHServerAuthenticationEntryPoint authenticationEntryPoint;

    @Value("${app.oauth2.success-url}")
    private String successUrl;
    @Value("${spring.session.max-idle-time}")
    private Integer maxIdleTime;
    @Value("${app.oauth2.azure.enable}")
    private Boolean azureEnable;

    @Bean
    public SecurityWebFilterChain securityWebFilterChain(ServerHttpSecurity http) {
        http.authorizeExchange(authorize -> authorize
                    .pathMatchers("/", "/login**", "/error**", "/assets/**", "/security/**").permitAll()
                    .anyExchange().authenticated()
            );
        if (azureEnable) {
            http.oauth2Login(oAuth2LoginSpec ->
                    oAuth2LoginSpec.authenticationSuccessHandler(new MHLoginSuccessHandler(successUrl, maxIdleTime, SecurityEntry.AZURE))
            );
        }
        http.formLogin(formLoginSpec ->
                formLoginSpec.loginPage("/login")
                        .authenticationManager(authenticationManager)
                        .securityContextRepository(securityContextRepository)
                        .authenticationSuccessHandler(new MHLoginSuccessHandler(successUrl, maxIdleTime, SecurityEntry.FORM)))
        .logout(logoutSpec ->
                logoutSpec.logoutSuccessHandler(logoutSuccessHandler).logoutUrl("/logout").requiresLogout(ServerWebExchangeMatchers.pathMatchers("/logout")))
        .exceptionHandling(exceptionHandlingSpec -> exceptionHandlingSpec.authenticationEntryPoint(authenticationEntryPoint))
        .csrf(ServerHttpSecurity.CsrfSpec::disable);

        return http.build();
    }

    @Bean
    public ReactiveOAuth2UserService<OidcUserRequest, OidcUser> oidcUserService() {
        final OidcReactiveOAuth2UserService delegate = new OidcReactiveOAuth2UserService();

        return (userRequest) -> delegate.loadUser(userRequest)
                .flatMap((oidcUser) -> accountService.getPerson(oidcUser.getEmail(), oidcUser.getName())
                        .flatMap(u -> Mono.just(u.toOidcUser(oidcUser)))).log();
    }

}
