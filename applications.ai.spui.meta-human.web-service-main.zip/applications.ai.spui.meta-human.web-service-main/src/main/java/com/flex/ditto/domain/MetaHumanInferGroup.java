package com.flex.ditto.domain;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import java.util.UUID;

@Data
@Table("meta_human_infer_group")
@NoArgsConstructor
public class MetaHumanInferGroup {
    @Id
    private UUID id;
    private String name;

    public MetaHumanInferGroup(String name) {
        this.name = name;
    }
}
