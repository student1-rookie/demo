package com.flex.ditto.service;

import com.flex.ditto.common.*;
import com.flex.ditto.common.inference.InferenceFaceTask;
import com.flex.ditto.common.inference.InferencePicInPicTask;
import com.flex.ditto.common.inference.InferenceTTSTask;
import com.flex.ditto.common.inference.InferenceWholeTask;
import com.flex.ditto.domain.*;
import com.flex.ditto.dto.*;
import com.flex.ditto.exception.InferenceException;
import com.flex.ditto.exception.PicTemplateException;
import com.flex.ditto.service.utils.ConvertUtils;
import com.flex.ditto.service.utils.MinIOConvertUtils;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.time.Duration;
import java.util.*;
import java.util.function.Function;
import java.util.function.Supplier;

@Slf4j
@Service
public class InferenceService {

    @Value("${app.mq.generic-routing-key:generic}")
    private String genericRoutingKey;

    @Autowired
    private MetaHumanDatasetRepository metaHumanDatasetRepository;

    @Autowired
    private InferenceRepository inferenceRepository;

    @Autowired
    private PicInPicTemplateRepository pipTemplateRepository;

    @Autowired
    private ModelService modelService;

    @Autowired
    private Map<String, CustomizedTTSService> customizedTTSServices;

    @Autowired
    private Map<String, CustomizedFaceService> customizedFaceServices;

    @Autowired
    private StorageService storageService;

    @Autowired
    private MetaHumanInferGroupRepository metaHumanInferGroupRepository;

    @Autowired
    private InferenceCacheService inferenceCacheService;

    @Autowired
    private InferenceTaskService  inferenceTaskService;

    @Autowired
    private RedisCacheService redisCacheService;

    public Mono<Void> inference(InferenceMetaDto inferenceMetaDto, UUID id) {
        return modelService.getTaskModel(id, inferenceMetaDto.getModels())
                .flatMap(m -> {
                    if (inferenceMetaDto.getType().equals(InferenceType.WHOLE) && (m.getT1().isPresent() || m.getT2().isPresent())) {
                        return inferenceWhole(inferenceMetaDto, m.getT1().get(), m.getT2().get(), id);
                    } else if (inferenceMetaDto.getType().equals(InferenceType.TTS_ONLY) && m.getT2().isPresent()) {
                        String ttsTypeName = m.getT2().get().getModelType().name();
                        if (customizedTTSServices.containsKey(ttsTypeName)) {
                            return customizedTTSServices.get(ttsTypeName).inference(inferenceMetaDto, m.getT2().get(), id, storageService.getWorkSpace(), storageService.isCluster());
                        } else if (m.getT2().get().getModelType().isCustomized()) {
                            return Mono.error(new InferenceException(String.format("Customized TTS service not found for model type: %s", ttsTypeName)));
                        }
                        return inferenceTTS(inferenceMetaDto, m.getT2().get(), id);
                    } else if (inferenceMetaDto.getType().equals(InferenceType.FACE_ONLY) && m.getT1().isPresent()) {
                        String faceTypeName = m.getT1().get().getModelType().name();
                        if (customizedFaceServices.containsKey(faceTypeName)) {
                            return customizedFaceServices.get(faceTypeName).inference(inferenceMetaDto, m.getT1().get(), id, storageService.getWorkSpace(), storageService.isCluster());
                        } else if (m.getT1().get().getModelType().isCustomized()) {
                            return Mono.error(new InferenceException(String.format("Customized FACE service not found for model type: %s", faceTypeName)));
                        }
                        return metaHumanDatasetRepository.findById(inferenceMetaDto.getWav())
                                .flatMap(d -> inferenceFace(inferenceMetaDto, m.getT1().get(), d, id))
                                .onErrorMap(RuntimeException::new);
                    }
                    return Mono.error(new InferenceException(String.format("model is missing! type: %s, face model: %s, voice model: %s", inferenceMetaDto.getType(), m.getT1().isEmpty(), m.getT2().isEmpty())));
                });
    }

    public Mono<Void> picInPicInference(InferencePicInPicTaskDto inferencePicInPicTaskDto, UUID id) {
        var datasetFlux = Flux.fromIterable(inferencePicInPicTaskDto.getInput()).concatMap(i -> metaHumanDatasetRepository.findById(UUID.fromString(i.getMedia())));
        // TODO: support background img
        return datasetFlux.collectList().flatMap(
                metaHumanDatasets -> {
                    if (metaHumanDatasets.isEmpty()) {
                        return Mono.error(new InferenceException("empty input datasets."));
                    }
                    if (metaHumanDatasets.size() != inferencePicInPicTaskDto.getInput().size()) {
                        return Mono.error(new InferenceException("include invalid input datasets."));
                    }
                    return modelService.getTaskModel(id, inferencePicInPicTaskDto.getModels())
                            .flatMap(m -> {
                                if (m.getT2().isPresent()) {
                                    FaceModel faceModel = m.getT1().isPresent() ? m.getT1().get() : null;
                                    return inferencePicInPic(inferencePicInPicTaskDto, metaHumanDatasets, faceModel, m.getT2().get(), id);
                                }
                                return Mono.error(new InferenceException(String.format("model is missing! voice model: %s", m.getT2().isEmpty())));
                            });
                }
        );
    }

    public Mono<ItemInferenceResultDto> itemPicInPicInference(InferencePicInPicTaskDto inferencePicInPicTaskDto, UUID userId) {
        var datasetFlux = Flux.fromIterable(inferencePicInPicTaskDto.getInput()).concatMap(i -> metaHumanDatasetRepository.findById(UUID.fromString(i.getMedia())));
        return datasetFlux.collectList().flatMap(
                metaHumanDatasets -> {
                    if (metaHumanDatasets.isEmpty()) {
                        return Mono.error(new InferenceException("empty input datasets."));
                    }
                    if (metaHumanDatasets.size() != inferencePicInPicTaskDto.getInput().size()) {
                        return Mono.error(new InferenceException("include invalid input datasets."));
                    }
                    return modelService.getTaskModel(userId, inferencePicInPicTaskDto.getModels())
                            .flatMap(m -> {
                                if (m.getT2().isPresent()) {
                                    FaceModel faceModel = m.getT1().isPresent() ? m.getT1().get() : null;
                                    return inferenceItemPicInPic(inferencePicInPicTaskDto, metaHumanDatasets, faceModel, m.getT2().get(), userId);
                                }
                                return Mono.error(new InferenceException(String.format("model is missing! voice model: %s", m.getT2().isEmpty())));
                            });
                }
        );
    }

    private Mono<Void> inferencePicInPic(InferencePicInPicTaskDto inferencePicInPicTaskDto, List<MetaHumanDataset> metaHumanDatasets, FaceModel faceModel, TTSModel ttsModel, UUID accountId) {
        // Steps:
        // - save pic template
        // - save inference
        // - pub infer task
        UUID faceModelId = faceModel == null ? null : faceModel.getId();
        Mono<UUID> groupIdMono = pipTemplateRepository.findPicInPicTemplatesByNameAndAccountId(inferencePicInPicTaskDto.getName(), accountId).collectList()
                .flatMap(picInPicTemplates -> {
                    if (picInPicTemplates.isEmpty()) {
                        return metaHumanInferGroupRepository.save(new MetaHumanInferGroup(inferencePicInPicTaskDto.getName() + "_grp"))
                            .flatMap(group -> reuse(inferencePicInPicTaskDto, null, accountId, ttsModel.getId(), faceModelId, group.getId())
                                    .flatMap(inferencePicInPicEntity -> pipTemplateRepository.save(new PicInPicTemplate(inferencePicInPicTaskDto.getName(), inferencePicInPicEntity, accountId, group.getId()))
                                    .thenReturn(group.getId())));
                    }

                    PicInPicTemplate existingTemplate = picInPicTemplates.get(0);
                    if (existingTemplate.getGroupId() == null) {
                        return metaHumanInferGroupRepository.save(new MetaHumanInferGroup(inferencePicInPicTaskDto.getName() + "_grp"))
                            .flatMap(group -> pipTemplateRepository.updateGroupIdById(group.getId(), existingTemplate.getId())
                                    .then(reuse(inferencePicInPicTaskDto, existingTemplate.getDetails(), accountId, ttsModel.getId(), faceModelId, group.getId()))
                                    .flatMap(inferencePicInPicEntity -> pipTemplateRepository.updateDetailsById(inferencePicInPicEntity, existingTemplate.getId()))
                                    .thenReturn(group.getId()));
                    }

                    return inferenceRepository.findPipRunningInferences(inferencePicInPicTaskDto.getName(), accountId).collectList()
                                    .flatMap(activeInfers -> {
                                        if (!activeInfers.isEmpty()) {
                                            // delete existing group and create a new one
                                            return metaHumanInferGroupRepository.deleteById(existingTemplate.getGroupId())
                                                    .then(metaHumanInferGroupRepository.save(new MetaHumanInferGroup(inferencePicInPicTaskDto.getName() + "_grp")))
                                                    .flatMap(newGroup -> pipTemplateRepository.updateGroupIdById(newGroup.getId(), existingTemplate.getId())
                                                            .then(reuse(inferencePicInPicTaskDto, existingTemplate.getDetails(), accountId, ttsModel.getId(), faceModelId, newGroup.getId()))
                                                            .flatMap(inferencePicInPicEntity -> pipTemplateRepository.updateDetailsById(inferencePicInPicEntity, existingTemplate.getId()))
                                                            .thenReturn(newGroup.getId()));
                                        }

                                        return reuse(inferencePicInPicTaskDto, existingTemplate.getDetails(), accountId, ttsModel.getId(), faceModelId, existingTemplate.getGroupId())
                                                .flatMap(inferencePicInPicEntity -> pipTemplateRepository.updateDetailsById(inferencePicInPicEntity, existingTemplate.getId()).thenReturn(existingTemplate.getGroupId()));
                    });
                });

        return groupIdMono.flatMap(
                groupId -> {
                    Mono<Map<String, Object>> faceExtraInfo = getFaceExtraInfo(faceModel);
                    Mono<Map<String, Object>> ttsExtraInfo = getTtsExtraInfo(ttsModel);

                    return inferenceRepository.save(new Inference(inferencePicInPicTaskDto.getName(), accountId, faceModelId, ttsModel.getId(), InferenceResult.getResultType(inferencePicInPicTaskDto.getType()), groupId))
                        .flatMap(infer -> 
                            faceExtraInfo.zipWith(ttsExtraInfo).flatMap(info -> {
                                Map<String, Object> extraInfo = new HashMap<>();
                                if (!info.getT1().isEmpty()) {
                                    extraInfo.putAll(info.getT1());
                                }
                                if (!info.getT2().isEmpty()) {
                                    extraInfo.putAll(info.getT2());
                                }
                                InferencePicInPicTask task = ConvertUtils.toInferencePicInPicTask(inferencePicInPicTaskDto, metaHumanDatasets, infer, faceModel, ttsModel,
                                    extraInfo, storageService.getWorkSpace(), storageService.isCluster(), groupId.toString());
                                return inferenceTaskService.pubInferTask(task, task.getId(), genericRoutingKey);
                        })
                    );
                }
        );
    }

    private Mono<ItemInferenceResultDto> inferenceItemPicInPic(InferencePicInPicTaskDto inferencePicInPicTaskDto, List<MetaHumanDataset> metaHumanDatasets, FaceModel faceModel, TTSModel ttsModel, UUID accountId) {
        String redisItemKey = inferencePicInPicTaskDto.createRedisItemKey(inferencePicInPicTaskDto.getInput().get(0), accountId);
        return inferenceCacheService.checkItemPicInPicExist(redisItemKey)
                .switchIfEmpty(doItemInference(accountId, faceModel, ttsModel, inferencePicInPicTaskDto, redisItemKey, metaHumanDatasets));
    }

    private Mono<ItemInferenceResultDto> doItemInference(UUID accountId, FaceModel faceModel, TTSModel ttsModel, InferencePicInPicTaskDto taskDto, String itemRedisKey, List<MetaHumanDataset> metaHumanDatasets) {
        UUID faceModelId = faceModel == null ? null : faceModel.getId();
        Inference inference = new Inference(itemRedisKey, accountId, faceModelId, ttsModel.getId(), InferenceResult.getResultType(taskDto.getType()));
        inference.setId(UUID.randomUUID());
        Mono<Map<String, Object>> faceExtraInfo = getFaceExtraInfo(faceModel);
        Mono<Map<String, Object>> ttsExtraInfo = getTtsExtraInfo(ttsModel);
        var createCacheMono =  inferenceCacheService.createItemPicInPicResult(itemRedisKey, inference.getId(), taskDto.getInput().get(0), taskDto.getName())
                .filter(Boolean.TRUE::equals)
                .switchIfEmpty(Mono.error(new InferenceException("Failed to write to Redis")));
        var pubTaskMono = faceExtraInfo.zipWith(ttsExtraInfo)
                .flatMap(info -> {
                    Map<String, Object> extraInfo = new HashMap<>();
                    if (!info.getT1().isEmpty()) {
                        extraInfo.putAll(info.getT1());
                    }
                    if (!info.getT2().isEmpty()) {
                        extraInfo.putAll(info.getT2());
                    }
                    InferencePicInPicTask task = ConvertUtils.toInferencePicInPicTask(taskDto, metaHumanDatasets, inference, faceModel, ttsModel,
                            extraInfo, storageService.getWorkSpace(), storageService.isCluster(), null);
                    return inferenceTaskService.pubInferTask(task, task.getId(), genericRoutingKey);
                });
        return Mono.when(createCacheMono, pubTaskMono).thenReturn(new ItemInferenceResultDto(itemRedisKey, inference.getId()));
    }

    private Mono<Map<String, Object>> getFaceExtraInfo(FaceModel faceModel) {
        if (faceModel != null && customizedFaceServices.containsKey(faceModel.getModelType().name())) {
            return metaHumanDatasetRepository.findById(faceModel.getDatasetId()).map(
                    dataset -> {
                        if (storageService.isCluster()) {
                            return Map.of("video_path", MinIOConvertUtils.toDatasetXPath(dataset, storageService.getWorkSpace()));
                        }
                        return Map.of("video_path", dataset.getDatasetPath());
                    });
        }
        return Mono.just(Collections.emptyMap());
    }

    private Mono<Map<String, Object>> getTtsExtraInfo(TTSModel ttsModel) {
        if (customizedTTSServices.containsKey(ttsModel.getModelType().name())) {
            return metaHumanDatasetRepository.findById(ttsModel.getDatasetId()).map(
                    dataset -> {
                        if (storageService.isCluster()) {
                            return Map.of("wav_path", MinIOConvertUtils.toDatasetXPath(dataset, storageService.getWorkSpace()));
                        }
                        return Map.of("wav_path", dataset.getDatasetPath());
                    });
        }
        return Mono.just(Collections.emptyMap());
    }

    private Mono<InferencePicInPicDto> reuse(InferencePicInPicTaskDto taskDto, InferencePicInPicDto dto,UUID accountId, UUID ttsModelId, UUID faceModelId, UUID groupId) {
        return inferenceRepository.findItemNamesByGroupId(groupId)
                .collect(HashSet<String>::new, Set::add)
                .flatMap(itemNames -> {
                    return Flux.fromIterable(taskDto.getInput()).flatMap(item -> {
                        return inferenceRepository.save(new Inference(buildItemName(item.createPreviewItemKey(), "item"), accountId, faceModelId, ttsModelId, InferenceResult.PIP_ITEM, groupId, InferenceStatus.INIT))
                                .flatMap(infer -> {
                                    item.setItemId(infer.getId());
                                    return inferenceCacheService.checkRedisReuse(taskDto, item, accountId, faceModelId, ttsModelId, groupId, false).flatMap(newItem -> {
                                        if (newItem.getReuseStatus() == null && dto != null) {
                                            checkChange(taskDto, newItem, itemNames, dto.getSubtitle());
                                        }
                                        return saveReuseItems(newItem, taskDto.getName(), false);
                                    });
                                });
                    }).then();
                })
                .thenReturn(taskDto.convert());
    }

    private void checkChange(InferencePicInPicTaskDto taskDto, PicInPicTaskDto item, Set<String> itemNames, Boolean oldSubtitle) {
        Reuse reuseStatus = CheckChangeTtsAndFace(taskDto, item, itemNames, oldSubtitle);
        item.setReuseStatus(reuseStatus);
    }

    private Reuse CheckChangeTtsAndFace(InferencePicInPicTaskDto taskDto, PicInPicTaskDto item, Set<String> itemNames, Boolean oldSubtitle) {
        Reuse reuseStatus = Reuse.ALL;
        if (item.getType() == ResourceType.VIDEO && itemNames.contains(buildItemName(item.createPreviewItemKey(), "item"))) {
            return reuseStatus;
        }
        String itemFaceName = buildItemName(taskDto.createItemFaceKey(item), "face");
        if (!itemNames.contains(itemFaceName) || Boolean.TRUE.equals(item.getAudio_only())) {
            reuseStatus = Reuse.TTS;
        }

        String itemTTsName = buildItemName(taskDto.createItemTTSKey(item), "tts");
        if (!itemNames.contains(itemTTsName) || !oldSubtitle && taskDto.getSubtitle()) {
            reuseStatus = reuseStatus == Reuse.TTS ? null : Reuse.FACE;
        }
        return reuseStatus;
    }

    private Mono<List<String>> saveReuseItems(PicInPicTaskDto item, String baseName, boolean isSave) {
        List<String> reusedItems = new ArrayList<>();
        if (item.getReuseStatus() == Reuse.ALL) {
            reusedItems.add(buildItemName(item.getTtsKey(), "tts"));
            reusedItems.add(buildItemName(item.getFaceKey(), "face"));
            if (isSave) {
                reusedItems.add(buildItemName(item.createPreviewItemKey(), "item"));
            }
        } else if (item.getReuseStatus() == Reuse.FACE) {
            reusedItems.add(buildItemName(item.getFaceKey(), "face"));
        } else if (item.getReuseStatus() == Reuse.TTS) {
            reusedItems.add(buildItemName(item.getTtsKey(), "tts"));
            if (isSave && Boolean.TRUE.equals(item.getAudio_only())) {
                reusedItems.add(buildItemName(item.createPreviewItemKey(), "item"));
            }
        }
        return Mono.just(reusedItems);
    }

    private Mono<Void> deleteUnusedInferenceItems(List<String> reusedItems, UUID groupId, UUID accountId) {
        return inferenceRepository.findItemsByNameInAndGroupId(reusedItems.toArray(new String[0]), groupId)
                .collect(HashSet::new, Set::add)
                .flatMap(reusedIdSet -> {
                    return inferenceRepository.findItemIdsByGroupId(groupId)
                            .filter(itemId -> !reusedIdSet.contains(itemId))
                            .flatMap(itemId -> {
                                return inferenceRepository.deleteById(itemId).then(storageService.deleteInference(accountId, itemId));
                            }).then();
                });
    }

    private String buildItemName(String itemKey, String middle) {
        return middle + "_" + itemKey;
    }

    private Mono<Void> inferenceWhole(InferenceMetaDto metaDto, FaceModel faceModel, TTSModel ttsModel, UUID accountId) {
        String ttsTypeName = ttsModel.getModelType().name();
        String faceTypeName = faceModel.getModelType().name();
        if (ttsModel.getModelType().isCustomized() && !customizedTTSServices.containsKey(ttsTypeName)) {
            return Mono.error(new InferenceException(String.format("Customized TTS service not found for model type: %s", ttsTypeName)));
        }
        if (faceModel.getModelType().isCustomized() && !customizedFaceServices.containsKey(faceTypeName)) {
            return Mono.error(new InferenceException(String.format("Customized FACE service not found for model type: %s", faceTypeName)));
        }
        return inferenceRepository.save(new Inference(metaDto.getName(), accountId, faceModel.getId(), ttsModel.getId(), InferenceResult.getResultType(metaDto.getType())))
                .flatMap(inference -> {
                    if (customizedTTSServices.containsKey(ttsModel.getModelType().name()) && customizedFaceServices.containsKey(faceModel.getModelType().name())) {
                        return Mono.zip(
                                metaHumanDatasetRepository.findById(ttsModel.getDatasetId()).map(dataset -> {
                                    if (storageService.isCluster()) {
                                        return MinIOConvertUtils.toDatasetXPath(dataset, storageService.getWorkSpace());
                                    }
                                    return dataset.getDatasetPath();
                                }),
                                metaHumanDatasetRepository.findById(faceModel.getDatasetId()).map(dataset -> {
                                    if (storageService.isCluster()) {
                                        return MinIOConvertUtils.toDatasetXPath(dataset, storageService.getWorkSpace());
                                    }
                                    return dataset.getDatasetPath();
                                })
                        ).flatMap(tuple -> {
                            var wav = tuple.getT1();
                            var video = tuple.getT2();
                            InferenceWholeTask task = ConvertUtils.toInferenceWholeTask(metaDto, inference, faceModel, ttsModel, Map.of("wav_path", wav, "video_path", video), storageService.getWorkSpace(), storageService.isCluster());
                            return inferenceTaskService.pubInferTask(task, task.getId(), genericRoutingKey);
                        });
                    } else if (customizedTTSServices.containsKey(ttsModel.getModelType().name())) {
                        return metaHumanDatasetRepository.findById(ttsModel.getDatasetId()).map(dataset -> {
                            if (storageService.isCluster()) {
                                return MinIOConvertUtils.toDatasetXPath(dataset, storageService.getWorkSpace());
                            }
                            return dataset.getDatasetPath();
                        }).flatMap(wav -> {
                            InferenceWholeTask task = ConvertUtils.toInferenceWholeTask(metaDto, inference, faceModel, ttsModel, Map.of("wav_path", wav), storageService.getWorkSpace(), storageService.isCluster());
                            return inferenceTaskService.pubInferTask(task, task.getId(), genericRoutingKey);
                        });
                    } else if (customizedFaceServices.containsKey(faceModel.getModelType().name())) {
                        return metaHumanDatasetRepository.findById(faceModel.getDatasetId()).map(dataset -> {
                            if (storageService.isCluster()) {
                                return MinIOConvertUtils.toDatasetXPath(dataset, storageService.getWorkSpace());
                            }
                            return dataset.getDatasetPath();
                        }).flatMap(video -> {
                            InferenceWholeTask task = ConvertUtils.toInferenceWholeTask(metaDto, inference, faceModel, ttsModel, Map.of("video_path", video), storageService.getWorkSpace(), storageService.isCluster());
                            return inferenceTaskService.pubInferTask(task, task.getId(), genericRoutingKey);
                        });
                    } else {
                        InferenceWholeTask task = ConvertUtils.toInferenceWholeTask(metaDto, inference, faceModel, ttsModel, Collections.emptyMap(), storageService.getWorkSpace(), storageService.isCluster());
                        return inferenceTaskService.pubInferTask(task, task.getId(), genericRoutingKey);
                    }
                });
    }

    private Mono<Void> inferenceFace(InferenceMetaDto metaDto, FaceModel faceModel, MetaHumanDataset dataset, UUID accountId) {
        return inferenceRepository.save(new Inference(metaDto.getName(), accountId, faceModel.getId(), null, InferenceResult.getResultType(metaDto.getType())))
                .flatMap(
                        inference -> {
                            InferenceFaceTask task = ConvertUtils.toInferenceFaceTask(metaDto, inference, faceModel, dataset, storageService.getWorkSpace(), storageService.isCluster());
                            return inferenceTaskService.pubInferTask(task, task.getId(), genericRoutingKey);
                        }
                );
    }

    private Mono<Void> inferenceTTS(InferenceMetaDto metaDto, TTSModel ttsModel, UUID accountId) {
        return inferenceRepository.save(new Inference(metaDto.getName(), accountId, null, ttsModel.getId(), InferenceResult.getResultType(metaDto.getType())))
                .flatMap(
                        inference -> {
                            InferenceTTSTask task = ConvertUtils.toInferenceTTSTask(metaDto, inference, ttsModel, storageService.getWorkSpace(), storageService.isCluster());
                            return inferenceTaskService.pubInferTask(task, task.getId(), genericRoutingKey);
                        }
                );
    }

    private Mono<Void> deleteGroupInferences(UUID accountId, UUID groupId) {
        return inferenceRepository.findIdsByGroupId(groupId)
            .flatMap(id -> storageService.deleteInference(accountId, id))
            .then(inferenceRepository.deleteByGroupId(groupId))
            .then();
    }

    public Mono<Inference> getInference(UUID taskId, UUID userId, boolean isAdmin) {
        return isAdmin ? inferenceRepository.findById(taskId) : inferenceRepository.findByIdAndAccountId(taskId, userId);
    }

    public Flux<InferenceInfoDto> getInferenceByAccount(UUID account) {
        return inferenceRepository.findByAccountId(account);
    }

    public Flux<InferenceInfoDto> getInferences() {
        return inferenceRepository.findAllInferences();
    }

    public Mono<Void> deleteInferenceById(UUID id, UUID userId, boolean isAdmin) {
        return getInference(id, userId, isAdmin).publishOn(Schedulers.boundedElastic()).flatMap(inference -> {
            storageService.deleteInference(userId, inference.getId()).subscribe();
            return inferenceRepository.deleteById(inference.getId());
        });
    }

    public Flux<TemplateTaskDto> getAllPicInPicTemplates(UUID accountId) {
        return pipTemplateRepository.findPicInPicTemplatesByAccountId(accountId)
            .flatMap(picInPicTemplate -> {
                return inferenceRepository.findByGroupId(picInPicTemplate.getGroupId())
                    .map(infer -> {
                        TemplateTaskDto templateTaskDto = picInPicTemplate.convertDetails();
                        templateTaskDto.setStatus(infer.getStatus());
                        return templateTaskDto;
                    }).switchIfEmpty(Mono.just(picInPicTemplate.convertDetails()));
            });
    }
      
    public Mono<Void> deleteInferenceList(List<UUID> ids, UUID userId, boolean isAdmin) {
        return Flux.fromIterable(ids).flatMap(inferenceId -> 
                deleteInferenceById(inferenceId, userId, isAdmin)).then();
    }

    public Mono<Void> renamePicInPicTemplate(UUID id, String newName) {
        return pipTemplateRepository.findPicInPicTemplatesByName(newName, id)
            .hasElement().flatMap(exists -> {
                if (exists) {
                    return Mono.error(new PicTemplateException("The pic template name already exists."));
                }
                return pipTemplateRepository.updateNameById(id, newName).flatMap(num -> {
                    if (num == 0) {
                        return Mono.error(new PicTemplateException("The pic Template not found ID: " + id));
                    }
                    return Mono.empty();
                });
            });
    }

    public Mono<String> savePicInPicTemplate(InferencePicInPicTaskDto inferencePicInPicTaskDto, UUID accountId) {
        return modelService.getTaskModel(accountId, inferencePicInPicTaskDto.getModels()).flatMap(m -> {
            if (m.getT2().isPresent()) {
                UUID ttsModelId = m.getT2().get().getId();
                UUID faceModelId = m.getT1().isPresent() ? m.getT1().get().getId() : null;
                if (inferencePicInPicTaskDto.getId() == null) {
                    return pipTemplateRepository.findPicInPicTemplatesByNameAndAccountId(inferencePicInPicTaskDto.getName(), accountId).hasElements().flatMap(exists -> {
                        if (exists) {
                            return Mono.error(new PicTemplateException("The currently saved pic template name already exists."));
                        } else {
                            return metaHumanInferGroupRepository.save(new MetaHumanInferGroup(inferencePicInPicTaskDto.getName() + "_grp"))
                                    .flatMap(group -> saveItemsCheckReuse(inferencePicInPicTaskDto, null, group.getId(), accountId, ttsModelId, faceModelId)
                                            .flatMap(inferencePicInPicDto -> pipTemplateRepository.save(new PicInPicTemplate(inferencePicInPicTaskDto.getName(), inferencePicInPicDto, accountId, group.getId())))
                                            .flatMap(picInPicTemplate -> Mono.just(picInPicTemplate.getId().toString()))
                                    );
                        }
                    });
                }
                return pipTemplateRepository.findById(inferencePicInPicTaskDto.getId())
                        .switchIfEmpty(Mono.error(new PicTemplateException("The currently modified template does not exist.")))
                        .flatMap(picInPicTemplate -> {
                            return saveItemsCheckReuse(inferencePicInPicTaskDto, picInPicTemplate.getDetails(), picInPicTemplate.getGroupId(),
                                    accountId, ttsModelId, faceModelId)
                                    .flatMap(inferencePicInPicDto -> pipTemplateRepository.updateDetailsById(inferencePicInPicDto, picInPicTemplate.getId()))
                                    .thenReturn(picInPicTemplate.getId().toString());
                        });
            }
            return Mono.error(new InferenceException(String.format("model is missing! voice model: %s", m.getT2().isEmpty())));
        });
    }

    private Mono<InferencePicInPicDto> saveItemsCheckReuse(InferencePicInPicTaskDto taskDto, InferencePicInPicDto dto, UUID groupId, UUID accountId,UUID ttsModelId, UUID faceModelId) {
        return inferenceRepository.findItemNamesByGroupId(groupId)
                .collect(HashSet<String>::new, Set::add)
                .flatMap(itemNames -> {
                    return Flux.fromIterable(taskDto.getInput()).flatMap(item -> {
                        return inferenceCacheService.checkRedisReuse(taskDto, item, accountId, faceModelId, ttsModelId, groupId, true).flatMap(newItem -> {
                            if (newItem.getReuseStatus() == null && dto != null) {
                                checkChange(taskDto, newItem, itemNames, dto.getSubtitle());
                            }
                            return saveReuseItems(newItem, taskDto.getName(), true);
                        });
                    }).collect(ArrayList<String>::new, ArrayList::addAll)
                            .flatMap(reusedItems -> deleteUnusedInferenceItems(reusedItems, groupId, accountId));
                }).thenReturn(taskDto.convert());
    }

    public Mono<Void> deletePicInPicTemplateById(UUID id) {
        return pipTemplateRepository.findById(id).flatMap(template -> {
            UUID groupId = template.getGroupId();
            if (groupId != null) {
                return deleteGroupInferences(template.getAccountId(), groupId)
                    .then(metaHumanInferGroupRepository.deleteById(groupId))
                    .then(pipTemplateRepository.deleteById(id)).then(inferenceRepository.deletePipItemsByGroupId(groupId));
            }
            return pipTemplateRepository.deleteById(id);
        });
    }

    public Mono<Void> deletePicInPicTemplateList(List<UUID> ids) {
        return Flux.fromIterable(ids).flatMap(id -> deletePicInPicTemplateById(id)).then();
    }

    public Mono<Resource> getInferenceResults(UUID id, UUID accountId, Boolean isAdmin) {
        return getInference(id, accountId, isAdmin).flatMap(
                inference -> {
                    if (!inference.getStatus().equals(InferenceStatus.COMPLETE)) {
                        return Mono.error(new InferenceException("Cannot get inference results before complete!"));
                    }
                    return storageService.loadInferenceResult(accountId, inference);
                }
        );
    }

    public Mono<ItemInferenceStatusDto> getItemResult(String itemKey) {
        return inferenceCacheService.getItemPicInPicResult(itemKey)
                .switchIfEmpty(Mono.error(new InferenceException("Cannot get inference results!")));
    }

    public Mono<Resource> getItemInferenceResults(String itemKey, UUID accountId) {
        return inferenceCacheService.getItemPicInPicResult(itemKey).flatMap(itemStatus -> {
            if (!itemStatus.getInferenceStatus().equals(InferenceStatus.COMPLETE)) {
                return Mono.error(new InferenceException("Cannot get inference results before complete!"));
            }
            return storageService.loadItemInference(accountId, itemStatus.getInferenceId(), itemStatus.getItemFileName());
        });
    }

    public Mono<ItemInferenceStatusDto> getItemInference(String itemKey, UUID accountId, UUID id) {
        return pipTemplateRepository.findById(id).flatMap(template -> 
            inferenceRepository.findByNameAndAccountIdAndGroupId(buildItemName(itemKey, "item"), accountId, template.getGroupId())
                .flatMap(inference -> {
                    return Mono.just(new  ItemInferenceStatusDto(inference.getId(), inference.getStatus()));
                }
            ));
    }

    public Mono<UUID> copyPicInPicTemplate(InferencePicInPicTaskDto dto, UUID accountId) {
        return checkTemplateNameNotExists(dto.getName())
            .then(pipTemplateRepository.findById(dto.getId()))
            .flatMap(template ->
                inferenceRepository.findByGroupId(template.getGroupId())
                    .flatMap(inference -> {
                        if (InferenceStatus.RUN.equals(inference.getStatus())) {
                            return withGroupLock(template.getGroupId(), () ->
                                createGroupAndCopy(dto, template, accountId)
                                    .map(PicInPicTemplate::getId)
                            );
                        } else {
                            return createGroupAndCopy(dto, template, accountId)
                                    .map(PicInPicTemplate::getId);
                        }
                }).switchIfEmpty(
                    createGroupAndCopy(dto, template, accountId).map(PicInPicTemplate::getId)
                )
            );
    }

    private Mono<Void> checkTemplateNameNotExists(String name) {
        return pipTemplateRepository.queryPicInPicTemplateByName(name)
            .hasElement()
            .flatMap(exists -> exists 
                ? Mono.error(new InferenceException("Template name already exists.")) : Mono.empty()
            );
    }

    private <T> Mono<T> withGroupLock(UUID groupId, Supplier<Mono<T>> action) {
        String lockKey = "lock:infer_group:" + groupId;
        String lockValue = UUID.randomUUID().toString();

        return redisCacheService.tryLock(lockKey, lockValue, Duration.ofMinutes(3))
            .flatMap(acquired -> {
                if (!acquired) {
                    return Mono.error(new IllegalStateException("Group is locked, copy failed"));
                }

                return action.get()
                    .doFinally(signal ->
                        redisCacheService.unlock(lockKey, lockValue).subscribe()
                    );
            });
    }

    private Mono<PicInPicTemplate> createGroupAndCopy(InferencePicInPicTaskDto dto, PicInPicTemplate template, UUID accountId) {
        return metaHumanInferGroupRepository
            .save(new MetaHumanInferGroup(dto.getName() + "_grp"))
            .flatMap(newGroup -> {
                UUID newGroupId = newGroup.getId();

                return pipTemplateRepository.save(
                        new PicInPicTemplate(
                            dto.getName(),
                            dto.convert(),
                            accountId,
                            newGroupId
                        )
                    ).flatMap(savedTemplate -> copyInferences(
                        template.getGroupId(),
                        newGroupId,
                        dto,
                        template,
                        accountId
                    ).collectList().thenReturn(savedTemplate));
            });
    }

    private Flux<Void> copyInferences(UUID oldGroupId, UUID newGroupId, InferencePicInPicTaskDto dto, PicInPicTemplate template, UUID accountId) {
        return inferenceRepository.findItemByGroupId(oldGroupId)
            .collectMap(Inference::getName, Function.identity())
            .flatMapMany(existMap ->
                Flux.fromIterable(dto.getInput())
                    .flatMap(input ->
                        buildNamesToReuse(dto, input, existMap.keySet(), template)
                            .flatMap(name ->
                                copySingleInference(existMap.get(name), newGroupId, accountId, dto.getSubtitle())
                            )
                    )
            );
    }

    private Flux<String> buildNamesToReuse(InferencePicInPicTaskDto dto, PicInPicTaskDto input, Set<String> existNames, PicInPicTemplate template) {
        Reuse reuse = CheckChangeTtsAndFace(dto, input, existNames, template.getDetails().getSubtitle());

        if (reuse == null) return Flux.empty();

        List<String> names = new ArrayList<>();
        String itemName = "item_" + input.createPreviewItemKey();
        String ttsName  = "tts_" + dto.createItemTTSKey(input);
        String faceName = "face_" + dto.createItemFaceKey(input);

        switch (reuse) {
            case TTS -> {
                names.add(ttsName);
                if (dto.getModels().get(ModelType.FACE) == null) {
                    names.add(itemName);
                }
            }
            case FACE -> {
                names.add(faceName);
            }
            case ALL -> {
                if (input.getType() == ResourceType.VIDEO) {
                    names.add(itemName);
                } else {
                    names.add(itemName);
                    names.add(ttsName);
                    names.add(faceName);
                }
            }
            default -> {
                names.add(itemName);
                names.add(ttsName);
                names.add(faceName);
            }
        }

        return Flux.fromIterable(names)
            .filter(existNames::contains);
    }

    private Mono<Void> copySingleInference(Inference old, UUID newGroupId, UUID accountId, Boolean newSutitle) {
        return inferenceRepository.save(
            new Inference(
                old.getName(),
                accountId,
                old.getFaceModelId(),
                old.getTtsModelId(),
                old.getType(),
                newGroupId,
                old.getStatus()
            )
        ).flatMap(newInfer -> {
             List<String> fileNames = resolveCopyFileNames(old, newSutitle);

            return Flux.fromIterable(fileNames)
                .flatMap(fileName ->
                    storageService.copyInference(
                        fileName,
                        old.getId(),
                        newInfer.getId(),
                        accountId,
                        fileName
                    )
                )
                .then();
        });
    }

    private List<String> resolveCopyFileNames(Inference old, Boolean newSutitle) {
        String name = old.getName();
        String suffix = getSuffix(name);
        String mainFile = name + suffix;

        if (!name.startsWith("tts_") || !newSutitle) {
            return List.of(mainFile);
        }

        String hashPart = name.substring("tts_".length());
        String srtFile = "srt_" + hashPart + ".json";

        return List.of(mainFile, srtFile);
    }

    private String getSuffix(String name) {
        if (name.contains("tts")) {
            return ".wav";
        }
        return ".mp4";
    }

    public Mono<Resource> getFailInference(UUID inferenceId) {
        return inferenceRepository.findById(inferenceId)
                .flatMap(inference -> storageService.loadFailTaskFile(inference.getAccountId(), inference.getId(), ResourceAccess.PRIVATE));
    }
}
