package com.flex.ditto.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.flex.ditto.common.InferenceResult;
import com.flex.ditto.common.InferenceStatus;
import com.flex.ditto.common.ResourceType;
import com.flex.ditto.common.Reuse;
import com.flex.ditto.domain.Inference;
import com.flex.ditto.domain.InferenceRepository;
import com.flex.ditto.dto.InferencePicInPicTaskDto;
import com.flex.ditto.dto.ItemInferenceResultDto;
import com.flex.ditto.dto.ItemInferenceStatusDto;
import com.flex.ditto.dto.PicInPicTaskDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.ReactiveRedisTemplate;
import org.springframework.data.redis.core.ReactiveValueOperations;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.UUID;

@Slf4j
@Service
public class InferenceCacheService {

    @Value("${app.redis.item.inference.prefix}")
    private String itemInferencePrefix;

    @Value("${app.temp.expiration}")
    private String durationDaysRule;

    @Autowired
    private StorageService storageService;

    @Autowired
    private InferenceRepository inferenceRepository;

    private final ObjectMapper objectMapper;

    private final ReactiveValueOperations<String, String> stringOps;

    public InferenceCacheService(ReactiveRedisTemplate<String, String> reactiveRedisTemplate,
                                 ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
        this.stringOps = reactiveRedisTemplate.opsForValue();
    }

    private String generateItemInferenceKey(String key) {
        return itemInferencePrefix + key;
    }

    public Mono<Boolean> createItemPicInPicResult(String redisKey, UUID inferenceId, PicInPicTaskDto item, String basename) {
        String itemInferenceKey = generateItemInferenceKey(redisKey);
        item.setItemKey(itemInferenceKey);
        item.setItemId(inferenceId);
        String itemJson;
        try {
            itemJson = objectMapper.writeValueAsString(new ItemInferenceStatusDto(inferenceId, InferenceStatus.INIT, null, null, null, null));
        } catch (JsonProcessingException e) {
            return Mono.just(Boolean.FALSE);
        }
        return stringOps.set(itemInferenceKey, itemJson, Duration.ofDays(Long.parseLong(durationDaysRule)));
    }

    public Mono<ItemInferenceResultDto> checkItemPicInPicExist(String redisKey) {
        return stringOps.get(generateItemInferenceKey(redisKey)).flatMap(json -> {
            try {
                ItemInferenceStatusDto itemStatus = objectMapper.readValue(json, ItemInferenceStatusDto.class);
                if (itemStatus.getInferenceStatus() != InferenceStatus.FAIL) {
                    return Mono.just(new ItemInferenceResultDto(redisKey, itemStatus.getInferenceId()));
                }
                return stringOps.delete(generateItemInferenceKey(redisKey)).then(Mono.empty());
            } catch (JsonProcessingException e) {
                return Mono.error(new RuntimeException("Failed to parse ItemInferenceStatusDto!"));
            }
        });
    }

    public Mono<ItemInferenceStatusDto> getItemPicInPicResult(String redisKey) {
        return stringOps.get(generateItemInferenceKey(redisKey)).flatMap(json -> {
            try {
                return Mono.just(objectMapper.readValue(json, ItemInferenceStatusDto.class));
            } catch (JsonProcessingException e) {
                return Mono.error(new  RuntimeException("Failed to parse ItemInferenceStatusDto!"));
            }
        });
    }

    public Mono<PicInPicTaskDto> checkRedisReuse(InferencePicInPicTaskDto inferencePicInPicTaskDto, PicInPicTaskDto item, UUID accountId, UUID faceModelId, UUID ttsModelId, UUID groupId, boolean isSave) {
        String redisKey = inferencePicInPicTaskDto.createRedisItemKey(item, accountId);
        return stringOps.get(generateItemInferenceKey(redisKey)).flatMap(json -> {
            try {
                ItemInferenceStatusDto itemStatus = objectMapper.readValue(json, ItemInferenceStatusDto.class);
                if (!itemStatus.getInferenceStatus().equals(InferenceStatus.COMPLETE) || item.getType() == ResourceType.VIDEO) return Mono.empty();
                item.setReuseStatus(Boolean.TRUE.equals(item.getAudio_only()) ? Reuse.TTS : Reuse.ALL);
                var itemMono = isSave ? inferenceRepository.save(new Inference("item_" + item.createPreviewItemKey(), accountId, null, ttsModelId, InferenceResult.PIP_ITEM, groupId, InferenceStatus.COMPLETE))
                        .flatMap(infer -> storageService.mvItemInference(itemStatus.getItemFileName(), itemStatus.getInferenceId(), infer.getId(), accountId, "item_" + item.createPreviewItemKey() + ".mp4")) :  Mono.empty();
                var ttsMono = inferenceRepository.save(new Inference("tts_" + inferencePicInPicTaskDto.createItemTTSKey(item), accountId, null, ttsModelId, InferenceResult.PIP_ITEM, groupId, null))
                        .flatMap(ttsItem -> {
                            var jsonMono = inferencePicInPicTaskDto.getSubtitle() ? storageService.mvItemInference(itemStatus.getSrtFileName(), itemStatus.getInferenceId(), ttsItem.getId(), accountId, "srt_" + item.getTtsKey() + ".json") : Mono.empty();
                            return jsonMono.then(storageService.mvItemInference(itemStatus.getTtsFileName(), itemStatus.getInferenceId(), ttsItem.getId(), accountId, ttsItem.getName() + ".wav"));
                        });
                var faceMono = Boolean.TRUE.equals(item.getAudio_only()) ? Mono.empty() : inferenceRepository.save(new Inference("face_" + inferencePicInPicTaskDto.createItemFaceKey(item), accountId, faceModelId, null, InferenceResult.PIP_ITEM, groupId, null))
                        .flatMap(faceItem -> storageService.mvItemInference(itemStatus.getFaceFileName(), itemStatus.getInferenceId(), faceItem.getId(), accountId, faceItem.getName() + ".mp4"));
                var deleteMono = stringOps.delete(generateItemInferenceKey(redisKey));
                return Mono.when(itemMono, ttsMono, faceMono, deleteMono);
            } catch (JsonProcessingException e) {
                return Mono.error(new RuntimeException("Failed to parse ItemInferenceStatusDto!"));
            }
        }).thenReturn(item);
    }

}
