package com.flex.ditto.domain;

import com.flex.ditto.common.ResourceAccess;
import com.flex.ditto.common.ResourceType;
import com.flex.ditto.common.Sentence;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.ZonedDateTime;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

@Data
@Table("meta_human_dataset")
@NoArgsConstructor
@AllArgsConstructor
public class MetaHumanDataset {
    @Id
    private UUID id;
    private String name;
    private ResourceAccess type;
    @Column("create_date")
    private ZonedDateTime date;
    @Column("file_name")
    private String fileName;
    private String identifier;
    @Column("file_type")
    private ResourceType fileType;
    private List<Sentence> text = Collections.emptyList();
    private Boolean internal = false;
    @Column("account_id")
    private UUID accountID;
    @Column("group_id")
    private UUID groupID;

    public MetaHumanDataset(String name, ZonedDateTime date, ResourceAccess type, String file_name, String identifier,
                            ResourceType file_type, UUID id) {
        this.name = name;
        this.date = date;
        this.type = type;
        this.fileName = file_name;
        this.identifier = identifier;
        this.fileType = file_type;
        this.accountID = id;
    }

    public MetaHumanDataset(String name, ZonedDateTime date, String file_name, String identifier, ResourceType file_type) {
        this.name = name;
        this.date = date;
        this.type = ResourceAccess.PUBLIC;
        this.fileName = file_name;
        this.identifier = identifier;
        this.fileType = file_type;
    }

    public String getDatasetPath() {
        return this.id.toString() + "/" + this.fileName;
    }
}
