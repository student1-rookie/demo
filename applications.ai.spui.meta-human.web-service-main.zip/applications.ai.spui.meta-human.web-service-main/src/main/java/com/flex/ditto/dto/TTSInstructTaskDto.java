package com.flex.ditto.dto;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.Data;

@Data
public class TTSInstructTaskDto {
    private String emotion;
    private String speed;

    private static final ObjectMapper objectMapper = new ObjectMapper()
        .setSerializationInclusion(JsonInclude.Include.NON_NULL);

    public Map<String, Object> toMap() {
        return objectMapper.convertValue(this, new TypeReference<Map<String, Object>>() {});
    }
}