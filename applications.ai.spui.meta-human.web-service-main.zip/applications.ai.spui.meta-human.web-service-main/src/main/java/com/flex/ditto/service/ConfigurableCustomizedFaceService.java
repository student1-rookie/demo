package com.flex.ditto.service;

import com.flex.ditto.common.*;
import com.flex.ditto.domain.*;
import com.flex.ditto.dto.InferenceMetaDto;
import com.flex.ditto.service.transports.InferenceTransport;
import com.flex.ditto.service.utils.ConvertUtils;
import com.flex.ditto.service.utils.MinIOConvertUtils;
import org.springframework.beans.factory.annotation.Autowired;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

public class ConfigurableCustomizedFaceService implements CustomizedFaceService{

    @Autowired
    private InferenceRepository inferenceRepository;
    @Autowired
    private MetaHumanDatasetRepository metaHumanDatasetRepository;

    private final Map<RunningDevice, InferenceTransport> transports;

    public ConfigurableCustomizedFaceService(List<InferenceTransport> transports) {
        this.transports = transports.stream()
                .flatMap(t -> t.getRunningDevices().stream().map(d -> Map.entry(d, t)))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
    }

    @Override
    public Mono<Void> inference(InferenceMetaDto metaDto, FaceModel model, UUID accountId, WorkSpace workSpace, Boolean isCluster) {
        return transports.get(metaDto.getDevice()).inference(metaDto, null, model, accountId, workSpace, isCluster);
    }

    @Override
    public Mono<Void> createModel(FaceModel faceModel, MetaHumanDataset dataset, WorkSpace workSpace, Boolean isCluster) {
        var task = toCreateTask(faceModel, dataset, workSpace, isCluster);
        return transports.get(RunningDevice.ANY).createModel(task);
    }

    private LatentSyncCreateTask toCreateTask(FaceModel faceModel, MetaHumanDataset dataset, WorkSpace workSpace, Boolean isCluster) {
        final String taskId = ConvertUtils.toModelBucket(faceModel.getId());
        if (isCluster) {
            return ClusterLatentSyncCreateTask.builder()
                    .id(taskId)
                    .dataset(MinIOConvertUtils.toDatasetXPath(dataset, workSpace))
                    .userBucket(MinIOConvertUtils.toUserBucket(faceModel, workSpace))
                    .workSpace(workSpace)
                    .env(workSpace.getEnv())
                    .account_id(faceModel.getAccountId())
                    .name(faceModel.getName())
                    .build();
        }
        return new LatentSyncCreateTask(ConvertUtils.toModelBucket(faceModel.getId()), dataset.getDatasetPath(), faceModel.getName(), faceModel.getAccountId());
    }
}
