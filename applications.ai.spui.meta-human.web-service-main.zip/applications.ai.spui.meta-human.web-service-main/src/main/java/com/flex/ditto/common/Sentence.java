package com.flex.ditto.common;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonSerialize
public record Sentence(String text, double start, double end) {

    public Sentence merge(Sentence other) {
        return new Sentence(this.text + other.text, this.start, other.end);
    }
}
