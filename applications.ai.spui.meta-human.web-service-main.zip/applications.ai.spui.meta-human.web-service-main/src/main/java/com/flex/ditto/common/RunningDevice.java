package com.flex.ditto.common;

public enum RunningDevice {
    ANY, CPU, CUDA, XPU
}
