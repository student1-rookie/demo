package com.flex.ditto.service;

import org.springframework.util.MimeTypeUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.messaging.rsocket.RSocketRequester;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class DenoiseService {

    private static final Logger logger = LoggerFactory.getLogger(DenoiseService.class);

    @Value("${service.denoise.route}")
    private String denoiseRoute;

    @Autowired
    @Qualifier("denoiseRSocketRequester")
    private RSocketRequester rSocketRequester;

    public Mono<byte[]> denoise(String fileName, byte[] fileBytes) {
        logger.debug("Sending denoise request for file: {}", fileName);

        return rSocketRequester.route(denoiseRoute)
                               .metadata(fileName, MimeTypeUtils.parseMimeType("message/x.rsocket.filename"))
                               .data(fileBytes)
                               .retrieveMono(byte[].class)
                               .doOnSuccess(response -> logger.debug("Received denoise response for file: {}", fileName))
                               .doOnError(error -> logger.error("Error during denoise request for file: {}", fileName, error));
    }
}
