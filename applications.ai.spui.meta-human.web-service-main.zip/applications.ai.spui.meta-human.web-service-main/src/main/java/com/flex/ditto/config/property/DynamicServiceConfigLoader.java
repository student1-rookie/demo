package com.flex.ditto.config.property;

import org.springframework.boot.context.properties.bind.BindResult;
import org.springframework.boot.context.properties.bind.Binder;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
public class DynamicServiceConfigLoader {

    private final Binder binder;
    private final Map<String, ServiceProperties> services = new HashMap<>();

    public DynamicServiceConfigLoader(Environment environment) {
        this.binder = Binder.get(environment);
    }

    public ServiceProperties load(String name) {
        return services.computeIfAbsent(name, this::doBind);
    }

    private ServiceProperties doBind(String name) {
        BindResult<ServiceProperties> result = binder.bind(name, ServiceProperties.class);
        if (!result.isBound()) {
            return null;
        }
        return result.orElse(null);
    }
}