package com.flex.ditto.dto;

import java.time.ZonedDateTime;
import java.util.UUID;

import com.flex.ditto.common.ModelStatus;
import lombok.Data;

@Data
public class MetaHumanNotifyDto {
    private UUID id;
    private ModelStatus status;
    private String message;
    private ZonedDateTime date;
    private UUID accountId;
}
