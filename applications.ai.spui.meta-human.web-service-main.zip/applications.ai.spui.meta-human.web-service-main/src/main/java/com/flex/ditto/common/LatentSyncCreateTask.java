package com.flex.ditto.common;

import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class LatentSyncCreateTask {
    String id;
    String dataset;
    String name;
    UUID account_id;
}
