package com.flex.ditto.service;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Range;
import org.springframework.data.redis.connection.Limit;
import org.springframework.data.redis.connection.stream.MapRecord;
import org.springframework.data.redis.connection.stream.ReadOffset;
import org.springframework.data.redis.connection.stream.StreamOffset;
import org.springframework.data.redis.connection.stream.StreamReadOptions;
import org.springframework.data.redis.core.ReactiveRedisTemplate;
import org.springframework.data.redis.core.ReactiveStreamOperations;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Function;

@Slf4j
@Service
public class LogService {

    private final int chunkSize = 10;
    @Autowired
    private ReactiveRedisTemplate<String, Object> reactiveRedisTemplate;
    @Autowired
    private StorageService storageService;
    @Autowired
    private ObjectMapper objectMapper;

    public Mono<Resource> getAllCompletedLogsFromStreamGroup(UUID userId, String streamId) {
        return storageService.loadLog(userId, streamId)
                .flatMap(resource -> {
                    if (resource.exists() && resource.isReadable()) {
                        return Mono.just(resource);
                    } else {
                        return Mono.error(new RuntimeException("No log files for streamId: " + streamId));
                    }
                });
    }

    public Flux<ServerSentEvent<String>> getOngoingLogs(String streamId, String lastEventId) {
        ReactiveStreamOperations<String, String, String> ops = reactiveRedisTemplate.opsForStream();
        AtomicReference<String> lastIdRef = new AtomicReference<>(lastEventId);

        Function<MapRecord<String, String, String>, ServerSentEvent<String>> toSSE = 
            record -> {
                try {
                    lastIdRef.set(record.getId().getValue());
                    return ServerSentEvent.<String>builder()
                            .id(record.getId().getValue())
                            .event("message")
                            .data(objectMapper.writeValueAsString(record.getValue()))
                            .build();
                } catch (Exception e) {
                        return ServerSentEvent.<String>builder()
                                .event("message")
                                .data("Error converting log to JSON")
                                .build();
                }
            };

        Flux<ServerSentEvent<String>> historyFlux = ops.range(streamId, Range.closed("0-0", "+"))
                .map(toSSE);

        Flux<ServerSentEvent<String>> incrementFlux =
            Flux.defer(() ->
                ops.read(
                        StreamReadOptions.empty().block(Duration.ofSeconds(10)).count(chunkSize),
                        StreamOffset.create(streamId, ReadOffset.from(lastIdRef.get()))
                    )
                    .filter(records -> records != null)
                    .map(toSSE)
            )
            .repeat();
        
        return Flux.concat(historyFlux, incrementFlux);
    }
}