package com.flex.ditto.service.transports;

import java.util.List;
import java.util.UUID;

import com.flex.ditto.common.RunningDevice;
import com.flex.ditto.common.WorkSpace;
import com.flex.ditto.domain.FaceModel;
import com.flex.ditto.domain.TTSModel;
import com.flex.ditto.dto.InferenceMetaDto;

import reactor.core.publisher.Mono;

public interface InferenceTransport {

    Mono<Void> inference(InferenceMetaDto meta, TTSModel ttsModel, FaceModel faceModel, UUID accountId, WorkSpace workSpace, Boolean isCluster);

    default Mono<Void> createModel(Object task) {
        return Mono.empty();
    }

    List<RunningDevice> getRunningDevices();
}
