package com.flex.ditto.common.parameter;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.flex.ditto.common.Sentence;
import lombok.Data;
import lombok.extern.log4j.Log4j2;

import java.io.IOException;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonSerialize
@Data
@Log4j2
public class VoicePromptParameter {
    @JsonProperty("cut_duration")
    double duration = 5.;
    @JsonProperty("customized_prompt")
    String text = "";

    public VoicePromptParameter() {}

    public VoicePromptParameter(double duration) {
        this.duration = duration;
    }

    public VoicePromptParameter(double duration, List<Sentence> sentences) {
        this.duration = duration;
        update(sentences);
    }

    public void update(List<Sentence> sentences) {
        var mergedSentence = sentences.stream().filter(sentence -> sentence.start() <= duration).reduce(Sentence::merge);
        if (mergedSentence.isPresent()) {
            duration = mergedSentence.get().end();
            text = mergedSentence.get().text();
        }
    }

    public String toJson() {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            return objectMapper.writeValueAsString(this);
        } catch (IOException e) {
            log.error("error when convert to string: {}", this, e);
            throw new RuntimeException(e);
        }
    }
}
