package com.flex.ditto.config.security;

import com.flex.ditto.common.SecurityEntry;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.session.SessionAuthenticationException;
import org.springframework.security.web.server.WebFilterExchange;
import org.springframework.security.web.server.authentication.logout.RedirectServerLogoutSuccessHandler;
import org.springframework.security.web.server.authentication.logout.ServerLogoutSuccessHandler;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.net.URI;
import java.util.Optional;

@Component
public class MHLogoutSuccessHandler implements ServerLogoutSuccessHandler {

    @Value("${homePage}")
    private String homePage;

    private final MHLogoutAzureSuccessHandler mhLogoutAzureSuccessHandler;

    public MHLogoutSuccessHandler(Optional<MHLogoutAzureSuccessHandler> mhLogoutAzureSuccessHandler) {
        this.mhLogoutAzureSuccessHandler = mhLogoutAzureSuccessHandler.orElse(null);
    }

    @Override
    public Mono<Void> onLogoutSuccess(WebFilterExchange exchange, Authentication authentication) {
        ServerWebExchange ex = exchange.getExchange();
        return ex.getSession()
                .flatMap(session -> {
                    SecurityEntry entry = session.getAttribute("type");
                    if (entry != null) {
                        if (entry.equals(SecurityEntry.AZURE)) {
                            return mhLogoutAzureSuccessHandler.onLogoutSuccess(exchange, authentication);
                        } else if (entry.equals(SecurityEntry.FORM)) {
                            var redirectServerLogoutSuccessHandler = new RedirectServerLogoutSuccessHandler();
                            redirectServerLogoutSuccessHandler.setLogoutSuccessUrl(URI.create(homePage));
                            return redirectServerLogoutSuccessHandler.onLogoutSuccess(exchange, authentication);
                        }
                    }
                    return Mono.error(new SessionAuthenticationException("No session type found"));
                });
    }
}
