package com.flex.ditto.service;

import com.flex.ditto.common.ModelType;
import com.flex.ditto.common.ResourceAccess;
import com.flex.ditto.common.StorageType;
import com.flex.ditto.common.WorkSpace;
import com.flex.ditto.domain.TTSModel;
import com.flex.ditto.domain.FaceModel;
import com.flex.ditto.domain.Inference;
import com.flex.ditto.domain.MetaHumanDataset;
import com.flex.ditto.dto.UploadModelDto;
import com.flex.ditto.exception.StorageException;
import com.flex.ditto.service.utils.ConvertUtils;
import com.flex.ditto.service.utils.TarGzUtils;
import com.flex.ditto.service.utils.WorkSpaceUtils;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DataBufferUtils;
import org.springframework.core.io.buffer.DefaultDataBufferFactory;
import org.springframework.util.FileSystemUtils;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;

public class LocalStorageService implements StorageService {

    final private String rootSpace;

    final private WorkSpace workSpace;

    final private int bufferSize = 8192;

    public LocalStorageService(String rootSpace, WorkSpace workSpace) {
        this.rootSpace = rootSpace;
        this.workSpace = workSpace;
    }

    @Override
    public WorkSpace getWorkSpace() {
        return workSpace;
    }

    @Override
    public StorageType getStorageType() {
        return StorageType.LOCAL;
    }

    @Override
    public Mono<Void> createWorkspace(UUID userId) {
        return Mono.empty();
    }

    @Override
    public Mono<Void> store(UUID userId, UUID datasetId, String fileName, Boolean isPublic, Flux<DataBuffer> dataBuffer) {
        Path workPath = WorkSpaceUtils.createWorkSpace(rootSpace, datasetId.toString());
        Path path = Paths.get(workPath.toString(), fileName);
        return DataBufferUtils.write(dataBuffer, path).onErrorResume(Mono::error);
    }

    @Override
    public Mono<Void> store(UUID userId, UUID datasetId, String fileName, Boolean isPublic, byte[] data) {
        return Mono.fromRunnable(() -> {
            Path workPath = WorkSpaceUtils.createWorkSpace(rootSpace, datasetId.toString());
            Path path = Paths.get(workPath.toString(), fileName);
            try {
                Files.write(path, data);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }).then().subscribeOn(Schedulers.boundedElastic());
    }

    @Override
    public Mono<Void> deleteDataset(UUID userId, UUID datasetId, Boolean isPublic) {
        return Mono.fromRunnable(() -> {
            try {
                Path path = Paths.get(rootSpace, datasetId.toString());
                if (Files.exists(path)) {
                    boolean ret = FileSystemUtils.deleteRecursively(path);
                    if (!ret) {
                        throw new StorageException("Failed to delete resource.");
                    }
                }
            } catch (Exception e) {
                throw new StorageException("Failed to delete resource.");
            }
        });
    }

    @Override
    public Mono<Void> deleteModel(UUID userId, UUID modelId, Boolean isPublic) {
        return Mono.fromRunnable(() -> {
            try {
                Path path = Paths.get(rootSpace, ConvertUtils.toModelBucket(modelId));
                if (Files.exists(path)) {
                    boolean ret = FileSystemUtils.deleteRecursively(path);
                    if (!ret) {
                        throw new StorageException("Failed to delete model files.");
                    }
                }
            } catch (IOException e) {
                throw new StorageException("Failed to delete model files.");
            }
        });
    }

    @Override
    public Mono<Void> deleteInference(UUID userId, UUID inferenceId) {
        try {
            Path path = Paths.get(rootSpace, workSpace.getInference(), inferenceId.toString());
            if (Files.exists(path)) {
                boolean ret = FileSystemUtils.deleteRecursively(path);
                if (!ret) {
                    throw new StorageException("Failed to delete inference result file.");
                }
            }
        } catch (IOException e) {
            throw new StorageException("Failed to delete inference result file.");
        }
        return Mono.empty();
    }

    @Override
    public Mono<Resource> loadDataset(UUID userId, MetaHumanDataset dataset) {
        Path path = Paths.get(rootSpace, dataset.getId().toString(), dataset.getFileName());
        return Mono.just(new FileSystemResource(path.toString()));
    }

    @Override
    public Mono<byte[]> loadDatasetBytes(UUID userId, MetaHumanDataset dataset) {
        Path path = Paths.get(rootSpace, dataset.getDatasetPath());
        return Mono.fromCallable(() -> Files.readAllBytes(path)).subscribeOn(Schedulers.boundedElastic());
    }

    @Override
    public Mono<Resource> loadLog(UUID userId, String logId) {
        return Mono.fromSupplier(() -> {
            Path path = Paths.get(rootSpace, workSpace.getLog(), logId + ".log");
            return new FileSystemResource(path.toString());
        });
    }

    @Override
    public Mono<Resource> loadAvatar(UUID userId, FaceModel faceModel, String fileName) {
        Path path = ConvertUtils.getAvatarPath(rootSpace, faceModel.getId(), fileName);
        if (Files.exists(path)) {
            FileSystemResource resource = new FileSystemResource(path.toString());
            return Mono.just(resource);
        }
        return Mono.empty();
    }

    @Override
    public Mono<Resource> loadAudio(UUID userId, TTSModel ttsModel, String fileName) {
        Path path = ConvertUtils.getAvatarPath(rootSpace, ttsModel.getId(), fileName);
        if (Files.exists(path)) {
            FileSystemResource resource = new FileSystemResource(path.toString());
            return Mono.just(resource);
        }
        return Mono.empty();
    }

    @Override
    public Mono<Resource> loadInferenceResult(UUID userId, Inference inference) {
        Path path = Paths.get(rootSpace, workSpace.getInference(), inference.getInferenceFilePath());
        if (Files.exists(path)) {
            FileSystemResource resource = new FileSystemResource(path.toString());
            return Mono.just(resource);
        }
        return Mono.empty();
    }

    @Override
    public Mono<Void> uploadModel(UploadModelDto modelInfo, Path file, UUID modelId, UUID userId, byte[] previewFile) {
        return Mono.fromCallable(() -> {
            Path modelWorkSpace = WorkSpaceUtils.createWorkSpace(rootSpace, ConvertUtils.toModelBucket(modelId));
            TarGzUtils.extractTarGzToDir(file, modelWorkSpace, bufferSize);
            if (modelInfo.getSubType().isFaceModelType()) {
                Path avatar = Paths.get(modelWorkSpace.toString(), "avatar");
                Files.createDirectories(avatar);
                ByteArrayInputStream jpgFile = new ByteArrayInputStream(previewFile);
                Path avatarPath = avatar.resolve("avatar.jpg");
                Path previewPath = avatar.resolve("preview.jpg");
                Files.copy(jpgFile, avatarPath, StandardCopyOption.REPLACE_EXISTING);
                Files.copy(jpgFile, previewPath, StandardCopyOption.REPLACE_EXISTING);
            }
            return null;
        }).then().subscribeOn(Schedulers.boundedElastic());
    }

    @Override
    public Flux<DataBuffer> downloadModel(UUID accountId, UUID modelId, ResourceAccess type, ModelType baseType, String modelName, UUID userId) {
        Path modelWorkSpace = WorkSpaceUtils.createWorkSpace(rootSpace, ConvertUtils.toModelBucket(modelId));
        if (!Files.exists(modelWorkSpace)) {
            throw new StorageException("error: The file does not exist!");
        }
        String tarGzName = (modelName != null && !modelName.isBlank() ? modelName : modelId.toString()) + ".tar.gz";
        Path tempDir = Paths.get(rootSpace, workSpace.getTemp() == null ? "temp" : workSpace.getTemp());
        try {
            Files.createDirectories(tempDir);
            Path tarGzPath = tempDir.resolve(tarGzName);
            return Mono.fromRunnable(() -> TarGzUtils.createTarGz(tarGzPath, modelWorkSpace))
                    .thenMany(DataBufferUtils.read(new FileSystemResource(tarGzPath), new DefaultDataBufferFactory(), bufferSize))
                    .doFinally(signalType -> {
                        try {
                            Files.deleteIfExists(tarGzPath);
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                    });
        } catch (IOException e) {
            throw new StorageException("Failed to download this model file.");
        }
    }

    @Override
    public Mono<Resource> loadItemInference(UUID accountId, UUID itemId, String fileName) {
        Path path = Paths.get(rootSpace, workSpace.getTemp(), itemId + "/" + fileName);
        if (Files.exists(path)) {
            FileSystemResource resource = new FileSystemResource(path.toString());
            return Mono.just(resource);
        }
        return Mono.empty();
    }

    @Override
    public Mono<Void> mvItemInference(String filename, UUID itemInferenceId, UUID itemId, UUID accountId, String newFilename) {
        return Mono.fromRunnable(() -> {
            try {
                Path sourcePath = Path.of(rootSpace, workSpace.getTemp(), itemInferenceId.toString(), filename);
                Path targetDir = Path.of(rootSpace, workSpace.getInference(), itemId.toString());
                Files.createDirectories(targetDir);
                Path targetPath = targetDir.resolve(newFilename);
                Files.move(sourcePath, targetPath, StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException e) {
                throw new RuntimeException("Failed to move inference file", e);
            }
        }).subscribeOn(Schedulers.boundedElastic()).then();
    }

    @Override
    public Mono<Void> copyInference(String filename, UUID itemInferenceId, UUID itemId, UUID accountId,
            String newFilename) {
        Path sourcePath = Path.of(rootSpace, workSpace.getInference(), itemInferenceId.toString(), filename);
        Path targetPath = Path.of(rootSpace, workSpace.getInference(), itemId.toString(), newFilename);
        return Mono.fromCallable(() -> {
                Files.createDirectories(targetPath.getParent());
                Files.copy(sourcePath, targetPath, StandardCopyOption.REPLACE_EXISTING);
                return true;
            }).subscribeOn(Schedulers.boundedElastic()).then();
    }

    @Override
    public Mono<Resource> loadFailTaskFile(UUID accountId, UUID failId, ResourceAccess type) {
        Path path = Paths.get(rootSpace, workSpace.getFail(), failId.toString(), failId.toString() + ".zip");
        if (Files.exists(path)) {
            FileSystemResource resource = new FileSystemResource(path.toString());
            return Mono.just(resource);
        }
        return Mono.error(new StorageException("error: The file does not exist!"));
    }
}
