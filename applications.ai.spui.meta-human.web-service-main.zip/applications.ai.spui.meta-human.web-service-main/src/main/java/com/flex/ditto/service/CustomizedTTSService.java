package com.flex.ditto.service;

import com.flex.ditto.common.WorkSpace;
import com.flex.ditto.common.parameter.VoicePromptParameter;
import com.flex.ditto.domain.MetaHumanDataset;
import com.flex.ditto.domain.TTSModel;
import com.flex.ditto.dto.InferenceMetaDto;
import reactor.core.publisher.Mono;

import java.util.UUID;

public interface CustomizedTTSService {

    Mono<Void> inference(InferenceMetaDto metaDto, TTSModel model, UUID accountId, WorkSpace workSpace, Boolean isCluster);

    Mono<Void> createModel(TTSModel ttsModel, MetaHumanDataset dataset, VoicePromptParameter parameter, Boolean update, WorkSpace workSpace, Boolean isCluster, String exampleText);

    default Boolean needPrompt(){
        return true;
    }

    default double cutDuration() {
        return 5.;
    }
}
