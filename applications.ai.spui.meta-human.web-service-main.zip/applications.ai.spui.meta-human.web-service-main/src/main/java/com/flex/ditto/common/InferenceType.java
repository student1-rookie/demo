package com.flex.ditto.common;

public enum InferenceType {
    WHOLE, FACE_ONLY, TTS_ONLY, PIC_IN_PIC, ITEM_PIC_IN_PIC, TTS_EXAMPLE
}
