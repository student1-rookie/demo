package com.flex.ditto.service;

import com.flex.ditto.domain.Account;
import com.flex.ditto.domain.AccountRepository;
import com.flex.ditto.dto.NewAccountDto;
import com.flex.ditto.dto.UserDto;
import com.flex.ditto.service.utils.RSAUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class AccountService {

    @Autowired
    AccountRepository accountRepository;

    @Autowired
    PasswordEncoder passwordEncoder;

    @Autowired
    StorageService storageService;

    public Mono<Account> getPerson(String email, String name) {
        // TODO: control roles by ldap
        String roles = "ROLE_USER";
        return accountRepository.findByEmail(email).collectList()
                .flatMap(l -> {
                    if (l.isEmpty()) {
                        return accountRepository.save(new Account(email, name, roles, null)).flatMap(
                                account -> storageService.createWorkspace(account.getId()).thenReturn(account)
                        );
                    }
                    return Mono.just(l.get(0));
                });
    }

    public Mono<Account> createAccount(NewAccountDto newAccount) {
        String roles = "ROLE_USER";
        return accountRepository.countByEmail(newAccount.getEmail())
                .flatMap(n -> {
                    if (n == 0) {
                        newAccount.setPassword(RSAUtils.decryptBase64(newAccount.getPassword()));
                        return accountRepository.save(newAccount.convertoAccount(roles, passwordEncoder));
                    }
                    return Mono.error(new RuntimeException("Email has been registered"));
                });
    }

    public Mono<String> generateKey() {
        return Mono.just(RSAUtils.generateBase64PublicKey());
    }

    public Flux<UserDto> listAccounts() {
        return accountRepository.findAll().map(a -> new UserDto(a.getName(), a.getEmail(), a.getId()));
    }
}
