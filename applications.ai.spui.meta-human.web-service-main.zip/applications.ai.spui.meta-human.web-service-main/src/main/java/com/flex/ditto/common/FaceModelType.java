package com.flex.ditto.common;

public enum FaceModelType {

    ERNERF(false),
    GAUSSIAN(false),
    LATENTSYNC(true);

    private final boolean customized;

    FaceModelType(boolean customized) {
        this.customized = customized;
    }

    public boolean isCustomized() {
        return customized;
    }
}
