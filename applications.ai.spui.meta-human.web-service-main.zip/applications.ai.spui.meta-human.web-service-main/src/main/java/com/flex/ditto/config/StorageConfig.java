package com.flex.ditto.config;

import com.flex.ditto.common.WorkSpace;
import com.flex.ditto.service.LocalStorageService;
import com.flex.ditto.service.MinIOStorageService;
import com.flex.ditto.service.StorageService;
import io.minio.MinioAsyncClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class StorageConfig {

    @Value("${mh.workspace}")
    private String workSpace;

    @Value("${mh.public-bucket}")
    private String publicBucket;

    @Value("${mh.user-bucket-prefix}")
    private String userBucketPrefix;

    @Value("${mh.model-base}")
    private String modelBase;

    @Value("${mh.dataset-base}")
    private String datasetBase;

    @Value("${mh.inference-base}")
    private String inferenceBase;

    @Value("${mh.log-base}")
    private String logBase;

    @Value("${mh.temp-base}")
    private String tempBase;

    @Value("${mh.env}")
    private String env;

    @Value("${mh.fail-base}")
    private String failBase;

    @Bean
    @ConditionalOnProperty(name = "app.storage", havingValue = "local")
    public StorageService localStorageService() {
        return new LocalStorageService(workSpace, new WorkSpace(modelBase, datasetBase, inferenceBase, logBase, tempBase, failBase, env, publicBucket, userBucketPrefix));
    }

    @Bean
    @ConditionalOnProperty(name = "app.storage", havingValue = "minio")
    public StorageService minIOStorageService(MinioAsyncClient minioAsyncClient) {
        return new MinIOStorageService(minioAsyncClient, new WorkSpace(modelBase, datasetBase, inferenceBase, logBase, tempBase, failBase, env, publicBucket, userBucketPrefix));
    }
}
