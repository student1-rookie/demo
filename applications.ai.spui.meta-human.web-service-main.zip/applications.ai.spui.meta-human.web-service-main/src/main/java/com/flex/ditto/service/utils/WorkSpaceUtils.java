package com.flex.ditto.service.utils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class WorkSpaceUtils {

    public static Path createWorkSpace(String main, String sub) {
        Path workSpace = Paths.get(main, sub);
        if (Files.notExists(workSpace)) {
            try {
                Files.createDirectory(workSpace);
            } catch (IOException e) {
                // TODO: handle it at ExceptionHandler
                throw new RuntimeException(e);
            }
        }
        return workSpace;
    }

}
