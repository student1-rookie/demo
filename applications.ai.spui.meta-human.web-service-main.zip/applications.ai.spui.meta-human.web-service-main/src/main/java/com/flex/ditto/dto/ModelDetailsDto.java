package com.flex.ditto.dto;

public record ModelDetailsDto(String main, String phase, Integer curr, Integer total, Integer estimated, String unit) {
}
