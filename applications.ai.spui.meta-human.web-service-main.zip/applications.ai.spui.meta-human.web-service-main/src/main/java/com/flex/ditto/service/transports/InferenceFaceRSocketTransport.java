package com.flex.ditto.service.transports;

import com.flex.ditto.common.InferenceResult;
import com.flex.ditto.common.RunningDevice;
import com.flex.ditto.common.WorkSpace;
import com.flex.ditto.domain.*;
import com.flex.ditto.dto.InferenceMetaDto;
import com.flex.ditto.service.utils.ConvertUtils;
import org.springframework.messaging.rsocket.RSocketRequester;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.UUID;
import java.util.function.BiFunction;

public class InferenceFaceRSocketTransport implements InferenceTransport {
    private final RSocketRequester rSocketRequester;
    private final InferenceRepository inferenceRepository;
    private final MetaHumanDatasetRepository metaHumanDatasetRepository;
    private final List<RunningDevice>  runningDevices;
    private final String createRoute;

    public InferenceFaceRSocketTransport(RSocketRequester rSocketRequester, InferenceRepository inferenceRepository, MetaHumanDatasetRepository metaHumanDatasetRepository, List<RunningDevice> runningDevices, String createRoute) {
        this.rSocketRequester = rSocketRequester;
        this.inferenceRepository = inferenceRepository;
        this.metaHumanDatasetRepository = metaHumanDatasetRepository;
        this.runningDevices = runningDevices;
        this.createRoute = createRoute;
    }


    @Override
    public Mono<Void> inference(InferenceMetaDto meta, TTSModel ttsModel, FaceModel faceModel, UUID accountId, WorkSpace workSpace, Boolean isCluster) {
        return Mono.zip(
                metaHumanDatasetRepository.findById(faceModel.getDatasetId()),
                metaHumanDatasetRepository.findById(meta.getWav())
        ).flatMap(tuple -> sendTask(meta, faceModel, accountId,
                (inference, dto) -> ConvertUtils.toInferenceLatentSyncFaceTask(meta, inference, faceModel, tuple.getT2(), tuple.getT1(), workSpace, isCluster)));
    }

    @Override
    public Mono<Void> createModel(Object task) {
        return rSocketRequester.route(createRoute).data(task).send();
    }

    @Override
    public List<RunningDevice> getRunningDevices() {
        return runningDevices;
    }

    private Mono<Void> sendTask(InferenceMetaDto dto, FaceModel faceModel, UUID accountId, BiFunction<Inference, InferenceMetaDto, Object> taskCreator) {
        UUID faceId = faceModel != null ? faceModel.getId() : null;
        return inferenceRepository.save(new Inference(dto.getName(), accountId, faceId, null, InferenceResult.getResultType(dto.getType())))
                .flatMap(inference -> {
                    Object task = taskCreator.apply(inference, dto);
                    final String route = "fire-and-forget";
                    return rSocketRequester.route(route).data(task).send();
                });
    }
}
