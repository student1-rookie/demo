package com.flex.ditto.dto;

import lombok.Data;

import java.util.Map;

@Data
public class TTSInstructDto {
    private String emotion;
    private String speed;
}
