package com.flex.ditto.domain;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.flex.ditto.common.ModelDetails;
import com.flex.ditto.common.ModelStatus;
import com.flex.ditto.common.ResourceAccess;
import com.flex.ditto.common.TTSModelType;
import io.r2dbc.postgresql.codec.Json;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.ZonedDateTime;
import java.util.Map;
import java.util.UUID;

@Slf4j
@Data
@Table("meta_human_tts")
@NoArgsConstructor
public class TTSModel {
    @Id
    private UUID id;
    private String name;
    private ResourceAccess type;
    @Column("model")
    private TTSModelType modelType;
    private ModelStatus status;
    private String detail;
    private Json parameters;
    @Column("run_service")
    private String runService;
    @Column("create_date")
    private ZonedDateTime date;
    @Column("account_id")
    private UUID accountId;
    @Column("dataset_id")
    private UUID datasetId;

    public TTSModel(String name, ZonedDateTime date, ResourceAccess type, String modelType, String parameters, UUID accountId, UUID datasetId) {
        this.name = name;
        this.date = date;
        this.type = type;
        this.status = ModelStatus.INIT;
        this.modelType = TTSModelType.valueOf(modelType.toUpperCase());
        this.accountId = accountId;
        this.datasetId = datasetId;
        this.parameters = Json.of(parameters);
    }

    public TTSModel(String name, ZonedDateTime date, ResourceAccess type, ModelStatus status, String modelType, String parameters, UUID accountId, UUID datasetId) {
        this.name = name;
        this.date = date;
        this.type = type;
        this.status = status;
        this.modelType = TTSModelType.valueOf(modelType.toUpperCase());
        this.accountId = accountId;
        this.datasetId = datasetId;
        this.parameters = Json.of(parameters);
    }

    public ModelDetails getModelDetail() {
        if (detail == null) {
            return new ModelDetails(null, null, null, null, null);
        }
        try {
            ObjectMapper mapper = new ObjectMapper();
            return mapper.readValue(detail, ModelDetails.class);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    public Map<String, Object> getParameterDetails() {
        if (this.parameters == null) {
            return Map.of("tts_model_type", modelType.name());
        }
        try {
            ObjectMapper mapper = new ObjectMapper();
            Map<String, Object> ret = mapper.readValue(parameters.asString(), new TypeReference<>() {});
            ret.put("tts_model_type", modelType.name());
            return ret;
        } catch (JsonProcessingException e) {
            log.error("error parsing: {}", parameters.asString(), e);
            return Map.of("tts_model_type", modelType.name());
        }
    }

}
