package com.flex.ditto.domain;

import org.springframework.data.r2dbc.repository.Modifying;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;

import com.flex.ditto.common.ResourceAccess;

import reactor.core.publisher.Mono;

import java.util.UUID;

public interface MetaHumanDatasetGroupRepository extends ReactiveCrudRepository<MetaHumanDatasetGroup, UUID> {
    @Modifying
    @Query("UPDATE meta_human_dataset_group SET name = :newName WHERE id = :id")
    Mono<Integer> updateNameById(UUID id, String newName);

    @Modifying
    @Query("UPDATE meta_human_dataset_group SET type = :access WHERE id = :id")
    Mono<Long> updateAccessById(UUID id, ResourceAccess access);

    @Modifying
    @Query("UPDATE meta_human_dataset_group SET account_id = :owner WHERE id = :id")
    Mono<Integer> updateOwnerById(UUID id, UUID owner);
}
