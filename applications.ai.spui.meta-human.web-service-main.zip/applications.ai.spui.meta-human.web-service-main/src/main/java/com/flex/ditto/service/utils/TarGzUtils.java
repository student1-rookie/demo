package com.flex.ditto.service.utils;

import com.flex.ditto.exception.StorageException;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream;
import org.apache.commons.compress.compressors.gzip.GzipCompressorOutputStream;
import org.yaml.snakeyaml.Yaml;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public class TarGzUtils {
    public static void extractTarGzToDir(Path tarGzFile, Path targetDir, int dataBufferSize) {
        try (InputStream is = Files.newInputStream(tarGzFile);
             GzipCompressorInputStream gzipIn = new GzipCompressorInputStream(is);
             TarArchiveInputStream tarIn = new TarArchiveInputStream(gzipIn)) {

            TarArchiveEntry entry;
            while ((entry = tarIn.getNextEntry()) != null) {
                if (entry.isDirectory()) {
                    Path dirPath = targetDir.resolve(entry.getName()).normalize();
                    if (!dirPath.startsWith(targetDir)) {
                        throw new IOException("Invalid entry path: " + entry.getName());
                    }
                    Files.createDirectories(dirPath);
                    continue;
                }
                Path outPath = targetDir.resolve(entry.getName()).normalize();
                if (!outPath.startsWith(targetDir)) {
                    throw new IOException("Invalid entry path: " + entry.getName());
                }
                Files.createDirectories(outPath.getParent());
                String fileName = outPath.getFileName().toString();
                try (var out = Files.newOutputStream(outPath)) {
                    byte[] buffer = new byte[dataBufferSize];
                    int len;
                    while ((len = tarIn.read(buffer)) != -1) {
                        out.write(buffer, 0, len);
                    }
                }
                if (fileName.equals("tts_infer.yml") || fileName.equals("face_infer.yml")) {
                    String oldPrefix = findWorkspaceReplacePrefix(outPath);
                    replaceWorkspacePrefixInYml(outPath, oldPrefix, targetDir.toString());
                }
            }
        } catch (IOException e) {
            throw new StorageException("Failed to extract tar gz file");
        }
    }

    public static void createTarGz(Path tarGzPath, Path modelWorkSpace) {
        try (var fos = Files.newOutputStream(tarGzPath);
             var gos = new GzipCompressorOutputStream(fos);
             var tarOut = new TarArchiveOutputStream(gos)) {
            tarOut.setLongFileMode(TarArchiveOutputStream.LONGFILE_GNU);
            TarGzUtils.addDirToTar(modelWorkSpace, tarOut);
        } catch (IOException e) {
            throw new StorageException("Failed to create tar gz file.");
        }
    }

    private static void addDirToTar(Path rootDir, TarArchiveOutputStream tarOut) throws IOException {
        Deque<Path> stack = new ArrayDeque<>();
        stack.push(rootDir);
        while (!stack.isEmpty()) {
            Path current = stack.pop();
            if (Files.isDirectory(current)) {
                try (var stream = Files.list(current)) {
                    List<Path> children = stream.toList();
                    for (int i = children.size() - 1; i >= 0; i--) {
                        stack.push(children.get(i));
                    }
                }
            } else {
                Path relPath = rootDir.relativize(current);
                String entryName = "./" + relPath.toString().replace(File.separatorChar, '/');
                TarArchiveEntry entry = new TarArchiveEntry(current.toFile(), entryName);
                tarOut.putArchiveEntry(entry);
                Files.copy(current, tarOut);
                tarOut.closeArchiveEntry();
            }
        }
    }

    private static void replaceWorkspacePrefixInYml(Path configFile,
                                             String oldPrefix,
                                             String newPrefix) throws IOException {
        String rawText = Files.readString(configFile, StandardCharsets.UTF_8);
        String updatedText = rawText.replace(oldPrefix, newPrefix);
        Files.writeString(configFile, updatedText, StandardCharsets.UTF_8);
    }

    private static String findWorkspaceReplacePrefix(Path path) throws IOException {
        Yaml yaml = new Yaml();
        Map<String, Object> yamlMap = yaml.loadAs(Files.newInputStream(path), Map.class);
        Map<String, Object> data = (Map<String, Object>) yamlMap.get("data");
        if (data == null || !data.containsKey("workspace_path")) {
            throw new IllegalStateException("YAML must contain data.workspace_path");
        }
        String workspacePath = data.get("workspace_path").toString();
        File f = new File(workspacePath);
        return f.getParent();
    }
}
