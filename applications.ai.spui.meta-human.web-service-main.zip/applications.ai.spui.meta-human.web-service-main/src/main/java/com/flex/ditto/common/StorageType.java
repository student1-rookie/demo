package com.flex.ditto.common;

public enum StorageType {
    LOCAL, MINIO
}
