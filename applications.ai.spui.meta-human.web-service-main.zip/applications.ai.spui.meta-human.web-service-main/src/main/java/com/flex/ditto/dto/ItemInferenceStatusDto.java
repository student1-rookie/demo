package com.flex.ditto.dto;

import com.flex.ditto.common.InferenceStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class ItemInferenceStatusDto {
    private UUID inferenceId;
    private InferenceStatus inferenceStatus;
    private String itemFileName;
    private String ttsFileName;
    private String faceFileName;
    private String srtFileName;

    public ItemInferenceStatusDto(UUID inferenceId, InferenceStatus inferenceStatus) {
        this.inferenceId = inferenceId;
        this.inferenceStatus = inferenceStatus;
    }
}
