package com.flex.ditto.domain;

import com.flex.ditto.common.ModelStatus;
import com.flex.ditto.common.ResourceAccess;
import com.flex.ditto.dto.ModelListDto;

import org.springframework.data.r2dbc.repository.Modifying;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.UUID;

public interface FaceModelRepository extends ReactiveCrudRepository<FaceModel, UUID> {

    @Query("SELECT * FROM meta_human_face WHERE account_id = :accountId OR type = 'PUBLIC'")
    Flux<FaceModel> findByAccountId(UUID accountId);

    @Query("SELECT * FROM meta_human_face WHERE name = :name AND ( account_id = :accountId OR type = 'PUBLIC' ) LIMIT 1")
    Mono<FaceModel> findByAccountIdAndName(UUID accountId, String name);

    @Query("SELECT * FROM meta_human_face WHERE id = :id AND ( account_id = :accountId AND ( status NOT IN ( 'TRAIN', 'WAIT') ) )")
    Mono<FaceModel> findByIdAndStatus(UUID id, UUID accountId);

    @Query("SELECT * FROM meta_human_face WHERE id = :id AND ( status NOT IN ( 'TRAIN', 'WAIT') )")
    Mono<FaceModel> findByIdAndStatus(UUID id);

    @Modifying
    @Query("UPDATE meta_human_face SET name = :name WHERE id = :id AND account_id = :accountId")
    Mono<Integer> updateNameByIdAndAccountId(String name, UUID id, UUID accountId);

    @Modifying
    @Query("UPDATE meta_human_face SET name = :name WHERE id = :id")
    Mono<Integer> updateNameById(String name, UUID id);

    @Query("UPDATE meta_human_face SET type = :access WHERE id = :id AND account_id = :accountId")
    Mono<Void> updateTypeByIdAndAccountId(ResourceAccess access, UUID id, UUID accountId);

    @Query("UPDATE meta_human_face SET type = :access WHERE id = :id")
    Mono<Void> updateTypeById(ResourceAccess access, UUID id);

    @Query("UPDATE meta_human_face SET status = :status WHERE id = :id")
    Mono<Void> updateStatusById(ModelStatus status, UUID id);

    @Modifying
    @Query("UPDATE meta_human_face SET account_id = :accountId WHERE id = :id")
    Mono<Long> updateAccountIdById(UUID accountId, UUID id);

    Mono<FaceModel> findByIdAndAccountId(UUID id, UUID accountId);

    @Query("SELECT meta_human_face.*, account.email AS account_email, account.name AS account_username," +
            "'FACE' AS base_type FROM meta_human_face INNER JOIN account ON meta_human_face.account_id = account.id " +
            "AND ( meta_human_face.account_id = :accountId OR meta_human_face.type = 'PUBLIC' )")
    Flux<ModelListDto> findModelAndUserById(UUID accountId);

    @Query("SELECT meta_human_face.*, account.email AS account_email, account.name AS account_username," +
            "'FACE' AS base_type FROM meta_human_face INNER JOIN account ON meta_human_face.account_id = account.id ")
    Flux<ModelListDto> findAllModels();

    Flux<FaceModel> findByAccountIdAndStatusIn(UUID id, List<ModelStatus> statuses);

    Flux<FaceModel> findByStatusNotIn(List<ModelStatus> statuses);

    @Query("SELECT meta_human_face.id, meta_human_face.model, meta_human_face.status " +
            "FROM meta_human_face WHERE id = :id")
    Mono<GenericModel> findGenericModelById(UUID id);

    @Query("SELECT meta_human_face.id, meta_human_face.model, meta_human_face.status " +
            "FROM meta_human_face WHERE id = :id AND account_id = :accountId")
    Mono<GenericModel> findGenericModelByIdAndAccountId(UUID id, UUID accountId);

    @Query("SELECT * FROM meta_human_face WHERE id = :id AND ( account_id = :accountId OR type = 'PUBLIC')")
    Mono<FaceModel> findByIdAndCheckAccountId(UUID id, UUID accountId);
}
