package com.flex.ditto.dto;

import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import com.flex.ditto.common.InferenceType;
import com.flex.ditto.common.ModelType;
import com.flex.ditto.common.RunningDevice;

import lombok.Data;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Data
public class InferenceMetaDto {
    private String name;
    private Map<ModelType, UUID> models;
    private String text;
    private UUID wav;
    private InferenceType type;
    private Boolean subtitle;
    private Boolean hdtr;
    private Integer seed;
    private SubtitleStyleTaskDto subtitleStyleDto;
    private TTSInstructTaskDto ttsInstructDto;
    private String routingKey;
    private RunningDevice device = RunningDevice.ANY;

    @JsonSetter(nulls = Nulls.SKIP)
    public void setDevice(RunningDevice device) {
        this.device = device;
    }

    public Map<String, Object> getExtraInfo() {
        Map<String, Object> extraInfo = new HashMap<>();
        if (hdtr != null) {
            extraInfo.put("hdtr", hdtr);
        }
        if (subtitle != null) {
            extraInfo.put("subtitle", subtitle);
        }
        if (seed != null) {
            extraInfo.put("seed", seed);
        }
        if (ttsInstructDto != null) {
            Map<String, Object> instructMap = ttsInstructDto.toMap();
            if (!instructMap.isEmpty()) {
                extraInfo.put("instruct", instructMap);
            }
        }
        if (subtitleStyleDto != null) {
            Map<String, Object> subtitleMap = subtitleStyleDto.toMap();
            if (!subtitleMap.isEmpty()) {
                extraInfo.put("subtitle_styles", subtitleMap);
            }
        }
        if (device != null) {
            extraInfo.put("device", device);
        }
        return extraInfo;
    }
}
