package com.flex.ditto.dto;

import com.flex.ditto.common.ResourceType;
import lombok.Data;

import java.util.List;

/*
* @params:
* text: inference text input
* media: insert media file (image/video)
* coordinate: overlay position, relative to the current background
* box: overlay box size
* is_meta_human_background: meta human as bg or media as bg
* type: media type (VIDEO/IMAGE)
*
* @IMAGE RULES:
* {
*   text: required,
*   media: optional (default null),
*   coordinate: optional (default null, form: [x0, y0])
*   box: optional (default null, form: [width, hieght])
*   is_meta_human_background: required,
*   type: optional (default null)
* }
* coordinate and box must have both
* media and type and is_meta_human_background must have both
*
*
* TODO: @VIDEO RULES
* */
@Data
public class PicInPicDto {
    private String text;
    private String media;
    private List<Float> coordinate;
    private List<Integer> box;
    private Boolean is_meta_human_background;
    private ResourceType type;
    private Boolean audio_only;
}
