package com.flex.ditto.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.r2dbc.convert.R2dbcCustomConversions;
import org.springframework.data.r2dbc.dialect.PostgresDialect;

import java.util.ArrayList;
import java.util.List;

@Configuration
public class PostgresConfig {

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Bean
    public R2dbcCustomConversions r2dbcCustomConversions() {
        List<Converter<?, ?>> converters = new ArrayList<>();
        converters.add(new JsonToSentencesConverter(objectMapper));
        converters.add(new SentencesToJsonConverter(objectMapper));
        converters.add(new PipDtoToJsonConverter(objectMapper));
        converters.add(new JsonToPipDtoConverter(objectMapper));
        return R2dbcCustomConversions.of(PostgresDialect.INSTANCE, converters);
    }
}
