package com.flex.ditto.domain;

import java.time.ZonedDateTime;
import java.util.UUID;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import com.flex.ditto.common.ModelStatus;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Table("meta_human_notify")
@NoArgsConstructor
public class MetaHumanNotify {
    @Id
    private UUID id;
    private ModelStatus status;
    private String message;
    @Column("create_date")
    private ZonedDateTime date;
    @Column("account_id")
    private UUID accountId;

    public MetaHumanNotify(UUID accountId, String message, ModelStatus status) {
        this.accountId = accountId;
        this.message = message;
        this.status = status;
    }
}