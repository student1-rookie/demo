package com.flex.ditto.config;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.flex.ditto.common.Sentence;
import io.r2dbc.postgresql.codec.Json;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.WritingConverter;

import java.util.List;

@Slf4j
@WritingConverter
@AllArgsConstructor
public class SentencesToJsonConverter implements Converter<List<Sentence>, Json> {

    final private ObjectMapper objectMapper;

    @Override
    public Json convert(List<Sentence> source) {
        try {
            return Json.of(objectMapper.writeValueAsString(source));
        } catch (JsonProcessingException e) {
            log.error("Error occurred when serialize List<Sentence> to JSON {}", source, e);
        }
        return Json.of("");
    }
}
