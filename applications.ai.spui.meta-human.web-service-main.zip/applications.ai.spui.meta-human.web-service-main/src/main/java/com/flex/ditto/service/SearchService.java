package com.flex.ditto.service;

import com.flex.ditto.common.ServiceType;
import com.rabbitmq.http.client.ReactorNettyClient;
import com.rabbitmq.http.client.domain.BindingInfo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;

@Service
public class SearchService {

    @Value("${app.train.exchange}")
    private String trainExchange;

    @Value("${app.infer.exchange}")
    private String inferenceExchange;

    @Value("${app.infer.routing-key}")
    private String inferenceRoutingKey;

    @Value("${app.mq.generic-routing-key:generic}")
    private String genericRoutingKey;

    @Value("${app.train.routing-key}")
    private String trainRoutingKey;

    final ReactorNettyClient reactorNettyClient;

    public SearchService(ReactorNettyClient reactorNettyClient) {
        this.reactorNettyClient = reactorNettyClient;
    }

    public Flux<String> searchRoutingKey(ServiceType serviceType) {
        return reactorNettyClient.getExchangeBindingsBySource("/", getExchange(serviceType))
                .filter(bindingInfo -> bindingInfo.getRoutingKey().contains(getRoutingKeyPrefix(serviceType))
                        && !getTargetService(serviceType).equals(bindingInfo.getRoutingKey()))
                .map(bindingInfo -> bindingInfo.getRoutingKey().replaceFirst("^" + getRoutingKeyPrefix(serviceType), ""));
    }

    private String getExchange(ServiceType serviceType) {
        return switch (serviceType) {
            case TTS_TRAIN, FACE_TRAIN -> trainExchange;
            case INFERENCE -> inferenceExchange;
        };
    }

    private String getRoutingKeyPrefix(ServiceType serviceType) {
        return switch (serviceType) {
            case TTS_TRAIN, FACE_TRAIN -> trainRoutingKey;
            case INFERENCE -> inferenceRoutingKey;
        };
    }

    private String getTargetService(ServiceType serviceType) {
        return switch (serviceType) {
            case TTS_TRAIN, FACE_TRAIN -> trainRoutingKey + genericRoutingKey;
            case INFERENCE -> inferenceRoutingKey + genericRoutingKey;
        };
    }

}
