package com.flex.ditto.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.flex.ditto.common.RunningDevice;
import com.flex.ditto.common.inference.ClusterInferenceFaceTask;
import com.flex.ditto.common.inference.ClusterInferencePicInPicTask;
import com.flex.ditto.common.inference.ClusterInferenceTTSTask;
import com.flex.ditto.common.inference.ClusterInferenceWholeTask;
import org.apache.commons.lang3.StringUtils;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
public class InferenceTaskService {

    @Value("${app.infer.exchange}")
    private String inferenceExchange;

    @Value("${app.infer.routing-key}")
    private String inferenceRoutingKey;

    @Autowired
    private RabbitTemplate rabbitTemplate;

    @Value("${app.xpu.exchange}")
    private String xpuExchange;

    @Value("${app.xpu.generic.routing-key}")
    private String genericXpuRoutingKey;

    public Mono<Void> pubInferTask(Object task, String id, String type) {
        return Mono.fromCallable(() -> {
            String targetService = type;
            if (task instanceof ClusterInferenceWholeTask) {
                ClusterInferenceWholeTask clusterInferenceWholeTask = (ClusterInferenceWholeTask) task;
                targetService = StringUtils.isEmpty(clusterInferenceWholeTask.getTargetService()) ? targetService
                        : clusterInferenceWholeTask.getTargetService();
                if (clusterInferenceWholeTask.getDevice() == RunningDevice.XPU) {
                    pubToXpu(task, id, xpuExchange, genericXpuRoutingKey);
                    return null;
                }
            }
            if (task instanceof ClusterInferenceTTSTask) {
                ClusterInferenceTTSTask clusterInferenceTTSTask = (ClusterInferenceTTSTask) task;
                targetService = StringUtils.isEmpty(clusterInferenceTTSTask.getTargetService()) ? targetService
                        : clusterInferenceTTSTask.getTargetService();
            }
            if (task instanceof ClusterInferenceFaceTask) {
                ClusterInferenceFaceTask clusterInferenceFaceTask = (ClusterInferenceFaceTask) task;
                targetService = StringUtils.isEmpty(clusterInferenceFaceTask.getTargetService()) ? targetService
                        : clusterInferenceFaceTask.getTargetService();
                if (clusterInferenceFaceTask.getDevice() == RunningDevice.XPU) {
                    pubToXpu(task, id, xpuExchange, genericXpuRoutingKey);
                    return null;
                }
            }
            if (task instanceof ClusterInferencePicInPicTask) {
                ClusterInferencePicInPicTask clusterInferencePicInPicTask = (ClusterInferencePicInPicTask) task;
                if (clusterInferencePicInPicTask.getDevice() == RunningDevice.XPU) {
                    pubToXpu(task, id, xpuExchange, genericXpuRoutingKey);
                    return null;
                }
            }

            String body = new ObjectMapper().writeValueAsString(task);
            var msg = MessageBuilder.withBody(body.getBytes()).setContentType(MessageProperties.CONTENT_TYPE_JSON).setMessageId(id).build();
            rabbitTemplate.convertAndSend(inferenceExchange, inferenceRoutingKey + targetService, msg);
            return null;
        });
    }

    public void pubToXpu(Object task, String id, String exchange, String routingKey) {
        try {
            String body = new ObjectMapper().writeValueAsString(task);
            var msg = MessageBuilder.withBody(body.getBytes()).setContentType(MessageProperties.CONTENT_TYPE_JSON).setMessageId("infer-" + id).build();
            rabbitTemplate.convertAndSend(exchange, routingKey, msg);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
