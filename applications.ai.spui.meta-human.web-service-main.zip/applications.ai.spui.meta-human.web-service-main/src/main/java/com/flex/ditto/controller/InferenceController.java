package com.flex.ditto.controller;

import com.flex.ditto.common.InferenceResult;
import com.flex.ditto.config.security.UserPrincipal;
import com.flex.ditto.domain.Inference;
import com.flex.ditto.dto.*;
import com.flex.ditto.service.InferenceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Comparator;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/mh")
public class InferenceController {

    @Autowired
    public InferenceService inferenceService;

    @PostMapping("/inference")
    public Mono<ResponseEntity<?>> inference(@RequestBody InferenceMetaDto inferenceMetaDto,
                                             @AuthenticationPrincipal UserPrincipal user) {
        UUID userId = user.getSid();
        return inferenceService.inference(inferenceMetaDto, userId)
                .then(Mono.just(ResponseEntity.ok().build()));
    }

    @PostMapping("/inference/pic-in-pic")
    public Mono<ResponseEntity<?>> inference(@RequestBody InferencePicInPicTaskDto inferencePicInPicTaskDto,
                                             @AuthenticationPrincipal UserPrincipal user) {
        UUID userId = user.getSid();
        return inferenceService.picInPicInference(inferencePicInPicTaskDto, userId)
                .then(Mono.just(ResponseEntity.ok().build()));
    }

    @PostMapping("/inference/item-pic-in-pic")
    public Mono<ResponseEntity<?>> itemInference(@RequestBody InferencePicInPicTaskDto inferencePicInPicTaskDto,
                                                 @AuthenticationPrincipal UserPrincipal user) {
        UUID userId = user.getSid();
        return inferenceService.itemPicInPicInference(inferencePicInPicTaskDto, userId)
                .map(itemKey -> ResponseEntity.ok().body(itemKey));
    }

    @GetMapping("/inference-ret/{id}")
    public Mono<Resource> getInferenceResults(@PathVariable UUID id, @AuthenticationPrincipal UserPrincipal user) {
        UUID userId = user.getSid();
        return inferenceService.getInferenceResults(id, userId, user.isAdmin());
    }

    @GetMapping("/inference-ret/type/{id}")
    public Mono<InferenceResult> getInferenceResultType(@PathVariable UUID id, @AuthenticationPrincipal UserPrincipal user) {
        UUID userId = user.getSid();
        return inferenceService.getInference(id, userId, user.isAdmin()).map(Inference::getType);
    }

    @GetMapping("/inferences")
    public Flux<InferenceInfoDto> getInferences(@AuthenticationPrincipal UserPrincipal user) {
        if (user.isAdmin()) {
            return inferenceService.getInferences()
                    .sort(Comparator.comparing(InferenceInfoDto::getDate).reversed());
        }
        UUID userId = user.getSid();
        return inferenceService.getInferenceByAccount(userId)
                .sort(Comparator.comparing(InferenceInfoDto::getDate).reversed());
    }

    @DeleteMapping("/inference/{id}")
    public Mono<ResponseEntity<?>> deleteInference(@PathVariable UUID id, @AuthenticationPrincipal UserPrincipal user) {
        UUID userId = user.getSid();
        return inferenceService.deleteInferenceById(id, userId, user.isAdmin()).then(Mono.just(ResponseEntity.ok().build()));
    }

    @DeleteMapping("/inference")
    public Mono<ResponseEntity<?>> deleteInferenceList(@RequestBody List<UUID> ids, @AuthenticationPrincipal UserPrincipal user) {
        UUID userId = user.getSid();
        return inferenceService.deleteInferenceList(ids, userId, user.isAdmin()).then(Mono.just(ResponseEntity.ok().build()));
    }

    @GetMapping("/pip/list")
    public ResponseEntity<Flux<TemplateTaskDto>> listPicInPicTemplates(@AuthenticationPrincipal UserPrincipal user) {
        return ResponseEntity.ok(inferenceService.getAllPicInPicTemplates(user.getSid()));
    }

    @GetMapping("/inference/fail")
    public Mono<Resource> getFailInference(@RequestParam("inferenceId") UUID inferenceId, @AuthenticationPrincipal  UserPrincipal user) {
        if (user.isAdmin()) {
            return inferenceService.getFailInference(inferenceId);
        }
        return Mono.error(new Exception("Permission denied!"));
    }

    @PostMapping("/pip/save")
    public Mono<ResponseEntity<?>> savePicInPicTemplate(@RequestBody InferencePicInPicTaskDto inferencePicInPicTaskDto,
                                                        @AuthenticationPrincipal UserPrincipal user) {
        return inferenceService.savePicInPicTemplate(inferencePicInPicTaskDto, user.getSid()).map(ResponseEntity::ok);
    }

    @PostMapping("/pip/copy")
    public Mono<ResponseEntity<?>> copyPicInPicTemplate(@RequestBody InferencePicInPicTaskDto inferencePicInPicTaskDto,
                                                        @AuthenticationPrincipal UserPrincipal user) {
        return inferenceService.copyPicInPicTemplate(inferencePicInPicTaskDto, user.getSid()).map(ResponseEntity::ok);
    }

    @DeleteMapping("/pic/{id}")
    public Mono<ResponseEntity<?>> deletePicInPicTemplate(@PathVariable UUID id) {
        return inferenceService.deletePicInPicTemplateById(id).then(Mono.just(ResponseEntity.ok().build()));
    }

    @DeleteMapping("/pip")
    public Mono<ResponseEntity<?>> deletePicInPicTemplateList(@RequestBody List<UUID> ids) {
        return inferenceService.deletePicInPicTemplateList(ids).then(Mono.just(ResponseEntity.ok().build()));
    }

    @PutMapping("/template/rename/{id}")
    public  Mono<ResponseEntity<?>> renamePicTemplate(@PathVariable UUID id, @RequestParam String newName, @AuthenticationPrincipal UserPrincipal user) {
        return inferenceService.renamePicInPicTemplate(id, newName).then(Mono.just(ResponseEntity.noContent().build()));
    }

    @GetMapping("/inference/item")
    public Mono<ItemInferenceStatusDto> getItemInferenceId(@RequestParam("itemKey")String itemKey, @RequestParam("id")UUID id, @AuthenticationPrincipal UserPrincipal user) {
        UUID accountId = user.getSid();
        return inferenceService.getItemInference(itemKey, accountId, id);
    }

    @GetMapping("/inference/item-status/{itemKey}")
    public Mono<ItemInferenceStatusDto> getItemInferenceStatus(@PathVariable String itemKey) {
        return inferenceService.getItemResult(itemKey);
    }

    @GetMapping("/item-inference-ret/{itemKey}")
    public Mono<Resource> getItemInferenceResult(@PathVariable String itemKey, @AuthenticationPrincipal UserPrincipal user) {
        UUID accountId = user.getSid();
        return inferenceService.getItemInferenceResults(itemKey, accountId);
    }
}
