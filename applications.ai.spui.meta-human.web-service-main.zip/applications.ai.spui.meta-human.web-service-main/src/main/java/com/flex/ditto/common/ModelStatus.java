package com.flex.ditto.common;

public enum ModelStatus {
    INIT, TRAIN, COMPLETE, WAIT, FAIL, CANCEL, CREATE_WAV
}
