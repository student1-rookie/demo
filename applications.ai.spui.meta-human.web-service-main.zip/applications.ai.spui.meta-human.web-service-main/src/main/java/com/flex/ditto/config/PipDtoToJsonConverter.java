package com.flex.ditto.config;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.flex.ditto.dto.InferencePicInPicDto;
import io.r2dbc.postgresql.codec.Json;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.WritingConverter;

import java.util.List;

@Slf4j
@WritingConverter
@AllArgsConstructor
public class PipDtoToJsonConverter implements Converter<InferencePicInPicDto, Json> {

    final private ObjectMapper objectMapper;

    @Override
    public Json convert(InferencePicInPicDto source) {
        try {
            ObjectNode node =  objectMapper.valueToTree(source);
            node.remove(List.of("id", "name"));
            return Json.of(objectMapper.writeValueAsString(node));
        } catch (JsonProcessingException e) {
            log.error("Error occurred when serialize InferencePicInPicDto to JSON {}", source, e);
        }
        return Json.of("");
    }
}
