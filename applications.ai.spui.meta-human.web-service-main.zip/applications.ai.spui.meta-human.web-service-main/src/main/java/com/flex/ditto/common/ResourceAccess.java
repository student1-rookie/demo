package com.flex.ditto.common;

public enum ResourceAccess {
    PUBLIC, PRIVATE;
}
