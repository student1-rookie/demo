package com.flex.ditto.config;

import com.flex.ditto.config.security.MHAuthenticationPrincipalArgumentResolver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.config.WebFluxConfigurer;
import org.springframework.web.reactive.result.method.annotation.ArgumentResolverConfigurer;

@Configuration
public class WebFluxConfig implements WebFluxConfigurer {

    @Autowired
    MHAuthenticationPrincipalArgumentResolver mhAuthenticationPrincipalArgumentResolver;

    @Override
    public void configureArgumentResolvers(ArgumentResolverConfigurer configurer) {
        configurer.addCustomResolver(mhAuthenticationPrincipalArgumentResolver);
    }
}
