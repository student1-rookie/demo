package com.flex.ditto.config;

import com.flex.ditto.config.property.CustomizedServicesProperties;
import com.flex.ditto.config.property.DynamicServiceConfigLoader;
import com.flex.ditto.config.property.ServiceProperties;
import com.flex.ditto.service.*;
import com.flex.ditto.service.transports.InferenceTransport;
import com.nimbusds.oauth2.sdk.util.CollectionUtils;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Configuration
public class CustomizedServiceConfig {

    private final DynamicServiceConfigLoader loader;

    public CustomizedServiceConfig(DynamicServiceConfigLoader loader) {
        this.loader = loader;
    }

    @Bean
    public Map<String, CustomizedTTSService> customizedTtsServices(
            CustomizedServicesProperties properties,
            Map<String, List<InferenceTransport>> ttsInferenceTransportsByName
    ) {
        Map<String, CustomizedTTSService> result = new HashMap<>();
        if (properties.getTts() == null) {
            return result;
        }

        for (String name : properties.getTts()) {
            ServiceProperties service = loader.load(name);
            if (service == null || result.containsKey(service.getService())) {
                continue;
            }
            List<InferenceTransport> transports = ttsInferenceTransportsByName.get(service.getService());
            if  (CollectionUtils.isEmpty(transports)) {
                continue;
            }

            Double cutDuration = null;
            Boolean needPrompt = null;
            if (service.getDetails() != null) {
                cutDuration = service.getDetails().getCutDuration();
                needPrompt = service.getDetails().getNeedPrompt();
            }

            CustomizedTTSService customizedTTSService = new ConfigurableCustomizedTTSService(
                    transports,
                    needPrompt,
                    cutDuration
            );
            result.put(service.getService(), customizedTTSService);
        }
        return result;
    }

    @Bean
    public Map<String, CustomizedFaceService> customizedFaceServices(
            CustomizedServicesProperties properties,
            Map<String, List<InferenceTransport>> faceInferenceTransportsByName
    ) {
        Map<String, CustomizedFaceService> result = new HashMap<>();
        if (properties.getFace() == null) {
            return result;
        }

        for (String name : properties.getFace()) {
            ServiceProperties service = loader.load(name);
            if (service == null || result.containsKey(service.getService())) {
                continue;
            }
            List<InferenceTransport> transports = faceInferenceTransportsByName.get(service.getService());
            if (CollectionUtils.isEmpty(transports)) {
                continue;
            }
            CustomizedFaceService customizedFaceService = new ConfigurableCustomizedFaceService(transports);
            result.put(service.getService(), customizedFaceService);
        }
        return result;
    }
}
