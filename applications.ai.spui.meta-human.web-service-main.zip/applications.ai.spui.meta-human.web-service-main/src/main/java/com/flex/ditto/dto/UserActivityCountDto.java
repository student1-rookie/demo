package com.flex.ditto.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserActivityCountDto {
    private String accountName;
    private String accountEmail;
    private Integer ttsTrainCount;
    private Integer faceTrainCount;
    private Integer inferCount;
    private Integer picInPicCount;
}
