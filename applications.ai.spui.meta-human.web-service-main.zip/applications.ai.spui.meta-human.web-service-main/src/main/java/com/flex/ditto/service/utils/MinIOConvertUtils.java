package com.flex.ditto.service.utils;

import com.flex.ditto.common.ResourceAccess;
import com.flex.ditto.common.WorkSpace;
import com.flex.ditto.domain.FaceModel;
import com.flex.ditto.domain.MetaHumanDataset;
import com.flex.ditto.domain.TTSModel;

import java.util.UUID;

public class MinIOConvertUtils {
    public static String toUserBucket(String prefix, UUID userId) {
        return prefix + userId.toString();
    }

    public static String toUserBucket(FaceModel faceModel, WorkSpace workSpace) {
        if (faceModel.getType().equals(ResourceAccess.PUBLIC)) {
            return workSpace.getPublicBucket();
        }
        return toUserBucket(workSpace.getUserBucketPrefix(), faceModel.getAccountId());
    }

    public static String toUserBucket(TTSModel ttsModel, WorkSpace workSpace) {
        if (ttsModel.getType().equals(ResourceAccess.PUBLIC)) {
            return workSpace.getPublicBucket();
        }
        return toUserBucket(workSpace.getUserBucketPrefix(), ttsModel.getAccountId());
    }

    public static String toLogPath(String base, String logId) {
        return base + "/" + logId + ".log";
    }

    public static String toObjectPath(String base, UUID objectId, String fileName) {
        return base + "/" + objectId.toString() + "/" + fileName;
    }

    public static String toDatasetXPath(MetaHumanDataset dataset, WorkSpace workSpace) {
        final String bucket = dataset.getType().equals(ResourceAccess.PUBLIC) ? workSpace.getPublicBucket() : toUserBucket(workSpace.getUserBucketPrefix(), dataset.getAccountID());
        return bucket + "/" + toObjectPath(workSpace.getDataset(), dataset.getId(), dataset.getFileName());
    }

    public static String toModelXPath(FaceModel faceModel, WorkSpace workSpace) {
        // TODO:
        //  - add file name into FaceModel
        //  - update real name at train ms
        final String bucket = faceModel.getType().equals(ResourceAccess.PUBLIC) ? workSpace.getPublicBucket() : toUserBucket(workSpace.getUserBucketPrefix(), faceModel.getAccountId());
        return bucket + "/" + toObjectPath(workSpace.getModel(), faceModel.getId(), faceModel.getName() + "_face.tar.gz");
    }

    public static String toModelXPath(TTSModel ttsModel, WorkSpace workSpace) {
        final String bucket = ttsModel.getType().equals(ResourceAccess.PUBLIC) ? workSpace.getPublicBucket() : toUserBucket(workSpace.getUserBucketPrefix(), ttsModel.getAccountId());
        return bucket + "/" + toObjectPath(workSpace.getModel(), ttsModel.getId(), ttsModel.getName() + "_tts.tar.gz");
    }
}
