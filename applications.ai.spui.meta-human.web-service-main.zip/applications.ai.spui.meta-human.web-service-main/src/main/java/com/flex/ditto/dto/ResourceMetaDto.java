package com.flex.ditto.dto;

import com.flex.ditto.common.ResourceType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.ZonedDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResourceMetaDto {
    // dataset name
    private String datasetName;
    private ZonedDateTime date;
    // ture: public; false: private.
    private Boolean type;
    // VIDEO/AUDIO
    private ResourceType fileType;
    // file md5 value
    private String identifier;
}
