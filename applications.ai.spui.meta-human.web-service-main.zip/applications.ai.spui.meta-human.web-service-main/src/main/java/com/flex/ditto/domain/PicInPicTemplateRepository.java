package com.flex.ditto.domain;

import com.flex.ditto.dto.InferencePicInPicDto;

import org.springframework.data.r2dbc.repository.Modifying;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.UUID;

public interface PicInPicTemplateRepository extends ReactiveCrudRepository<PicInPicTemplate, UUID> {

    Flux<PicInPicTemplate> findPicInPicTemplatesByAccountId(UUID accountId);

    Flux<PicInPicTemplate> findPicInPicTemplatesByNameAndAccountId(String name, UUID accountId);

    @Query("SELECT * FROM meta_human_pic_template WHERE name = :name and id != :id")
    Mono<PicInPicTemplate> findPicInPicTemplatesByName(String name, UUID id);

    @Query("UPDATE meta_human_pic_template SET details = :details WHERE id = :id")
    Mono<Void> updateDetailsById(InferencePicInPicDto details, UUID id);

    @Query("UPDATE meta_human_pic_template SET group_id = :groupId WHERE id = :id")
    Mono<Void> updateGroupIdById(UUID groupId, UUID id);

    @Modifying
    @Query("UPDATE meta_human_pic_template SET name = :newName WHERE id = :id")
    Mono<Integer> updateNameById(UUID id, String newName);

    Mono<PicInPicTemplate> queryPicInPicTemplateByName(String name);
}
