package com.flex.ditto.common.inference;

import java.util.UUID;

import com.flex.ditto.common.InferenceType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class InferenceLatentSyncFaceTask {
    String id;
    String name;
    String audio_path;
    String video_path;
    String face_model;
    InferenceType type;
    String extra;
    UUID account_id;
}