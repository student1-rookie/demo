package com.flex.ditto.common;

public enum SecurityEntry {
    AZURE, FORM
}
