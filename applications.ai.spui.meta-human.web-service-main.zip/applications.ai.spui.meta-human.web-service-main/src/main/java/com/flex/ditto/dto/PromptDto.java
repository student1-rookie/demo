package com.flex.ditto.dto;

import lombok.Data;

@Data
public class PromptDto {
    private String dataset;
    private Float cutDuration;
}
