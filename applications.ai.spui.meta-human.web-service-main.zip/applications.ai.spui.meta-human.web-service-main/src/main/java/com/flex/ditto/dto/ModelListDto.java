package com.flex.ditto.dto;

import com.flex.ditto.common.MetaHumanModelType;
import com.flex.ditto.common.ModelStatus;
import com.flex.ditto.common.ModelType;
import com.flex.ditto.common.ResourceAccess;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.ZonedDateTime;
import java.util.UUID;

@Data
@NoArgsConstructor
public class ModelListDto {
    private UUID id;
    private String name;
    private ResourceAccess type;
    private MetaHumanModelType model;
    private ModelStatus status;
    private String detail;
    private ZonedDateTime date;
    private UUID accountId;
    private UUID datasetId;

    private String account_email;
    private String account_username;

    private ModelType base_type;
}

