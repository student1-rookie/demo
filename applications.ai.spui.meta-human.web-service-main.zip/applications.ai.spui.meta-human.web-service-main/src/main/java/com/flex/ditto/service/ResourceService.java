package com.flex.ditto.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.flex.ditto.common.ModelType;
import com.flex.ditto.common.ResourceAccess;
import com.flex.ditto.common.ResourceType;
import com.flex.ditto.common.StorageType;
import com.flex.ditto.domain.*;
import com.flex.ditto.dto.ModelTableDto;
import com.flex.ditto.dto.ResourceDto;
import com.flex.ditto.dto.ResourceMetaDto;
import com.flex.ditto.dto.ResourcesTableDto;
import com.flex.ditto.exception.ParserException;
import com.flex.ditto.exception.ResourcesException;
import com.flex.ditto.exception.StorageException;
import com.flex.ditto.service.utils.ConvertUtils;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DataBufferUtils;
import org.springframework.http.codec.multipart.FilePartEvent;
import org.springframework.http.codec.multipart.FormPartEvent;
import org.springframework.http.codec.multipart.PartEvent;
import org.springframework.stereotype.Service;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

@Service
public class ResourceService {

    @Autowired
    MetaHumanDatasetRepository datasetRepository;
    @Autowired
    FaceModelRepository faceModelRepository;
    @Autowired
    TTSModelRepository ttsModelRepository;
    @Autowired
    AccountRepository accountRepository;
    @Autowired
    PresentationParserService presentationParserService;
    @Autowired
    StorageService storageService;
    @Autowired
    MetaHumanDatasetGroupRepository metaHumanDatasetGroupRepository;

    @PostConstruct
    public void init() {
        storageService.createPublicBucket().subscribe();
    }

    public boolean cluster() {
        return storageService.getStorageType().equals(StorageType.MINIO);
    }

    public Mono<Resource> getResourceFile(UUID datasetId, UUID account, Boolean admin) {
        var datasetMono = admin ? datasetRepository.findById(datasetId) : datasetRepository.findByAccountAndId(account, datasetId);
        return datasetMono.flatMap(dataset -> getResourceFile(dataset, admin ? dataset.getAccountID() : account));
    }

    public Mono<Resource> getResourceFile(MetaHumanDataset dataset, UUID account) {
        return storageService.loadDataset(account, dataset);
    }

    public Mono<Void> deleteResource(UUID id, UUID userId, Boolean isAdmin) {
        var datasetMono = isAdmin ? datasetRepository.findById(id) : datasetRepository.findByAccountAndId(userId, id);
        return datasetMono.publishOn(Schedulers.boundedElastic()).flatMap(
                dataset -> {
                    UUID userPathId = isAdmin ? dataset.getAccountID() : userId;
                    storageService.deleteDataset(userPathId, id, dataset.getType().equals(ResourceAccess.PUBLIC)).subscribe();
                    return datasetRepository.deleteById(id);
                }
        );
    }

    public Mono<Void> deleteResourceGroup(UUID groupId, UUID userId, Boolean isAdmin) {
        var deleteGroupMono = metaHumanDatasetGroupRepository.deleteById(groupId);
        var datasetFlux = datasetRepository.findByGroupId(groupId);
        return datasetFlux.flatMap(dataset -> deleteResource(dataset.getId(), userId, isAdmin))
                .then(deleteGroupMono);
    }

    public Mono<Void> deleteResourceList(ResourcesTableDto dto, UUID userId, Boolean isAdmin) {
        Flux<Void> resourceDeletes = Flux.fromIterable(dto.getResourceIds())
            .flatMap(id -> deleteResource(id, userId, isAdmin));
        Flux<Void> groupDeletes = Flux.fromIterable(dto.getResourceGroupIds())
            .flatMap(id -> deleteResourceGroup(id, userId, isAdmin));

        return Flux.merge(resourceDeletes, groupDeletes).then();
    }

    public Mono<Void> deleteModel(UUID modelId, ModelType type, UUID userId, Boolean isAdmin) {
        if (type == ModelType.FACE) {
            var faceModelMono = isAdmin ? faceModelRepository.findByIdAndStatus(modelId) : faceModelRepository.findByIdAndStatus(modelId, userId);
            return faceModelMono.publishOn(Schedulers.boundedElastic())
                    .switchIfEmpty(Mono.error(new StorageException("Deletion failed: Model is in use.")))
                    .flatMap(m -> {
                        storageService.deleteModel(userId, modelId, m.getType().equals(ResourceAccess.PUBLIC)).subscribe();
                        return faceModelRepository.deleteById(modelId);
                    });
        } else if (type == ModelType.TTS) {
            var ttsModelMono = isAdmin ? ttsModelRepository.findByIdAndStatus(modelId) : ttsModelRepository.findByIdAndStatus(modelId, userId);
            return ttsModelMono.publishOn(Schedulers.boundedElastic())
                    .switchIfEmpty(Mono.error(new StorageException("Deletion failed: Model is in use.")))
                    .flatMap(m -> {
                        storageService.deleteModel(userId, modelId, m.getType().equals(ResourceAccess.PUBLIC)).subscribe();
                        return ttsModelRepository.deleteById(modelId);
                    });
        }
        return Mono.error(new StorageException("Invalid MetaHuman model type"));
    }

    public Mono<Void> deleteModelList(ModelTableDto modelTableDto, UUID userId, Boolean isAdmin) {
        Flux<Void> ttsModelFlux = Flux.fromIterable(modelTableDto.getTtsModelIds())
            .flatMap(ttsModelId -> deleteModel(ttsModelId, ModelType.TTS, userId, isAdmin));
        Flux<Void> faceModelFlux = Flux.fromIterable(modelTableDto.getFaceModelIds())
            .flatMap(faceModelId -> deleteModel(faceModelId, ModelType.FACE, userId, isAdmin));

        return Flux.merge(ttsModelFlux, faceModelFlux).then();
    }

    public Flux<ResourceDto> listResources(UUID accountID, Boolean isAdmin) {
        var datasets = isAdmin ? datasetRepository.findAll() : datasetRepository.findByAccountId(accountID);
        return datasets.flatMap(dataset -> getResourceDto(dataset));
    }

    public Flux<ResourceDto> listResourcesGroup(UUID accountID, Boolean isAdmin) {
        var datasets = isAdmin ? datasetRepository.findDatasetGroupAll() : datasetRepository.findDatasetGroupByAccountId(accountID);
        return datasets.flatMap(dataset -> getResourceDto(dataset));
    }

    public Flux<ResourceDto> listResourcesByGroupId(UUID groupId) {
        var datasets = datasetRepository.findByGroupId(groupId);
        return datasets.flatMap(dataset -> getResourceDto(dataset));
    }

    private Mono<ResourceDto> getResourceDto(MetaHumanDataset dataset) {
        if (dataset.getType() == ResourceAccess.PUBLIC) {
            return Mono.just(new ResourceDto(dataset.getId(), dataset.getName(), dataset.getDate(), dataset.getType(),
                    dataset.getFileType(), "", dataset.getIdentifier()));
        }
        return accountRepository.findById(dataset.getAccountID())
                .map(account -> new ResourceDto(dataset.getId(), dataset.getName(), dataset.getDate(), dataset.getType(),
                        dataset.getFileType(), account.getName(), dataset.getIdentifier()));
    }

    public Mono<MetaHumanDataset> saveResource(Flux<PartEvent> allParts, UUID account) {
        AtomicReference<ResourceMetaDto> resourceMetaDto = new AtomicReference<>();
        AtomicBoolean exist = new AtomicBoolean(false);
        AtomicReference<String> identifier = new AtomicReference<>();
        var metaHumanDatasetFlux = allParts.windowUntil(PartEvent::isLast)
                .concatMap(p -> p.switchOnFirst((signal, partEvents) -> {
                    if (signal.hasValue()) {
                        PartEvent event = signal.get();
                        if (event instanceof FormPartEvent formEvent) {
                            try {
                                resourceMetaDto.set(new ObjectMapper().registerModule(new JavaTimeModule()).readValue(formEvent.value(), ResourceMetaDto.class));
                                identifier.set(ConvertUtils.generateCombineIdentifier(account, resourceMetaDto.get().getIdentifier()));
                            } catch (JsonProcessingException e) {
                                throw new RuntimeException(e);
                            }
                            return datasetRepository.findByIdentifier(identifier.get()).map(
                                    d -> {
                                        exist.set(true);
                                        if (exist.get()) {
                                            throw new ResourcesException("The uploaded file already exists");
                                        }
                                        return d;
                                    }
                            );
                        } else if (event instanceof FilePartEvent fileEvent) {
                            if (!exist.get()) {
                                Flux<DataBuffer> contents = partEvents.map(PartEvent::content);
                                String filename = fileEvent.filename();
                                if (resourceMetaDto.get().getFileType().equals(ResourceType.PRESENTATION)) {
                                    // parser presentation file
                                    return DataBufferUtils.join(contents).map(dataBuffer -> {
                                        byte[] bytes = new byte[dataBuffer.readableByteCount()];
                                        dataBuffer.read(bytes);
                                        DataBufferUtils.release(dataBuffer);
                                        return bytes;
                                    }).flatMap(bytes ->
                                            presentationParserService.parsePresentation(account, resourceMetaDto.get().getType() ? ResourceAccess.PUBLIC : ResourceAccess.PRIVATE, filename, bytes, storageService.getWorkSpace(), storageService.isCluster()).flatMap(ret -> {
                                                if (ret.code() == 0) {
                                                    MetaHumanDataset metaHumanDataset = ConvertUtils.toDataset(
                                                        resourceMetaDto.get(),
                                                        filename,
                                                        account,
                                                        identifier.get(),
                                                        UUID.fromString(ret.groupId()),
                                                        true
                                                    );
                                                    return datasetRepository.save(metaHumanDataset); 
                                                } else {
                                                    return Mono.error(new ParserException(ret.msg()));
                                                }
                                            })
                                    );
                                }
                                return datasetRepository.save(ConvertUtils.toDataset(resourceMetaDto.get(), filename, account, identifier.get(), null, false))
                                        .flatMap(dataset -> storageService.store(account, dataset.getId(), dataset.getFileName(), dataset.getType().equals(ResourceAccess.PUBLIC), contents).thenReturn(dataset));
                            }
                            return Flux.empty();
                        } else return Mono.error(new StorageException("Unexpected event: " + event));
                    }
                    return Flux.empty();
                }));
        return metaHumanDatasetFlux.next().switchIfEmpty(metaHumanDatasetFlux.skip(1).next());
    }

    public Mono<Void> renameResource(String id, String newName, UUID userId) {
        return datasetRepository.updateNameByAccountAndId(userId, UUID.fromString(id), newName)
                .flatMap(updatedRows -> {
                    if (updatedRows > 0) {
                        return Mono.empty();
                    } else {
                        return Mono.error(new StorageException("Resource not found ID: " + id));
                    }
                });

    }

    public Mono<Void> renameResource(String id, String newName) {
        return datasetRepository.updateNameById(UUID.fromString(id), newName)
                .flatMap(updatedRows -> {
                    if (updatedRows > 0) {
                        return Mono.empty();
                    } else {
                        return Mono.error(new StorageException("Resource not found ID: " + id));
                    }
                });
    }

    public Mono<Void> changeAccessList(ResourcesTableDto resourcesTableDto, UUID userId, Boolean isAdmin) {
        Flux<Void> resourceAccess = Flux.fromIterable(resourcesTableDto.getResourceIds())
            .flatMap(id -> changeAccess(id, resourcesTableDto.getAccess(), userId, isAdmin).then());
        Flux<Void> resourceGroupAccess = Flux.fromIterable(resourcesTableDto.getResourceGroupIds())
            .flatMap(groupId -> changeGroupAccess(groupId, resourcesTableDto.getAccess(), userId, isAdmin));
        
        return Flux.merge(resourceAccess, resourceGroupAccess).then();
    }

    public Mono<Void> renameGroupResource(UUID id, String newName) {
        return metaHumanDatasetGroupRepository.updateNameById(id, newName)
                .flatMap(updatedRows -> {
                    if (updatedRows > 0) {
                        return Mono.empty();
                    } else {
                        return Mono.error(new StorageException("Group Resource not found ID: " + id));
                    }
                });
    }

    public Mono<Long> changeAccess(UUID id, ResourceAccess access, UUID userId, Boolean isAdmin) {
        var datasetMono = isAdmin ? datasetRepository.findById(id) : datasetRepository.findByIdAndAccountID(id, userId);
        return datasetMono.switchIfEmpty(Mono.error(new StorageException("Resource not found ID: " + id)))
                .flatMap(dataset -> {
                            if (!dataset.getType().equals(access)) {
                                if (access == ResourceAccess.PUBLIC) {
                                    return storageService.mvDatasetPublic(dataset).then(datasetRepository.updateTypeById(access, id));
                                }
                                return storageService.mvDataset(userId, dataset).then(datasetRepository.updateTypeById(access, id));
                            }
                            return Mono.empty();
                        }
                );
    }

    public Mono<Void> changeGroupAccess(UUID groupId, ResourceAccess access, UUID userId, Boolean isAdmin) {
        var updateAccess = metaHumanDatasetGroupRepository.updateAccessById(groupId, access);
        return updateAccess.filter(res -> res > 0)
                .switchIfEmpty(Mono.error(new StorageException("Resource Group not found ID: " + groupId)))
                .flatMap(res -> datasetRepository.findByGroupId(groupId)
                    .flatMap(dataset -> changeAccess(dataset.getId(), access, userId, isAdmin)).then());
    }

    public Mono<Integer> changeOwner(UUID id, UUID owner) {
        return datasetRepository.findById(id)
                .switchIfEmpty(Mono.error(new StorageException("Resource not found ID: " + id)))
                .flatMap(metaHumanDataset ->
                        storageService.mvDataset(owner, metaHumanDataset).then(datasetRepository.updateAccountIdById(owner, id)));
    }

    public Mono<Void> changeGroupOwner(UUID groupId, UUID owner) {
        var updateOwner = metaHumanDatasetGroupRepository.updateOwnerById(groupId, owner);
        return updateOwner.filter(res -> res > 0)
                .switchIfEmpty(Mono.error(new StorageException("Resource Group not found ID: " + groupId)))
                .flatMap(res -> datasetRepository.findByGroupId(groupId)
                    .flatMap(dataset -> changeOwner(dataset.getId(), owner)).then());
    }

    public Mono<Void> changeOwnerList(ResourcesTableDto resourcesTableDto) {
        Flux<Void> resourceOwner = Flux.fromIterable(resourcesTableDto.getResourceIds())
            .flatMap(id -> changeOwner(id, resourcesTableDto.getOwner()).then());
        Flux<Void> resourceGroupOwner   = Flux.fromIterable(resourcesTableDto.getResourceGroupIds())
            .flatMap(id -> changeGroupOwner(id, resourcesTableDto.getOwner()).then());
            
        return Flux.merge(resourceOwner, resourceGroupOwner).then();
    }

    public Mono<Resource> findAvatar(UUID modelId, Boolean preview, UUID userId, Boolean isAdmin) {
        String fileName = preview ? "preview.jpg" : "avatar.jpg";
        return faceModelRepository.findById(modelId)
                .flatMap(faceModel -> {
                    var id = isAdmin ? faceModel.getAccountId() : userId;
                    return storageService.loadAvatar(id, faceModel, "avatar/" + fileName);
                });
    }

    public Mono<Resource> findAudio(UUID modelId, UUID userId, Boolean isAdmin) {
        return ttsModelRepository.findById(modelId)
                .flatMap(ttsModel -> {
                    var id = isAdmin ? ttsModel.getAccountId() : userId;
                    return storageService.loadAudio(id, ttsModel, "example/example.wav");
                });
    }
}
