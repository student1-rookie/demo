package com.flex.ditto.service;

import com.flex.ditto.common.ClusterCosyVoiceCreateTask;
import com.flex.ditto.common.CosyVoiceCreateTask;
import com.flex.ditto.common.RunningDevice;
import com.flex.ditto.common.WorkSpace;
import com.flex.ditto.common.parameter.VoicePromptParameter;
import com.flex.ditto.domain.MetaHumanDataset;
import com.flex.ditto.domain.TTSModel;
import com.flex.ditto.dto.InferenceMetaDto;
import com.flex.ditto.service.transports.InferenceTransport;
import com.flex.ditto.service.utils.ConvertUtils;
import com.flex.ditto.service.utils.MinIOConvertUtils;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

public class ConfigurableCustomizedTTSService implements CustomizedTTSService {

    private final Map<RunningDevice, InferenceTransport> transports;
    private final Boolean needPromptOverride;
    private final Double cutDurationOverride;

    public ConfigurableCustomizedTTSService(List<InferenceTransport> transports,
                                            Boolean needPromptOverride,
                                            Double cutDurationOverride) {
        this.transports = transports.stream()
                .flatMap(t -> t.getRunningDevices().stream().map(d -> Map.entry(d, t)))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

        this.needPromptOverride = needPromptOverride;
        this.cutDurationOverride = cutDurationOverride;
    }

    @Override
    public Mono<Void> inference(InferenceMetaDto cosyVoiceMetaDto, TTSModel ttsModel, UUID accountId, WorkSpace workSpace, Boolean isCluster) {
        return transports.get(cosyVoiceMetaDto.getDevice()).inference(cosyVoiceMetaDto, ttsModel, null, accountId, workSpace, isCluster);
    }

    @Override
    public Mono<Void> createModel(TTSModel ttsModel, MetaHumanDataset dataset, VoicePromptParameter parameter, Boolean update, WorkSpace workSpace, Boolean isCluster, String exampleText) {
        var task = toCreateTask(ttsModel, dataset, parameter, update, workSpace, isCluster, exampleText);
        return transports.get(RunningDevice.ANY).createModel(task);
    }

    private CosyVoiceCreateTask toCreateTask(TTSModel ttsModel, MetaHumanDataset dataset, VoicePromptParameter parameter, Boolean update, WorkSpace workSpace, Boolean isCluster, String exampleText) {
        final String taskId = ConvertUtils.toModelBucket(ttsModel.getId());
        if (isCluster) {
            return ClusterCosyVoiceCreateTask.builder().id(taskId)
                    .name(ttsModel.getName())
                    .access(ttsModel.getType().name())
                    .dataset(MinIOConvertUtils.toDatasetXPath(dataset, workSpace))
                    .parameter(parameter)
                    .account_id(ttsModel.getAccountId())
                    .update(update)
                    .exampleText(exampleText)
                    .userBucket(MinIOConvertUtils.toUserBucket(ttsModel, workSpace))
                    .workSpace(workSpace)
                    .env(workSpace.getEnv())
                    .build();
        }
        return new CosyVoiceCreateTask(
                taskId,
                ttsModel.getName(),
                ttsModel.getType().name(),
                dataset.getDatasetPath(),
                parameter,
                ttsModel.getAccountId(),
                update,
                exampleText
        );
    }

    @Override
    public Boolean needPrompt() {
        return Objects.requireNonNullElseGet(needPromptOverride, CustomizedTTSService.super::needPrompt);
    }

    @Override
    public double cutDuration() {
        return Objects.requireNonNullElseGet(cutDurationOverride, CustomizedTTSService.super::cutDuration);
    }
}
