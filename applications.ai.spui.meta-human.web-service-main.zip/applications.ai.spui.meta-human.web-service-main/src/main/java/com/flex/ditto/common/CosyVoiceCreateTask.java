package com.flex.ditto.common;

import com.flex.ditto.common.parameter.VoicePromptParameter;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class CosyVoiceCreateTask {
    String id;
    String name;
    String access;
    String dataset;
    VoicePromptParameter parameter;
    UUID account_id;
    Boolean update;
    String exampleText;
}
