package com.flex.ditto.config;

import com.rabbitmq.http.client.ReactorNettyClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.amqp.RabbitProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitmqManagementConfig {

    @Value("${rabbitmq.management.port:15672}")
    private Integer port;

    @Bean
    public ReactorNettyClient reactorNettyClient(RabbitProperties properties) {
        return new ReactorNettyClient(String.format("http://%s:%d/api/", properties.getHost(), port), properties.getUsername(), properties.getPassword());
    }
}
