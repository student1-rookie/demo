package com.flex.ditto.controller;

import java.time.ZonedDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.flex.ditto.config.security.UserPrincipal;
import com.flex.ditto.dto.MetaHumanNotifyDto;
import com.flex.ditto.service.NotificationService;
import reactor.core.publisher.Flux;

@RestController
@RequestMapping("/notify")
public class NotificationController {

    @Autowired
    private NotificationService notificationService;

    @GetMapping("/messages")
    public Flux<ServerSentEvent<String>> getMessages(@AuthenticationPrincipal UserPrincipal user) {
        return notificationService.sseNotify(user.getSid().toString());
    }

    @GetMapping("/list")
    public ResponseEntity<Flux<MetaHumanNotifyDto>> getNotifications(@AuthenticationPrincipal UserPrincipal user, ZonedDateTime date) {
        return ResponseEntity.ok(notificationService.getNotificationsByCreateDate(user.getSid(), date));
    }
}
