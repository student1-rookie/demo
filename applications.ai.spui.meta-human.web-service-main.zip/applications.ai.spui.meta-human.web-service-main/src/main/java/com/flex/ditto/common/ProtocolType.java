package com.flex.ditto.common;

public enum ProtocolType {
    MQ, RSOCKET
}
