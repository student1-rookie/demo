package com.flex.ditto.service.transports;

import com.flex.ditto.common.InferenceResult;
import com.flex.ditto.common.RunningDevice;
import com.flex.ditto.common.WorkSpace;
import com.flex.ditto.common.inference.InferenceLatentSyncFaceTask;
import com.flex.ditto.domain.*;
import com.flex.ditto.dto.InferenceMetaDto;
import com.flex.ditto.service.InferenceTaskService;
import com.flex.ditto.service.utils.ConvertUtils;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.UUID;

public class InferenceFaceMqTransport implements InferenceTransport {
    private final String exchange;
    private final String routingKey;
    private final MetaHumanDatasetRepository metaHumanDatasetRepository;
    private final InferenceRepository inferenceRepository;
    private final InferenceTaskService inferenceTaskService;
    private final List<RunningDevice>  runningDevices;

    public InferenceFaceMqTransport(String protocol, String routingKey, MetaHumanDatasetRepository metaHumanDatasetRepository, InferenceRepository inferenceRepository, InferenceTaskService inferenceTaskService, List<RunningDevice> runningDevices) {
        this.exchange = protocol;
        this.routingKey = routingKey;
        this.metaHumanDatasetRepository = metaHumanDatasetRepository;
        this.inferenceRepository = inferenceRepository;
        this.inferenceTaskService = inferenceTaskService;
        this.runningDevices = runningDevices;
    }

    @Override
    public Mono<Void> inference(InferenceMetaDto meta, TTSModel ttsModel, FaceModel faceModel, UUID accountId, WorkSpace workSpace, Boolean isCluster) {
        return metaHumanDatasetRepository.findById(faceModel.getDatasetId())
                .flatMap(dataset -> inferenceRepository.save(new Inference(meta.getName(), accountId, faceModel.getId(), null, InferenceResult.getResultType(meta.getType())))
                        .flatMap(inference -> {
                            return Mono.zip(metaHumanDatasetRepository.findById(faceModel.getDatasetId()), metaHumanDatasetRepository.findById(meta.getWav()))
                                    .flatMap(tuple -> {
                                        InferenceLatentSyncFaceTask task = ConvertUtils.toInferenceLatentSyncFaceTask(meta, inference, faceModel, tuple.getT2(), tuple.getT1(), workSpace, isCluster);
                                        return Mono.fromCallable(() -> {
                                            inferenceTaskService.pubToXpu(task, task.getId(), exchange, routingKey);
                                            return null;
                                        });
                                    });
                        })
                );
    }

    @Override
    public List<RunningDevice> getRunningDevices() {
        return this.runningDevices;
    }
}
