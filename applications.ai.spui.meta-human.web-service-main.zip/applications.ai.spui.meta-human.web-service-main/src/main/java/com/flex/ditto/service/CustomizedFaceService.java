package com.flex.ditto.service;

import com.flex.ditto.common.WorkSpace;
import com.flex.ditto.domain.FaceModel;
import com.flex.ditto.domain.MetaHumanDataset;
import com.flex.ditto.dto.InferenceMetaDto;
import reactor.core.publisher.Mono;

import java.util.UUID;

public interface CustomizedFaceService {

    Mono<Void> inference(InferenceMetaDto inferenceMetaDto, FaceModel model, UUID id, WorkSpace workSpace, Boolean isCluster);

    Mono<Void> createModel(FaceModel faceModel, MetaHumanDataset dataset, WorkSpace workSpace, Boolean isCluster);
}
