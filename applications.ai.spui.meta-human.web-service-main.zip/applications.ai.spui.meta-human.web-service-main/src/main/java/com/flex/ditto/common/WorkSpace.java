package com.flex.ditto.common;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class WorkSpace {
    @JsonProperty("modelBase")
    String model;
    @JsonProperty("datasetBase")
    String dataset;
    @JsonProperty("inferenceBase")
    String inference;
    @JsonProperty("logBase")
    String log;
    @JsonProperty("tempBase")
    String temp;
    @JsonProperty("failBase")
    String fail;
    @JsonIgnore
    String env;
    @JsonIgnore
    String publicBucket;
    @JsonIgnore
    String userBucketPrefix;

    @JsonIgnore
    public Map<String, Object> getExtra() {
        return Map.of("env", env);
    }
}
