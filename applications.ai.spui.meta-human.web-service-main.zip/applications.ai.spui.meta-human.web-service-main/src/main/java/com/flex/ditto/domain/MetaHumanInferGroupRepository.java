package com.flex.ditto.domain;

import org.springframework.data.repository.reactive.ReactiveCrudRepository;

import java.util.UUID;

public interface MetaHumanInferGroupRepository extends ReactiveCrudRepository<MetaHumanInferGroup, UUID> {

}