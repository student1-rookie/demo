package com.flex.ditto.common;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;


@JsonSerialize
@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class TrainTask{
    @JsonIgnore
    String id;
    String name;
    String dataset;
    String task;
    String model;
    String extra;
    UUID account_id;
    @JsonIgnore
    private RunningDevice device;
}
