package com.flex.ditto.domain;

import com.flex.ditto.dto.InferenceInfoDto;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.UUID;

public interface InferenceRepository extends ReactiveCrudRepository<Inference, UUID> {

    Mono<Inference> findByIdAndAccountId(UUID id, UUID accountId);

    @Query("SELECT infer.*, " +
            "COALESCE(tts.name, '') AS tts_model_name, " +
            "COALESCE(face.name, '') AS face_model_name " +
            "FROM meta_human_infer infer " +
            "LEFT JOIN meta_human_tts tts ON infer.tts_model = tts.id " +
            "LEFT JOIN meta_human_face face ON infer.face_model = face.id " +
            "WHERE infer.account_id = :accountId " +
            "AND infer.type != 'PIP_ITEM'")
    Flux<InferenceInfoDto> findByAccountId(UUID accountId);

    @Query("SELECT infer.*, " +
            "COALESCE(tts.name, '') AS tts_model_name, " +
            "COALESCE(face.name, '') AS face_model_name " +
            "FROM meta_human_infer infer " +
            "LEFT JOIN meta_human_tts tts ON infer.tts_model = tts.id " +
            "LEFT JOIN meta_human_face face ON infer.face_model = face.id " +
            "WHERE infer.type != 'PIP_ITEM'")
    Flux<InferenceInfoDto> findAllInferences();

    @Query("SELECT infer.*, " +
            "COALESCE(tts.name, '') AS tts_model_name, " +
            "COALESCE(face.name, '') AS face_model_name " +
            "FROM meta_human_infer infer " +
            "LEFT JOIN meta_human_tts tts ON infer.tts_model = tts.id " +
            "LEFT JOIN meta_human_face face ON infer.face_model = face.id " +
            "WHERE infer.name = :name " +
            "AND infer.account_id = :accountId " +
            "AND infer.type = 'PIP' " +
            "AND infer.status IN ('WAIT', 'RUN')")
    Flux<InferenceInfoDto> findPipRunningInferences(String name, UUID accountId);

    @Query("SELECT infer.id " +
           "FROM meta_human_infer infer " +
           "WHERE infer.group_id = :groupId")
    Flux<UUID> findIdsByGroupId(UUID groupId);

    Mono<Void> deleteByGroupId(UUID groupId);

    Mono<Void> deleteById(UUID id);

    Mono<Void> deleteByIdAndAccountId(UUID id, UUID accountId);

    @Query("""
        SELECT DISTINCT ON (name) id
        FROM meta_human_infer
        WHERE name = ANY(:names) AND group_id = :groupId
        ORDER BY name, id DESC
    """)
    Flux<UUID> findItemsByNameInAndGroupId(String[] names, UUID groupId);

    @Query("SELECT infer.* FROM meta_human_infer infer WHERE infer.name = :name AND infer.account_id = :accountId AND infer.group_id = :groupId ORDER BY infer.create_date DESC LIMIT 1")
    Mono<Inference> findByNameAndAccountIdAndGroupId(String name, UUID accountId, UUID groupId);

    @Query("DELETE FROM meta_human_infer infer WHERE infer.group_id = :groupId AND infer.type = 'PIP_ITEM'")
    Mono<Void> deletePipItemsByGroupId(UUID groupId);

    @Query("SELECT infer.id " +
            "FROM meta_human_infer infer " +
            "WHERE infer.group_id = :groupId and infer.type = 'PIP_ITEM' and (infer.status != 'INIT' or infer.status is null)")
    Flux<UUID> findItemIdsByGroupId(UUID groupId);

    @Query("SELECT name FROM meta_human_infer WHERE group_id = :groupId AND type = 'PIP_ITEM'")
    Flux<String> findItemNamesByGroupId(UUID groupId);

    @Query("SELECT * FROM meta_human_infer WHERE group_id = :groupId AND type = 'PIP' ORDER BY create_date DESC LIMIT 1")
    Mono<Inference> findByGroupId(UUID groupId);

    @Query("SELECT * FROM meta_human_infer WHERE (status = 'COMPLETE' OR status IS NULL) AND group_id = :groupId AND type = 'PIP_ITEM'")
    Flux<Inference> findItemByGroupId(UUID groupId);
}
