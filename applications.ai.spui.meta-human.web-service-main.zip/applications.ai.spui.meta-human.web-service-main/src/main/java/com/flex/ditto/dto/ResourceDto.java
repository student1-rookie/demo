package com.flex.ditto.dto;

import com.flex.ditto.common.ResourceAccess;
import com.flex.ditto.common.ResourceType;

import java.time.ZonedDateTime;
import java.util.UUID;

public record ResourceDto(UUID id, String name, ZonedDateTime createdTime, ResourceAccess type, ResourceType fileType, String owner, String identifier) {
    
}
