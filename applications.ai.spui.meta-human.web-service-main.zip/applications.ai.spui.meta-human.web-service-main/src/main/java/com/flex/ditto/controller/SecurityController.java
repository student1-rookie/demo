package com.flex.ditto.controller;

import com.flex.ditto.domain.Account;
import com.flex.ditto.dto.NewAccountDto;
import com.flex.ditto.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/security")
public class SecurityController {
    @Autowired
    AccountService accountService;

    @GetMapping("/public")
    public Mono<ResponseEntity<?>> getPublicKey() {
        return accountService.generateKey().map(ResponseEntity::ok);
    }

    @PostMapping("/signup")
    public Mono<ResponseEntity<String>> signup(@RequestBody NewAccountDto newAccountDto) {
        return accountService.createAccount(newAccountDto)
                .map(account -> ResponseEntity.ok().body("success"))
                .onErrorResume(e -> Mono.just(ResponseEntity.badRequest().body(e.getMessage())));
    }
}
