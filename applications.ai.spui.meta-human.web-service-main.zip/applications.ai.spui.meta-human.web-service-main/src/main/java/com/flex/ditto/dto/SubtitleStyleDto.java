package com.flex.ditto.dto;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.Data;

@Data
public class SubtitleStyleDto {
    private String color;
    private Integer bold;
    private Integer fontSize;
    @JsonProperty("margin_v")
    private Integer margin;
    private String extendColor;
    private Float extendRatio;

    private static final ObjectMapper objectMapper = new ObjectMapper()
            .setSerializationInclusion(JsonInclude.Include.NON_NULL);

    public Map<String, Object> toMap() {
        return objectMapper.convertValue(this, new TypeReference<Map<String, Object>>() {});
    }
}
