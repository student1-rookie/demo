package com.flex.ditto.service.transports;

import java.util.List;
import java.util.UUID;

import com.flex.ditto.common.InferenceResult;
import com.flex.ditto.common.RunningDevice;
import com.flex.ditto.common.WorkSpace;
import com.flex.ditto.common.inference.InferenceCustomizedTTSTask;
import com.flex.ditto.domain.*;
import com.flex.ditto.dto.InferenceMetaDto;
import com.flex.ditto.service.InferenceTaskService;
import com.flex.ditto.service.utils.ConvertUtils;

import reactor.core.publisher.Mono;

public class InferenceTTSMqTransport implements InferenceTransport {
    private final String exchange;
    private final String routingKey;
    private final MetaHumanDatasetRepository metaHumanDatasetRepository;
    private final InferenceRepository inferenceRepository;
    private final InferenceTaskService inferenceTaskService;
    private final List<RunningDevice>  runningDevices;

    public InferenceTTSMqTransport(String protocol, String routingKey, MetaHumanDatasetRepository metaHumanDatasetRepository, InferenceRepository inferenceRepository, InferenceTaskService inferenceTaskService, List<RunningDevice> runningDevices) {
        this.exchange = protocol;
        this.routingKey = routingKey;
        this.metaHumanDatasetRepository = metaHumanDatasetRepository;
        this.inferenceRepository = inferenceRepository;
        this.inferenceTaskService = inferenceTaskService;
        this.runningDevices = runningDevices;
    }

    @Override
    public Mono<Void> inference(InferenceMetaDto meta, TTSModel ttsModel, FaceModel faceModel, UUID accountId, WorkSpace workSpace, Boolean isCluster) {
        return metaHumanDatasetRepository.findById(ttsModel.getDatasetId())
                .flatMap(dataset -> inferenceRepository.save(new Inference(meta.getName(), accountId, null, ttsModel.getId(), InferenceResult.getResultType(meta.getType())))
                        .flatMap(inference -> {
                                    InferenceCustomizedTTSTask task = ConvertUtils.toInferenceCustomizedTTSTask(meta, inference, ttsModel, dataset, workSpace, isCluster);
                                    return Mono.fromCallable(() -> {
                                        inferenceTaskService.pubToXpu(task, task.getId(), exchange, routingKey);
                                        return null;
                                    });
                                }
                        ));
    }

    @Override
    public List<RunningDevice> getRunningDevices() {
        return this.runningDevices;
    }
}
