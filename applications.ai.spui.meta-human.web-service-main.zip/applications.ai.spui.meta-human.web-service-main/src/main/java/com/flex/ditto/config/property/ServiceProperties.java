package com.flex.ditto.config.property;

import lombok.Data;

@Data
public class ServiceProperties {
    private String service;
    private String device;
    private String host;
    private Integer port;
    private String createRoute;
    private Details details;
    private String exchange;
    private String inferenceRoutingKey;
    private String protocol;

    @Data
    public static class Details {
        private Double cutDuration;
        private Boolean needPrompt;
    }
}
