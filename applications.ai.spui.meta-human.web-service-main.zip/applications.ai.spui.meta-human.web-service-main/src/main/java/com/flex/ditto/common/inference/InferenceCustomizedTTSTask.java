package com.flex.ditto.common.inference;

import java.util.UUID;

import com.flex.ditto.common.InferenceType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class InferenceCustomizedTTSTask {
    String id;
    String name;
    String text;
    String wav_path;
    InferenceType type;
    String extra;
    UUID account_id;
}