package com.flex.ditto.common;

public enum InferenceStatus {
    INIT, RUN, COMPLETE, WAIT, FAIL
}
