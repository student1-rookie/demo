package com.flex.ditto.exception;

public class ToolException extends RuntimeException {

    public ToolException(String message) {
        super(message);
    }
}