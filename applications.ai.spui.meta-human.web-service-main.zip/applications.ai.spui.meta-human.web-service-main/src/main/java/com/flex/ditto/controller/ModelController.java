package com.flex.ditto.controller;

import com.flex.ditto.common.ModelType;
import com.flex.ditto.common.ResourceAccess;
import com.flex.ditto.config.security.UserPrincipal;
import com.flex.ditto.dto.ModelListDto;
import com.flex.ditto.dto.ModelTableDto;
import com.flex.ditto.dto.UploadModelDto;
import com.flex.ditto.service.ModelService;
import com.flex.ditto.service.ResourceService;
import com.flex.ditto.service.StorageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.ResponseEntity;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.UUID;

@RestController
@RequestMapping("/models")
public class ModelController {
    @Autowired
    private ModelService modelService;
    @Autowired
    private ResourceService resourceService;
    @Autowired
    private StorageService storageService;

    @DeleteMapping("/delete/{id}")
    public Mono<Void> deleteModel(@PathVariable String id,
                                  @RequestParam("type") ModelType type,
                                  @AuthenticationPrincipal UserPrincipal user) {
        UUID userId = user.getSid();
        return resourceService.deleteModel(UUID.fromString(id), type, userId, user.isAdmin());
    }

    @DeleteMapping("/delete")
    public Mono<Void> deleteModelList(@RequestBody ModelTableDto modelTableDto, 
                                      @AuthenticationPrincipal UserPrincipal user) {
        UUID userId = user.getSid();
        return resourceService.deleteModelList(modelTableDto, userId, user.isAdmin());
    }

    @GetMapping("/list")
    public ResponseEntity<Flux<ModelListDto>> listModels(@AuthenticationPrincipal UserPrincipal user) {
        if (user.isAdmin()) {
            return ResponseEntity.ok(modelService.listModels());
        }
        UUID userId = user.getSid();
        return ResponseEntity.ok(modelService.listModels(userId));
    }

    @PutMapping("/rename/{id}")
    public Mono<ResponseEntity<?>> renameModel(@PathVariable String id,
                                               @RequestParam("name") String newName,
                                               @RequestParam("type") ModelType type,
                                               @AuthenticationPrincipal UserPrincipal user) {
        if (user.isAdmin()) {
            return modelService.renameModel(UUID.fromString(id), newName, type)
                    .then(Mono.just(ResponseEntity.noContent().build()));
        }
        UUID userId = user.getSid();
        return modelService.renameModel(UUID.fromString(id), newName, type, userId)
                .then(Mono.just(ResponseEntity.noContent().build()));
    }

    @PutMapping("/reaccess/{id}")
    public Mono<ResponseEntity<?>> changeAccess(@PathVariable String id,
                                                @RequestParam("access") ResourceAccess access,
                                                @RequestParam("type") ModelType type,
                                                @AuthenticationPrincipal UserPrincipal user) {
        UUID userId = user.getSid();
        return modelService.changeAccess(UUID.fromString(id), access, type, userId, user.isAdmin())
                .then(Mono.just(ResponseEntity.noContent().build()));
    }

    @PutMapping("/reaccess")
    public Mono<ResponseEntity<?>> changeAccess(@RequestBody ModelTableDto modelTableDto,
                                                @AuthenticationPrincipal UserPrincipal user) {
        UUID userId = user.getSid();
        return modelService.changeAccessList(modelTableDto, userId, user.isAdmin())
                .then(Mono.just(ResponseEntity.noContent().build()));
    }

    @PutMapping("/owner/{id}")
    public Mono<ResponseEntity<?>> changeOwner(@PathVariable String id,
                                                @RequestParam("owner") UUID owner,
                                                @RequestParam("type") ModelType type,
                                                @AuthenticationPrincipal UserPrincipal user) {
        if (user.isAdmin()) {
            return modelService.changeOwner(UUID.fromString(id), owner, type)
                    .then(Mono.just(ResponseEntity.noContent().build()));
        }
        return Mono.just(ResponseEntity.badRequest().build());
    }

    @PutMapping("/owner")
    public Mono<ResponseEntity<?>> changeOwnerList(@RequestBody ModelTableDto modelTableDto,
                                                   @AuthenticationPrincipal UserPrincipal user) {
        if (user.isAdmin()) {
            return modelService.changeOwnerList(modelTableDto)
                    .then(Mono.just(ResponseEntity.noContent().build()));
        }
        return Mono.just(ResponseEntity.badRequest().build());
    }

    @GetMapping("/download")
    public Flux<DataBuffer> downloadModel(@RequestParam("id") UUID modelId,
                                          @RequestParam("type") ResourceAccess type,
                                          @RequestParam("baseType") ModelType baseType,
                                          @RequestParam("modelName") String modelName,
                                          @AuthenticationPrincipal UserPrincipal user) {
        return storageService.downloadModel(user.getSid(), modelId, type, baseType, modelName, user.getSid())
                .onErrorResume(Flux::error);
    }

    @PostMapping("/upload")
    public Mono<ResponseEntity<Object>> uploadModel(@RequestPart("modelInfo") UploadModelDto modelInfo,
                                                    @RequestPart("model") FilePart file,
                                                    @AuthenticationPrincipal UserPrincipal user) {
        return modelService.uploadModel(modelInfo, file, user.getSid())
                .onErrorResume(err -> {
                    return Mono.just(ResponseEntity.badRequest().body(err.getMessage()));
                });
    }

    @GetMapping("/fail")
    public Mono<Resource> getFailModel(@RequestParam("modelId") UUID modelId,
                                       @RequestParam("modelType") ModelType modelType,
                                       @AuthenticationPrincipal UserPrincipal user) {
        if (user.isAdmin()) {
            return modelService.getFailModel(modelId, modelType);
        }
        return Mono.error(new Exception("Permission denied!"));
    }

}
