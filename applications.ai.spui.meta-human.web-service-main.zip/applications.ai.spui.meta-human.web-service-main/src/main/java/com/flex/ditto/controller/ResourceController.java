package com.flex.ditto.controller;

import com.flex.ditto.common.ResourceAccess;
import com.flex.ditto.config.security.UserPrincipal;
import com.flex.ditto.dto.ResourceDto;
import com.flex.ditto.dto.ResourcesTableDto;
import com.flex.ditto.service.ResourceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.codec.multipart.PartEvent;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.UUID;

@RestController
@RequestMapping("/resources")
public class ResourceController {

    @Autowired
    private ResourceService resourceService;


    @PostMapping("/upload")
    public Mono<ResponseEntity<?>> uploadResource(@RequestBody Flux<PartEvent> allParts,
                                                  @AuthenticationPrincipal UserPrincipal user) {
        UUID userId = user.getSid();
        return resourceService.saveResource(allParts, userId).map(dataset -> ResponseEntity.status(HttpStatus.CREATED).body(dataset.getId()));
    }

    @DeleteMapping("/delete/{id}")
    public Mono<Void> deleteResource(@PathVariable UUID id, @AuthenticationPrincipal UserPrincipal user) {
        UUID userId = user.getSid();
        return resourceService.deleteResource(id, userId, user.isAdmin());
    }

    @DeleteMapping("/delete-group/{groupId}")
    public Mono<Void> deleteResourceGroup(@PathVariable UUID groupId, @AuthenticationPrincipal UserPrincipal user) {
        UUID userId = user.getSid();
        return resourceService.deleteResourceGroup(groupId, userId, user.isAdmin());
    }

    @DeleteMapping("/delete")
    public Mono<Void> deleteResourceList(@RequestBody ResourcesTableDto resourcesTableDto, @AuthenticationPrincipal UserPrincipal user) {
        UUID userId = user.getSid();
        return resourceService.deleteResourceList(resourcesTableDto, userId, user.isAdmin());
    }

    @GetMapping("/list")
    public ResponseEntity<Flux<ResourceDto>> listResources(@AuthenticationPrincipal UserPrincipal user) {
        UUID userId = user.getSid();
        return ResponseEntity.ok(resourceService.listResources(userId, user.isAdmin()));
    }

    @GetMapping("/list-group")
    public ResponseEntity<Flux<ResourceDto>> listResourcesGroup(@AuthenticationPrincipal UserPrincipal user) {
        UUID userId = user.getSid();
        return ResponseEntity.ok(resourceService.listResourcesGroup(userId, user.isAdmin()));
    }

    @GetMapping("/list/{groupId}")
    public ResponseEntity<Flux<ResourceDto>> listResourcesByGroupId(@PathVariable UUID groupId, @AuthenticationPrincipal UserPrincipal user) {
        return ResponseEntity.ok(resourceService.listResourcesByGroupId(groupId));
    }

    @PutMapping("/rename/{id}")
    public Mono<ResponseEntity<?>> renameResource(@PathVariable String id, @RequestParam String newName,
                                                  @AuthenticationPrincipal UserPrincipal user) {
        if (user.isAdmin()) {
            return resourceService.renameResource(id, newName)
                    .then(Mono.just(ResponseEntity.noContent().build()));
        }
        UUID userId = user.getSid();
        return resourceService.renameResource(id, newName, userId)
                .then(Mono.just(ResponseEntity.noContent().build()));
    }

    @PutMapping("/rename-group/{id}")
    public Mono<ResponseEntity<?>> renameGroupResource(@PathVariable UUID id, @RequestParam String newName,
                                                  @AuthenticationPrincipal UserPrincipal user) {
        return resourceService.renameGroupResource(id, newName)
                .then(Mono.just(ResponseEntity.noContent().build()));
    }

    @GetMapping("/preview/{id}")
    public Mono<Resource> getResourcePreview(@PathVariable String id,
                                             @AuthenticationPrincipal UserPrincipal user) {
        UUID userId = user.getSid();
        return resourceService.getResourceFile(UUID.fromString(id), userId, user.isAdmin());
    }

    @PutMapping("/chmod/{id}")
    public Mono<ResponseEntity<?>> changeAccess(@PathVariable UUID id,
                                                @RequestParam("access") ResourceAccess access,
                                                @AuthenticationPrincipal UserPrincipal user) {
        UUID userId = user.getSid();
        return resourceService.changeAccess(id, access, userId, user.isAdmin())
                .then(Mono.just(ResponseEntity.noContent().build()));
    }

    @PutMapping("/chmod-group/{id}")
    public Mono<ResponseEntity<?>> changeGroupAccess(@PathVariable UUID id,
                                                @RequestParam("access") ResourceAccess access,
                                                @AuthenticationPrincipal UserPrincipal user) {
        UUID userId = user.getSid();
        return resourceService.changeGroupAccess(id, access, userId, user.isAdmin())
                .then(Mono.just(ResponseEntity.noContent().build()));
    }

    @PutMapping("/chmod")
    public Mono<ResponseEntity<?>> changeAccessList(@RequestBody ResourcesTableDto resourcesTableDto,
                                                @AuthenticationPrincipal UserPrincipal user) {
        UUID userId = user.getSid();
        return resourceService.changeAccessList(resourcesTableDto, userId, user.isAdmin())
                .then(Mono.just(ResponseEntity.noContent().build()));
    }

    @PutMapping("/owner/{id}")
    public Mono<ResponseEntity<?>> changeOwner(@PathVariable UUID id,
                                               @RequestParam("owner") UUID owner,
                                               @AuthenticationPrincipal UserPrincipal user) {
        if (user.isAdmin()) {
            return resourceService.changeOwner(id, owner)
                    .then(Mono.just(ResponseEntity.noContent().build()));
        }
        return Mono.just(ResponseEntity.badRequest().build());
    }

    @PutMapping("/owner-group/{id}")
    public Mono<ResponseEntity<?>> changeGroupOwner(@PathVariable UUID id,
                                               @RequestParam("owner") UUID owner,
                                               @AuthenticationPrincipal UserPrincipal user) {
        if (user.isAdmin()) {
            return resourceService.changeGroupOwner(id, owner)
                    .then(Mono.just(ResponseEntity.noContent().build()));
        }
        return Mono.just(ResponseEntity.badRequest().build());
    }

    @PutMapping("/owner")
    public Mono<ResponseEntity<?>> changeOwnerList(@RequestBody ResourcesTableDto resourcesTableDto, @AuthenticationPrincipal UserPrincipal user) {
        if (user.isAdmin()) {
            return resourceService.changeOwnerList(resourcesTableDto)
                    .then(Mono.just(ResponseEntity.noContent().build()));
        }
        return Mono.just(ResponseEntity.badRequest().build());
    }

    @GetMapping("/avatar/{id}")
    public Mono<ResponseEntity<?>> getAvatar(@PathVariable UUID id,
                                             @AuthenticationPrincipal UserPrincipal user) {
        return resourceService.findAvatar(id, false, user.getSid(), user.isAdmin()).map(ResponseEntity::ok);
    }

    @GetMapping("/avatar-preview/{id}")
    public Mono<ResponseEntity<?>> getAvatarPreview(@PathVariable UUID id,
                                             @AuthenticationPrincipal UserPrincipal user) {
        return resourceService.findAvatar(id, true, user.getSid(), user.isAdmin()).map(ResponseEntity::ok);
    }

    @GetMapping("/audio/{id}")
    public Mono<ResponseEntity<?>> getAudio(@PathVariable UUID id,
                                             @AuthenticationPrincipal UserPrincipal user) {
        return resourceService.findAudio(id, user.getSid(), user.isAdmin()).map(ResponseEntity::ok);
    }
}
