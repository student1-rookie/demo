package com.flex.ditto.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.flex.ditto.common.ResourceType;
import com.flex.ditto.common.Reuse;
import lombok.Data;
import org.apache.commons.codec.digest.DigestUtils;

import java.util.List;
import java.util.UUID;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PicInPicTaskDto {
    private String text;
    private String media;
    private List<Float> coordinate;
    private List<Integer> box;
    private Boolean is_meta_human_background;
    private ResourceType type;
    private Boolean audio_only;
    private String itemKey;
    private String ttsKey;
    private String faceKey;
    private Reuse reuseStatus;
    private UUID itemId;

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    public String getItemKey() {
        if (itemKey == null) {
            ObjectNode object = OBJECT_MAPPER.createObjectNode();
            object.put("text", this.text);
            itemKey = DigestUtils.sha256Hex(object.toString());
        }
        return itemKey;
    }

    public String createPreviewItemKey() {
        ObjectNode object = OBJECT_MAPPER.createObjectNode();
        object.put("media", this.media);
        object.put("text", this.text);
        if (this.coordinate != null) {
            object.put("coordinate", String.format("[%.2f, %.2f]", this.coordinate.get(0), this.coordinate.get(1)));
        } else {
            object.putNull("coordinate");
        }
        if (this.box != null) {
            object.set("box", OBJECT_MAPPER.valueToTree(this.box));
        } else {
            object.putNull("box");
        }
        object.put("is_meta_human_background", this.is_meta_human_background);
        object.put("audio_only", this.audio_only);
        object.put("type", this.type != null ? this.type.name() : null);
        return DigestUtils.sha256Hex(object.toString());
    }
}