package com.flex.ditto.dto;

import jakarta.validation.constraints.NotBlank;

public record AccountDto(@NotBlank String username, @NotBlank String email, @NotBlank Boolean isAdmin) {}
