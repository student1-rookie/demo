package com.flex.ditto.dto;

import com.flex.ditto.common.ModelStatus;
import com.flex.ditto.common.ModelType;
import lombok.Builder;

import java.time.ZonedDateTime;
import java.util.UUID;

@Builder
public record TrainingModelsDto(UUID id, String name, ZonedDateTime date, ModelType type, ModelStatus status) {}
