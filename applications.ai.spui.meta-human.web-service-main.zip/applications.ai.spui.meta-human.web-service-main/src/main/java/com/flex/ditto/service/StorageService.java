package com.flex.ditto.service;

import com.flex.ditto.common.ModelType;
import com.flex.ditto.common.ResourceAccess;
import com.flex.ditto.common.StorageType;
import com.flex.ditto.common.WorkSpace;
import com.flex.ditto.domain.TTSModel;
import com.flex.ditto.domain.FaceModel;
import com.flex.ditto.domain.Inference;
import com.flex.ditto.domain.MetaHumanDataset;
import com.flex.ditto.dto.UploadModelDto;
import org.springframework.core.io.Resource;
import org.springframework.core.io.buffer.DataBuffer;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.nio.file.Path;
import java.util.UUID;

public interface StorageService {

    default Mono<Void> createPublicBucket() {
        return Mono.empty();
    }

    default Boolean isCluster() {
        return false;
    }

    WorkSpace getWorkSpace();

    StorageType getStorageType();

    Mono<Void> store(UUID userId, UUID datasetId, String fileName, Boolean isPublic, Flux<DataBuffer> dataBuffer);

    Mono<Void> store(UUID userId, UUID datasetId, String fileName, Boolean isPublic, byte[] data);

    default Mono<Void> mvDataset(UUID tarId, MetaHumanDataset dataset) {
        return Mono.empty();
    }

    default Mono<Void> mvDatasetPublic(MetaHumanDataset dataset) {
        return Mono.empty();
    }

    default Mono<Void> mvModel(UUID tarId, FaceModel faceModel) {
        return Mono.empty();
    }

    default Mono<Void> mvModel(UUID tarId, TTSModel ttsModel) {
        return Mono.empty();
    }

    default Mono<Void> mvModelPublic(FaceModel faceModel) {
        return Mono.empty();
    }

    default Mono<Void> mvModelPublic(TTSModel ttsModel) {
        return Mono.empty();
    }

    Mono<Void> mvItemInference(String filename, UUID itemInferenceId, UUID itemId, UUID accountId, String newFilename);

    Mono<Void> deleteDataset(UUID userId, UUID datasetId, Boolean isPublic);

    Mono<Void> deleteModel(UUID userId, UUID modelId, Boolean isPublic);

    Mono<Void> deleteInference(UUID userId, UUID inferenceId);

    Mono<Void> createWorkspace(UUID userId);

    Mono<Resource> loadDataset(UUID userId, MetaHumanDataset dataset);

    Mono<byte[]> loadDatasetBytes(UUID userId, MetaHumanDataset dataset);

    Mono<Resource> loadLog(UUID userId, String logId);

    Mono<Resource> loadAvatar(UUID userId, FaceModel faceModel, String fileName);

    Mono<Resource> loadAudio(UUID userId, TTSModel faceModel, String fileName);

    Mono<Resource> loadInferenceResult(UUID userId, Inference inference);

    Mono<Void> uploadModel(UploadModelDto modelInfo, Path file, UUID modelId, UUID  userId, byte[] previewFile);

    Flux<DataBuffer> downloadModel(UUID accountId, UUID modelId, ResourceAccess type, ModelType baseType, String modelName, UUID userId);

    Mono<Resource> loadItemInference(UUID accountId, UUID itemId, String fileName);

    Mono<Void> copyInference(String filename, UUID itemInferenceId, UUID itemId, UUID accountId, String newFilename);
  
    Mono<Resource> loadFailTaskFile(UUID accountId, UUID taskId, ResourceAccess type);
}
