package com.flex.ditto.dto;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.flex.ditto.common.ModelType;
import com.flex.ditto.common.parameter.VoicePromptParameter;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.log4j.Log4j2;

import java.io.IOException;

@Data
@AllArgsConstructor
@Log4j2
public class TrainModelDto {
    // model name
    private String name;
    private ModelType task;
    // model type
    private String type;
    // parameters
    private String parameters;

    public VoicePromptParameter getVoicePromptParameter() {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            return objectMapper.readValue(parameters, VoicePromptParameter.class);
        } catch (IOException e) {
            log.error("error when parsing JSON: {}", parameters, e);
            return null;
        }
    }
}
