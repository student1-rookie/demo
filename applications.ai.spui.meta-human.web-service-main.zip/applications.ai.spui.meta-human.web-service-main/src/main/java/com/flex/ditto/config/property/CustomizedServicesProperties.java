package com.flex.ditto.config.property;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.List;

@Data
@ConfigurationProperties(prefix = "customized-services")
public class CustomizedServicesProperties {
    private List<String> tts;
    private List<String> face;
}
