package com.flex.ditto.dto;

import com.flex.ditto.domain.Account;
import lombok.Data;
import org.springframework.security.crypto.password.PasswordEncoder;

@Data
public class NewAccountDto {
    private String name;
    private String email;
    private String password;

    public Account convertoAccount(String roles, PasswordEncoder passwordEncoder) {
        return new Account(email, name, roles, passwordEncoder.encode(password));
    }
}
