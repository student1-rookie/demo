package com.flex.ditto.dto;

import java.util.List;
import java.util.UUID;
import com.flex.ditto.common.ResourceAccess;
import lombok.Data;

@Data
public class ModelTableDto {
    private List<UUID> ttsModelIds;
    private List<UUID> faceModelIds;
    private ResourceAccess access;
    private UUID owner;
}
