package com.flex.ditto.exception;

public class ResourcesException extends RuntimeException {
    
    public ResourcesException(String message) {
        super(message);
    }
}
