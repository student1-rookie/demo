package com.flex.ditto.exception;

import io.rsocket.exceptions.ConnectionErrorException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.reactive.result.method.annotation.ResponseEntityExceptionHandler;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(InferenceException.class)
    public Mono<ResponseEntity<String>> handleInferenceException(InferenceException e, ServerWebExchange exchange) {
        return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage()));
    }

    @ExceptionHandler(ModelException.class)
    public Mono<ResponseEntity<String>> handleModelException(ModelException e, ServerWebExchange exchange) {
        return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage()));
    }

    @ExceptionHandler(StorageException.class)
    public Mono<ResponseEntity<String>> handleStorageException(StorageException e, ServerWebExchange exchange) {
        return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage()));
    }

    @ExceptionHandler(ConnectionErrorException.class)
    public Mono<ResponseEntity<String>> handleRSocketException(ConnectionErrorException e, ServerWebExchange exchange) {
        return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Inference timed out!"));
    }

    @ExceptionHandler(ToolException.class)
    public Mono<ResponseEntity<String>> handleToolException(ToolException e, ServerWebExchange exchange) {
        return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage()));
    }

    @ExceptionHandler(PicTemplateException.class)
    public Mono<ResponseEntity<String>> handlePicTemplateException(PicTemplateException e, ServerWebExchange exchange) {
        return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage()));
    }
    
    @ExceptionHandler(ResourcesException.class)
    public Mono<ResponseEntity<String>> ResourcesException(ResourcesException e, ServerWebExchange exchange) {
        return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage()));
    }
}
