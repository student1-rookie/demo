package com.flex.ditto.service;

import com.flex.ditto.common.ClusterAsrTask;
import com.flex.ditto.common.ResourceType;
import com.flex.ditto.common.Sentence;
import com.flex.ditto.common.WorkSpace;
import com.flex.ditto.domain.MetaHumanDataset;
import com.flex.ditto.service.utils.MinIOConvertUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.client.MultipartBodyBuilder;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;

@Service
public class AsrService {

    @Autowired
    private WebClient webClient;

    public Flux<Sentence> asr(Resource resource, ResourceType resourceType) {
        MultipartBodyBuilder builder = new MultipartBodyBuilder();
        builder.part("file", resource);
        builder.part("type", resourceType.name().toLowerCase());
        builder.part("lang", "auto");
        return webClient.post().uri("/api/v1/asr-1").contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(builder.build()))
                .retrieve()
                .bodyToFlux(Sentence.class);
    }

    public Flux<Sentence> clusterAsr(MetaHumanDataset dataset, WorkSpace workSpace) {
        var task = new ClusterAsrTask(MinIOConvertUtils.toDatasetXPath(dataset, workSpace), dataset.getFileType().name().toLowerCase(), workSpace.getEnv(), "auto");
        return webClient.post().uri("/api/v1/asr-2").contentType(MediaType.APPLICATION_JSON)
                .body(BodyInserters.fromValue(task))
                .retrieve()
                .bodyToFlux(Sentence.class);
    }
}
