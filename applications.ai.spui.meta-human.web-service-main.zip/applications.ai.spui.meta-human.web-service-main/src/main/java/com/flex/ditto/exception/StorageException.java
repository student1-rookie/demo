package com.flex.ditto.exception;

public class StorageException extends RuntimeException {

    public StorageException(String message) {
        super(message);
    }
}
