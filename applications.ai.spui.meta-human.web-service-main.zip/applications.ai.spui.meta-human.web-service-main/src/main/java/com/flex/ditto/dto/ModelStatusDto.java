package com.flex.ditto.dto;

import com.flex.ditto.common.ResourceAccess;

public record ModelStatusDto(String name, ResourceAccess type, String faceStatus, String ttsStatus, Boolean creator) {}
