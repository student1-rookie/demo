package com.flex.ditto.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.ZonedDateTime;
import java.util.List;

@Data
@AllArgsConstructor
public class TrainMetaDto {
    // models
    private List<TrainModelDto> models;
    // dataset identifier
    private String dataset;
    private ZonedDateTime date;
    // ture: public; false: private.
    private Boolean type;
}
