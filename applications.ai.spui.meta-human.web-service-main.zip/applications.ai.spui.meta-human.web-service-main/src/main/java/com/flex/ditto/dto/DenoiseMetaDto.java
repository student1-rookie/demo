package com.flex.ditto.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class DenoiseMetaDto {
    private String dataset;
    private String outputName;
    private Boolean newResource;
}
