package com.flex.ditto.common;

public enum ServiceType {
    FACE_TRAIN, TTS_TRAIN, INFERENCE;
}
