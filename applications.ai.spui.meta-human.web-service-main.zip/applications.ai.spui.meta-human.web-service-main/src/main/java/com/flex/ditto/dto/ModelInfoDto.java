package com.flex.ditto.dto;

import com.flex.ditto.common.ResourceAccess;

public record ModelInfoDto(String name, ResourceAccess access) {
}
