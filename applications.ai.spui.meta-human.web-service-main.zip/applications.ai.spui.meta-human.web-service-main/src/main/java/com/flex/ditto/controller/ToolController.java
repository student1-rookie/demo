package com.flex.ditto.controller;

import com.flex.ditto.config.security.UserPrincipal;
import com.flex.ditto.dto.DenoiseMetaDto;
import com.flex.ditto.dto.UserActivityCountDto;
import com.flex.ditto.service.ToolService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.UUID;

@RestController
@RequestMapping("/tools")
public class ToolController {

    private static final Logger logger = LoggerFactory.getLogger(ToolController.class);

    @Autowired
    private ToolService toolService;

    @PostMapping("/denoise")
    public Mono<ResponseEntity<Resource>> denoiseResource(@RequestBody DenoiseMetaDto denoiseMetaDto,
                                                          @AuthenticationPrincipal UserPrincipal user) {
        UUID userId = user.getSid();
        
        // Log the incoming request data
        logger.debug("Received denoise request with data: {}", denoiseMetaDto);
        logger.debug("User ID: {}", userId);

        return toolService.denoiseResource(denoiseMetaDto, userId)
                .map(resource -> {
                    // Log the response data
                    logger.debug("Denoise process completed. Returning file: {}", resource.getFilename());
                    return ResponseEntity.ok()
                            .contentType(MediaType.APPLICATION_OCTET_STREAM)
                            .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
                            .body(resource);
                });
    }
    
    @GetMapping("/summary")
    public ResponseEntity<Flux<UserActivityCountDto>> totalResource(@RequestParam("startTime") Long startTime, @RequestParam("endTime") Long endTime, @AuthenticationPrincipal UserPrincipal user) {
        if(user.isAdmin()) {
            return ResponseEntity.ok(toolService.getUserActivityCount(startTime, endTime));
        }
        return ResponseEntity.badRequest().body(Flux.empty());
    }
}
