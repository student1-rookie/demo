package com.flex.ditto.service.transports;

import java.util.List;
import java.util.UUID;
import java.util.function.BiFunction;

import com.flex.ditto.common.RunningDevice;
import com.flex.ditto.domain.*;
import org.springframework.messaging.rsocket.RSocketRequester;

import com.flex.ditto.common.InferenceResult;
import com.flex.ditto.common.WorkSpace;
import com.flex.ditto.dto.InferenceMetaDto;
import com.flex.ditto.service.utils.ConvertUtils;

import reactor.core.publisher.Mono;

public class InferenceTTSRSocketTransport implements InferenceTransport {
    private final RSocketRequester rSocketRequester;
    private final InferenceRepository inferenceRepository;
    private final MetaHumanDatasetRepository metaHumanDatasetRepository;
    private final List<RunningDevice>  runningDevices;
    private final String createRoute;

    public InferenceTTSRSocketTransport(RSocketRequester rSocketRequester, InferenceRepository inferenceRepository,
                                        MetaHumanDatasetRepository metadataRepository, List<RunningDevice> runningDevices, String createRoute) {
        this.rSocketRequester = rSocketRequester;
        this.inferenceRepository = inferenceRepository;
        this.metaHumanDatasetRepository = metadataRepository;
        this.runningDevices = runningDevices;
        this.createRoute = createRoute;
    }

    @Override
    public Mono<Void> inference(InferenceMetaDto meta, TTSModel ttsModel, FaceModel faceModel, UUID accountId, WorkSpace workSpace,
                                Boolean isCluster) {
        return metaHumanDatasetRepository.findById(ttsModel.getDatasetId())
                .flatMap(w -> sendTask(meta, ttsModel, accountId,
                        (inference, dto) -> ConvertUtils.toInferenceCustomizedTTSTask(meta, inference, ttsModel, w, workSpace, isCluster)));
    }

    @Override
    public Mono<Void> createModel(Object task) {
        return rSocketRequester.route(createRoute).data(task).send();
    }

    @Override
    public List<RunningDevice> getRunningDevices() {
        return this.runningDevices;
    }

    private Mono<Void> sendTask(InferenceMetaDto dto, TTSModel ttsModel, UUID accountId, BiFunction<Inference, InferenceMetaDto, Object> taskCreator) {
        return inferenceRepository.save(new Inference(dto.getName(), accountId, null, ttsModel.getId(), InferenceResult.getResultType(dto.getType())))
                .flatMap(inference -> {
                    Object task = taskCreator.apply(inference, dto);
                    final String route = "fire-and-forget";
                    return rSocketRequester.route(route).data(task).send();
                });
    }
}
