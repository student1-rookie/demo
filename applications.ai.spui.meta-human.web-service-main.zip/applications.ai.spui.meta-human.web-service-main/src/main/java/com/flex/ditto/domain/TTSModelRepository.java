package com.flex.ditto.domain;

import com.flex.ditto.common.ModelStatus;
import com.flex.ditto.common.ResourceAccess;
import com.flex.ditto.dto.ModelListDto;
import io.r2dbc.postgresql.codec.Json;

import org.springframework.data.r2dbc.repository.Modifying;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.UUID;

public interface TTSModelRepository extends ReactiveCrudRepository<TTSModel, UUID> {

    @Query("SELECT * FROM meta_human_tts WHERE account_id = :accountId OR type = 'PUBLIC'")
    Flux<TTSModel> findByAccountId(UUID accountId);

    @Query("SELECT * FROM meta_human_tts WHERE name = :name AND ( account_id = :accountId OR type = 'PUBLIC' ) LIMIT 1")
    Mono<TTSModel> findByAccountIdAndName(UUID accountId, String name);

    @Query("SELECT * FROM meta_human_tts WHERE id = :id AND ( account_id = :accountId AND ( status NOT IN ( 'TRAIN', 'WAIT') ) )")
    Mono<TTSModel> findByIdAndStatus(UUID id, UUID accountId);

    @Query("SELECT * FROM meta_human_tts WHERE id = :id AND ( status NOT IN ( 'TRAIN', 'WAIT') )")
    Mono<TTSModel> findByIdAndStatus(UUID id);

    @Modifying
    @Query("UPDATE meta_human_tts SET name = :name WHERE id = :id AND account_id = :accountId")
    Mono<Integer> updateNameByIdAndAccountId(String name, UUID id, UUID accountId);

    @Modifying
    @Query("UPDATE meta_human_tts SET name = :name WHERE id = :id")
    Mono<Integer> updateNameById(String name, UUID id);

    @Query("UPDATE meta_human_tts SET type = :access WHERE id = :id AND account_id = :accountId")
    Mono<Void> updateTypeByIdAndAccountId(ResourceAccess access, UUID id, UUID accountId);

    @Query("UPDATE meta_human_tts SET type = :access WHERE id = :id")
    Mono<Void> updateTypeById(ResourceAccess access, UUID id);

    @Modifying
    @Query("UPDATE meta_human_tts SET account_id = :accountId WHERE id = :id")
    Mono<Long> updateAccountIdById(UUID accountId, UUID id);

    Mono<TTSModel> findByIdAndAccountId(UUID id, UUID accountId);

    @Query("SELECT meta_human_tts.*, account.email AS account_email, account.name AS account_username, " +
            "'TTS' AS base_type FROM meta_human_tts INNER JOIN account ON meta_human_tts.account_id = account.id " +
            "AND ( meta_human_tts.account_id = :accountId OR meta_human_tts.type = 'PUBLIC' )")
    Flux<ModelListDto> findModelAndUserById(UUID accountId);

    @Query("SELECT meta_human_tts.*, account.email AS account_email, account.name AS account_username, " +
            "'TTS' AS base_type FROM meta_human_tts INNER JOIN account ON meta_human_tts.account_id = account.id ")
    Flux<ModelListDto> findAllModels();

    Flux<TTSModel> findByAccountIdAndStatusIn(UUID id, List<ModelStatus> statuses);

    Flux<TTSModel> findByStatusNotIn(List<ModelStatus> statuses);

    @Query("UPDATE meta_human_tts SET status = :modelStatus, parameters = :parameters WHERE id = :id")
    Mono<Void> updateStatusAndParametersById(ModelStatus modelStatus, Json parameters, UUID id);

    @Query("UPDATE meta_human_tts SET parameters = :parameters WHERE id = :id")
    Mono<Void> updateParametersById(Json parameters, UUID id);

    @Query("UPDATE meta_human_tts SET status = :modelStatus WHERE id = :id")
    Mono<Void> updateStatusById(ModelStatus modelStatus, UUID id);

    @Query("SELECT meta_human_tts.id, meta_human_tts.model, meta_human_tts.status " +
            "FROM meta_human_tts WHERE id = :id")
    Mono<GenericModel> findGenericModelById(UUID id);

    @Query("SELECT meta_human_tts.id, meta_human_tts.model, meta_human_tts.status " +
            "FROM meta_human_tts WHERE id = :id AND account_id = :accountId")
    Mono<GenericModel> findGenericModelByIdAndAccountId(UUID id, UUID accountId);

    @Query("SELECT * FROM meta_human_tts WHERE id = :id AND ( account_id = :accountId OR type = 'PUBLIC')")
    Mono<TTSModel> findByIdAndCheckAccountId(UUID id, UUID accountId);
}
