package com.flex.ditto.common;

public enum Reuse {
    ALL, TTS, FACE
}