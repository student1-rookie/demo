package com.flex.ditto.service;

import com.flex.ditto.common.*;
import com.flex.ditto.common.inference.ClusterInferenceTTSTask;
import com.flex.ditto.common.inference.InferenceTTSTask;
import com.flex.ditto.common.parameter.VoicePromptParameter;
import com.flex.ditto.domain.*;
import com.flex.ditto.dto.*;
import com.flex.ditto.exception.ModelException;
import com.flex.ditto.service.utils.ConvertUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;
import reactor.util.function.Tuple2;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.ZonedDateTime;
import java.util.*;
import java.util.regex.Pattern;

@Slf4j
@Service
public class ModelService {

    @Value("${service.tts.example-text}")
    private String ttsExampleText;

    @Value("${app.mq.generic-routing-key:generic}")
    private String genericRoutingKey;

    @Autowired
    FaceModelRepository faceModelRepository;

    @Autowired
    TTSModelRepository ttsModelRepository;

    @Autowired
    MetaHumanDatasetRepository datasetRepository;

    @Autowired
    AsrService asrService;

    @Autowired
    ResourceService resourceService;

    @Autowired
    StorageService storageService;

    @Autowired
    private Map<String, CustomizedTTSService> customizedTTSServices;

    @Autowired
    private Map<String, CustomizedFaceService> customizedFaceServices;

    @Autowired
    InferenceTaskService inferenceTaskService;

    @Autowired
    NotificationService notificationService;

    private static final Map<MetaHumanModelType, List<Pattern>> PATTERN_MAP;

    static {
        PATTERN_MAP = new HashMap<>();
        PATTERN_MAP.put(MetaHumanModelType.BERTVITS, List.of(Pattern.compile("^\\./[A-Za-z0-9.-_]+/train_data/models/G_[0-9]+\\.pth$")));
        PATTERN_MAP.put(MetaHumanModelType.GPTSOVITS, List.of(
                Pattern.compile("^\\./[A-Za-z0-9._-]+/train_res/logs_s1_v4/weights/s1-e\\d+\\.ckpt$"),
                Pattern.compile("^\\./[A-Za-z0-9._-]+/train_res/.*\\.wav$"),
                Pattern.compile("^\\./[A-Za-z0-9._-]+/train_res/logs_s2_v4/weights/s2-e\\d+\\.pth$")));
        PATTERN_MAP.put(MetaHumanModelType.ERNERF, List.of(
                Pattern.compile("^\\./[A-Za-z0-9._-]+/train_data/au\\.csv$"),
                Pattern.compile("^\\./[A-Za-z0-9._-]+/train_data/bc\\.jpg$"),
                Pattern.compile("^\\./[A-Za-z0-9._-]+/train_data/first\\.jpg$"),
                Pattern.compile("^\\./[A-Za-z0-9._-]+/train_data/fps_25\\.mp4$"),
                Pattern.compile("^\\./[A-Za-z0-9._-]+/train_data/transforms_val\\.json$"),
                Pattern.compile("^\\./[A-Za-z0-9._-]+/train_data/transforms_train\\.json$"),
                Pattern.compile("^\\./[A-Za-z0-9._-]+/train_data/identity\\.npy$"),
                Pattern.compile("^\\./[A-Za-z0-9._-]+/train_data/checkpoints/.+$"),
                Pattern.compile("^\\./[A-Za-z0-9._-]+/train_data/checkpoint/.+$"),
                Pattern.compile("^\\./[A-Za-z0-9._-]+/train_data/face/.+$"),
                Pattern.compile("^\\./[A-Za-z0-9._-]+/train_data/gt_imgs/.+$"),
                Pattern.compile("^\\./[A-Za-z0-9._-]+/train_data/kpt/.+$"),
                Pattern.compile("^\\./[A-Za-z0-9._-]+/train_data/ori_imgs/.+$"),
                Pattern.compile("^\\./[A-Za-z0-9._-]+/train_data/parsing/.+$"),
                Pattern.compile("^\\./[A-Za-z0-9._-]+/train_data/torso_imgs/.+$")));
    }

    public Flux<ModelInfoDto> getModelInfo(UUID accountId, ModelType type) {
        if (type == ModelType.FACE) {
            return faceModelRepository.findByAccountId(accountId).map(x -> new ModelInfoDto(x.getName(), x.getType()));
        } else {
            return ttsModelRepository.findByAccountId(accountId).map(x -> new ModelInfoDto(x.getName(), x.getType()));
        }
    }

    public Mono<Tuple2<Optional<FaceModel>, Optional<TTSModel>>> getTaskModel(UUID accountId, Map<ModelType, UUID> models) {
        Mono<Optional<FaceModel>> faceModel = Mono.just(Optional.empty());
        if (models.containsKey(ModelType.FACE)) {
            faceModel = faceModelRepository.findByIdAndCheckAccountId(models.get(ModelType.FACE), accountId).singleOptional();
        }
        Mono<Optional<TTSModel>> ttsModel = Mono.just(Optional.empty());
        if (models.containsKey(ModelType.TTS)) {
            ttsModel = ttsModelRepository.findByIdAndCheckAccountId(models.get(ModelType.TTS), accountId).singleOptional();
        }
        return faceModel.zipWith(ttsModel);
    }

    public Mono<GenericModel> getDetailModelType(UUID accountId, UUID taskId, ModelType modelType, Boolean isAdmin) {
        if (modelType.equals(ModelType.FACE)) {
            if (isAdmin) {
                return faceModelRepository.findGenericModelById(taskId);
            }
            return faceModelRepository.findGenericModelByIdAndAccountId(taskId, accountId);
        } else {
            if (isAdmin) {
                return ttsModelRepository.findGenericModelById(taskId);
            }
            return ttsModelRepository.findGenericModelByIdAndAccountId(taskId, accountId);
        }
    }

    public Mono<MetaHumanDataset> getDatasetByIdentifier(String identifier, UUID accountId) {
        return datasetRepository.findByIdentifierAndAccountId(identifier, accountId).collectList().flatMap(
                d -> {
                    if (d.isEmpty()) {
                        return Mono.error(new Exception("Cannot find dataset!"));
                    }
                    return Mono.just(d.get(0));
                }
        );
    }

    public Flux<TrainTask> createModel(TrainMetaDto trainMetaDto, UUID accountId, MetaHumanDataset dataset) {
        final ResourceAccess resourceAccess = trainMetaDto.getType() ? ResourceAccess.PUBLIC : ResourceAccess.PRIVATE;
        return Flux.fromIterable(trainMetaDto.getModels()).flatMap(
                trainModelDto -> {
                    if (trainModelDto.getTask().equals(ModelType.FACE)) {
                        if (customizedFaceServices.containsKey(trainModelDto.getType())) {
                            return createCustomizedFaceModel(customizedFaceServices.get(trainModelDto.getType()), trainModelDto, accountId, dataset, trainMetaDto.getDate(), resourceAccess).thenMany(Flux.empty());
                        } else if (FaceModelType.valueOf(trainModelDto.getType()).isCustomized()) {
                            return Mono.error(new ModelException(String.format("Customized FACE service not found for model type: %s", trainModelDto.getType())));
                        }
                        return faceModelRepository.save(new FaceModel(trainModelDto.getName(), trainMetaDto.getDate(),
                                        resourceAccess, trainModelDto.getType(), trainModelDto.getParameters(),
                                        accountId, dataset.getId()))
                                .map(faceModel -> ConvertUtils.toTrainTask(faceModel, dataset, storageService.getWorkSpace(), resourceService.cluster()));
                    } else {
                        // handle customized tts
                        if (customizedTTSServices.containsKey(trainModelDto.getType())) {
                            return createCustomizedTTSModel(customizedTTSServices.get(trainModelDto.getType()), trainModelDto, accountId, dataset, trainMetaDto.getDate(), resourceAccess, ttsExampleText).thenMany(Flux.empty());
                        } else if (TTSModelType.valueOf(trainModelDto.getType()).isCustomized()) {
                            return Mono.error(new ModelException(String.format("Customized TTS service not found for model type: %s", trainModelDto.getType())));
                        }
                        return ttsModelRepository.save(new TTSModel(trainModelDto.getName(), trainMetaDto.getDate(),
                                        resourceAccess, trainModelDto.getType(), trainModelDto.getParameters(),
                                        accountId, dataset.getId()))
                                .map(ttsModel -> ConvertUtils.toTrainTask(ttsModel, dataset, storageService.getWorkSpace(), resourceService.cluster(), ttsExampleText));
                    }
                }
        );
    }

    public Mono<VoicePromptParameter> generatePrompt(float cutDuration, UUID accountId, MetaHumanDataset dataset) {
        if (!dataset.getText().isEmpty()) {
            return Mono.just(new VoicePromptParameter(cutDuration, dataset.getText()));
        }
        var sentenceFlux = storageService.isCluster() ? asrService.clusterAsr(dataset, storageService.getWorkSpace()) : resourceService.getResourceFile(dataset, accountId).flatMapMany(resource ->
                asrService.asr(resource, dataset.getFileType()));
        return sentenceFlux.collectList().flatMap(sentences -> {
            if (sentences.isEmpty()) {
                log.info("sentences is empty for {}", dataset.getId());
                return Mono.just(new VoicePromptParameter());
            }

            VoicePromptParameter parameter = new VoicePromptParameter(cutDuration, sentences);
            dataset.setText(sentences);
            return datasetRepository.save(dataset)
                    .thenReturn(parameter);
        });
    }

    private Mono<TTSModel> createCustomizedTTSModel(CustomizedTTSService ttsService, TrainModelDto trainModelDto, UUID accountId, MetaHumanDataset dataset, ZonedDateTime date, ResourceAccess resourceAccess, String exampleText) {
        VoicePromptParameter voicePromptParameter;
        if (ttsService.needPrompt()) {
           voicePromptParameter = trainModelDto.getVoicePromptParameter();
            if (voicePromptParameter == null) {
                return Mono.error(new Exception("VoicePromptParameter is null!"));
            }

            var datasetText = dataset.getText();
            var cvParamText = voicePromptParameter.getText();

            if (cvParamText.isEmpty() && !datasetText.isEmpty()) {
                voicePromptParameter.update(datasetText);
            }
        }
        else {
            var datasetText = dataset.getText();
            voicePromptParameter = new VoicePromptParameter(ttsService.cutDuration());
            if (!datasetText.isEmpty()) {
                voicePromptParameter.update(datasetText);
            }
        }

        if (!voicePromptParameter.getText().isEmpty()) {
            return ttsModelRepository.save(
                    new TTSModel(trainModelDto.getName(), date, resourceAccess, ModelStatus.INIT,
                            trainModelDto.getType(), voicePromptParameter.toJson(), accountId, dataset.getId())
            ).flatMap(ttsModel -> ttsService.createModel(ttsModel, dataset, voicePromptParameter, false, storageService.getWorkSpace(), storageService.isCluster(), exampleText).thenReturn(ttsModel));
        }

        var model = ttsModelRepository.save(new TTSModel(trainModelDto.getName(), date, resourceAccess,
                ModelStatus.TRAIN, trainModelDto.getType(), "{}", accountId, dataset.getId()));
        return model.publishOn(Schedulers.boundedElastic()).map(
                ttsModel -> {
                    if (storageService.isCluster()) {
                        asrService.clusterAsr(dataset, storageService.getWorkSpace()).collectList().flatMap(
                                sentences -> saveCustomizedTTSModel(ttsService, sentences, dataset, voicePromptParameter, ttsModel, exampleText)
                        ).onErrorResume(
                                e -> ttsModelRepository.updateStatusById(ModelStatus.FAIL, ttsModel.getId()).then(Mono.error(e))
                        ).subscribe();
                    } else {
                        resourceService.getResourceFile(dataset, accountId).flatMap(resource ->
                                asrService.asr(resource, dataset.getFileType()).collectList().flatMap(
                                        sentences -> saveCustomizedTTSModel(ttsService, sentences, dataset, voicePromptParameter, ttsModel, exampleText)
                                ).onErrorResume(
                                        e -> ttsModelRepository.updateStatusById(ModelStatus.FAIL, ttsModel.getId()).then(Mono.error(e))
                                )
                        ).subscribe();
                    }
                    return ttsModel;
                }
        );
    }

    private Mono<Void> saveCustomizedTTSModel(CustomizedTTSService ttsService, List<Sentence> sentences, MetaHumanDataset dataset, VoicePromptParameter voicePromptParameter, TTSModel ttsModel, String exampleText) {
        if (sentences.isEmpty()) {
            log.info("sentences is empty for {}", dataset.getId());
            return ttsModelRepository.updateStatusById(ModelStatus.FAIL, ttsModel.getId()).then(Mono.error(new Exception("Sentences is null!")));
        }
        dataset.setText(sentences);
        voicePromptParameter.update(sentences);
        // update sentences into dataset
        // update model status and parameters
        return datasetRepository.save(dataset)
                .flatMap(dataset1 -> ttsService.createModel(ttsModel, dataset1, voicePromptParameter, true, storageService.getWorkSpace(), storageService.isCluster(), exampleText));
    }

    private Mono<FaceModel> createCustomizedFaceModel(CustomizedFaceService faceService, TrainModelDto trainModelDto, UUID accountId, MetaHumanDataset dataset, ZonedDateTime date, ResourceAccess resourceAccess) {
        return faceModelRepository.save(new FaceModel(trainModelDto.getName(), date,
                resourceAccess, ModelStatus.INIT, trainModelDto.getType(), trainModelDto.getParameters(),
                accountId, dataset.getId())).flatMap(faceModel -> faceService.createModel(faceModel, dataset, storageService.getWorkSpace(), storageService.isCluster()).thenReturn(faceModel));
    }

    public Mono<ModelDetailsDto> getModelStatus(ModelDto modelDto) {
        if (modelDto.type().equals(ModelType.FACE)) {
            return faceModelRepository.findById(modelDto.id())
                    .map(faceModel -> faceModel.getModelDetail().toModelDetailsDto(faceModel.getStatus()));
        }
        return ttsModelRepository.findById(modelDto.id())
                .map(ttsModel -> ttsModel.getModelDetail().toModelDetailsDto(ttsModel.getStatus()));
    }

    public Mono<Void> updateModelStatus(UUID id, ModelType modelType, ModelStatus modelStatus) {
        if (modelType.equals(ModelType.FACE)) {
            return faceModelRepository.updateStatusById(modelStatus, id);
        }
        return ttsModelRepository.updateStatusById(modelStatus, id);
    }

    public Flux<ModelListDto> listModels(UUID accountID) {
        return Flux.merge(faceModelRepository.findModelAndUserById(accountID),
                        ttsModelRepository.findModelAndUserById(accountID))
                .sort(Comparator.comparing(ModelListDto::getDate));
    }

    public Flux<ModelListDto> listModels() {
        return Flux.merge(
                        faceModelRepository.findAllModels(),
                        ttsModelRepository.findAllModels()
                )
                .sort(Comparator.comparing(ModelListDto::getDate));
    }

    public Mono<Integer> renameModel(UUID id, String newName, ModelType type, UUID accountId) {
        Mono<Integer> updatedRes;
        if (type == ModelType.FACE) {
            return faceModelRepository.findByIdAndAccountId(id, accountId)
                    .switchIfEmpty(Mono.error(new ModelException("Model not found ID: " + id)))
                    .then(faceModelRepository.updateNameByIdAndAccountId(newName, id, accountId));
        } else if (type == ModelType.TTS) {
            return ttsModelRepository.findByIdAndAccountId(id, accountId)
                    .switchIfEmpty(Mono.error(new ModelException("Model not found ID: " + id)))
                    .then(ttsModelRepository.updateNameByIdAndAccountId(newName, id, accountId));
        } else {
            return Mono.error(new ModelException("Invalid MetaHuman model type"));
        }
    }

    public Mono<Void> renameModel(UUID id, String newName, ModelType type) {
        Mono<Integer> updatedRes;
        if (type == ModelType.FACE) {
            updatedRes = faceModelRepository.updateNameById(newName, id);
        } else if (type == ModelType.TTS) {
            updatedRes = ttsModelRepository.updateNameById(newName, id);
        } else {
            return Mono.error(new ModelException("Invalid MetaHuman model type"));
        }

        return updatedRes.flatMap(updatedRows -> {
            if (updatedRows > 0) {
                return Mono.empty();
            } else {
                return Mono.error(new ModelException("Model not found ID: " + id));
            }
        });
    }

    public Mono<Void> changeAccess(UUID id, ResourceAccess access, ModelType type, UUID accountId, Boolean isAdmin) {
        if (type == ModelType.FACE) {
            var faceModelMono = isAdmin ? faceModelRepository.findById(id) : faceModelRepository.findByIdAndAccountId(id, accountId);
            return faceModelMono
                    .switchIfEmpty(Mono.error(new ModelException("Model not found ID: " + id)))
                    .flatMap(faceModel -> {
                                if (faceModel.getStatus() != ModelStatus.COMPLETE) {
                                    return Mono.error(new ModelException("Cannot change access: face model is not in COMPLETE status"));
                                } else if (!faceModel.getType().equals(access)) {
                                    if (access.equals(ResourceAccess.PUBLIC)) {
                                        return storageService.mvModelPublic(faceModel).then(faceModelRepository.updateTypeById(access, id));
                                    }
                                    return storageService.mvModel(accountId, faceModel).then(faceModelRepository.updateTypeById(access, id));
                                }
                                return Mono.empty();
                            }
                    );
        } else if (type == ModelType.TTS) {
            var ttsModelMono = isAdmin ? ttsModelRepository.findById(id) : ttsModelRepository.findByIdAndAccountId(id, accountId);
            return ttsModelMono
                    .switchIfEmpty(Mono.error(new ModelException("Model not found ID: " + id)))
                    .flatMap(ttsModel -> {
                                if (ttsModel.getStatus() != ModelStatus.COMPLETE) {
                                    return Mono.error(new ModelException("Cannot change access: tts model is not in COMPLETE status"));
                                } else if (!ttsModel.getType().equals(access)) {
                                    if (access.equals(ResourceAccess.PUBLIC)) {
                                        return storageService.mvModelPublic(ttsModel).then(ttsModelRepository.updateTypeById(access, id));
                                    }
                                    return storageService.mvModel(accountId, ttsModel).then(ttsModelRepository.updateTypeById(access, id));
                                }
                                return Mono.empty();
                            }
                    );
        } else {
            return Mono.error(new ModelException("Invalid MetaHuman model type"));
        }
    }

    public Mono<Void> changeAccessList(ModelTableDto modelTableDto, UUID accountId, Boolean isAdmin) {
        Flux<Void> ttsModelFlux = Flux.fromIterable(modelTableDto.getTtsModelIds())
            .flatMap(ttsModelId -> changeAccess(ttsModelId, modelTableDto.getAccess(), ModelType.TTS, accountId, isAdmin));
        Flux<Void> faceModelFlux = Flux.fromIterable(modelTableDto.getFaceModelIds())
            .flatMap(faceModelId -> changeAccess(faceModelId, modelTableDto.getAccess(), ModelType.FACE, accountId, isAdmin));

        return Flux.merge(ttsModelFlux, faceModelFlux).then();
    }

    public Mono<Long> changeOwner(UUID id, UUID owner, ModelType type) {
        if (type == ModelType.FACE) {
            return faceModelRepository.findById(id)
                    .switchIfEmpty(Mono.error(new ModelException("Model not found ID: " + id)))
                    .flatMap(faceModel -> {
                        if (faceModel.getStatus() != ModelStatus.COMPLETE) {
                            return Mono.error(new ModelException("Cannot change owner: face model is not in COMPLETE status"));
                        }
                        return storageService.mvModel(owner, faceModel).then(faceModelRepository.updateAccountIdById(owner, id));
                    });
        } else if (type == ModelType.TTS) {
            return ttsModelRepository.findById(id)
                    .switchIfEmpty(Mono.error(new ModelException("Model not found ID: " + id)))
                    .flatMap(ttsModel -> {
                        if (ttsModel.getStatus() != ModelStatus.COMPLETE) {
                            return Mono.error(new ModelException("Cannot change owner: tts model is not in COMPLETE status"));
                        }
                        return storageService.mvModel(owner, ttsModel).then(ttsModelRepository.updateAccountIdById(owner, id));
                    });
        } else {
            return Mono.error(new ModelException("Invalid MetaHuman model type"));
        }
    }

    public Mono<Void> changeOwnerList(ModelTableDto modelTableDto) {
        Flux<Void> ttsModelFlux = Flux.fromIterable(modelTableDto.getTtsModelIds())
            .flatMap(ttsModelId -> changeOwner(ttsModelId, modelTableDto.getOwner(), ModelType.TTS).then());
        Flux<Void> faceModelFlux = Flux.fromIterable(modelTableDto.getFaceModelIds())
            .flatMap(faceModelId -> changeOwner(faceModelId, modelTableDto.getOwner(), ModelType.FACE).then());

        return Flux.merge(ttsModelFlux, faceModelFlux).then();
    }

    public Flux<TrainingModelsDto> getMyTrainingModels(UUID accountId) {
        Flux<TrainingModelsDto> faceTraining = faceModelRepository.findByAccountIdAndStatusIn(accountId, List.of(ModelStatus.WAIT, ModelStatus.TRAIN, ModelStatus.CANCEL)).map(
                f -> TrainingModelsDto.builder().id(f.getId()).name(f.getName()).date(f.getDate()).status(f.getStatus()).type(ModelType.FACE).build());
        Flux<TrainingModelsDto> TTSTraining = ttsModelRepository.findByAccountIdAndStatusIn(accountId, List.of(ModelStatus.WAIT, ModelStatus.TRAIN, ModelStatus.CANCEL)).map(
                f -> TrainingModelsDto.builder().id(f.getId()).name(f.getName()).date(f.getDate()).status(f.getStatus()).type(ModelType.TTS).build());
        return Flux.merge(faceTraining, TTSTraining).sort(Comparator.comparing(TrainingModelsDto::date).reversed());
    }

    public Mono<ResponseEntity<Object>> uploadModel(UploadModelDto modelInfo, FilePart file, UUID userId) {
        return Mono.using(
                () -> Files.createTempFile("upload", ".tmp"),
                tempFile -> file.transferTo(tempFile)
                        .then(checkModelFile(modelInfo, tempFile, userId))
                        .map(modelId -> ResponseEntity.ok().body(modelId)),
                tempFile -> {
                    try {
                        Files.deleteIfExists(tempFile);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
        );
    }

    private Mono<UUID> checkModelFile(UploadModelDto modelInfo, Path file, UUID userId) {
        List<Pattern> rules = PATTERN_MAP.getOrDefault(modelInfo.getSubType(), null);
        if (rules == null || rules.isEmpty()) {
            return Mono.error(new IllegalArgumentException("invalid type!"));
        }
        return Mono.fromCallable(() -> {
                    Set<Pattern> matched = new HashSet<>();
                    byte[] previewImageBytes = new byte[0];
                    try (InputStream is = Files.newInputStream(file);
                         GzipCompressorInputStream gzip = new GzipCompressorInputStream(is);
                         TarArchiveInputStream ti = new TarArchiveInputStream(gzip)) {
                        TarArchiveEntry entry;
                        while ((entry = ti.getNextEntry()) != null) {
                            if (entry.isDirectory()) continue;
                            String name = entry.getName();
                            for (Pattern rule : rules) {
                                if (rule.matcher(name).matches()) {
                                    matched.add(rule);
                                    if (modelInfo.getSubType().isFaceModelType()) {
                                        if (rule.pattern().equals("^\\./[A-Za-z0-9._-]+/train_data/first\\.jpg$")) {
                                            previewImageBytes = ti.readAllBytes();
                                        }
                                    }
                                    break;
                                }
                            }
                        }
                        if (matched.size() != rules.size()) {
                            throw new IllegalArgumentException("missing required files!");
                        }
                    } catch (IOException e) {
                        throw new IOException("Failed to process archive: " + e.getMessage());
                    }
                    return previewImageBytes;
                })
                .flatMap(previewImageBytes -> {
                    return addModelFromUser(modelInfo, userId)
                            .flatMap(modelId -> {
                                Mono<Void> uploadModelMono = storageService.uploadModel(modelInfo, file, modelId, userId, previewImageBytes);
                                if (modelInfo.getSubType().isFaceModelType()) {
                                    return uploadModelMono
                                            .then(notificationService.publishNotify(userId, "[Train-face] " + modelInfo.getName() + " is complete", ModelStatus.COMPLETE))
                                            .then(faceModelRepository.updateStatusById(ModelStatus.COMPLETE, modelId))
                                            .thenReturn(modelId)
                                            .onErrorResume(e ->
                                                    faceModelRepository.updateStatusById(ModelStatus.FAIL, modelId).
                                                    then(notificationService.publishNotify(userId, "[Train-face] " + modelInfo.getName() + " is fail", ModelStatus.FAIL)).then(Mono.error(e))
                                            );
                                }
                                return uploadModelMono
                                        .doOnSuccess(ignored -> createExampleWav(modelId, userId).subscribe())
                                        .thenReturn(modelId);
                            });
                });
    }

    private Mono<Void> createExampleWav(UUID modelId, UUID accountId) {
        return ttsModelRepository.findByIdAndAccountId(modelId, accountId).flatMap(ttsModel -> {
            InferenceTTSTask ttsTask = ConvertUtils.toInferenceTTSExampleTask(accountId, modelId, ttsModel, ttsExampleText, storageService.getWorkSpace(), storageService.isCluster());
            if (ttsModel.getType().equals(ResourceAccess.PUBLIC)) {
                ClusterInferenceTTSTask task = (ClusterInferenceTTSTask) ttsTask;
                task.setUserBucket(storageService.getWorkSpace().getPublicBucket());
            }
            return inferenceTaskService.pubInferTask(ttsTask, ttsTask.getId(), genericRoutingKey);
        });
    }

    private Mono<UUID> addModelFromUser(UploadModelDto modelInfo, UUID userId) {
        if (modelInfo.getSubType().isTTSModelType()) {
            return ttsModelRepository.save(new TTSModel(modelInfo.getName(), modelInfo.getCreated(), modelInfo.getAccess(),
                            ModelStatus.INIT, modelInfo.getSubType().name(), "{}", userId, null))
                    .map(TTSModel::getId);
        } else {
            return faceModelRepository.save(new FaceModel(modelInfo.getName(), modelInfo.getCreated(), modelInfo.getAccess(),
                            ModelStatus.INIT, modelInfo.getSubType().name(), "{}", userId, null))
                    .map(FaceModel::getId);
        }
    }

    public Mono<Resource> getFailModel(UUID modelId, ModelType modelType) {
        if (modelType.equals(ModelType.TTS)) {
            return ttsModelRepository.findById(modelId).flatMap(ttsModel -> storageService.loadFailTaskFile(ttsModel.getAccountId(), ttsModel.getId(), ttsModel.getType()));
        } else {
            return faceModelRepository.findById(modelId).flatMap(faceModel ->  storageService.loadFailTaskFile(faceModel.getAccountId(), faceModel.getId(), faceModel.getType()));
        }
    }
}
