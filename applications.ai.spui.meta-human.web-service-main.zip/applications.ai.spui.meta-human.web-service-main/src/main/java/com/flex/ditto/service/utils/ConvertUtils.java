package com.flex.ditto.service.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.flex.ditto.common.*;
import com.flex.ditto.common.inference.*;
import com.flex.ditto.domain.*;
import com.flex.ditto.dto.InferenceMetaDto;
import com.flex.ditto.dto.InferencePicInPicTaskDto;
import com.flex.ditto.dto.ResourceMetaDto;
import com.flex.ditto.exception.InferenceException;

import io.r2dbc.postgresql.codec.Json;

import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;
import java.util.function.Function;

public class ConvertUtils {

    public static MetaHumanDataset toDataset(ResourceMetaDto dto, String fileName, UUID account, String identifier, UUID groupId, Boolean internal) {
        String[] nameParts = dto.getDatasetName().split("\\.", 2);
        MetaHumanDataset metaHumanDataset = new MetaHumanDataset();
        metaHumanDataset.setName(nameParts[0]);
        metaHumanDataset.setDate(dto.getDate());
        metaHumanDataset.setFileName(checkFileName(fileName, dto.getFileType().toString()));
        metaHumanDataset.setIdentifier(identifier);
        metaHumanDataset.setFileType(dto.getFileType());
        metaHumanDataset.setType(dto.getType() ? ResourceAccess.PUBLIC : ResourceAccess.PRIVATE);
        metaHumanDataset.setAccountID(dto.getType() ? null : account);
        metaHumanDataset.setGroupID(groupId);
        metaHumanDataset.setInternal(internal);
        return metaHumanDataset;
    }

    public static String checkFileName(String fileName, String fileType) {
        if (fileName.contains(".")) {
            return fileName;
        }
        String suffix = switch (fileType) {
            case "AUDIO" -> ".wav";
            case "VIDEO" -> ".mp4";
            default -> "";
        };
        return fileName + suffix;
    }

    public static TrainTask toTrainTask(FaceModel faceModel, MetaHumanDataset dataset, WorkSpace workSpace, boolean isCluster) {
        final String faceTaskId = toModelBucket(faceModel.getId());
        String targetService = getTargetServiceByParameters(faceModel.getParameters(), "targetService");
        String device = getTargetServiceByParameters(faceModel.getParameters(), "device");
        RunningDevice runningDevice = "".equals(device) ? RunningDevice.ANY : RunningDevice.valueOf(device);
        if (isCluster) {
            return collectDetails((extra) ->
                            ClusterTrainTask.builder().id(faceTaskId)
                                    .name(faceModel.getName())
                                    .dataset(MinIOConvertUtils.toDatasetXPath(dataset, workSpace))
                                    .task(ModelType.FACE.name().toLowerCase())
                                    .model(faceModel.getModelType().name())
                                    .extra(extra)
                                    .userBucket(MinIOConvertUtils.toUserBucket(faceModel, workSpace))
                                    .workSpace(workSpace)
                                    .device(runningDevice)
                                    .targetService(targetService)
                                    .account_id(faceModel.getAccountId())
                                    .build(),
                    List.of(faceModel.getDetails(), workSpace.getExtra()));
        }
        return collectDetails((extra) -> new TrainTask(faceTaskId, faceModel.getName(), dataset.getDatasetPath(), ModelType.FACE.name().toLowerCase(), faceModel.getModelType().name(), extra, faceModel.getAccountId(), runningDevice),
                List.of(faceModel.getDetails()));
    }

    public static String getTargetServiceByParameters(Json paramJson, String fieldName) {
        ObjectMapper mapper = new ObjectMapper();
        JsonNode paramsNode;
        try {
            paramsNode = mapper.readTree(paramJson.asString());
        } catch (JsonMappingException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to parse parameters: ", e);           
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to parse parameters: ", e);
        }
        JsonNode fieldValue = paramsNode.get(fieldName);
        return fieldValue != null ? fieldValue.asText() : "";
    }

    public static TrainTask toTrainTask(TTSModel ttsModel, MetaHumanDataset dataset, WorkSpace workSpace, boolean isCluster, String exampleText) {
        final String ttsTaskId = toModelBucket(ttsModel.getId());
        String targetService = getTargetServiceByParameters(ttsModel.getParameters(), "targetService");
        if (isCluster) {
            return collectDetails((extra) ->
                            ClusterTrainTask.builder().id(ttsTaskId)
                                    .name(ttsModel.getName())
                                    .dataset(MinIOConvertUtils.toDatasetXPath(dataset, workSpace))
                                    .task(ModelType.TTS.name().toLowerCase())
                                    .model(ttsModel.getModelType().name())
                                    .extra(extra)
                                    .userBucket(MinIOConvertUtils.toUserBucket(ttsModel, workSpace))
                                    .workSpace(workSpace)
                                    .device(RunningDevice.ANY)
                                    .targetService(targetService)
                                    .account_id(ttsModel.getAccountId())
                                    .build(),
                    List.of(ttsModel.getParameterDetails(), Map.of("exampleText", exampleText), workSpace.getExtra()));
        }
        return collectDetails((extra) -> new TrainTask(ttsTaskId, ttsModel.getName(), dataset.getDatasetPath(), ModelType.TTS.name().toLowerCase(), ttsModel.getModelType().name(), extra, ttsModel.getAccountId(), RunningDevice.ANY),
                List.of(ttsModel.getParameterDetails(), Map.of("exampleText", exampleText)));
    }

    public static InferencePicInPicTask toInferencePicInPicTask(InferencePicInPicTaskDto inferencePicInPicTaskDto, List<MetaHumanDataset> metaHumanDatasets, Inference inference, FaceModel faceModel, TTSModel ttsModel, Map<String, Object> extraInfo, WorkSpace workSpace, boolean isCluster, String groupId) {
        final String inferenceTaskId = toModelBucket(inference.getId());
        Map<String, Object> faceModelDetails = faceModel == null ? Collections.emptyMap() : faceModel.getDetails();
        if (isCluster) {
            return collectDetails((extra) ->
                            ClusterInferencePicInPicTask.builder().id(inferenceTaskId)
                                    .name(inferencePicInPicTaskDto.getName())
                                    .input(inferencePicInPicTaskDto.getTaskInput(metaHumanDatasets, workSpace, isCluster))
                                    .background(inferencePicInPicTaskDto.getBackgroundImage())
                                    .face_model(faceModel != null ? MinIOConvertUtils.toModelXPath(faceModel, workSpace) : null)
                                    .tts_model(MinIOConvertUtils.toModelXPath(ttsModel, workSpace))
                                    .pic_in_pic(Boolean.TRUE)
                                    .account_id(inference.getAccountId())
                                    .groupId(groupId)
                                    .extra(extra)
                                    .userBucket(MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), inference.getAccountId()))
                                    .workSpace(workSpace)
                                    .device(inferencePicInPicTaskDto.getDevice() == null ? RunningDevice.ANY : inferencePicInPicTaskDto.getDevice())
                                    .targetService("")
                                    .type(inferencePicInPicTaskDto.getType())
                                    .build(),
                    List.of(faceModelDetails, ttsModel.getParameterDetails(), inferencePicInPicTaskDto.getExtraInfo(), workSpace.getExtra(), extraInfo));
        }
        return collectDetails((extra) -> new InferencePicInPicTask(inferenceTaskId, inferencePicInPicTaskDto.getName(), inferencePicInPicTaskDto.getTaskInput(metaHumanDatasets, workSpace, isCluster), inferencePicInPicTaskDto.getBackgroundImage(), faceModel != null ? toModelBucket(faceModel.getId()) : null, toModelBucket(ttsModel.getId()),
                        Boolean.TRUE, inference.getAccountId(), groupId, extra, inferencePicInPicTaskDto.getType()),
                List.of(faceModelDetails, ttsModel.getParameterDetails(), inferencePicInPicTaskDto.getExtraInfo(), extraInfo));
    }

    public static InferenceWholeTask toInferenceWholeTask(InferenceMetaDto dto, Inference inference, FaceModel faceModel, TTSModel ttsModel, Map<String, Object> extraInfo, WorkSpace workSpace, boolean isCluster) {
        final String inferenceTaskId = toModelBucket(inference.getId());
        if (isCluster) {
            return collectDetails((extra) ->
                            ClusterInferenceWholeTask.builder().id(inferenceTaskId)
                                    .name(dto.getName())
                                    .text(dto.getText())
                                    .face_model(MinIOConvertUtils.toModelXPath(faceModel, workSpace))
                                    .tts_model(MinIOConvertUtils.toModelXPath(ttsModel, workSpace))
                                    .type(dto.getType())
                                    .extra(extra)
                                    .userBucket(MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), inference.getAccountId()))
                                    .workSpace(workSpace)
                                    .device(dto.getDevice() == null ? RunningDevice.ANY : dto.getDevice())
                                    .targetService(dto.getRoutingKey())
                                    .account_id(inference.getAccountId())
                                    .build(),
                    List.of(faceModel.getDetails(), ttsModel.getParameterDetails(), dto.getExtraInfo(), workSpace.getExtra(), extraInfo));
        }
        return collectDetails((extra) -> new InferenceWholeTask(inferenceTaskId, dto.getName(), dto.getText(), toModelBucket(faceModel.getId()), toModelBucket(ttsModel.getId()), dto.getType(), extra, inference.getAccountId()),
                List.of(faceModel.getDetails(), ttsModel.getParameterDetails(), dto.getExtraInfo(), extraInfo));
    }

    public static InferenceCustomizedTTSTask toInferenceCustomizedTTSTask(InferenceMetaDto dto, Inference inference, TTSModel ttsModel, MetaHumanDataset dataset, WorkSpace workSpace, boolean isCluster) {
        final String inferenceTaskId = toModelBucket(inference.getId());
        if (isCluster) {
            return collectDetails((extra) ->
                            ClusterInferenceCustomizedTask.builder().id(inferenceTaskId)
                                    .name(dto.getName())
                                    .text(dto.getText())
                                    .wav_path(MinIOConvertUtils.toDatasetXPath(dataset, workSpace))
                                    .type(dto.getType())
                                    .extra(extra)
                                    .userBucket(MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), inference.getAccountId()))
                                    .workSpace(workSpace)
                                    .device(dto.getDevice() == null ? RunningDevice.ANY : dto.getDevice())
                                    .targetService("")
                                    .account_id(inference.getAccountId())
                                    .build(),
                    List.of(ttsModel.getParameterDetails(), dto.getExtraInfo(), workSpace.getExtra()));
        }
        return collectDetails((extra) -> new InferenceCustomizedTTSTask(inferenceTaskId, dto.getName(),
                        dto.getText(), dataset.getDatasetPath(), dto.getType(), extra, inference.getAccountId()),
                List.of(ttsModel.getParameterDetails(), dto.getExtraInfo()));
    }

    public static InferenceCustomizedTTSTask toCustomizedTTSCreateTask(TTSModel ttsModel, MetaHumanDataset dataset, WorkSpace workSpace, Boolean isCluster, String exampleText) {
        final String modelId = toModelBucket(ttsModel.getId());
        if (isCluster) {
            return ClusterInferenceCustomizedTask.builder()
                    .id(modelId)
                    .name("example")
                    .text(exampleText)
                    .wav_path(MinIOConvertUtils.toDatasetXPath(dataset, workSpace))
                    .type(InferenceType.TTS_EXAMPLE)
                    .userBucket(MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), ttsModel.getAccountId()))
                    .workSpace(workSpace)
                    .device(RunningDevice.ANY)
                    .targetService("")
                    .build();
        }
        return InferenceCustomizedTTSTask.builder()
                .id(modelId)
                .name("example")
                .text(exampleText)
                .wav_path(dataset.getDatasetPath())
                .type(InferenceType.TTS_EXAMPLE)
                .build();
    }

    public static InferenceFaceTask toInferenceFaceTask(InferenceMetaDto inferenceMetaDto, Inference inference, FaceModel faceModel, MetaHumanDataset dataset, WorkSpace workSpace, boolean isCluster) {
        final String faceTaskId = toModelBucket(inference.getId());
        if (isCluster) {
            return collectDetails((extra) ->
                            ClusterInferenceFaceTask.builder().id(faceTaskId)
                                    .name(inferenceMetaDto.getName())
                                    .wav(MinIOConvertUtils.toDatasetXPath(dataset, workSpace))
                                    .face_model(MinIOConvertUtils.toModelXPath(faceModel, workSpace))
                                    .type(inferenceMetaDto.getType())
                                    .extra(extra)
                                    .userBucket(MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), inference.getAccountId()))
                                    .workSpace(workSpace)
                                    .device(inferenceMetaDto.getDevice() == null ? RunningDevice.ANY : inferenceMetaDto.getDevice())
                                    .targetService(inferenceMetaDto.getRoutingKey())
                                    .account_id(inference.getAccountId())
                                    .build(),
                    List.of(faceModel.getDetails(), inferenceMetaDto.getExtraInfo(), workSpace.getExtra()));
        }
        return collectDetails((extra) -> new InferenceFaceTask(faceTaskId, inferenceMetaDto.getName(), dataset.getDatasetPath(), toModelBucket(faceModel.getId()), inferenceMetaDto.getType(), extra, inference.getAccountId()),
                List.of(faceModel.getDetails(), inferenceMetaDto.getExtraInfo()));
    }

    public static InferenceLatentSyncFaceTask toInferenceLatentSyncFaceTask(InferenceMetaDto inferenceMetaDto, Inference inference, FaceModel faceModel, MetaHumanDataset wav, MetaHumanDataset video, WorkSpace workSpace, boolean isCluster) {
        final String inferenceTaskId = toModelBucket(inference.getId());
        if (isCluster) {
            return collectDetails((extra) ->
                            ClusterInferenceLatentSyncTask.builder().id(inferenceTaskId)
                                    .name(inferenceMetaDto.getName())
                                    .audio_path(MinIOConvertUtils.toDatasetXPath(wav, workSpace))
                                    .video_path(MinIOConvertUtils.toDatasetXPath(video, workSpace))
                                    .face_model(MinIOConvertUtils.toModelXPath(faceModel, workSpace))
                                    .type(inferenceMetaDto.getType())
                                    .extra(extra)
                                    .userBucket(MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), inference.getAccountId()))
                                    .workSpace(workSpace)
                                    .device(RunningDevice.ANY)
                                    .targetService("")
                                    .account_id(inference.getAccountId())
                                    .build(),
                    List.of(faceModel.getDetails(), inferenceMetaDto.getExtraInfo(), workSpace.getExtra()));
        }
        return collectDetails((extra) -> new InferenceLatentSyncFaceTask(inferenceTaskId, inferenceMetaDto.getName(), wav.getDatasetPath(), video.getDatasetPath(), toModelBucket(faceModel.getId()), inferenceMetaDto.getType(), extra, inference.getAccountId()),
                List.of(faceModel.getDetails(), inferenceMetaDto.getExtraInfo()));
    }

    public static InferenceTTSTask toInferenceTTSTask(InferenceMetaDto inferenceMetaDto, Inference inference, TTSModel ttsModel, WorkSpace workSpace, boolean isCluster) {
        final String ttsTaskId = toModelBucket(inference.getId());
        if (isCluster) {
            return collectDetails((extra) ->
                            ClusterInferenceTTSTask.builder().id(ttsTaskId)
                                    .name(inferenceMetaDto.getName())
                                    .text(inferenceMetaDto.getText())
                                    .tts_model(MinIOConvertUtils.toModelXPath(ttsModel, workSpace))
                                    .type(inferenceMetaDto.getType())
                                    .extra(extra)
                                    .userBucket(MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), inference.getAccountId()))
                                    .workSpace(workSpace)
                                    .device(RunningDevice.ANY)
                                    .targetService(inferenceMetaDto.getRoutingKey())
                                    .account_id(inference.getAccountId())
                                    .build(),
                    List.of(ttsModel.getParameterDetails(), inferenceMetaDto.getExtraInfo(), workSpace.getExtra()));
        }
        return collectDetails((extra) -> new InferenceTTSTask(ttsTaskId, inferenceMetaDto.getName(), inferenceMetaDto.getText(), toModelBucket(ttsModel.getId()), inferenceMetaDto.getType(), extra, inference.getAccountId()),
                List.of(ttsModel.getParameterDetails(), inferenceMetaDto.getExtraInfo()));
    }

    public static InferenceTTSTask toInferenceTTSExampleTask(UUID accountId, UUID modelId, TTSModel ttsModel, String ttsExampleText, WorkSpace workSpace, boolean isCluster) {
        final String ttsTaskId = toModelBucket(modelId);
        if (isCluster) {
            return collectDetails((extra) ->
                            ClusterInferenceTTSTask.builder().id(ttsTaskId)
                                    .name(ttsModel.getName())
                                    .text(ttsExampleText)
                                    .tts_model(MinIOConvertUtils.toModelXPath(ttsModel, workSpace))
                                    .type(InferenceType.TTS_EXAMPLE)
                                    .extra(extra)
                                    .userBucket(MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), accountId))
                                    .workSpace(workSpace)
                                    .device(RunningDevice.ANY)
                                    .targetService("")
                                    .device(RunningDevice.ANY)
                                    .account_id(accountId)
                                    .build(),
                    List.of(ttsModel.getParameterDetails(), workSpace.getExtra()));
        }
        return collectDetails((extra) -> new InferenceTTSTask(ttsTaskId, ttsModel.getName(), ttsExampleText, toModelBucket(ttsModel.getId()), InferenceType.TTS_EXAMPLE, extra, accountId),
                List.of(ttsModel.getParameterDetails()));
    }

    public static CancelTask toCancelTask(GenericModel model) {
        return new CancelTask(toModelBucket(model.getId()), model.getModel().name());
    }

    private static <T> T collectDetails(Function<String, T> taskCreator, List<Map<String, Object>> details) {
        Map<String, Object> extraInfo = new HashMap<>();
        for (var entry : details) {
            extraInfo.putAll(entry);
        }
        ObjectMapper mapper = new ObjectMapper();
        try {
            String extra = mapper.writeValueAsString(extraInfo);
            return taskCreator.apply(extra);
        } catch (JsonProcessingException e) {
            throw new InferenceException("Convert fail for model type!");
        }
    }

    public static String toModelBucket(UUID id) {
        return Base64.getEncoder().withoutPadding().encodeToString(id.toString().getBytes());
    }

    public static String generateCombineIdentifier(UUID sid, String fileMd5) {
        String combined = sid.toString() + fileMd5;
        try {
            MessageDigest digest = MessageDigest.getInstance("MD5");
            byte[] hashBytes = digest.digest(combined.getBytes(StandardCharsets.UTF_8));
            return Base64.getUrlEncoder().withoutPadding().encodeToString(hashBytes);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Failed to generate filename");
        }
    }

    public static Path getAvatarPath(String root, UUID id, String fileName) {
        String base64Id = Base64.getEncoder().encodeToString(id.toString().getBytes());
        // avatar absolute path: <workspace root>/base64(model-id-str)/avatar/avatar.jpg
        // preview absolute path: <workspace root>/base64(model-id-str)/avatar/preview.jpg
        return Paths.get(root, base64Id, fileName);
    }

    public static String computeMD5(byte[] bytes) {
        try {
            MessageDigest digest = MessageDigest.getInstance("MD5");
            byte[] hashBytes = digest.digest(bytes);
            return bytesToHex(hashBytes);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Failed to compute MD5", e);
        }
    }

    public static String bytesToHex(byte[] bytes) {
        StringBuilder hexString = new StringBuilder();
        for (byte b : bytes) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }
        return hexString.toString();
    }

    public static String getFileExtension(String fileName) {
        int lastDotIndex = fileName.lastIndexOf('.');
        if (lastDotIndex == -1) {
            return "";
        }
        return fileName.substring(lastDotIndex);
    }
}
