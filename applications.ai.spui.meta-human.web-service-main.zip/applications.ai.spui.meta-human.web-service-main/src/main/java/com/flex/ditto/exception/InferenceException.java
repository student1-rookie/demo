package com.flex.ditto.exception;

public class InferenceException extends RuntimeException {

    public InferenceException(String message) {
        super(message);
    }
}
