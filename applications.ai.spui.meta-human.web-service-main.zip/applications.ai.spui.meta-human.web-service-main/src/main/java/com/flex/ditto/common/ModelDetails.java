package com.flex.ditto.common;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.flex.ditto.dto.ModelDetailsDto;

@JsonSerialize
public record ModelDetails(String phase, Integer curr, Integer total, Integer estimated, String unit) {

    public ModelDetailsDto toModelDetailsDto(ModelStatus status) {
        return new ModelDetailsDto(status.name(), this.phase, this.curr, this.total, this.estimated, this.unit);
    }
}
