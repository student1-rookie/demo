package com.flex.ditto.common;

public enum ResourceType {
    VIDEO, AUDIO, IMAGE, PRESENTATION;
}
