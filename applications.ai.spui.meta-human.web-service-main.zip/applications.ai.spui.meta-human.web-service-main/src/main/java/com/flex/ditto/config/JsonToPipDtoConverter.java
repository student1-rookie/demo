package com.flex.ditto.config;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.flex.ditto.dto.InferencePicInPicDto;
import io.r2dbc.postgresql.codec.Json;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.ReadingConverter;

import java.io.IOException;

@Slf4j
@AllArgsConstructor
@ReadingConverter
public class JsonToPipDtoConverter implements Converter<Json, InferencePicInPicDto> {

    final private ObjectMapper objectMapper;

    @Override
    public InferencePicInPicDto convert(Json source) {
        try {
            return objectMapper.readValue(source.asString(), new TypeReference<>() {
            });
        } catch (IOException e) {
            log.error("error when parsing JSON: {}", source, e);
        }
        return null;
    }
}
