package com.flex.ditto.common;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonSerialize
public record InferenceRet (String status, String out) {
}
