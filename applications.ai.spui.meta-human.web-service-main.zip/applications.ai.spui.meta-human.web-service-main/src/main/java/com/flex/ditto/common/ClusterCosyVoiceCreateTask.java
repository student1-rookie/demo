package com.flex.ditto.common;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.SuperBuilder;

@Data
@EqualsAndHashCode(callSuper = true)
@SuperBuilder
public class ClusterCosyVoiceCreateTask extends CosyVoiceCreateTask {

    final private Boolean cluster = true;

    private String userBucket;

    private WorkSpace workSpace;

    private String env;
}
