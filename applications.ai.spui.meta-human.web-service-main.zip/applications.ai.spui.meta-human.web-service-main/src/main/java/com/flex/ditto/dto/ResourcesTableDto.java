package com.flex.ditto.dto;

import java.util.List;
import java.util.UUID;

import com.flex.ditto.common.ResourceAccess;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ResourcesTableDto {
    private List<UUID> resourceIds;
    private List<UUID> resourceGroupIds;
    private ResourceAccess access;
    private UUID owner;
}
