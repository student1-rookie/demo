package com.flex.ditto.config;

import com.flex.ditto.common.ProtocolType;
import com.flex.ditto.common.RunningDevice;
import com.flex.ditto.config.property.CustomizedServicesProperties;
import com.flex.ditto.config.property.DynamicServiceConfigLoader;
import com.flex.ditto.config.property.ServiceProperties;
import com.flex.ditto.domain.InferenceRepository;
import com.flex.ditto.domain.MetaHumanDatasetRepository;
import com.flex.ditto.service.*;
import com.flex.ditto.service.transports.*;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.rsocket.RSocketRequester;

import java.util.*;

@Configuration
public class TransportConfig {
    private final CustomizedServicesProperties properties;
    private final InferenceRepository inferenceRepository;
    private final MetaHumanDatasetRepository metaHumanDatasetRepository;
    private final InferenceTaskService inferenceTaskService;
    private final DynamicServiceConfigLoader loader;

    public TransportConfig(CustomizedServicesProperties properties,
                           InferenceRepository inferenceRepository,
                           MetaHumanDatasetRepository metaHumanDatasetRepository,
                           InferenceTaskService inferenceTaskService,
                           DynamicServiceConfigLoader loader) {
        this.properties = properties;
        this.inferenceRepository = inferenceRepository;
        this.metaHumanDatasetRepository = metaHumanDatasetRepository;
        this.inferenceTaskService = inferenceTaskService;
        this.loader = loader;
    }

    @Bean
    public Map<String, List<InferenceTransport>> ttsInferenceTransportsByName(
            @Qualifier("customizedServiceRequesters") Map<String, RSocketRequester> customizedServiceRequesters
    ) {
        Map<String, List<InferenceTransport>> result = new HashMap<>();
        if (properties.getTts() == null) {
            return result;
        }

        for (String name : properties.getTts()) {
            ServiceProperties service = loader.load(name);
            if (service != null) {
                List<RunningDevice>  runningDevices = service.getDevice().toUpperCase().equals(RunningDevice.CUDA.name()) ? List.of(RunningDevice.CUDA, RunningDevice.ANY) : List.of(RunningDevice.XPU);
                if (ProtocolType.RSOCKET.name().equals(service.getProtocol().toUpperCase())) {
                    RSocketRequester requester = customizedServiceRequesters.get(service.getService());
                    if (requester != null) {
                        InferenceTransport rSocketTransport = new InferenceTTSRSocketTransport(
                                requester,
                                inferenceRepository,
                                metaHumanDatasetRepository,
                                runningDevices,
                                service.getCreateRoute()
                        );
                        result.computeIfAbsent(service.getService(), k -> new ArrayList<>())
                                .add(rSocketTransport);
                    }
                } else if (ProtocolType.MQ.name().equals(service.getProtocol().toUpperCase())) {
                    InferenceTransport mqTransport = new InferenceTTSMqTransport(
                            service.getExchange(),
                            service.getInferenceRoutingKey(),
                            metaHumanDatasetRepository,
                            inferenceRepository,
                            inferenceTaskService,
                            runningDevices
                    );
                    result.computeIfAbsent(service.getService(), k -> new ArrayList<>())
                            .add(mqTransport);
                }
            }
        }
        return result;
    }

    @Bean
    public Map<String, List<InferenceTransport>> faceInferenceTransportsByName(
            @Qualifier("customizedServiceRequesters") Map<String, RSocketRequester> customizedServiceRequesters
    ) {
        Map<String, List<InferenceTransport>> result = new HashMap<>();
        if (properties.getFace() == null) {
            return result;
        }
        for (String name : properties.getFace()) {
            ServiceProperties service = loader.load(name);
            if (service != null) {
                List<RunningDevice>  runningDevices = service.getDevice().toUpperCase().equals(RunningDevice.CUDA.name()) ? List.of(RunningDevice.CUDA, RunningDevice.ANY) : List.of(RunningDevice.XPU);
                if (ProtocolType.RSOCKET.name().equals(service.getProtocol().toUpperCase())) {
                    RSocketRequester requester = customizedServiceRequesters.get(service.getService());
                    if (requester != null) {
                        InferenceTransport rSocketTransport = new InferenceFaceRSocketTransport(
                                requester,
                                inferenceRepository,
                                metaHumanDatasetRepository,
                                runningDevices,
                                service.getCreateRoute());
                        result.computeIfAbsent(service.getService(), k -> new ArrayList<>())
                                .add(rSocketTransport);
                    }
                } else if (ProtocolType.MQ.name().equals(service.getProtocol().toUpperCase())) {
                    InferenceFaceMqTransport mqTransport = new InferenceFaceMqTransport(
                            service.getExchange(),
                            service.getInferenceRoutingKey(),
                            metaHumanDatasetRepository,
                            inferenceRepository,
                            inferenceTaskService,
                            runningDevices
                    );
                    result.computeIfAbsent(service.getService(), k -> new ArrayList<>())
                            .add(mqTransport);
                }
            }
        }
        return result;
    }
}
