package com.flex.ditto.dto;

import jakarta.validation.constraints.NotBlank;

import java.util.UUID;

public record UserDto(@NotBlank String username, @NotBlank String email, @NotBlank UUID id) {}
