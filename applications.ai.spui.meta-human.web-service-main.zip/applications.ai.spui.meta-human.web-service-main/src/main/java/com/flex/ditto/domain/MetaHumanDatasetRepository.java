package com.flex.ditto.domain;

import com.flex.ditto.common.ResourceAccess;

import org.springframework.data.r2dbc.repository.Modifying;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.UUID;

public interface MetaHumanDatasetRepository extends ReactiveCrudRepository<MetaHumanDataset, UUID> {
    Flux<MetaHumanDataset> findByName(String name);

    Mono<MetaHumanDataset> findByIdentifier(String identifier);

    Flux<MetaHumanDataset> findByFileNameAndAccountID(String fileName, UUID accountID);

    @Query("SELECT * FROM meta_human_dataset WHERE identifier = :identifier AND (account_id = :accountId OR type = 'PUBLIC')")
    Flux<MetaHumanDataset> findByIdentifierAndAccountId(String identifier, UUID accountId);

    @Query("SELECT * FROM meta_human_dataset WHERE (account_id = :id OR type = 'PUBLIC') AND NOT internal")
    Flux<MetaHumanDataset> findByAccountId(UUID id);

    @Modifying
    @Query("UPDATE meta_human_dataset SET name = :newName WHERE id = :id AND account_id = :account")
    Mono<Integer> updateNameByAccountAndId(UUID account, UUID id, String newName);

    @Modifying
    @Query("UPDATE meta_human_dataset SET name = :newName WHERE id = :id")
    Mono<Integer> updateNameById(UUID id, String newName);

    @Modifying
    @Query("UPDATE meta_human_dataset SET account_id = :accountId WHERE id = :id")
    Mono<Integer> updateAccountIdById(UUID accountId, UUID id);

    @Query("DELETE FROM meta_human_dataset WHERE id = :id AND account_id = :account")
    Mono<Void> deleteByAccountAndId(UUID account, UUID id);

    @Query("SELECT * FROM meta_human_dataset WHERE id = :id AND (account_id = :account OR type = 'PUBLIC')")
    Mono<MetaHumanDataset> findByAccountAndId(UUID account, UUID id);

    Mono<MetaHumanDataset> findByIdAndAccountID(UUID id, UUID accountId);

    @Modifying
    @Query("UPDATE meta_human_dataset SET type = :type WHERE id = :id AND account_id = :accountId")
    Mono<Long>  updateTypeByIdAndAccountID(ResourceAccess type, UUID id, UUID accountId);

    @Modifying
    @Query("UPDATE meta_human_dataset SET type = :type WHERE id = :id")
    Mono<Long> updateTypeById(ResourceAccess type, UUID id);

    @Query("SELECT id, name, type, file_type, create_date, file_name, identifier, account_id " +
            "FROM  meta_human_dataset " +
            "WHERE group_id IS NULL AND NOT internal " +
            "UNION " +
            "SELECT id, name, type, NULL as file_type, create_date, NULL as file_name, NULL as identifier, account_id " +    
            "FROM meta_human_dataset_group")
    Flux<MetaHumanDataset> findDatasetGroupAll();

    @Query("SELECT id, name, type, file_type, create_date, file_name, identifier, account_id " +
            "FROM  meta_human_dataset " +
            "WHERE (account_id = :id OR type = 'PUBLIC') AND NOT internal AND group_id IS NULL " +
            "UNION " +
            "SELECT id, name, type, NULL as file_type, create_date, NULL as file_name, NULL as identifier, account_id " +    
            "FROM meta_human_dataset_group " +
            "WHERE account_id = :id OR type = 'PUBLIC'")
    Flux<MetaHumanDataset> findDatasetGroupByAccountId(UUID id);

    @Query("SELECT * FROM meta_human_dataset WHERE group_id = :groupId")
    Flux<MetaHumanDataset> findByGroupId(UUID groupId);
}
