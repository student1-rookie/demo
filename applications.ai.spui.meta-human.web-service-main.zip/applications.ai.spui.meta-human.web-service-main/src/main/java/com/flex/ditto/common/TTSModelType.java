package com.flex.ditto.common;

public enum TTSModelType {

    BERTVITS(false),
    GPTSOVITS(false),

    COSYVOICE(true),
    MOSSTTSD(true),
    VIBEVOICE(true),
    VOXCPM(true),
    QWENTTS(true);

    private final boolean customized;

    TTSModelType(boolean customized) {
        this.customized = customized;
    }

    public boolean isCustomized() {
        return customized;
    }
}
