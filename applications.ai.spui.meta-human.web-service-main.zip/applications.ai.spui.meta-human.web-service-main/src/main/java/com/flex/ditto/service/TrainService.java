package com.flex.ditto.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.flex.ditto.common.CancelTask;
import com.flex.ditto.common.ClusterTrainTask;
import com.flex.ditto.common.RunningDevice;
import com.flex.ditto.common.TrainTask;

import org.apache.commons.lang3.StringUtils;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
public class TrainService {

    @Value("${app.train.exchange}")
    private String trainExchange;

    @Value("${app.train.routing-key}")
    private String trainRoutingKey;

    @Value("${app.control.exchange}")
    private String ctlExchange;

    @Value("${app.mq.generic-routing-key:generic}")
    private String genericRoutingKey;

    @Value("${app.xpu.exchange}")
    private String trainXpuExchange;

    @Value("${app.xpu.generic.routing-key}")
    private String genericXpuRoutingKey;

    @Autowired
    private RabbitTemplate rabbitTemplate;

    public Mono<Void> pubTrainTask(TrainTask trainTask) {
        return Mono.fromCallable(() -> {
            if (trainTask.getDevice() == RunningDevice.XPU) {
                pubToXpu(trainTask);
            } else {
                pubToGenericDevice(trainTask);
            }
            return null;
        });
    }

    private void pubToXpu(TrainTask trainTask) {
        try {
            String taskBody = new ObjectMapper().writeValueAsString(trainTask);
            Message msg = MessageBuilder.withBody(taskBody.getBytes())
                .setContentType(MessageProperties.CONTENT_TYPE_JSON).setMessageId("train-" + trainTask.getId()).build();
            rabbitTemplate.convertAndSend(trainXpuExchange, genericXpuRoutingKey, msg);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void pubToGenericDevice(TrainTask trainTask) throws JsonProcessingException {
        String targetService = genericRoutingKey;
        if (trainTask instanceof ClusterTrainTask) {
            ClusterTrainTask clusterTrainTask = (ClusterTrainTask) trainTask;
            targetService = StringUtils.isEmpty(clusterTrainTask.getTargetService()) ? targetService 
                : clusterTrainTask.getTargetService();
        }
        try {
            String taskBody = new ObjectMapper().writeValueAsString(trainTask);
            Message msg = MessageBuilder.withBody(taskBody.getBytes())
                .setContentType(MessageProperties.CONTENT_TYPE_JSON).setMessageId(trainTask.getId()).build();
            rabbitTemplate.convertAndSend(trainExchange, trainRoutingKey + targetService, msg);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public Mono<Void> cancelTrainTask(CancelTask cancelTask) {
        return Mono.fromCallable(() -> {
            String taskBody = new ObjectMapper().writeValueAsString(cancelTask);
            Message msg = MessageBuilder.withBody(taskBody.getBytes())
                    .setContentType(MessageProperties.CONTENT_TYPE_JSON).setMessageId(cancelTask.id()).build();
            rabbitTemplate.convertAndSend(ctlExchange, "", msg);
            return null;
        });
    }
}
