package com.flex.ditto.controller;

import com.flex.ditto.config.security.UserPrincipal;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@RestController
@RequestMapping("/workflow")
public class WorkflowController {

    private final String jsonDir = "json";

    @GetMapping("/list")
    public Mono<ResponseEntity<List<String>>> listJsonFiles(@AuthenticationPrincipal UserPrincipal user) {
        
        PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        
        try {
            Resource[] resources = resolver.getResources("classpath:" + jsonDir + "/*.json");
            List<String> jsonFiles = Stream.of(resources)
                    .map(Resource::getFilename)
                    .collect(Collectors.toList());
            return Mono.just(ResponseEntity.ok(jsonFiles));
        } catch (IOException e) {
            e.printStackTrace();
            return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build());
        }
    }

    @GetMapping(value = "/download/{filename:.+}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<ResponseEntity<Resource>> downloadJsonFile(@PathVariable String filename, @AuthenticationPrincipal UserPrincipal user) {
        Resource resource = new ClassPathResource(jsonDir + "/" + filename);

        if (!resource.exists()) {
            return Mono.just(ResponseEntity.status(HttpStatus.NOT_FOUND).build());
        }

        return Mono.just(ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
                .body(resource));
    }
}
