package com.flex.ditto.service;

import java.time.ZonedDateTime;
import java.util.UUID;

import com.flex.ditto.common.ModelStatus;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.stereotype.Service;
import com.fasterxml.jackson.databind.ObjectMapper;
import reactor.core.publisher.Flux;
import com.flex.ditto.domain.*;
import com.flex.ditto.dto.MetaHumanNotifyDto;
import reactor.core.publisher.Mono;

@Service
public class NotificationService {

    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    private MetaHumanNotifyRepository metaHumanNotifyRepository;
    @Autowired
    private RedisCacheService redisCacheService;

    public Flux<ServerSentEvent<String>> sseNotify(String userId) {
        String streamKey = "notifications:" + userId;
        String group = "group:" + userId;
        String consumer = "consumer:" + userId;

        return redisCacheService.createGroup(streamKey, group)
                .thenMany(redisCacheService.readStreamRecord(streamKey, consumer, group))
                .map(record -> {
                    String json;
                    try {
                        json = objectMapper.writeValueAsString(record.getValue());
                    } catch (Exception e) {
                        json = "{}";
                    }
                    return ServerSentEvent.<String>builder()
                            .id(record.getId().getValue())
                            .event("message")
                            .data(json)
                            .build();
                });
    }

    /**
     * Query notification messages
     */
    public Flux<MetaHumanNotifyDto> getNotificationsByCreateDate(UUID userId, ZonedDateTime date) {
        return metaHumanNotifyRepository.findByAccountIdAndCreateDate(userId, date)
            .map(entity -> {
                MetaHumanNotifyDto metaHumanNotifyDto = new MetaHumanNotifyDto();
                BeanUtils.copyProperties(entity, metaHumanNotifyDto);
                return metaHumanNotifyDto;
            });
    }

    public Mono<Void> publishNotify(UUID userId, String message, ModelStatus status) {
        return metaHumanNotifyRepository.save(new MetaHumanNotify(userId, message, status))
                .then(redisCacheService.publishNotify(userId, message, status));
    }

}
