package com.flex.ditto.dto;

import java.util.*;
import java.util.stream.IntStream;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.BeanUtils;

import com.flex.ditto.common.InferenceType;
import com.flex.ditto.common.ModelType;
import com.flex.ditto.common.RunningDevice;
import com.flex.ditto.common.WorkSpace;
import com.flex.ditto.domain.MetaHumanDataset;
import com.flex.ditto.service.utils.MinIOConvertUtils;
import lombok.Data;

@Data
public class InferencePicInPicTaskDto {
    private UUID id;
    private String name;
    private Map<ModelType, UUID> models;
    private InferenceType type;
    private List<PicInPicTaskDto> input;
    private String backgroundImage;
    private Boolean subtitle;
    private Boolean hdtr;
    private Integer seed;
    private String resolution;
    private RunningDevice device;
    private SubtitleStyleTaskDto subtitleStyleTaskDto;
    private TTSInstructTaskDto ttsInstructTaskDto;

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    public Map<String, Object> getExtraInfo() {
        Map<String, Object> extraInfo = new HashMap<>();
        if (hdtr != null) {
            extraInfo.put("hdtr", hdtr);
        }
        if (subtitle != null) {
            extraInfo.put("subtitle", subtitle);
        }
        if (seed != null) {
            extraInfo.put("seed", seed);
        }
        if (device != null) {
            extraInfo.put("device", device);
        }
        if (ttsInstructTaskDto != null) {
            Map<String, Object> instructMap = ttsInstructTaskDto.toMap();
            if (!instructMap.isEmpty()) {
                extraInfo.put("instruct", instructMap);
            }
        }
        if (subtitleStyleTaskDto != null) {
            Map<String, Object> subtitleMap = subtitleStyleTaskDto.toMap();
            if (!subtitleMap.isEmpty()) {
                extraInfo.put("subtitle_styles", subtitleMap);
            }
        }
        if (resolution != null) {
            Map<String, Object> pipMap = new HashMap<>();
            pipMap.put("default_resolution", resolution);
            extraInfo.put("pip_settings", pipMap);
        }
        return extraInfo;
    }

    public List<PicInPicTaskDto> getTaskInput(List<MetaHumanDataset> metaHumanDatasets, WorkSpace workSpace, boolean isCluster) {
        IntStream.range(0, Math.min(metaHumanDatasets.size(), input.size())).forEach(i -> {
            if (isCluster) {
                input.get(i).setMedia(MinIOConvertUtils.toDatasetXPath(metaHumanDatasets.get(i), workSpace));
            } else {
                input.get(i).setMedia(metaHumanDatasets.get(i).getDatasetPath());
            }
            createItemTTSKey(input.get(i));
            createItemFaceKey(input.get(i));
        });
        return input;
    }

    public InferencePicInPicDto convert() {
        InferencePicInPicDto inferencePicInPicDto = new InferencePicInPicDto();
        BeanUtils.copyProperties(this, inferencePicInPicDto);
        if (this.input != null) {
            List<PicInPicDto> picInPicDtos = this.input.stream()
                .map(picInPicTaskDto -> {
                    PicInPicDto picInPicDto = new PicInPicDto();
                    BeanUtils.copyProperties(picInPicTaskDto, picInPicDto);
                    return picInPicDto;
                })
                .toList();
            inferencePicInPicDto.setInput(picInPicDtos);
        }
        SubtitleStyleDto subtitleStyleDto = new SubtitleStyleDto();
        BeanUtils.copyProperties(this.subtitleStyleTaskDto, subtitleStyleDto);
        inferencePicInPicDto.setSubtitleStyleDto(subtitleStyleDto);
        TTSInstructDto ttsInstructDto = new TTSInstructDto();
        BeanUtils.copyProperties(this.ttsInstructTaskDto, ttsInstructDto);
        inferencePicInPicDto.setTtsInstructDto(ttsInstructDto);
        inferencePicInPicDto.setExtraInfo(getExtraInfo());
        return inferencePicInPicDto;
    }

    public String createRedisItemKey(PicInPicTaskDto itemDto, UUID accountId) {
        ObjectNode object = OBJECT_MAPPER.createObjectNode();
        object.put("name", this.name);
        object.put("ttsModel", this.models.get(ModelType.TTS).toString());
        object.put("faceModel", this.models.get(ModelType.FACE) == null ? null : this.models.get(ModelType.FACE).toString());
        object.put("subtitle", this.subtitle);
        object.put("hdtr", this.hdtr);
        object.put("seed", this.seed);
        object.put("resolution", this.resolution);
        if (this.subtitleStyleTaskDto != null) {
            object.set("subtitleStyleTaskDto", OBJECT_MAPPER.valueToTree(this.subtitleStyleTaskDto));
        } else {
            object.putNull("subtitleStyleTaskDto");
        }
        if (this.ttsInstructTaskDto != null) {
            object.set("ttsInstructTaskDto", OBJECT_MAPPER.valueToTree(this.ttsInstructTaskDto));
        } else {
            object.putNull("ttsInstructTaskDto");
        }
        if (this.device != null) {
            object.set("device", OBJECT_MAPPER.valueToTree(this.device));
        } else {
            object.putNull("device");
        }
        object.put("accountId", accountId.toString());
        object.put("itemDto", itemDto.createPreviewItemKey());
        return DigestUtils.sha256Hex(object.toString());
    }

    public String createItemTTSKey(PicInPicTaskDto item) {
        if (item.getTtsKey() != null) {
            return item.getTtsKey();
        }
        ObjectNode object = OBJECT_MAPPER.createObjectNode();
        object.put("ttsModel", this.models.get(ModelType.TTS).toString());
        object.put("itemKey", item.getItemKey());
        item.setTtsKey(DigestUtils.sha256Hex(object.toString()));
        return item.getTtsKey();

    }

    public String createItemFaceKey(PicInPicTaskDto item) {
        if (item.getFaceKey() != null) {
            return item.getFaceKey();
        }
        ObjectNode object = OBJECT_MAPPER.createObjectNode();
        object.put("faceModel", this.models.get(ModelType.FACE) == null ? null : this.models.get(ModelType.FACE).toString());
        object.put("ttsModel", this.models.get(ModelType.TTS).toString());
        object.put("itemKey", item.getItemKey());
        item.setFaceKey(DigestUtils.sha256Hex(object.toString()));
        return item.getFaceKey();
    }
}