package com.flex.ditto.common.inference;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.flex.ditto.common.RunningDevice;
import com.flex.ditto.common.WorkSpace;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.SuperBuilder;

@JsonSerialize
@Data
@EqualsAndHashCode(callSuper = true)
@SuperBuilder
public class ClusterInferenceFaceTask extends InferenceFaceTask {

    final private Boolean cluster = true;

    private String userBucket;

    private WorkSpace workSpace;

    @JsonIgnore
    private RunningDevice device;

    @JsonIgnore
    private String targetService;
}
