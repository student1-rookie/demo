package com.flex.ditto.domain;

import com.flex.ditto.common.InferenceResult;
import com.flex.ditto.common.InferenceStatus;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.UUID;

@Data
@Table("meta_human_infer")
public class Inference {
    @Id
    private UUID id;
    private String name;
    @Column("create_date")
    private ZonedDateTime date;
    private InferenceStatus status;
    @Column("account_id")
    private UUID accountId;
    @Column("face_model")
    private UUID faceModelId;
    @Column("tts_model")
    private UUID ttsModelId;
    @Column("type")
    private InferenceResult type;
    @Column("run_service")
    private String runService;
    @Column("group_id")
    private UUID groupId;

    public Inference(String name, UUID accountId, UUID faceModelId, UUID ttsModelId, InferenceResult type) {
        this.name = name;
        this.date = ZonedDateTime.now(ZoneId.of("UTC"));
        this.status = InferenceStatus.INIT;
        this.accountId = accountId;
        this.faceModelId = faceModelId;
        this.ttsModelId = ttsModelId;
        this.type = type;
    }

    public Inference(String name, UUID accountId, UUID faceModelId, UUID ttsModelId, InferenceResult type, UUID groupId) {
        this.name = name;
        this.date = ZonedDateTime.now(ZoneId.of("UTC"));
        this.status = InferenceStatus.INIT;
        this.accountId = accountId;
        this.faceModelId = faceModelId;
        this.ttsModelId = ttsModelId;
        this.type = type;
        this.groupId = groupId;
    }

    public Inference(String name, UUID accountId, UUID faceModelId, UUID ttsModelId, InferenceResult type, UUID groupId, InferenceStatus status) {
        this.name = name;
        this.date = ZonedDateTime.now(ZoneId.of("UTC"));
        this.status = status;
        this.accountId = accountId;
        this.faceModelId = faceModelId;
        this.ttsModelId = ttsModelId;
        this.type = type;
        this.groupId = groupId;
    }

    public Inference() {}

    public String getInferenceFilePath() {
        return id.toString() + "/" + getFileName();
    }

    public String getFileName() {
        String suffix = type.equals(InferenceResult.AUDIO) ? ".wav" : ".mp4";
        return name + suffix;
    }

}
