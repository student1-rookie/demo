package com.flex.ditto.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.flex.ditto.common.ServiceType;
import com.flex.ditto.service.SearchService;

import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/search")
public class SearchController {
    @Autowired
    private SearchService searchService;

    @GetMapping("/service/{serviceType}")
    public Mono<ResponseEntity<List<String>>> searchRoutingKey(@PathVariable ServiceType serviceType) {
        return searchService.searchRoutingKey(serviceType).collectList().map(ResponseEntity::ok);
    }
}
