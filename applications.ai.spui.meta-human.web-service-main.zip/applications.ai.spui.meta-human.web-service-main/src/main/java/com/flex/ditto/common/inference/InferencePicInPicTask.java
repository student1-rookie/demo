package com.flex.ditto.common.inference;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.flex.ditto.common.InferenceType;
import com.flex.ditto.dto.PicInPicTaskDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;
import java.util.UUID;

@JsonSerialize
@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class InferencePicInPicTask {
    @JsonIgnore
    String id;
    String name;
    List<PicInPicTaskDto> input;
    String background;
    String face_model;
    String tts_model;
    Boolean pic_in_pic;
    UUID account_id;
    String groupId;
    String extra;
    InferenceType type;
}