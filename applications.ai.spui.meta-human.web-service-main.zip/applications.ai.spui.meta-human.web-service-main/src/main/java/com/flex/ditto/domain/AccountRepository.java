package com.flex.ditto.domain;

import com.flex.ditto.dto.UserActivityCountDto;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.OffsetDateTime;
import java.util.UUID;

public interface AccountRepository extends ReactiveCrudRepository<Account, UUID> {

    Flux<Account> findByEmail(String email);

    Flux<Account> findByEmailAndPasswordNotNull(String email);

    Mono<Long> countByEmail(String email);

    @Query("""
            SELECT
                a.name AS account_name,
                a.email AS account_email,
                COALESCE(tts.tts_count, 0) AS tts_train_count,
                COALESCE(face.face_count, 0) AS face_train_count,
                COALESCE(infer.infer_count, 0) AS infer_count,
                COALESCE(infer.pic_count, 0) AS pic_in_pic_count
            FROM account a
            LEFT JOIN (
                SELECT account_id, COUNT(*) AS tts_count
                FROM meta_human_tts
                WHERE create_date >= :start AND create_date < :end
                GROUP BY account_id
            ) tts ON tts.account_id = a.id
            LEFT JOIN (
                SELECT account_id, COUNT(*) AS face_count
                FROM meta_human_face
                WHERE create_date >= :start AND create_date < :end
                GROUP BY account_id
            ) face ON face.account_id = a.id
            LEFT JOIN (
                SELECT account_id,
                    COUNT(CASE WHEN type IN ('AUDIO', 'VIDEO') THEN account_id end) AS infer_count,
                    COUNT(CASE WHEN type = 'PIP' THEN account_id end) AS pic_count
                FROM meta_human_infer
                WHERE create_date >= :start AND create_date < :end
                GROUP BY account_id
            ) infer ON infer.account_id = a.id
            WHERE
                tts.tts_count != 0 OR
                face.face_count != 0 OR
                infer.infer_count != 0 OR
                infer.pic_count != 0
            ORDER BY a.name
        """)
    Flux<UserActivityCountDto> queryByTimeRange(OffsetDateTime start, OffsetDateTime end);
}
