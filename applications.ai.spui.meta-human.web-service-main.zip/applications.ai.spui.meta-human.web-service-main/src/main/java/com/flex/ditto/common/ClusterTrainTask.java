package com.flex.ditto.common;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.SuperBuilder;


@JsonSerialize
@Data
@EqualsAndHashCode(callSuper = true)
@SuperBuilder
public class ClusterTrainTask extends TrainTask {

    final private Boolean cluster = true;

    private String userBucket;

    private WorkSpace workSpace;

    @JsonIgnore
    private String targetService;
}
