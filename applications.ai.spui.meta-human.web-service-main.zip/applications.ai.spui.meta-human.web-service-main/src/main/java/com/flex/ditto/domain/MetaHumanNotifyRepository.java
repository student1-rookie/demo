package com.flex.ditto.domain;

import java.time.ZonedDateTime;
import java.util.UUID;

import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;

import reactor.core.publisher.Flux;

public interface MetaHumanNotifyRepository extends ReactiveCrudRepository<MetaHumanNotify, UUID> {
    @Query("SELECT * FROM meta_human_notify WHERE account_id = :accountId and create_date > :date ORDER BY create_date DESC")
    Flux<MetaHumanNotify> findByAccountIdAndCreateDate(UUID accountId, ZonedDateTime date);
}
