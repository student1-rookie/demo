package com.flex.ditto.dto;

import java.util.UUID;

public record ItemInferenceResultDto(String itemKey, UUID inferenceId) {
}
