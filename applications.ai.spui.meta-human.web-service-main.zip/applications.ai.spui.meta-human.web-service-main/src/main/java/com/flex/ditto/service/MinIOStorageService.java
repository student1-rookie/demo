package com.flex.ditto.service;

import com.flex.ditto.common.*;
import com.flex.ditto.domain.*;
import com.flex.ditto.dto.UploadModelDto;
import com.flex.ditto.service.utils.MinIOConvertUtils;
import io.minio.*;
import io.minio.errors.*;
import io.minio.messages.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DataBufferUtils;
import org.springframework.core.io.buffer.DefaultDataBufferFactory;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public class MinIOStorageService implements StorageService {

    private final MinioAsyncClient minioAsyncClient;

    private final WorkSpace workSpace;

    @Value("${mh.temp-base:temp}")
    private String filterPrefixRule;

    @Value("${app.temp.expiration}")
    private String durationDaysRule;

    private final int bufferSize = 8192;

    public MinIOStorageService(MinioAsyncClient minioAsyncClient, WorkSpace workSpace) {
        this.minioAsyncClient = minioAsyncClient;
        this.workSpace = workSpace;
    }

    @Override
    public Boolean isCluster() {
        return true;
    }

    @Override
    public WorkSpace getWorkSpace() {
        return workSpace;
    }

    @Override
    public StorageType getStorageType() {
        return StorageType.MINIO;
    }

    @Override
    public Mono<Void> store(UUID userId, UUID datasetId, String fileName, Boolean isPublic, Flux<DataBuffer> data) {
        return DataBufferUtils.join(data).flatMap(
                dataBuffer -> {
                    InputStream inputStream = dataBuffer.asInputStream();
                    String userWorkspace = isPublic ? workSpace.getPublicBucket() : MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), userId);
                    String path = MinIOConvertUtils.toObjectPath(workSpace.getDataset(), datasetId, fileName);
                    return Mono.fromFuture(() -> uploadObject(userWorkspace, path, inputStream, dataBuffer.readableByteCount()))
                            .then();
                }
        );
    }

    @Override
    public Mono<Void> store(UUID userId, UUID datasetId, String fileName, Boolean isPublic, byte[] data) {
        return Mono.fromFuture(() -> {
            String userWorkspace = isPublic ? workSpace.getPublicBucket() : MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), userId);
            String path = MinIOConvertUtils.toObjectPath(workSpace.getDataset(), datasetId, fileName);
            return uploadObject(userWorkspace, path, new ByteArrayInputStream(data), data.length);
        }).then();
    }

    @Override
    public Mono<Void> mvDataset(UUID tarId, MetaHumanDataset dataset) {
        String destWorkspace = MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), tarId);
        String path = MinIOConvertUtils.toObjectPath(workSpace.getDataset(), dataset.getId(), dataset.getFileName());

        if (dataset.getType().equals(ResourceAccess.PRIVATE)) {
            return Mono.fromFuture(() -> {
                String srcWorkspace = MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), dataset.getAccountID());
                return copyObject(srcWorkspace, path, destWorkspace);
            }).then(deleteDataset(dataset.getAccountID(), dataset.getId(), Boolean.FALSE));
        }

        return Mono.fromFuture(() -> copyObject(workSpace.getPublicBucket(), path, destWorkspace))
            .then(deleteDataset(null, dataset.getId(), Boolean.TRUE));
    }

    @Override
    public Mono<Void> mvDatasetPublic(MetaHumanDataset dataset) {
        return Mono.fromFuture(() -> {
            String srcWorkspace = MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), dataset.getAccountID());
            String path = MinIOConvertUtils.toObjectPath(workSpace.getDataset(), dataset.getId(), dataset.getFileName());
            return copyObject(srcWorkspace, path, workSpace.getPublicBucket());
        }).then(deleteDataset(dataset.getAccountID(), dataset.getId(), Boolean.FALSE));
    }

    @Override
    public Mono<Void> mvModel(UUID tarId, FaceModel faceModel) {
        if (faceModel.getType().equals(ResourceAccess.PRIVATE)) {
            return Mono.fromCallable(() -> {
                String srcWorkspace = MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), faceModel.getAccountId());
                String destWorkspace = MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), tarId);
                String path = MinIOConvertUtils.toObjectPath(workSpace.getModel(), faceModel.getId(), "");
                return mvObjects(srcWorkspace, path, destWorkspace);
            });
        }
        return Mono.empty();
    }

    @Override
    public Mono<Void> mvModel(UUID tarId, TTSModel ttsModel) {
        if (ttsModel.getType().equals(ResourceAccess.PRIVATE)) {
            return Mono.fromCallable(() -> {
                String srcWorkspace = MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), ttsModel.getAccountId());
                String destWorkspace = MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), tarId);
                String path = MinIOConvertUtils.toObjectPath(workSpace.getModel(), ttsModel.getId(), "");
                return mvObjects(srcWorkspace, path, destWorkspace);
            });
        }
        return Mono.empty();
    }

    @Override
    public Mono<Void> mvModelPublic(FaceModel faceModel) {
        return Mono.fromCallable(() -> {
            String srcWorkspace = MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), faceModel.getAccountId());
            String path = MinIOConvertUtils.toObjectPath(workSpace.getModel(), faceModel.getId(), "");
            return mvObjects(srcWorkspace, path, workSpace.getPublicBucket());
        });
    }

    @Override
    public Mono<Void> mvModelPublic(TTSModel ttsModel) {
        return Mono.fromCallable(() -> {
            String srcWorkspace = MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), ttsModel.getAccountId());
            String path = MinIOConvertUtils.toObjectPath(workSpace.getModel(), ttsModel.getId(), "");
            return mvObjects(srcWorkspace, path, workSpace.getPublicBucket());
        });
    }

    @Override
    public Mono<Void> mvItemInference(String filename, UUID itemInferenceId, UUID itemId, UUID accountId, String newFilename) {
        String srcWorkspace = MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), accountId);
        String srcPath = MinIOConvertUtils.toObjectPath(workSpace.getTemp(), itemInferenceId, filename);
        String destPath = MinIOConvertUtils.toObjectPath(workSpace.getInference(), itemId, newFilename);
        return Mono.fromFuture(() -> copyObject(srcWorkspace, srcPath, srcWorkspace, destPath)).then(Mono.fromCallable(() -> {
            try {
                return removeObjects(srcWorkspace, srcPath);
            } catch (ServerException | InsufficientDataException | ErrorResponseException | IOException |
                     NoSuchAlgorithmException | InvalidKeyException | InvalidResponseException | XmlParserException |
                     InternalException e) {
                throw new RuntimeException(e);
            }
        }));
    }

    @Override
    public Mono<Void> deleteDataset(UUID userId, UUID datasetId, Boolean isPublic) {
        return Mono.fromCallable(() -> {
            String userWorkspace = isPublic ? workSpace.getPublicBucket() : MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), userId);
            String path = MinIOConvertUtils.toObjectPath(workSpace.getDataset(), datasetId, "");
            try {
                return removeObjects(userWorkspace, path);
            } catch (ServerException | InsufficientDataException | ErrorResponseException | IOException |
                     NoSuchAlgorithmException | InvalidKeyException | InvalidResponseException | XmlParserException |
                     InternalException e) {
                throw new RuntimeException(e);
            }
        });
    }

    @Override
    public Mono<Void> deleteModel(UUID userId, UUID modelId, Boolean isPublic) {
        return Mono.fromCallable(() -> {
            String userWorkspace = isPublic ? workSpace.getPublicBucket() : MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), userId);
            String path = MinIOConvertUtils.toObjectPath(workSpace.getModel(), modelId, "");
            try {
                return removeObjects(userWorkspace, path);
            } catch (ServerException | InsufficientDataException | ErrorResponseException | IOException |
                     NoSuchAlgorithmException | InvalidKeyException | InvalidResponseException | XmlParserException |
                     InternalException e) {
                throw new RuntimeException(e);
            }
        });
    }

    @Override
    public Mono<Void> deleteInference(UUID userId, UUID inferenceId) {
        return Mono.fromCallable(() -> {
            String userWorkspace = MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), userId);
            String path = MinIOConvertUtils.toObjectPath(workSpace.getInference(), inferenceId, "");
            try {
                return removeObjects(userWorkspace, path);
            } catch (ServerException | InsufficientDataException | ErrorResponseException | IOException |
                     NoSuchAlgorithmException | InvalidKeyException | InvalidResponseException | XmlParserException |
                     InternalException e) {
                throw new RuntimeException(e);
            }
        });
    }

    @Override
    public Mono<Void> createPublicBucket() {
        return Mono.fromFuture(() -> checkBucketExists(workSpace.getPublicBucket())).filter(found -> !found)
                .flatMap(found -> Mono.fromFuture(() -> createBucket(workSpace.getPublicBucket())))
                .then(handleLifecycle(workSpace.getPublicBucket()));
    }

    @Override
    public Mono<Void> createWorkspace(UUID userId) {
        final String userWorkspace = MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), userId);
        return Mono.fromFuture(() -> checkBucketExists(userWorkspace)).filter(found -> !found)
                .flatMap(found -> Mono.fromFuture(() -> createBucket(userWorkspace)))
                .then(handleLifecycle(userWorkspace));
    }

    @Override
    public Mono<Resource> loadDataset(UUID userId, MetaHumanDataset dataset) {
        final String userWorkspace = dataset.getType().equals(ResourceAccess.PRIVATE) ? MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), userId) : workSpace.getPublicBucket();
        final String path = MinIOConvertUtils.toObjectPath(workSpace.getDataset(), dataset.getId(), dataset.getFileName());
        return getResource(userWorkspace, path);
    }

    @Override
    public Mono<byte[]> loadDatasetBytes(UUID userId, MetaHumanDataset dataset) {
        final String userWorkspace = dataset.getType().equals(ResourceAccess.PRIVATE) ? MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), userId) : workSpace.getPublicBucket();
        final String path = MinIOConvertUtils.toObjectPath(workSpace.getDataset(), dataset.getId(), dataset.getFileName());
        return Mono.fromFuture(() -> getObject(userWorkspace, path))
                .publishOn(Schedulers.boundedElastic())
                .handle((getObjectResponse, sink) -> {
                    try {
                        sink.next(getObjectResponse.readAllBytes());
                    } catch (IOException e) {
                        sink.error(new RuntimeException(e));
                    }
                });
    }

    @Override
    public Mono<Resource> loadLog(UUID userId, String logId) {
        final String userWorkspace = MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), userId);
        final String path = MinIOConvertUtils.toLogPath(workSpace.getLog(), logId);
        return getResource(userWorkspace, path);
    }

    @Override
    public Mono<Resource> loadAvatar(UUID userId, FaceModel faceModel, String fileName) {
        final String userWorkspace = faceModel.getType().equals(ResourceAccess.PRIVATE) ? MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), userId) : workSpace.getPublicBucket();
        final String path = MinIOConvertUtils.toObjectPath(workSpace.getModel(), faceModel.getId(), fileName);
        return getResource(userWorkspace, path);
    }

    @Override
    public Mono<Resource> loadAudio(UUID userId, TTSModel ttsModel, String fileName) {
        final String userWorkspace = ttsModel.getType().equals(ResourceAccess.PRIVATE) ? MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), userId) : workSpace.getPublicBucket();
        final String path = MinIOConvertUtils.toObjectPath(workSpace.getModel(), ttsModel.getId(), fileName);
        return getResource(userWorkspace, path);
    }

    @Override
    public Mono<Resource> loadInferenceResult(UUID userId, Inference inference) {
        final String path = MinIOConvertUtils.toObjectPath(workSpace.getInference(), inference.getId(), inference.getFileName());
        return getResource(MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), userId), path);
    }

    @Override
    public Mono<Void> uploadModel(UploadModelDto modelInfo, Path file, UUID modelId, UUID userId, byte[] previewFile) {
        return Mono.defer(() -> {
            String type = modelInfo.getSubType().isFaceModelType() ? "_face" : "_tts";
            String userWorkspace = modelInfo.getAccess() == ResourceAccess.PUBLIC ? workSpace.getPublicBucket() : MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), userId);
            String modelPath = MinIOConvertUtils.toObjectPath(workSpace.getModel(), modelId, modelInfo.getName() + type + ".tar.gz");
            Mono<Void> uploadModelMono = Mono.fromFuture(() ->
                    {
                        try {
                            return uploadObject(userWorkspace, modelPath, Files.newInputStream(file), Files.size(file));
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                    }
            ).then();
            if (modelInfo.getSubType().isFaceModelType()) {
                String previewPath = MinIOConvertUtils.toObjectPath(workSpace.getModel(), modelId, "avatar/preview.jpg");
                String avatarPath = MinIOConvertUtils.toObjectPath(workSpace.getModel(), modelId, "avatar/avatar.jpg");
                Mono<Void> uploadPreviewMono = Mono.fromFuture(() ->
                        uploadObject(userWorkspace, previewPath,
                                new ByteArrayInputStream(previewFile), previewFile.length)
                ).then();
                Mono<Void> uploadAvatarMono = Mono.fromFuture(() ->
                        uploadObject(userWorkspace, avatarPath,
                                new ByteArrayInputStream(previewFile), previewFile.length)
                ).then();
                return Mono.when(uploadModelMono, uploadPreviewMono, uploadAvatarMono);
            }
            return uploadModelMono;
        });
    }

    @Override
    public Flux<DataBuffer> downloadModel(UUID accountId, UUID modelId, ResourceAccess type, ModelType baseType, String modelName, UUID userId) {
        String userWorkspace = type == ResourceAccess.PUBLIC ? workSpace.getPublicBucket() : MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), userId);
        String fileName = modelName + "_" + baseType.toString().toLowerCase() + ".tar.gz";
        String sourcePath = MinIOConvertUtils.toObjectPath(workSpace.getModel(), modelId, fileName);
        return Mono.fromFuture(() -> getObject(userWorkspace, sourcePath))
                .flatMapMany(response ->
                        DataBufferUtils.readInputStream(() -> response, new DefaultDataBufferFactory(), bufferSize)
                            .doFinally(signalType -> {
                                try {
                                    response.close();
                                } catch (Exception e) {
                                    throw new RuntimeException("Model download failed");
                                }
                            })
                ).onErrorMap(throwable -> new RuntimeException("Model download failed"));
    }

    @Override
    public Mono<Resource> loadItemInference(UUID accountId, UUID itemId, String fileName) {
        String path = MinIOConvertUtils.toObjectPath(workSpace.getTemp(), itemId, fileName);
        return getResource(MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), accountId), path);
    }

    @Override
    public Mono<Resource> loadFailTaskFile(UUID accountId, UUID failId, ResourceAccess type) {
        String rootWorkspace = type == ResourceAccess.PUBLIC ? workSpace.getPublicBucket() : MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), accountId);
        final String failName = MinIOConvertUtils.toObjectPath(workSpace.getFail(), failId, failId.toString() + ".zip");
        return getResource(rootWorkspace, failName);
    }

    private CompletableFuture<Boolean> checkBucketExists(String bucketName) {
        try {
            return minioAsyncClient.bucketExists(BucketExistsArgs.builder().bucket(bucketName).build());
        } catch (InsufficientDataException | InternalException | InvalidKeyException | IOException |
                 NoSuchAlgorithmException | XmlParserException e) {
            throw new RuntimeException(e);
        }
    }

    private CompletableFuture<Void> createBucket(String bucketName) {
        try {
            return minioAsyncClient.makeBucket(MakeBucketArgs.builder().bucket(bucketName).build());
        } catch (InsufficientDataException | InternalException | InvalidKeyException | IOException |
                 NoSuchAlgorithmException | XmlParserException e) {
            throw new RuntimeException(e);
        }
    }

    public Mono<Void> setLifecycle(String userWorkspace) {
        String prefix = filterPrefixRule.endsWith("/") ? filterPrefixRule : filterPrefixRule + "/";

        List<LifecycleRule> rules = List.of(
            new LifecycleRule(
                Status.ENABLED,
                null,
                new Expiration(null, Integer.parseInt(durationDaysRule), null, null),
                new RuleFilter(prefix),
                "storage-expire-minio",
                null, null, null
            )
        );

        LifecycleConfiguration config = new LifecycleConfiguration(rules);

        return Mono.fromFuture(() -> {
            try {
                return minioAsyncClient.setBucketLifecycle(
                    SetBucketLifecycleArgs.builder()
                        .bucket(userWorkspace)
                        .config(config)
                        .build()
                );
            } catch (Exception e) {
                throw new RuntimeException("Failed to set lifecycle", e);
            }
        });
    }

    public Mono<Void> handleLifecycle(String userWorkspace) {
        return Mono.fromFuture(() -> {
            try {
                return minioAsyncClient.getBucketLifecycle(
                    GetBucketLifecycleArgs.builder().bucket(userWorkspace).build()
                ).whenComplete((res, ex) -> {
                    if (res == null) {
                        setLifecycle(userWorkspace);
                    }
                });
            } catch (Exception e) {
                throw new RuntimeException("Failed to query lifecycle", e);
            }
        }).flatMap(configRes -> {
            if (configRes == null || configRes.rules().isEmpty()) {
                return setLifecycle(userWorkspace);
            } else {
                configRes.rules().forEach(rule ->
                    System.out.println("Existing rule: " + rule.id())
                );
                return Mono.empty();
            }
        })
        .onErrorResume(e -> {
            e.printStackTrace();
            return setLifecycle(userWorkspace);
        });
    }

    private Mono<Resource> getResource(String bucketName, String objectName) {
        return Mono.fromFuture(() -> getObject(bucketName, objectName))
                .publishOn(Schedulers.boundedElastic())
                .handle((getObjectResponse, sink) -> {
                    try {
                        sink.next(new ByteArrayResource(getObjectResponse.readAllBytes()));
                    } catch (IOException e) {
                        sink.error(new RuntimeException(e));
                    }
                });
    }

    private CompletableFuture<ObjectWriteResponse> uploadObject(String bucketName, String path, InputStream data, long dataLength) {
        try {
            return minioAsyncClient.putObject(PutObjectArgs.builder().bucket(bucketName).object(path).stream(data, dataLength, -1).build());
        } catch (InsufficientDataException | InternalException | InvalidKeyException | IOException |
                 NoSuchAlgorithmException | XmlParserException e) {
            throw new RuntimeException(e);
        }
    }

    private CompletableFuture<GetObjectResponse> getObject(String bucketName, String objectName) {
        try {
            return minioAsyncClient.getObject(GetObjectArgs.builder()
                    .bucket(bucketName)
                    .object(objectName)
                    .build());
        } catch (InsufficientDataException | IOException | NoSuchAlgorithmException | InvalidKeyException |
                 XmlParserException | InternalException e) {
            throw new RuntimeException(e);
        }
    }

    private Void removeObjects(String bucketName, String objectPath) throws ServerException, InsufficientDataException, ErrorResponseException, IOException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException {
        var objects = minioAsyncClient.listObjects(ListObjectsArgs.builder().bucket(bucketName).prefix(objectPath).recursive(true).build());
        List<DeleteObject> deleteObjectList = new LinkedList<>();
        for (var object : objects) {
            deleteObjectList.add(new DeleteObject(object.get().objectName()));
        }
        var results = minioAsyncClient.removeObjects(RemoveObjectsArgs.builder().bucket(bucketName).objects(deleteObjectList).build());
        for (var result : results) {
            DeleteError error = result.get();
            System.out.println("Failed to delete object: " + error.objectName() + ", error: " + error.message());
        }
        return null;
    }

    private CompletableFuture<ObjectWriteResponse> copyObject(String srcBucket, String srcObject, String destBucket) {
        try {
            return minioAsyncClient.copyObject(CopyObjectArgs.builder()
                    .bucket(destBucket)
                    .object(srcObject)
                        .source(CopySource.builder()
                            .bucket(srcBucket)
                            .object(srcObject)
                            .build())
                    .build());
        } catch (InsufficientDataException | InternalException | InvalidKeyException | IOException |
                 NoSuchAlgorithmException | XmlParserException e) {
            throw new RuntimeException(e);
        }
    }

    private CompletableFuture<ObjectWriteResponse> copyObject(String srcBucket, String srcObject, String destBucket, String destObject) {
        try {
            return minioAsyncClient.copyObject(CopyObjectArgs.builder()
                    .bucket(destBucket)
                    .object(destObject)
                    .source(CopySource.builder()
                            .bucket(srcBucket)
                            .object(srcObject)
                            .build())
                    .build());
        } catch (InsufficientDataException | InternalException | InvalidKeyException | IOException |
                 NoSuchAlgorithmException | XmlParserException e) {
            throw new RuntimeException(e);
        }
    }

    private Void mvObjects(String srcBucket, String srcObjectPath, String destBucket) throws ServerException, InsufficientDataException, ErrorResponseException, IOException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException {
        var objects = minioAsyncClient.listObjects(ListObjectsArgs.builder().bucket(srcBucket).prefix(srcObjectPath).recursive(true).build());
        List<DeleteObject> deleteObjectList = new LinkedList<>();
        for (var object : objects) {
            copyObject(srcBucket, object.get().objectName(), destBucket);
            deleteObjectList.add(new DeleteObject(object.get().objectName()));
        }
        var results = minioAsyncClient.removeObjects(RemoveObjectsArgs.builder().bucket(srcBucket).objects(deleteObjectList).build());
        for (var result : results) {
            DeleteError error = result.get();
            System.out.println("Failed to delete object: " + error.objectName() + ", error: " + error.message());
        }
        return null;
    }

    @Override
    public Mono<Void> copyInference(String filename, UUID itemInferenceId, UUID itemId, UUID accountId, String newFilename) {
        String userWorkspace = MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), accountId);
        String srcPath = MinIOConvertUtils.toObjectPath(workSpace.getInference(), itemInferenceId, filename);
        String tarPath = MinIOConvertUtils.toObjectPath(workSpace.getInference(), itemId, newFilename);
        return Mono.fromFuture(() -> copyObject(userWorkspace, srcPath, userWorkspace, tarPath)).then();
    }
}
