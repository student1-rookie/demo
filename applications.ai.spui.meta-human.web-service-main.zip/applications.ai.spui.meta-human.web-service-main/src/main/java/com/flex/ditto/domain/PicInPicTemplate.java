package com.flex.ditto.domain;

import com.flex.ditto.dto.InferencePicInPicDto;
import com.flex.ditto.dto.TemplateTaskDto;

import lombok.Data;

import org.springframework.beans.BeanUtils;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.util.UUID;

@Data
@Table("meta_human_pic_template")
public class PicInPicTemplate {
    @Id
    private UUID id;
    private String name;
    private InferencePicInPicDto details;
    @Column("account_id")
    private UUID accountId;
    @Column("group_id")
    private UUID groupId;

    public PicInPicTemplate(String name, InferencePicInPicDto details, UUID accountId, UUID groupId) {
        this.name = name;
        this.details = details;
        this.accountId = accountId;
        this.groupId = groupId;
    }

    public InferencePicInPicDto getDetails() {
        details.setId(id);
        details.setName(name);
        return details;
    }

    public TemplateTaskDto convertDetails() {
        TemplateTaskDto templateTaskDto = new TemplateTaskDto();
        BeanUtils.copyProperties(getDetails(), templateTaskDto);
        return templateTaskDto;
    }
}
