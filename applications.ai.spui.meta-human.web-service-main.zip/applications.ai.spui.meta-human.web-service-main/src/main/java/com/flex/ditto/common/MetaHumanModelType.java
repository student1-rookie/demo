package com.flex.ditto.common;

public enum MetaHumanModelType {
    ERNERF(FaceModelType.ERNERF),
    GAUSSIAN(FaceModelType.GAUSSIAN),
    LATENTSYNC(FaceModelType.LATENTSYNC),

    BERTVITS(TTSModelType.BERTVITS),
    GPTSOVITS(TTSModelType.GPTSOVITS),
    COSYVOICE(TTSModelType.COSYVOICE),
    MOSSTTSD(TTSModelType.MOSSTTSD),
    VIBEVOICE(TTSModelType.VIBEVOICE),
    VOXCPM(TTSModelType.VOXCPM),
    QWENTTS(TTSModelType.QWENTTS),

    INVALID(null);

    private final Enum<?> originalType;

    MetaHumanModelType(Enum<?> originalType) {
        this.originalType = originalType;
    }

    public static MetaHumanModelType fromFaceModelType(FaceModelType faceModelType) {
        for (MetaHumanModelType type : values()) {
            if (type.originalType == faceModelType) {
                return type;
            }
        }
        return INVALID;
    }

    public static MetaHumanModelType fromTTSModelType(TTSModelType ttsModelType) {
        for (MetaHumanModelType type : values()) {
            if (type.originalType == ttsModelType) {
                return type;
            }
        }
        return INVALID;
    }

    public boolean isFaceModelType() {
        return originalType instanceof FaceModelType;
    }

    public boolean isTTSModelType() {
        return originalType instanceof TTSModelType;
    }

    public boolean isCustomized() {
        if (originalType instanceof TTSModelType ttsModelType) {
            return ttsModelType.isCustomized();
        }
        if (originalType instanceof FaceModelType faceModelType) {
            return faceModelType.isCustomized();
        }
        return false;
    }
}
