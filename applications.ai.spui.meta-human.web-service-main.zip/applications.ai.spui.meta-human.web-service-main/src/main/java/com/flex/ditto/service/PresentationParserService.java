package com.flex.ditto.service;

import com.flex.ditto.common.ParserRet;
import com.flex.ditto.common.ResourceAccess;
import com.flex.ditto.common.WorkSpace;
import com.flex.ditto.service.utils.MinIOConvertUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.rsocket.RSocketRequester;
import org.springframework.stereotype.Service;
import org.springframework.util.MimeTypeUtils;
import reactor.core.publisher.Mono;

import java.util.UUID;

@Service
public class PresentationParserService {

    @Value("${service.parser.route}")
    private String parserRoute;

    @Autowired
    @Qualifier("parserRSocketRequester")
    private RSocketRequester rSocketRequester;

    public Mono<ParserRet> parsePresentation(UUID accountID, ResourceAccess access, String fileName, byte[] fileBytes, WorkSpace workSpace, Boolean isCluster) {
        var request = rSocketRequester.route(parserRoute)
                .metadata(fileName, MimeTypeUtils.parseMimeType("message/x.rsocket.filename"))
                .metadata(accountID.toString(), MimeTypeUtils.parseMimeType("message/x.rsocket.accountid"))
                .metadata(access.name(), MimeTypeUtils.parseMimeType("message/x.rsocket.access"));
        if (isCluster) {
            request = request.metadata("true", MimeTypeUtils.parseMimeType("message/x.rsocket.cluster"))
                    .metadata(access.equals(ResourceAccess.PRIVATE) ? MinIOConvertUtils.toUserBucket(workSpace.getUserBucketPrefix(), accountID) : workSpace.getPublicBucket(), MimeTypeUtils.parseMimeType("message/x.rsocket.userbucket"))
                    .metadata(workSpace.getDataset(), MimeTypeUtils.parseMimeType("message/x.rsocket.datasetbase"))
                    .metadata(workSpace.getEnv(), MimeTypeUtils.parseMimeType("message/x.rsocket.env"));
        }
        return request.data(fileBytes).retrieveMono(ParserRet.class);
    }
}
