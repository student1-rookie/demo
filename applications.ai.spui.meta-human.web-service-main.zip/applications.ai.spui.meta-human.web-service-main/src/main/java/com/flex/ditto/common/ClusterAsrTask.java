package com.flex.ditto.common;

public record ClusterAsrTask(String dataset, String type, String env, String lang) {
}
