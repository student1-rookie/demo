package com.flex.ditto.config.security;

import com.flex.ditto.domain.Account;
import lombok.Data;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import reactor.core.publisher.Mono;

import java.util.*;
import java.util.stream.Collectors;

@Data
public class UserPrincipal {
    private Map<String, Object> principal;

    private UserPrincipal(Map<String, Object> principal) {
        this.principal = principal;
    }

    public static Mono<UserPrincipal> convertToUserPrincipal(Authentication authentication) {
        Map<String, Object> p = new HashMap<>();
        if (authentication instanceof OAuth2AuthenticationToken) {
            OidcUser principal = (OidcUser) authentication.getPrincipal();
            p.put("sid", Objects.requireNonNull(principal.getAttribute("id")));
            p.put("roles", principal.getAuthorities().stream().map(GrantedAuthority::getAuthority).collect(Collectors.joining(",")));
            p.put("email", Objects.requireNonNull(principal.getEmail()));
            p.put("name", Objects.requireNonNull(principal.getName()));
        } else if (authentication instanceof UsernamePasswordAuthenticationToken) {
            Object info = authentication.getCredentials();
            if (info instanceof Account account) {
                p.put("sid", account.getId());
                p.put("roles", account.getRoles());
                p.put("email", account.getEmail());
                p.put("name", account.getName());
            }
        }
        return Mono.just(new UserPrincipal(p));
    }

    public Boolean containsAttribute(String attribute) {
        return principal != null && principal.containsKey(attribute);
    }

    private Object attributeCheck(String attribute) {
        if (principal == null) {
            throw new NullPointerException("UserPrincipal is null");
        }
        if (!principal.containsKey(attribute)) {
            throw new IllegalArgumentException("UserPrincipal does not contain attribute: " + attribute);
        }
        Object v = principal.get(attribute);
        if (v == null) {
            throw new NoSuchElementException("UserPrincipal attribute is null: " + attribute);
        }
        return v;
    }

    public UUID getSid() {
        return getAttribute("sid", UUID.class);
    }

    public List<String> getRoles() {
        return Arrays.stream(getAttribute("roles", String.class).split(",+")).toList();
    }

    public boolean isAdmin() {
        return getRoles().contains("ROLE_ADMIN");
    }

    public String getEmail() {
        return getAttribute("email");
    }

    public String getName() {
        return getAttribute("name");
    }

    public String getAttribute(String attribute) {
        return attributeCheck(attribute).toString();
    }

    public <T> T getAttribute(String attribute, Class<T> clazz) {
        Object v = attributeCheck(attribute);
        if (clazz.isInstance(v)) {
            return clazz.cast(v);
        }
        throw new ClassCastException("Attribute " + attribute + " cannot be cast to " + clazz);
    }
}
