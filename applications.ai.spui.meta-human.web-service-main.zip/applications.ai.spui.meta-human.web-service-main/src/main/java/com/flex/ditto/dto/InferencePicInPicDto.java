package com.flex.ditto.dto;

import com.flex.ditto.common.InferenceType;
import com.flex.ditto.common.ModelType;
import com.flex.ditto.common.RunningDevice;

import lombok.Data;

import java.util.List;
import java.util.Map;
import java.util.UUID;

@Data
public class InferencePicInPicDto {
    private UUID id;
    private String name;
    private Map<ModelType, UUID> models;
    private InferenceType type;
    private List<PicInPicDto> input;
    private String backgroundImage;
    private Boolean subtitle;
    private Boolean hdtr;
    private Integer seed;
    private String resolution;
    private SubtitleStyleDto subtitleStyleDto;
    private TTSInstructDto ttsInstructDto;
    private Map<String, Object> extraInfo;
    private RunningDevice device;
}