package com.flex.ditto.common;

public enum ModelType {
    TTS, FACE
}
