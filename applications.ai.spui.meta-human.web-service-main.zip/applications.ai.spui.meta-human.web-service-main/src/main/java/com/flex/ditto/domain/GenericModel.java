package com.flex.ditto.domain;

import com.flex.ditto.common.MetaHumanModelType;
import com.flex.ditto.common.ModelStatus;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@NoArgsConstructor
public class GenericModel {
    private UUID id;
    private MetaHumanModelType model;
    private ModelStatus status;
}
