package com.flex.ditto.domain;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import com.flex.ditto.common.ResourceAccess;

import java.time.ZonedDateTime;
import java.util.UUID;

@Data
@Table("meta_human_dataset_group")
@NoArgsConstructor
public class MetaHumanDatasetGroup {
    @Id
    private UUID id;
    private String name;
    private ResourceAccess type;
    @Column("create_date")
    private ZonedDateTime date;
    @Column("account_id")
    private UUID accountId;

    public MetaHumanDatasetGroup(String name) {
        this.name = name;
    }

    public MetaHumanDatasetGroup(String name, ZonedDateTime date, ResourceAccess type, UUID accountId) {
        this.name = name;
        this.type= type;
        this.date = date;
        this.accountId = accountId;
    }
}
