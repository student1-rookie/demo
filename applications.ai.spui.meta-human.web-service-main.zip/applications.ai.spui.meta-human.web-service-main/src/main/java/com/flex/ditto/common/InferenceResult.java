package com.flex.ditto.common;

public enum InferenceResult {
    VIDEO, AUDIO, PIP, PIP_ITEM;

    public static InferenceResult getResultType(InferenceType type) {
        if (type.equals(InferenceType.TTS_ONLY)) {
            return AUDIO;
        } else if (type.equals(InferenceType.PIC_IN_PIC)) {
            return PIP;
        } else {
            return VIDEO;
        }
    }
}
