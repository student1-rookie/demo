package com.flex.ditto.dto;

import com.flex.ditto.common.ModelType;

import java.util.UUID;

public record ModelDto(UUID id, ModelType type) {}
