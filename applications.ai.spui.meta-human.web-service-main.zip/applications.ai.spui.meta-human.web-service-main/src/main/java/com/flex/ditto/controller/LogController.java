package com.flex.ditto.controller;

import com.flex.ditto.config.security.UserPrincipal;
import com.flex.ditto.service.LogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/log")
public class LogController {
    @Autowired
    private LogService logService;

    @GetMapping("/complete")
    public Mono<Resource> getCompleteLogs(@RequestParam(value = "jobId", required = true) String jobId,
                                          @AuthenticationPrincipal UserPrincipal user) {
        return logService.getAllCompletedLogsFromStreamGroup(user.getSid(), jobId);
    }

    @GetMapping("/ongoing")
    public Flux<ServerSentEvent<String>> getOngoingLogs(@RequestParam(value = "jobId", required = true) String jobId, 
                                                       @RequestParam(defaultValue = "0-0") String lastEventId) {
       return logService.getOngoingLogs(jobId, lastEventId);
    }
}