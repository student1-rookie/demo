package com.flex.ditto.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.data.relational.core.mapping.Table;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.core.oidc.OidcUserInfo;
import org.springframework.security.oauth2.core.oidc.user.DefaultOidcUser;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;

import java.util.*;

@Data
@Table("account")
public class Account {
    @Id
    private UUID id;
    private final String email;
    private final String name;
    private final String roles;
    @JsonIgnore
    private final String password;

    public OidcUser toOidcUser(OidcUser ori) {
        Set<GrantedAuthority> mappedAuthorities = new HashSet<>(Arrays.stream(this.roles.split(","))
                .map(SimpleGrantedAuthority::new).toList());
        Map<String, Object> claims = new HashMap<>(ori.getClaims());
        claims.put("id", id);
        return new DefaultOidcUser(mappedAuthorities, ori.getIdToken(), new OidcUserInfo(claims), "name");
    }
}
