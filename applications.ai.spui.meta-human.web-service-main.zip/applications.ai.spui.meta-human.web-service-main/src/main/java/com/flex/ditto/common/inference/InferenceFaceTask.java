package com.flex.ditto.common.inference;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.flex.ditto.common.InferenceType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@JsonSerialize
@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class InferenceFaceTask {
    @JsonIgnore
    String id;
    String name;
    String wav;
    String face_model;
    InferenceType type;
    String extra;
    UUID account_id;
}
