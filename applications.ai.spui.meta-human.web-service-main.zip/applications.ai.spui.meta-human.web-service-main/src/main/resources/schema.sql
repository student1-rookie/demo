CREATE TABLE IF NOT EXISTS account (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) NOT NULL UNIQUE,
    name VARCHAR(255) NOT NULL,
    roles VARCHAR(255),
    password VARCHAR(255)
);
CREATE TABLE IF NOT EXISTS meta_human_dataset_group (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    type VARCHAR(10) DEFAULT 'PRIVATE',
    create_date TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    account_id UUID REFERENCES account (id)
);
CREATE TABLE IF NOT EXISTS meta_human_dataset (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    type VARCHAR(10) DEFAULT 'PRIVATE',
    file_type VARCHAR(12) DEFAULT 'VIDEO',
    create_date TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    file_name VARCHAR(255) NOT NULL,
    identifier VARCHAR(255) NOT NULL UNIQUE,
    text json,
    internal boolean DEFAULT FALSE,
    account_id UUID REFERENCES account (id),
    group_id UUID REFERENCES meta_human_dataset_group (id)
);
CREATE TABLE IF NOT EXISTS meta_human_face (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    type VARCHAR(10) DEFAULT 'PRIVATE',
    model VARCHAR(255),
    status VARCHAR(10),
    detail VARCHAR(255),
    parameters jsonb,
    run_service VARCHAR(255),
    create_date TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    account_id UUID REFERENCES account (id),
    dataset_id UUID REFERENCES meta_human_dataset (id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS meta_human_tts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    type VARCHAR(10) DEFAULT 'PRIVATE',
    model VARCHAR(255),
    status VARCHAR(10),
    detail VARCHAR(255),
    parameters jsonb,
    run_service VARCHAR(255),
    create_date TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    account_id UUID REFERENCES account (id),
    dataset_id UUID REFERENCES meta_human_dataset (id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS meta_human_infer_group (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL
);
CREATE TABLE IF NOT EXISTS meta_human_infer (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    create_date TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(10),
    account_id UUID REFERENCES account (id),
    face_model UUID,
    tts_model UUID,
    type VARCHAR(10) NOT NULL,
    run_service VARCHAR(255),
    group_id UUID REFERENCES meta_human_infer_group (id) ON DELETE SET NULL,
    FOREIGN KEY (face_model) REFERENCES meta_human_face(id) ON DELETE SET NULL,
    FOREIGN KEY (tts_model) REFERENCES meta_human_tts(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS meta_human_pic_template (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    details json NOT NULL,
    account_id UUID REFERENCES account (id) NOT NULL,
    group_id UUID REFERENCES meta_human_infer_group (id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS meta_human_notify (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    message VARCHAR(128) NOT NULL,
    create_date TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    account_id UUID REFERENCES account (id),
    status VARCHAR(10)
);

ALTER TABLE meta_human_face ALTER COLUMN create_date TYPE TIMESTAMPTZ USING create_date::TIMESTAMPTZ;
ALTER TABLE meta_human_tts ALTER COLUMN create_date TYPE TIMESTAMPTZ USING create_date::TIMESTAMPTZ;
ALTER TABLE meta_human_infer ALTER COLUMN create_date TYPE TIMESTAMPTZ USING create_date::TIMESTAMPTZ;
ALTER TABLE meta_human_dataset ALTER COLUMN create_date TYPE TIMESTAMPTZ USING create_date::TIMESTAMPTZ;
ALTER TABLE meta_human_dataset ADD COLUMN IF NOT EXISTS text json;
ALTER TABLE meta_human_face ADD COLUMN IF NOT EXISTS parameters jsonb;
ALTER TABLE meta_human_tts ADD COLUMN IF NOT EXISTS parameters jsonb;
ALTER TABLE meta_human_face ADD COLUMN IF NOT EXISTS run_service VARCHAR(255);
ALTER TABLE meta_human_tts ADD COLUMN IF NOT EXISTS run_service VARCHAR(255);
ALTER TABLE meta_human_infer ADD COLUMN IF NOT EXISTS run_service VARCHAR(255);
ALTER TABLE meta_human_dataset ADD COLUMN IF NOT EXISTS group_id UUID REFERENCES meta_human_dataset_group (id);
ALTER TABLE meta_human_dataset ADD COLUMN IF NOT EXISTS internal boolean DEFAULT FALSE;
ALTER TABLE meta_human_dataset_group ADD COLUMN IF NOT EXISTS type varchar(10) DEFAULT 'PRIVATE' NULL;
ALTER TABLE meta_human_dataset_group ADD COLUMN IF NOT EXISTS create_date timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL;
ALTER TABLE meta_human_dataset_group ADD COLUMN IF NOT EXISTS account_id UUID REFERENCES account (id) NULL;
ALTER TABLE meta_human_pic_template ADD COLUMN IF NOT EXISTS group_id UUID REFERENCES meta_human_infer_group (id);
ALTER TABLE meta_human_infer ADD COLUMN IF NOT EXISTS group_id UUID REFERENCES meta_human_infer_group (id);
ALTER TABLE meta_human_dataset ALTER COLUMN file_type TYPE VARCHAR(12) USING file_type::VARCHAR(12);

BEGIN;
ALTER TABLE meta_human_pic_template DROP CONSTRAINT IF EXISTS meta_human_pic_template_group_id_fkey;
ALTER TABLE meta_human_pic_template ADD CONSTRAINT meta_human_pic_template_group_id_fkey FOREIGN KEY (group_id) REFERENCES meta_human_infer_group (id) ON DELETE SET NULL;
COMMIT;

BEGIN;
ALTER TABLE meta_human_face DROP CONSTRAINT meta_human_face_dataset_id_fkey;
ALTER TABLE meta_human_tts DROP CONSTRAINT meta_human_tts_dataset_id_fkey;
ALTER TABLE meta_human_face ADD CONSTRAINT meta_human_face_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES meta_human_dataset (id) ON DELETE SET NULL;
ALTER TABLE meta_human_tts ADD CONSTRAINT meta_human_tts_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES meta_human_dataset (id) ON DELETE SET NULL;
COMMIT;