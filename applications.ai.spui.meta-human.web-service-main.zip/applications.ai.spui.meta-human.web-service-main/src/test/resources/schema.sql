DROP TABLE IF EXISTS account CASCADE;
DROP TABLE IF EXISTS meta_human_dataset CASCADE;
DROP TABLE IF EXISTS meta_human_face CASCADE;
DROP TABLE IF EXISTS meta_human_tts CASCADE;
DROP TABLE IF EXISTS meta_human_infer CASCADE;
CREATE TABLE IF NOT EXISTS account
(
    id    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) NOT NULL UNIQUE,
    name  VARCHAR(255) NOT NULL,
    password VARCHAR(255),
    roles VARCHAR(255)
);
CREATE TABLE IF NOT EXISTS meta_human_dataset
(
    id          UUID PRIMARY KEY      DEFAULT gen_random_uuid(),
    name        VARCHAR(255) NOT NULL,
    type        VARCHAR(10)           DEFAULT 'PRIVATE',
    file_type   VARCHAR(10)           DEFAULT 'VIDEO',
    create_date TIMESTAMPTZ  NOT NULL DEFAULT CURRENT_TIMESTAMP,
    file_name   VARCHAR(255) NOT NULL,
    identifier  VARCHAR(255) NOT NULL UNIQUE,
    text        json,
    account_id  UUID REFERENCES account (id)
);
CREATE TABLE IF NOT EXISTS meta_human_face
(
    id          UUID PRIMARY KEY      DEFAULT gen_random_uuid(),
    name        VARCHAR(255) NOT NULL,
    type        VARCHAR(10)           DEFAULT 'PRIVATE',
    model       VARCHAR(255),
    status      VARCHAR(10),
    detail      VARCHAR(255),
    parameters  json,
    create_date TIMESTAMPTZ  NOT NULL DEFAULT CURRENT_TIMESTAMP,
    account_id  UUID REFERENCES account (id),
    dataset_id  UUID REFERENCES meta_human_dataset (id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS meta_human_tts
(
    id          UUID PRIMARY KEY      DEFAULT gen_random_uuid(),
    name        VARCHAR(255) NOT NULL,
    type        VARCHAR(10)           DEFAULT 'PRIVATE',
    model       VARCHAR(255),
    status      VARCHAR(10),
    detail      VARCHAR(255),
    parameters  json,
    create_date TIMESTAMPTZ  NOT NULL DEFAULT CURRENT_TIMESTAMP,
    account_id  UUID REFERENCES account (id),
    dataset_id  UUID REFERENCES meta_human_dataset (id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS meta_human_infer
(
    id          UUID PRIMARY KEY      DEFAULT gen_random_uuid(),
    name        VARCHAR(255) NOT NULL,
    create_date TIMESTAMPTZ  NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status      VARCHAR(10),
    account_id  UUID REFERENCES account (id),
    face_model  UUID,
    tts_model   UUID,
    type VARCHAR(10) NOT NULL,
    FOREIGN KEY (face_model) REFERENCES meta_human_face (id) ON DELETE SET NULL,
    FOREIGN KEY (tts_model) REFERENCES meta_human_tts (id) ON DELETE SET NULL
);