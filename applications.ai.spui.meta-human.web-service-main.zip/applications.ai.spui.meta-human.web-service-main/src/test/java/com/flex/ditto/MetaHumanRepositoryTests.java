package com.flex.ditto;

import com.flex.ditto.common.ResourceAccess;
import com.flex.ditto.common.ResourceType;
import com.flex.ditto.config.PostgresConfig;
import com.flex.ditto.domain.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.data.r2dbc.DataR2dbcTest;
import org.springframework.context.annotation.Import;
import org.springframework.data.r2dbc.core.R2dbcEntityTemplate;
import org.springframework.data.r2dbc.dialect.PostgresDialect;
import org.springframework.r2dbc.core.DatabaseClient;
import org.springframework.test.context.ActiveProfiles;
import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

@ActiveProfiles("test")
@DataR2dbcTest
@Import(PostgresConfig.class)
class MetaHumanRepositoryTests {

    @Autowired
    private DatabaseClient databaseClient;

    @Autowired
    private FaceModelRepository faceModelRepository;

    @Autowired
    private TTSModelRepository ttsModelRepository;

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private MetaHumanDatasetRepository datasetRepository;

    @BeforeEach
    public void setup() {
        initDatabase();
    }

    private void initDatabase() {
        MetaHumanDataset dataset = datasetRepository.save(new MetaHumanDataset("test_dataset", ZonedDateTime.now(ZoneId.of("UTC")),
                "test.mp4", UUID.randomUUID().toString(), ResourceType.VIDEO)).block();
        Account testAccount = new Account("test@test.com", "test", "ROLE_TEST", null);
        R2dbcEntityTemplate template = new R2dbcEntityTemplate(databaseClient, PostgresDialect.INSTANCE);
        template.insert(Account.class).using(testAccount).then().as(StepVerifier::create).verifyComplete();
        FaceModel faceModel = new FaceModel("model", ZonedDateTime.now(ZoneId.of("UTC")), ResourceAccess.PRIVATE, "ERNERF", "{\"seed\": 123}", testAccount.getId(), dataset.getId());
        template.insert(FaceModel.class).using(faceModel).then().as(StepVerifier::create).verifyComplete();
        TTSModel ttsModel = new TTSModel("model", ZonedDateTime.now(ZoneId.of("UTC")), ResourceAccess.PRIVATE, "BERTVITS", "{\"seed\": 123}", testAccount.getId(), dataset.getId());
        template.insert(TTSModel.class).using(ttsModel).then().as(StepVerifier::create).verifyComplete();

        for (int i = 0; i < 3; i++) {
            FaceModel pubFaceModel = new FaceModel("model_" + i, ZonedDateTime.now(ZoneId.of("UTC")), ResourceAccess.PUBLIC, "ERNERF", "{\"seed\": 111}", null, dataset.getId());
            template.insert(FaceModel.class).using(pubFaceModel).then().as(StepVerifier::create).verifyComplete();
            TTSModel pubTtsModel = new TTSModel("model_" + i, ZonedDateTime.now(ZoneId.of("UTC")), ResourceAccess.PUBLIC, "BERTVITS", "{\"seed\": 111}", null, dataset.getId());
            template.insert(TTSModel.class).using(pubTtsModel).then().as(StepVerifier::create).verifyComplete();
        }
    }

    @Test
    void findModels() {
        Flux<Account> account = accountRepository.findByEmail("test@test.com");
        account.as(StepVerifier::create).assertNext(a -> {
            assertThat(a.getName()).isEqualTo("test");
            assertThat(a.getRoles()).isEqualTo("ROLE_TEST");
        }).verifyComplete();
        Flux<FaceModel> faceModels = accountRepository.findByEmail("test@test.com").next().flatMapMany(
                x -> faceModelRepository.findByAccountId(x.getId())
        );
        faceModels.map(FaceModel::getName).as(StepVerifier::create)
                .expectNext("model", "model_0", "model_1", "model_2")
                .expectComplete().verify();
        Flux<TTSModel> ttsModels = accountRepository.findByEmail("test@test.com").next().flatMapMany(
                x -> ttsModelRepository.findByAccountId(x.getId())
        );
        ttsModels.map(TTSModel::getName).as(StepVerifier::create)
                .expectNext("model", "model_0", "model_1", "model_2")
                .expectComplete().verify();
    }
}
