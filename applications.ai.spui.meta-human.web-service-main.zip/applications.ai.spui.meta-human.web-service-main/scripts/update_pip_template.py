from transfer import search_db
from clean import update_db
import json

def update_templates():
    sql = "select * from meta_human_pic_template"
    template_infos = search_db(sql, {})
    for template_info in template_infos:
        template_id = template_info[0]
        template_account_id = template_info[3]

        template_details = template_info[2]
        template_models = template_details.get("models")
        if not template_models:
            continue

        tts_model_name = template_models.get("TTS", None)
        face_model_name = template_models.get("FACE", None)
        tts_id = get_model(tts_model_name, template_account_id, "tts")
        face_id = get_model(face_model_name, template_account_id, "face")

        update_template_details(template_id, template_details, tts_id, face_id)
        print(f"update {template_info[1]} complete")

def get_model(model_name, account_id, task):
    sql = f"select id from meta_human_{task} where name = %s and (account_id = %s or type = 'PUBLIC') limit 1"
    ret = search_db(sql, (model_name, account_id))
    return ret[0][0] if ret else None

def update_template_details(template_id, template_details, tts_id, face_id):
    template_details["models"]["TTS"] = tts_id
    template_details["models"]["FACE"] = face_id
    sql = "update meta_human_pic_template set details = %s where id = %s"
    template_details_json = json.dumps(template_details, ensure_ascii=False)
    update_db(sql, (template_details_json, template_id))

if __name__ == "__main__":
    update_templates()