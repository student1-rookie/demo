from transfer import search_db, model_base, minio_client, public_bucket, user_bucket_prefix
from clean import update_db

TASKS = ["face", "tts"]


def check_object(bucket, object_path):
    if minio_client.bucket_exists(bucket):
        try:
            minio_client.stat_object(bucket, object_path)
            return True  # Object exists
        except Exception as e:
            # print(e)
            return False

    else:
        print("Bucket {} doesn't exist".format(bucket))
    return False


def delete_model(task, ids):
    sql = f"DELETE FROM meta_human_{task} WHERE id IN %(ids)s"
    update_db(sql, {"ids": tuple(ids)})


def get_models(task):
    sql = f"select id, type, name, account_id, model from meta_human_{task}"
    model_info = search_db(sql, {})
    invalid_models = []
    for model in model_info:
        model_id = model[0]
        is_public = model[1] == "PUBLIC"
        bucket = public_bucket if is_public else f"{user_bucket_prefix}{model[3]}"
        if model[4] in ["ERNERF", "GAUSSIAN", "BERTVITS", "GPTSOVITS"]:
            # check exist...
            object_path = f"{model_base}/{model_id}/{model[2]}_{task}.tar.gz"
            ret = check_object(bucket, object_path)
            if not ret:
                print(f"Invalid model:", model)
                invalid_models.append(model_id)
    print("Invalid models count:", len(invalid_models))
    if len(invalid_models) > 0:
        delete_model(task, invalid_models)

if __name__ == "__main__":
    for task in TASKS:
        get_models(task)
