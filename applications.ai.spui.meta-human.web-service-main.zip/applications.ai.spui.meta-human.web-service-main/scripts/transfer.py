import os.path
import base64
import shutil
import psycopg2

from minio import Minio
from dataclasses import dataclass

mh_workspace = ""
infer_dir = ""
log_dir = ""
minio_endpoint = os.environ.get("MINIO_ENDPOINT", "localhost:9000")
minio_access_key = os.environ.get("MINIO_ACCESS_KEY", "")
minio_secret_key = os.environ.get("MINIO_SECRET_KEY", "")
minio_client = Minio(endpoint=minio_endpoint, access_key=minio_access_key, secret_key=minio_secret_key, secure=False)

public_bucket = "mh-public"
user_bucket_prefix = "user-"
dataset_base = "dataset"
model_base = "model"
infer_base = "infer"
log_base = "log"


@dataclass
class DbConfig:
    host: str
    database: str
    user: str
    password: str

    @staticmethod
    def generate():
        host = os.getenv("DB_HOST", "localhost")
        database = os.getenv("DB_DATABASE", "flex_mh")
        user = os.getenv("DB_USER", "<USER>")
        password = os.getenv("DB_PASSWORD", "<PASSWORD>")
        return DbConfig(host, database, user, password)


db_config = DbConfig.generate()


def create_bucket(bucket):
    if not minio_client.bucket_exists(bucket):
        minio_client.make_bucket(bucket)


def upload(bucket, object_path, src_path):
    if minio_client.bucket_exists(bucket):
        minio_client.fput_object(bucket, object_path, src_path)
    else:
        print("Bucket {} doesn't exist".format(bucket))


def search_db(sql, vars):
    with psycopg2.connect(**db_config.__dict__) as conn:
        with conn.cursor() as cur:
            cur.execute(sql, vars)
            return cur.fetchall()


# create user bucket and public bucket

def init_bucket():
    account_info = search_db("select id from account", {})
    if len(account_info) != 0:
        for account in account_info:
            account_id = account[0]
            create_bucket(f"{user_bucket_prefix}{account_id}")
        print(f"account count is {len(account_info)}")


# upload dataset
def transfer_dataset():
    dataset_info = search_db("select id, type, file_name, account_id from meta_human_dataset", {})
    if len(dataset_info) != 0:
        for dataset in dataset_info:
            dataset_id = dataset[0]
            is_public = dataset[1] == "PUBLIC"
            bucket = public_bucket if is_public else f"{user_bucket_prefix}{dataset[3]}"
            file_path = os.path.join(mh_workspace, dataset_id, dataset[2])
            if os.path.isfile(file_path):
                upload(bucket, f"{dataset_base}/{dataset_id}/{dataset[2]}", file_path)
            else:
                print(f"Dataset file doesn't exist: {file_path}")
        print(f"dataset count is {len(dataset_info)}")


# upload model
def transfer_model(task: str):
    model_info = search_db(f"select id, type, name, account_id, model from meta_human_{task}", {})
    if len(model_info) != 0:
        for model in model_info:
            model_id = model[0]
            is_public = model[1] == "PUBLIC"
            bucket = public_bucket if is_public else f"{user_bucket_prefix}{model[3]}"
            if model[4] in ["ERNERF", "GAUSSIAN", "BERTVITS", "GPTSOVITS"]:
                # local mode
                model_dir_id = base64.b64encode(model_id.encode('ascii')).decode('ascii')
                model_folder = os.path.join(mh_workspace, model_dir_id, f"{model[2]}_{task}")
                if os.path.exists(model_folder):
                    # tar model folder
                    root_dir = os.path.dirname(model_folder)
                    zip_file = shutil.make_archive(model_folder, "gztar", root_dir, None)
                    object_path = f"{model_base}/{model_id}/" + os.path.basename(zip_file)
                    upload(bucket, object_path, zip_file)
                else:
                    print(f"Model file doesn't exist: {model_folder}")
                if model[4] in ["ERNERF", "GAUSSIAN"]:
                    # upload avatar
                    avatar_file = os.path.join(mh_workspace, model_dir_id, "avatar", "avatar.jpg")
                    if os.path.isfile(avatar_file):
                        avatar_object_path = f"{model_base}/{model_id}/avatar/avatar.jpg"
                        upload(bucket, avatar_object_path, avatar_file)
                    else:
                        print(f"Avatar file doesn't exist: {avatar_file}")
                    preview_file = os.path.join(mh_workspace, model_dir_id, "preview", "preview.jpg")
                    if os.path.isfile(preview_file):
                        preview_object_path = f"{model_base}/{model_id}/preview/preview.jpg"
                        upload(bucket, preview_object_path, preview_file)
                    else:
                        print(f"Preview file doesn't exist: {preview_file}")
            # upload log
            log_file = os.path.join(mh_workspace, log_dir, f"{model_id}.log")
            if os.path.isfile(log_file):
                log_object_path = f"{log_base}/{model_id}.log"
                upload(bucket, log_object_path, log_file)
            else:
                print(f"Log file doesn't exist: {log_file}")


# upload infer
def transfer_infer():
    infer_info = search_db("select id, name, account_id, type from meta_human_infer", {})
    if len(infer_info) != 0:
        for infer in infer_info:
            infer_id = infer[0]
            bucket = f"{user_bucket_prefix}{infer[2]}"
            file_suffix = ".wav" if infer[3] == "AUDIO" else ".mp4"
            infer_file = os.path.join(mh_workspace, infer_dir, infer_id, infer[1] + file_suffix)
            if os.path.isfile(infer_file):
                infer_object_path = f"{infer_base}/{infer_id}/{infer[1] + file_suffix}"
                upload(bucket, infer_object_path, infer_file)
            else:
                print(f"Infer file doesn't exist: {infer_file}")
            # upload log
            log_file = os.path.join(mh_workspace, log_dir, f"{infer_id}.log")
            if os.path.isfile(log_file):
                log_object_path = f"{log_base}/{infer_id}.log"
                upload(bucket, log_object_path, log_file)
            else:
                print(f"Log file doesn't exist: {log_file}")


if __name__ == "__main__":
    init_bucket()
    transfer_dataset()
    transfer_model("face")
    transfer_model("tts")
    transfer_infer()
