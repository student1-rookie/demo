from minio.deleteobjects import DeleteObject
import psycopg2
from itertools import islice

from transfer import search_db, minio_client, db_config, public_bucket, user_bucket_prefix, dataset_base

ACCOUNT_ID = ""
FILE_TYPE = "IMAGE"
SEARCH_SQL = "select id, type from meta_human_dataset where account_id = %(account_id)s and file_type = %(file_type)s"


# clean it by minio api
def clean_object(bucket, object_path):
    if minio_client.bucket_exists(bucket):
        objects = minio_client.list_objects(bucket, prefix=object_path, recursive=True)
        delete_objects = [DeleteObject(obj.object_name) for obj in objects]
        if not delete_objects:
            print(f"{object_path} does not exist")
            return

        errors = minio_client.remove_objects(bucket, delete_objects)
        for error in errors:
            print(f"delete failed: {error.object_name}, error: {error.message}")
    else:
        print("Bucket {} doesn't exist".format(bucket))


def update_db(sql, vars):
    with psycopg2.connect(**db_config.__dict__) as conn:
        with conn.cursor() as cur:
            cur.execute(sql, vars)
            updated_row_count = cur.rowcount
            returned_id = None
            if cur.description and 'RETURNING' in sql.upper():
                returned_id = cur.fetchone()[0]
        conn.commit()
    return updated_row_count, returned_id


def delete_dataset(ids):
    sql = "DELETE FROM meta_human_dataset WHERE id IN %(ids)s"
    update_db(sql, {"ids": tuple(ids)})


def chunk_iterator(iterator, chunk_size):
    while True:
        chunk = list(islice(iterator, chunk_size))
        if not chunk:
            break
        yield chunk


if __name__ == "__main__":
    dataset_info = search_db(SEARCH_SQL, {"account_id": ACCOUNT_ID, "file_type": FILE_TYPE})
    dataset_ids = [d[0] for d in dataset_info]

    for info in dataset_info:
        dataset_id = info[0]
        is_public = info[1] == "PUBLIC"
        bucket = public_bucket if is_public else f"{user_bucket_prefix}{ACCOUNT_ID}"
        dataset_path = f"{dataset_base}/{dataset_id}"
        clean_object(bucket, dataset_path)
    print("dataset ids count:", len(dataset_ids))
    for parts in chunk_iterator(iter(dataset_ids), 10):
        delete_dataset(parts)
