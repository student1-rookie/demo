# Meta-human web

Node: v18
npm: v9

Install:
`npm install`

Run for development:
`npx vite --host`

Build for production:
`npm run build`

