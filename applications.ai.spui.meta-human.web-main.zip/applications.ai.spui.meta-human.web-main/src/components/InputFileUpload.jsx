import Button from '@mui/material/Button';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import PropTypes from 'prop-types';

  export default function InputFileUpload({ onChange }) {
    return (
      <Button
        component="label"
        role={undefined}
        variant="contained"
        tabIndex={-1}
        startIcon={<CloudUploadIcon />}
      >
        Upload Video
        <input
          type="file"
          accept="video/*"
          hidden
          onChange={onChange}
        />
      </Button>
    );
  }

  InputFileUpload.propTypes = {
    /**
     * The onChange callback
     */
    onChange: PropTypes.func.isRequired,
  };