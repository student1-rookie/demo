import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import { useRef, useState, useEffect } from "react";
import {
  Backdrop,
  Card,
  CardActions,
  CardContent,
  CardHeader,
  CardMedia, CircularProgress,
  IconButton, Stack,
  TextField, Typography
} from "@mui/material";
import VideocamOutlinedIcon from '@mui/icons-material/VideocamOutlined';
import VideocamOffOutlinedIcon from '@mui/icons-material/VideocamOffOutlined';
import SparkMD5 from "spark-md5";
import Swal from "sweetalert2";
import {postResourceFile} from "../lib/mh.js";
import CircularProgressWithLabel from "./CircularProgressWithLabel.jsx";
import PropTypes from "prop-types";
import MenuItem from "@mui/material/MenuItem";
import Select from "@mui/material/Select";
import FormControl from "@mui/material/FormControl";
import InputLabel from "@mui/material/InputLabel";

export default function VideoRecord({ fetchResources, fetchResourcesGroup }) {

  const [videoURL, setVideoURL] = useState('');
  const [videoBlob, setVideoBlob] = useState(null);
  const [videoError, setVideoError] = useState(false);

  const videoRecoderRef = useRef(null);
  const recordingRef = useRef(null);
  const streamRef = useRef(null);


  const [videoName, setVideoName] = useState("");

  const [recording, setRecording] = useState(false);

  const [isLargeFile, setIsLargeFile] = useState(false);
  const [uploadStatusText, setUploadStatusText] = useState('');
  const [progress, setProgress] = useState(0);

  const CONFIRM_BUTTON_COLOR = '#1976d2';

  const [uploading, setUploading] = useState(false);

  const [resolution, setResolution] = useState('720p');
  const [availableResolutions, setAvailableResolutions] = useState(['720p']);
  const resolutionMap = {
    '480p':  { width: 640, height: 480},
    '720p':  { width: 1280, height: 720 },
    '1080p': { width: 1920, height: 1080 },
    '2k':    { width: 2560, height: 1440 },
    '4k':    { width: 3840, height: 2160 },
  };

  useEffect(() => {
    let probeStream;
    const probeCapabilities = async () => {
      try {
        probeStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
        const videoTrack = probeStream.getVideoTracks()[0];
        const capabilities = videoTrack.getCapabilities ? videoTrack.getCapabilities() : null;
        const settings = videoTrack.getSettings ? videoTrack.getSettings() : {};
        const maxWidth = capabilities?.width?.max ?? settings.width ?? 1280;
        const maxHeight = capabilities?.height?.max ?? settings.height ?? 720;
        const supported = Object.entries(resolutionMap)
          .filter(([, wh]) => wh.width <= maxWidth && wh.height <= maxHeight)
          .map(([key]) => key);
        setAvailableResolutions(supported.length ? supported : ['720p']);
        if (supported.length && !supported.includes(resolution)) {
          const best = supported
            .sort((a, b) => {
              const pa = resolutionMap[a].width * resolutionMap[a].height;
              const pb = resolutionMap[b].width * resolutionMap[b].height;
              return pb - pa;
            })[0];
          setResolution(best);
        }
      } catch (err) {
        setAvailableResolutions(['720p']);
      } finally {
        if (probeStream) {
          probeStream.getTracks().forEach(track => track.stop());
        }
      }
    };
    probeCapabilities();
  }, [resolution]);

  const getMediaConstraints = () => {
    const { width, height } = resolutionMap[resolution] || resolutionMap['720p'];
    return {
      video: {
        width:  { ideal: width },
        height: { ideal: height }
      },
      audio: true
    };
  };

  const getStreamByConstraints = async () => {
    try {
      const constraints = getMediaConstraints();
      const stream = await navigator.mediaDevices.getUserMedia(constraints);

      if (streamRef.current) {
        streamRef.current.getTracks().forEach(t => t.stop());
      }
      streamRef.current = stream;
      if (videoRecoderRef.current) {
        videoRecoderRef.current.srcObject = stream;
      }
      return stream;
    } catch (err) {
      console.error('getUserMedia error:', err);
      Swal.fire({
        title: 'failed to access the camera',
        text: 'Please check if the device is available',
        icon: 'error',
        confirmButtonColor: '#1976d2'
      });
      throw err;
    }
  };

  const startRecording = async () => {
    if (!recording) {
      const stream = await getStreamByConstraints();

      recordingRef.current = new MediaRecorder(stream);
      const chunks = [];
      recordingRef.current.ondataavailable = (event) => {
        chunks.push(event.data);
      }

      recordingRef.current.onstop = async () => {
        const blob = new Blob(chunks, { type: "video/mp4" });
        const url = URL.createObjectURL(blob);
        setVideoURL(url);
        setVideoBlob(blob);
      }

      recordingRef.current.start();
      setRecording(true);
    }
  }

  const stopRecording = () => {
    recordingRef.current.stop();
    videoRecoderRef.current.srcObject.getTracks().forEach(track => track.stop());
    setRecording(false);
  }

  const videoUpload = async () => {
    if (!videoName || videoName.trim() === '') {
      setVideoError(true);
      return;
    }
    setUploading(true);
    let blobSlice = File.prototype.slice || File.prototype.mozSlice || File.prototype.webkitSlice;
    const chunkSize = 10 * 1024 * 1024; // 10MB
    const chunks = Math.ceil(videoBlob.size / chunkSize);
    let currentChunk = 0;
    let spark = new SparkMD5.ArrayBuffer();
    let fileReader = new FileReader();
    setIsLargeFile(videoBlob.size > 50 * 1024 * 1024); // 50MB
    setUploadStatusText(`Computing MD5 of ${videoName}...`);

    fileReader.onerror = function () {
      console.warn('oops, something went wrong.');
      setUploadStatusText('');
      setProgress(0);
    };

    function loadNext() {
      let start = currentChunk * chunkSize,
        end = ((start + chunkSize) >= videoBlob.size) ? videoBlob.size : start + chunkSize;

      fileReader.readAsArrayBuffer(blobSlice.call(videoBlob, start, end));
    }

    fileReader.onload = async function (e) {
      setProgress((currentChunk + 1) / chunks * 100.0);
      spark.append(e.target.result); // Append array buffer
      currentChunk++;

      console.log(spark);
      if (currentChunk < chunks) {
        loadNext();
      } else {
        console.log('finished loading');
        setProgress(0);
        setUploadStatusText('');
        const hash = spark.end();
        console.info('computed hash', hash);  // Compute hash

        setUploadStatusText(`Uploading ${videoName} ...`);

        const metaInfo = {
          datasetName: videoName,
          date: new Date().toISOString(), // ISO
          type: false,
          identifier: hash,
          fileType: 'VIDEO'
        }
        console.log(metaInfo);
        try {
          const status = await postResourceFile(videoBlob, metaInfo, (progressPercent) => {
            setProgress(progressPercent);
          });
          console.log(status);
          if (status !== 201) { // created
            Swal.fire({
              title: 'Failed to upload file',
              text: `Error code: ${status}`,
              icon: 'error',
              confirmButtonColor: CONFIRM_BUTTON_COLOR
            });
          }
          Swal.fire({
            title: 'upload successfully',
            showConfirmButton: false,
            icon: "success",
            timer: 1500
          });
          URL.revokeObjectURL(videoURL);
          fetchResources();
          fetchResourcesGroup();
          setVideoURL('');
          setVideoName('');
          setVideoBlob(null);
        } catch (e) {
          console.error(e);
        } finally {
          setUploadStatusText('');
          setProgress(0);
          setUploading(false);
        }
      }
    };

    loadNext();
  }

  return (
    <>
      <Box display="flex" flexDirection="column" justifyContent="flex-start" gap={2}>

        <Box display="flex" flexDirection="row" justifyContent="center" gap={2}>
          <Card>
            <CardHeader title="Video Recording" />
            <CardContent>
              <FormControl size="small" sx={{ mb: 1, minWidth: 140 }}>
                <InputLabel id="resolution-select-label">resolution</InputLabel>
                <Select
                  labelId="resolution-select-label"
                  value={resolution}
                  label="resolution"
                  size="small"
                  onChange={(e) => {
                    const next = e.target.value;
                    setResolution(next);
                    if (recording) {
                      Swal.fire({
                        title: 'resolution has been changed',
                        text: 'Please start recording again',
                        icon: 'warning',
                        confirmButtonColor: '#1976d2'
                      });
                    }
                  }}
                >
                  {availableResolutions.map(opt => (
                    <MenuItem key={opt} value={opt}>{opt}</MenuItem>
                  ))}
                </Select>
              </FormControl>
              <video ref={videoRecoderRef} width="480" height="480" autoPlay></video>
            </CardContent>
            <CardActions>
              <IconButton onClick={startRecording}>
                <VideocamOutlinedIcon />
              </IconButton>
              <IconButton onClick={stopRecording}>
                <VideocamOffOutlinedIcon />
              </IconButton>
            </CardActions>
          </Card>
          <Card>
            <CardHeader title="Video" />
            <CardContent>
              <CardMedia
                component="video"
                src={videoURL}
                style={{ width: 480, height: 480 }}
                controls
                alt={'video'} />
            </CardContent>
            <CardActions>
              <TextField
                label="Video Name"
                sx={{mt: 2}}
                fullWidth
                value={videoName}
                error={videoError}
                helperText={videoError ? 'Name is required' : ''}
                onChange={(e) => {
                  setVideoName(e.target.value);
                  if (e.target.value.trim() !== '') {
                    setVideoError(false);
                  }
                }}
                InputProps={{
                  endAdornment: (
                    <>
                      <Button onClick={videoUpload}>Upload</Button>
                      <Stack sx={{mb: 1}} direction={"row"} spacing={2} >
                        {isLargeFile && <Typography variant="body">{uploadStatusText}</Typography>}
                        {(progress > 0 && isLargeFile) && <CircularProgressWithLabel value={progress}/>}
                      </Stack>
                    </>
                  )
                }}
              />
            </CardActions>
          </Card>
        </Box>
        <Backdrop sx={{ color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1 }} open={uploading}>
          <CircularProgress color="inherit" />
        </Backdrop>
      </Box>
    </>
  );
}

VideoRecord.propTypes = {
  fetchResources: PropTypes.func.isRequired,
  fetchResourcesGroup: PropTypes.func.isRequired
};