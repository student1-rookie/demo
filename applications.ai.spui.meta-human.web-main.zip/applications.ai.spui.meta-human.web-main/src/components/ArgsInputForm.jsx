import Box from "@mui/material/Box";
import {FormControl, Autocomplete} from "@mui/material";
import TextField from "@mui/material/TextField";
import Grid from "@mui/material/Grid";
import {useFormContext, Controller} from "react-hook-form";
import PropTypes from "prop-types";
import { forwardRef } from "react";


const ArgsInputForm = forwardRef((props) => {

    const {formItems, children} = props;

    const { 
        control,
        register,
        formState: {errors}, 
    } = useFormContext();


    return (
        <Box sx={{width: '100%'}}>
            <Grid container spacing={2}>
                {formItems.map((item, index) => {
                    if (item.component === 'input') {
                        const isPrompt = item.name == 'customized_prompt';
                        return (
                            <Grid item xs={12}sm={isPrompt ? 12 : 6} key={index}>
                                <Box sx={{ display: 'flex' }}>
                                    <TextField
                                    label={item.label}
                                    variant="outlined"
                                    size="small"
                                    multiline
                                    {...register(`parameters.${item.name}`)}
                                    error={!!errors.parameters?.[item.name]}
                                    helperText={errors.parameters?.[item.name]?.message}
                                    fullWidth
                                    />
                                </Box>
                            </Grid>
                        );
                    } else if (item.component === 'select') {
                        return (
                            <Grid item xs={12} sm={6} key={index}>
                                <Box sx={{ display: 'flex' }}>
                                    <FormControl variant="outlined" style={{flex: 1}} size="small" error={!!errors.parameters?.[item.name]}>
                                        <Controller
                                            name={`parameters.${item.name}`}
                                            control={control}
                                            render={({ field }) => (
                                                <Autocomplete
                                                    {...field}
                                                    value={field.value || null}
                                                    onChange={(e, newValue) => field.onChange(newValue)}
                                                    options={item.values}
                                                    renderInput={(params) => (
                                                        <TextField
                                                            {...params}
                                                            label={item.label}
                                                            size="small"
                                                            error={!!errors.parameters?.[item.name]}
                                                            helperText={errors.parameters?.[item.name]?.message}
                                                        />
                                                    )}
                                                    fullWidth
                                                    clearOnEscape
                                                    disableClearable={false}
                                                />
                                            )}
                                        />
                                    </FormControl>
                                </Box>
                            </Grid>
                        );
                    }
                })}
                </Grid>
            {children}
        </Box>
    );
});

ArgsInputForm.propTypes = {
    formItems: PropTypes.arrayOf(PropTypes.shape({
        name: PropTypes.string.isRequired,
        label: PropTypes.string.isRequired,
        component: PropTypes.oneOf(['input', 'select']).isRequired,
        type: PropTypes.oneOf(['string', 'number', 'int', 'float']).isRequired,
        values: PropTypes.array,
        defaultValue: PropTypes.any,
    })).isRequired,
    children: PropTypes.node,
};

ArgsInputForm.displayName = "ArgsInputForm";
export default ArgsInputForm;