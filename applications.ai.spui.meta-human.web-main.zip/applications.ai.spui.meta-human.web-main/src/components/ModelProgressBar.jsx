import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import LinearProgress from '@mui/material/LinearProgress';
import {getModelStatus} from "../lib/mh.js";
function LinearProgressWithLabel(props) {
    const formatEstimation = (seconds) => {
        if (seconds <= 0) return "0s";
        if (seconds > 3600) {
            return `${(seconds / 3600).toFixed(2)}h`;
        } else if (seconds > 60) {
            return `${(seconds / 60).toFixed(2)}min`;
        } else {
            return `${Math.ceil(seconds)}s`;
        }
    };
    return (
        <Box display="flex" alignItems="center">
            <Box width="75%" mr={1}>
                <LinearProgress variant="determinate" {...props} />
            </Box>

            <Box minWidth={35}>
                <Typography variant="body2" color="textSecondary">{`Progress: ${Math.round(
                    props.value,
                )}%`}</Typography>
                <Typography variant="body2" color="textSecondary">{`Estimation: ${formatEstimation(props.esti)}`}</Typography>
            </Box>
        </Box>
    );
}

LinearProgressWithLabel.propTypes = {

    value: PropTypes.number.isRequired,
    esti: PropTypes.number.isRequired
};


export default function ModelProcessBar({id, name, type}) {


    const [progress, setProgress] = React.useState(0);
    const [estimation, setEstimation] = React.useState(0);
    const [phase, setPhase] = React.useState("NULL");
    const [status, setStatus] = React.useState("WAIT");

    useEffect(() => {
        let isPolling = true;
        const poll = async () => {
            try {
                let model = {
                    id: id,
                    type: type,
                }
                let modelStatus = await getModelStatus(model);
                if (modelStatus) {
                    setStatus(modelStatus.main);
                    setPhase(modelStatus.phase);
                    //TODO: adjust logic
                    //state:
                    //wait null null (0)
                    //train null null (0)
                    //train pre-process null (0)
                    //train training null (0)
                    //train training num (num)
                    //train post-process null (100)
                    //complete null null (100)
                    if (modelStatus.main === "WAIT" || modelStatus.main === "INIT") {
                        setProgress(0);
                        setEstimation(0);
                    } else if (modelStatus.main === "COMPLETE" || modelStatus.main === "FAIL") {
                        setProgress(100);
                        setEstimation(0);
                        isPolling = false;
                    } else if (modelStatus.main === "TRAIN") {
                        if (!modelStatus.curr) {
                            if (!modelStatus.phase || modelStatus.phase === "PRE-PROCESSING" || modelStatus.phase === "TRAINING") {
                                setProgress(0);
                                setEstimation(0);
                            } else {
                                setProgress(100);
                                setEstimation(0);
                            }
                        } else {
                            setProgress(modelStatus.curr / modelStatus.total * 100);
                            setEstimation(modelStatus.estimated);
                        }
                    }
                }
            } catch (err) {
                console.log("training progress data error:", err);
            }
        }

        let t = null;
        const startPolling = () => {
            poll().then(() => {
                if (isPolling) {
                    t = setTimeout(startPolling, 1000);
                }
            })
        }

        startPolling();

        return () => {
            isPolling = false;
            clearTimeout(t);
        }
    }, [id]);

    return (
        <div style={{width: '100%'}}>
            <Typography variant="body1" color="textSecondary">
                {`Name: ${name} | Status: ${status} | Phase: ${phase}`}
            </Typography>
            <LinearProgressWithLabel value={progress} esti={estimation} sx={{
                height: 20,
                borderRadius: 4,
            }} />
        </div>
    );
}

ModelProcessBar.propTypes = {
    id: PropTypes.object.isRequired,
    name: PropTypes.object.isRequired,
    type: PropTypes.oneOf(['face', 'tts']).isRequired
}
