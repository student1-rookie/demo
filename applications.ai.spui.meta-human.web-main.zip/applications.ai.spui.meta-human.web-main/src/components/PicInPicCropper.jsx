import {forwardRef, useEffect, useImperativeHandle, useRef, useState} from "react";
import Cropper from "cropperjs";
import PropTypes from "prop-types";
import {Backdrop, CircularProgress} from "@mui/material";


const PicInPicCropper = forwardRef((props, ref) => {

  const { width, height, image, overlay, x, y, cropWidth, cropHeight } = props;

  const canvasRef = useRef(null);
  const cropper = useRef(null);

  const [showBackDrop, setShowBackDrop] = useState(false);

  const lastOverlayRef = useRef(null);

  useEffect(() => {
    lastOverlayRef.current = {url: overlay, width: null, height: null};
    if (image && !(x >= 0 && y >= 0 && cropWidth > 0 && cropHeight > 0)) {
      const cropOverlay = new Image();
      cropOverlay.src = overlay;
      cropOverlay.onload = (e) => {
        const { naturalWidth, naturalHeight } = e.target;

        const imageData = cropper.current.getImageData();
        const maxWidth = imageData.naturalWidth;
        const maxHeight = imageData.naturalHeight;
        let boxWidth = naturalWidth;
        let boxHeight = naturalHeight;
        if (naturalWidth > maxWidth || naturalHeight > maxHeight) {
          const scaleWidth = maxWidth / naturalWidth;
          const scaleHeight = maxHeight / naturalHeight;

          const scale = Math.min(scaleWidth, scaleHeight);

          boxWidth = Math.floor(naturalWidth * scale / 2) * 2;
          boxHeight = Math.floor(naturalHeight * scale / 2) * 2;
          console.log('scale into a new resolution', boxWidth, boxHeight);
        } else console.log('fit in');

        const cropBox = {
          x: 0,
          y: 0,
          height: boxHeight,
          width: boxWidth,
        };
        lastOverlayRef.current.width = boxWidth;
        lastOverlayRef.current.height = boxHeight;
        cropper.current.setAspectRatio(boxWidth / boxHeight);
        cropper.current.setData(cropBox);

        const cropFace = document.querySelectorAll('.cropper-face');
        cropFace.forEach((face) => {
          face.style.backgroundImage = `url(${overlay})`;
          face.style.backgroundRepeat = 'no-repeat';
          face.style.backgroundPosition = 'center';
          face.style.backgroundSize = 'contain';
          face.style.opacity = '1';
        });
      }
    }
  }, [overlay]);

  const cropperOptions = {
    viewMode: 1,
    movable: false,
    scalable: false,
    zoomable: false,
    crop(event) { // eslint-disable-line no-unused-vars

    },
    ready() {
      const cropImage = lastOverlayRef.current.url;
      if (x >= 0 && y >= 0 && cropWidth > 0 && cropHeight > 0) {
        const data = cropper.current.getData();
        const cropBox = {
          ...data,
          x: x,
          y: y,
          width: cropWidth,
          height: cropHeight,
        };
        cropper.current.setData(cropBox);
        if (cropImage) {
          const cropFace = document.querySelectorAll('.cropper-face');
          cropFace.forEach((face) => {
            face.style.backgroundImage = `url(${overlay})`;
            face.style.backgroundRepeat = 'no-repeat';
            face.style.backgroundPosition = 'center';
            face.style.backgroundSize = 'contain';
            face.style.opacity = '1';
          });
        }
      } else if (cropImage) {
        const cropOverlay = new Image();
        cropOverlay.src = cropImage;
        cropOverlay.onload = (e) => {
          const { naturalWidth, naturalHeight } = e.target;

          const imageData = cropper.current.getImageData();
          const maxWidth = imageData.naturalWidth;
          const maxHeight = imageData.naturalHeight;
          let boxWidth = naturalWidth;
          let boxHeight = naturalHeight;
          if (naturalWidth > maxWidth || naturalHeight > maxHeight) {
            const scaleWidth = maxWidth / naturalWidth;
            const scaleHeight = maxHeight / naturalHeight;
            const scale = Math.min(scaleWidth, scaleHeight);
            boxWidth = Math.floor(naturalWidth * scale / 2) * 2;
            boxHeight = Math.floor(naturalHeight * scale / 2) * 2;
            console.log('scale into a new resolution', boxWidth, boxHeight);
          } else console.log('fit in');

          const cropBox = {
            x: 0,
            y: 0,
            height: boxHeight,
            width: boxWidth,
          };
          lastOverlayRef.current.width = boxWidth;
          lastOverlayRef.current.height = boxHeight;
          cropper.current.setAspectRatio(boxWidth / boxHeight);
          cropper.current.setData(cropBox);

          const cropFace = document.querySelectorAll('.cropper-face');
          cropFace.forEach((face) => {
            face.style.backgroundImage = `url(${cropImage})`;
            face.style.backgroundRepeat = 'no-repeat';
            face.style.backgroundPosition = 'center';
            face.style.backgroundSize = 'contain';
            face.style.opacity = '1';
          });
        }
      } else {
        const imageData = cropper.current.getImageData();
        const width = Math.round((imageData.naturalWidth / 2) / 2) * 2;
        const height = Math.round((imageData.naturalHeight / 2) / 2) * 2;
        const cropBox = {
          x: imageData.naturalWidth - width,
          y: 0,
          height: height,
          width: width,
        };
        cropper.current.setData(cropBox);
      }
      setShowBackDrop(false);

    },
    cropmove() {
      if (lastOverlayRef.current.width && lastOverlayRef.current.height) {
        const cropBoxData = cropper.current.getData();
        const maxWidth = lastOverlayRef.current.width;
        const maxHeight = lastOverlayRef.current.height;
        if (cropBoxData.width > maxWidth) {
          cropBoxData.width = maxWidth;
        }
        if (cropBoxData.height > maxHeight) {
          cropBoxData.height = maxHeight;
        }
        if (cropBoxData.height * cropBoxData.width > maxHeight * maxWidth) {
          cropBoxData.height = maxHeight;
          cropBoxData.width = maxWidth;
        }

        cropper.current.setData(cropBoxData);
      }
    },
  }

  useEffect(() => {
    const cropNode = new Cropper(canvasRef.current, cropperOptions);
    if (image) {
      setShowBackDrop(true);
      cropNode.replace(image);
    }
    cropper.current = cropNode;
    console.log(cropper.current.getCropBoxData());
    console.log(props);
  }, []);

  useEffect(() => {
    if (image) {
      setShowBackDrop(true);
      cropper.current.replace(image);
    }
  }, [image]);

  useImperativeHandle(ref, () => ({
    getSelectedCropBoxData: () => {
      const cropData = cropper.current.getData();

      const realWidth = Math.round(cropData.width / 2) * 2;
      const realHeight = Math.round(cropData.height / 2) * 2;

      return { coordinate: [cropData.x, cropData.y], resolution: [realWidth, realHeight] };
    },
  }));

  return (
    <div style={{width: width, height: height, overflow: 'hidden'}}>
      <canvas id="canvas" ref={canvasRef} style={{width: '100%', height: '100%'}}/>
      <Backdrop sx={{color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1}} open={showBackDrop}>
        <CircularProgress color="inherit"/>
      </Backdrop>
    </div>
  );
});

PicInPicCropper.displayName = 'PicInPicCropper';
PicInPicCropper.propTypes = {
  width: PropTypes.number.isRequired,
  height: PropTypes.number.isRequired,
  image: PropTypes.string.isRequired,
  overlay: PropTypes.string.isRequired,
  x: PropTypes.number.isRequired,
  y: PropTypes.number.isRequired,
  cropWidth: PropTypes.number.isRequired,
  cropHeight: PropTypes.number.isRequired,
}

export default PicInPicCropper;