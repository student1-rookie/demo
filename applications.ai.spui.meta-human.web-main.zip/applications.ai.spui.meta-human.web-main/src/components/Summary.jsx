import { useState, useEffect } from "react";
import {
    Container,
    Typography,
    Box,
    Table,
    TableCell,
    TableBody,
    TableHead,
    TableRow,
    Paper,
    Button,
    Snackbar,
    Alert
} from '@mui/material';
import {AdapterDayjs} from '@mui/x-date-pickers/AdapterDayjs';
import {LocalizationProvider} from '@mui/x-date-pickers/LocalizationProvider';
import {DatePicker} from '@mui/x-date-pickers/DatePicker';
import dayjs from 'dayjs';
import {getActivityCount} from '../lib/mh.js'
 
function Summary() {
    const [data, setData] = useState([]);
    const [startDate, setStartDate] = useState(dayjs());
    const [endDate, setEndDate] = useState(dayjs());
    const [total, setTotal] = useState(null);

    const [snackbarOpen, setSnackbarOpen] = useState(false);    
    const [snackbarMessage, setSnackbarMessage] = useState('');
    const [snackbarSeverity, setSnackbarSeverity] = useState('success');

    const handleCopy = async () => {
        if (!data || data.length === 0) {
            setSnackbarMessage("No data available");
            setSnackbarSeverity("warning");
            setSnackbarOpen(true);
            return;
        }
        let msg = '';
        msg += 'account\t' + 
               'TTS Training Count\t' + 
               'Face Training Count\t' + 
               'Inference Count\t' + 
               'Pic In Pic Count\n';
        data.forEach(e => {
            msg += `${e.accountName} (${e.accountEmail})\t` + 
                   `${e.ttsTrainCount}\t` + 
                   `${e.faceTrainCount}\t` + 
                   `${e.inferCount}\t` + 
                   `${e.picInPicCount}\n`;
        });
        msg += `total\t` +
               `${total.tts_train_count}\t` +
               `${total.face_train_count}\t` +
               `${total.infer_count}\t` +
               `${total.pic_in_pic_count}\n`;
        try {
            await navigator.clipboard.writeText(msg);
            setSnackbarMessage("Copied to clipboard!");
            setSnackbarSeverity("success");
            setSnackbarOpen(true);
        } catch (err) {
            console.error("Failed to copy: ", err);
            setSnackbarMessage("Copy failed!");
            setSnackbarSeverity("error");
            setSnackbarOpen(true);
        }
    };

    const handleCloseSnackbar = () => {
        setSnackbarOpen(false);
    }

    useEffect(() => {
        const fetchData = async () => {
            const startStr = startDate.startOf('day').unix();
            const endStr = endDate.add(1, 'day').startOf('day').unix();
            try {
                const res = await getActivityCount(startStr, endStr);
                console.log(res);
                if (res === null) {
                    setData([]);
                    setTotal(null);
                } else {
                    setData(res);
                    console.log(res);
                    const calculatedTotal = res.reduce(
                        (acc, item) => ({
                            tts_train_count: acc.tts_train_count + item.ttsTrainCount,
                            face_train_count: acc.face_train_count + item.faceTrainCount,
                            infer_count: acc.infer_count + item.inferCount,
                            pic_in_pic_count: acc.pic_in_pic_count + item.picInPicCount
                        }), 
                        {
                            tts_train_count: 0,
                            face_train_count: 0,
                            infer_count: 0,
                            pic_in_pic_count: 0
                        }
                    );
                    setTotal(calculatedTotal);
                }
            } catch(err) {
                setData([]);
                console.log(err);
            }
        };
        fetchData();
    }, [startDate, endDate]);
    return (
        <Container maxWidth="lg">
            <Typography variant="h5" component="h3" gutterBottom>
                Usage Statistics
            </Typography>
            <LocalizationProvider dateAdapter={AdapterDayjs}>
                <Box sx={{mb : 3, gap : 2, display: 'flex'}}>
                    <DatePicker
                        label='startDate'
                        value={startDate}
                        onChange={(newValue) => {
                            if (newValue && newValue.isAfter(endDate)) {
                                setStartDate(endDate);
                            } else {
                                setStartDate(newValue);
                            }
                        }}
                        slotProps={{
                            textField: {
                                variant: 'outlined'
                            }
                        }} 
                        format='YYYY-MM-DD'
                    />
                    <DatePicker
                        label='endDate'
                        value={endDate}
                        onChange={(newValue) => {
                            if (newValue && newValue.isBefore(startDate)) {
                                setEndDate(startDate);
                            } else if (newValue && newValue.isAfter(dayjs())){
                                setEndDate(dayjs());
                            } else {
                                setEndDate(newValue);
                            }
                        }}
                        slotProps={{
                            textField: {
                                variant: 'outlined'
                            }
                        }} 
                        format='YYYY-MM-DD'
                    />
                    <Button variant="contained" color="primary" onClick={handleCopy} disabled={data.length === 0} sx={{ml : 'auto'}}>
                        Copy the table
                    </Button>
                </Box>
            </LocalizationProvider>
            <Paper sx={{overflow : 'hidden', boxShadow : 3}}>
                <Table sx = {{tableLayout : 'auto', width : '100%'}}>
                    <TableHead sx={{backgroundColor : 'white'}}>
                        <TableRow>
                            <TableCell><strong>account</strong></TableCell>
                            <TableCell><strong>TTS Training Count</strong></TableCell>
                            <TableCell><strong>Face Training Count</strong></TableCell>
                            <TableCell><strong>Inference Count</strong></TableCell>
                            <TableCell><strong>Pic In Pic Count</strong></TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {
                            data.length > 0 ? (
                                data.map((row) => (
                                    <TableRow key={row.account}>
                                        <TableCell>{`${row.accountName} (${row.accountEmail})`}</TableCell>
                                        <TableCell>{row.ttsTrainCount}</TableCell>
                                        <TableCell>{row.faceTrainCount}</TableCell>
                                        <TableCell>{row.inferCount}</TableCell>
                                        <TableCell>{row.picInPicCount}</TableCell>
                                    </TableRow>
                                ))
                            ) : (
                                <TableRow key={null}>
                                    <TableCell colSpan={5} align="center" sx={{py : 3}}>
                                        <Typography color="textSecondary">
                                            No data available
                                        </Typography>
                                    </TableCell> 
                                </TableRow>
                            )
                        }
                        {
                            data.length > 0 && (
                                <TableRow sx={{backgroundColor : 'silver', fontWeight: 'bold'}} key={"total"}>
                                    <TableCell><strong>total</strong></TableCell>
                                    <TableCell><strong>{total.tts_train_count}</strong></TableCell>
                                    <TableCell><strong>{total.face_train_count}</strong></TableCell>
                                    <TableCell><strong>{total.infer_count}</strong></TableCell>
                                    <TableCell><strong>{total.pic_in_pic_count}</strong></TableCell>
                                </TableRow>
                            )
                        }
                    </TableBody>
                </Table>
            </Paper>
            <Snackbar open = {snackbarOpen} autoHideDuration={5000} onClose={handleCloseSnackbar} anchorOrigin={{vertical : "top", horizontal : "center"}}>
                <Alert onClose={handleCloseSnackbar} severity={snackbarSeverity} sx={{width : "100%", marginTop : '50px'}}>
                    {snackbarMessage}
                </Alert>
            </Snackbar>
        </Container>
    );
}
export default Summary