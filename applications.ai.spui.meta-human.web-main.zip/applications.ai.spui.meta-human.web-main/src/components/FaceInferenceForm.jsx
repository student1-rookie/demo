import FormControl from "@mui/material/FormControl";
import TextField from "@mui/material/TextField";
import Box from "@mui/material/Box";
import InputLabel from "@mui/material/InputLabel";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import { Checkbox, FormControlLabel, FormHelperText, Link, InputAdornment } from "@mui/material";
import Button from "@mui/material/Button";
import * as yup from "yup";
import ResourceUploader from './ResourceUploader.jsx';
import {Controller, useForm} from "react-hook-form";
import {yupResolver} from "@hookform/resolvers/yup";
import { postInference, searchRoutingKey } from "../lib/mh.js";
import Swal from "sweetalert2";
import { useState, useEffect, useMemo } from "react";
import PropTypes from "prop-types";
import Accordion from '@mui/material/Accordion';
import AccordionDetails from '@mui/material/AccordionDetails';
import AccordionSummary from '@mui/material/AccordionSummary';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import Typography from '@mui/material/Typography';
import Grid from "@mui/material/Grid";
import Autocomplete from '@mui/material/Autocomplete';

const schema = yup.object().shape({
  name: yup.string().required('Inference name is required'),
  faceModel: yup.string().required('Face Model is required'),
  formInputWAV: yup.string().required('Audio File is required'),
});

export default function FaceInferenceForm(props) {

  const {faceModels, currentUserInfo, datasets, getInferenceInfo, fetchResources} = props;

  const [picFormExpanded, setPicFormExpanded] = useState(false);
  const [routingKeys, setRoutingKeys] = useState([]);
  const [faceModelValue, setFaceModelValue] = useState('');
  const [filterModelType, setFilterModelType] = useState('');

  const {
    control,
    handleSubmit,
    setValue,
    watch,
    formState: {errors},
  } = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      name: '',
      faceModel: '',
      formInputWAV: '',
      showSubtitle: false,
      hdtr: false,
    },
  });

  const targetServiceValue = watch('targetService');
  const deviceValue = watch('device');

  useEffect(() => {
    const subscription = watch((values) => {
      setDisplayHdtr(
        values.faceModel && 
        faceModels.find(
          faceModel => faceModel.id === values.faceModel && 
                       faceModel.model === 'LATENTSYNC')
      );
      const selectedFaceModel = faceModels.find(
        faceModel => faceModel.id === values.faceModel && faceModel.model === 'ERNERF'
      );
      setFaceModelValue(selectedFaceModel ? selectedFaceModel.model : '');
  });
    return () => subscription.unsubscribe();
  }, [watch, faceModels]);

  useEffect(() => {
    async function fetchKeys() {
      const res = await searchRoutingKey('INFERENCE');
      setRoutingKeys(res);
    }
    if (deviceValue === 'XPU') {
      setRoutingKeys([]);
    } else {
      fetchKeys();
    }
  }, [deviceValue]);

  const CONFIRM_BUTTON_COLOR = '#1976d2';

  const [displayHdtr, setDisplayHdtr] = useState(false);
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false);

  const filteredFaceModels = useMemo(() => {
    return faceModels.filter(m => {
      const visible = (m.account_email === currentUserInfo.email || m.type === "PUBLIC");
      if (!visible) return false;
      if (filterModelType) {
        return m.model === filterModelType;
      }
      return true;
    });
  }, [faceModels, currentUserInfo.email, filterModelType]);

  const faceModelTypeOptions = useMemo(
    () => [...new Set(faceModels.map(m => m.model).filter(Boolean))],
    [faceModels]
  );

  const onSubmit = async (data) => {
    console.log(data);
    const inferenceMeta = {
      name: data.name,
      models: [],
      type: 'FACE_ONLY',
      text: null,
      wav: null,
      subtitle: data.showSubtitle,
      hdtr: data.hdtr,
      subtitleStyleDto: {
        fontSize: data.fontSize,
        color: data.color,
        bold: data.bold,
        margin_v: data.marginV
      },
      routingKey: data.targetService,
      device: data.device
    };
    inferenceMeta.wav = data.formInputWAV;
    inferenceMeta.models = {'FACE': data.faceModel};

    try {
      await postInference(inferenceMeta);
      Swal.fire({
        icon: "success",
        title: "Inference started",
        showConfirmButton: false,
        timer: 1500
      });
    } catch (e) {
      Swal.fire({
        title: "Inference failed to start",
        icon: "error",
        confirmButtonColor: CONFIRM_BUTTON_COLOR
      });
    } finally {
      await getInferenceInfo();
    }

  };

  const marginNumbers = Array.from({ length: 20 }, (_, i) => i + 1);

  const fontSizeNumbers = Array.from({ length: 21 }, (_, i) => i + 10);

  const showSubtitle = watch('showSubtitle');

  const modeValue = localStorage.getItem("mode");

  const deviceOptions = useMemo(() => {
    if (faceModelValue === 'ERNERF' && targetServiceValue == null) {
      return ['CUDA', 'XPU'];
    }
    return ['CUDA'];
  }, [faceModelValue]);

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <FormControl fullWidth margin="normal" variant="outlined" size="small">
        <Controller
          name="name"
          control={control}
          render={({ field }) => (
            <TextField
              {...field}
              label="Name"
              variant="outlined"
              size="small"
              error={!!errors.name}
              helperText={errors.name?.message}
            />
          )}
          />
      </FormControl>

      <Box display="flex" alignItems="center" gap={2} sx={{ mt: 2 }}>
        <FormControl
          fullWidth
          margin="normal"
          size="small"
          error={!!errors.faceModel}
          sx={{ mt: 0 }}
        >
          <Controller
            name="faceModel"
            control={control}
            render={({ field }) => (
              <Autocomplete
                size="small"
                options={filteredFaceModels}
                getOptionLabel={(option) => {
                  if (!option) return "";
                  if (option.date) {
                    return `${option.name} (${new Date(option.date).toLocaleString()})`;
                  }
                  return option.name;
                }}
                isOptionEqualToValue={(option, value) => option.id === value.id}
                value={faceModels.find((m) => m.id === field.value) || null}
                onChange={(_, newValue) => {
                  const modelId = newValue?.id ?? "";
                  field.onChange(modelId);
                }}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Face Model"
                    size="small"
                    InputProps={{
                      ...params.InputProps,
                      startAdornment: (
                        <InputAdornment
                          position="start"
                          sx={{
                            position: "absolute",
                            left: "8px",
                            top: "50%",
                            transform: "translateY(-50%)",
                            zIndex: 1,
                          }}
                        >
                          <Select
                            onChange={(e) => {
                              const value = e.target.value;
                              setFilterModelType(value === "ALL" ? "" : value);
                            }}
                            value={filterModelType || "ALL"}
                            variant="standard"
                            disableUnderline
                            sx={{ minWidth: 80, fontSize: "0.85rem" }}
                          >
                            <MenuItem value="ALL">ALL</MenuItem>
                            {faceModelTypeOptions.map((type) => (
                              <MenuItem key={type} value={type}>
                                {type}
                              </MenuItem>
                            ))}
                          </Select>
                        </InputAdornment>
                      ),
                      sx: {
                        "& input": {
                          marginLeft: "96px",
                        },
                      },
                    }}
                  />
                )}
                renderOption={(props, option) => (
                  <MenuItem {...props} key={option.id} value={option.id}>
                    {option.date
                      ? `${option.name} (${new Date(option.date).toLocaleString()})`
                      : option.name}
                  </MenuItem>
                )}
                fullWidth
              />
            )}
          />
          {errors.faceModel && (
            <FormHelperText error>{errors.faceModel.message}</FormHelperText>
          )}
        </FormControl>
      </Box>

      <Box display="flex" alignItems="center" gap={2} sx={{mt: 2}}>
        <FormControl variant="outlined" style={{flex: 1}} size="small" error={!!errors.formInputWAV}>
          <InputLabel>Upload Audio</InputLabel>
          <Controller
            name="formInputWAV"
            control={control}
            render={({ field }) => {
              return (
              <Select
                {...field}
                label="Upload Audio"
              >
                {datasets.map(
                  (dataset) =>
                    dataset.fileType === 'AUDIO' && (
                      <MenuItem value={dataset.id} key={dataset.id}>
                        {dataset.name}
                      </MenuItem>
                    )
                )}
                <MenuItem
                  value="new"
                  onClick={() => {
                    setIsUploadDialogOpen(true);
                  }}
                >
                  <Link href="#" underline="hover">
                    Add Audio
                  </Link>
                </MenuItem>
              </Select>);
            }}
          />
          {errors.formInputWAV && <FormHelperText error>{errors.formInputWAV.message}</FormHelperText>}
        </FormControl>
      </Box>

      {(showSubtitle || modeValue === 'advance') && (
        <Box display="flex" alignItems="center" gap={2} sx={{ mt: 2 }}>
          <Accordion expanded={picFormExpanded} onChange={() => setPicFormExpanded(!picFormExpanded)} defaultExpanded sx={{ width: '100%', height: '50%' }}>
            <AccordionSummary expandIcon={<ExpandMoreIcon />} aria-controls="panel1-content" id="panel1-header">
              <Typography component="span">Arguments</Typography>
            </AccordionSummary>
            <AccordionDetails>
              {showSubtitle && 
                <Box>
                  <Typography variant="subtitle1" gutterBottom>Subtitle Settings</Typography>
                  <Grid container spacing={2}>
                    <Grid item xs={6}>
                      <Controller
                        name="fontSize"
                        control={control}
                        render={({ field }) => (
                          <Autocomplete
                            {...field}
                            onChange={(e, newValue) => field.onChange(newValue)}
                            options={fontSizeNumbers}
                              renderInput={(params) => <TextField {...params} label="FontSize" size="small" />}
                            fullWidth
                            clearOnEscape
                            disableClearable={false}
                          />
                        )}
                      />
                    </Grid>
                    <Grid item xs={6}>
                      <Controller
                        name="color"
                        control={control}
                        render={({ field }) => (
                          <Autocomplete
                            {...field}
                            onChange={(e, newValue) => field.onChange(newValue)}
                            options={['black', 'white', 'red', 'green', 'blue', 'yellow', 'cyan', 'magenta', 'gray']}
                            renderInput={(params) => <TextField {...params} label="Color" size="small" />}
                            renderOption={(props, option) => (
                              <Box component="li" {...props} sx={{ display: 'flex', alignItems: 'center' }}>
                                <Box
                                  sx={{
                                    width: 20,
                                    height: 20,
                                    backgroundColor: option,
                                    borderRadius: '50%',
                                    marginRight: 1,
                                    border: '1px solid #ccc',
                                  }}
                                />
                                <Typography variant="body1">{option}</Typography>
                              </Box>
                            )}
                            fullWidth
                            clearOnEscape
                            disableClearable={false}
                          />
                        )}
                      />
                    </Grid>
                    <Grid item xs={6}>
                      <Controller
                        name="marginV"
                        control={control}
                        render={({ field }) => (
                          <Autocomplete
                            {...field}
                            onChange={(e, newValue) => field.onChange(newValue)}
                            options={marginNumbers}
                            renderInput={(params) => <TextField {...params} label="Margin" size="small" />}
                            fullWidth
                            clearOnEscape
                            disableClearable={false}
                          />
                        )}
                      />
                    </Grid>
                    <Grid item xs={6}>
                      <Controller
                        name="bold"
                        control={control}
                        render={({ field }) => (
                          <Autocomplete
                            {...field}
                            onChange={(e, newValue) => field.onChange(newValue)}
                            options={[0, 1]}
                            renderInput={(params) => <TextField {...params} label="Bold" size="small" />}
                            fullWidth
                            clearOnEscape
                            disableClearable={false}
                          />
                        )}
                      />
                    </Grid>
                  </Grid>
                </Box>
              }
              {modeValue === 'advance' && 
                <>
                  <Box>
                    <Typography variant="subtitle1" gutterBottom>Target Service</Typography>
                    <Grid container spacing={2}>
                      <Grid item xs={6}>
                          <Controller
                            name="targetService"
                            control={control}
                            render={({ field }) => (
                              <Autocomplete
                                {...field}
                                onChange={(e, newValue) => field.onChange(newValue)}
                                options={routingKeys}
                                renderInput={(params) => <TextField {...params} label="Target Service" size="small" />}
                                fullWidth
                                clearOnEscape
                                disableClearable={false}
                              />
                            )}
                          />
                      </Grid>
                    </Grid>
                  </Box>
                  <Box>
                    <Typography variant="subtitle1" gutterBottom>Device</Typography>
                    <Grid container spacing={2}>
                      <Grid item xs={6}>
                        <Controller
                            name="device"
                            control={control}
                            render={({ field }) => (
                              <Autocomplete
                                {...field}
                                onChange={(e, newValue) => field.onChange(newValue)}
                                options={deviceOptions}
                                renderInput={(params) => <TextField {...params} label="device" size="small" />}
                                fullWidth
                                clearOnEscape
                                disableClearable={false}
                              />
                            )}
                          />
                      </Grid>
                    </Grid>
                  </Box>
                </>
              }
            </AccordionDetails>
          </Accordion>
        </Box>
      )}

      <ResourceUploader
        open={isUploadDialogOpen}
        onClose={() => setIsUploadDialogOpen(false)}
        onUploadComplete={async (fileId) => {
          const files = await fetchResources(); // Refresh resources after upload
          setIsUploadDialogOpen(false);
          const newFile = files.find(file => file.id === fileId);
          if (newFile) {
            setValue('formInputWAV', newFile.id); // Update form value
          }
        }}
        allowedFileTypes={['audio']}
      />

      <Box display="flex" alignItems="center" gap={2} sx={{ mt: 2 }}>
        <Button variant="contained" type="submit">
          Submit
        </Button>
        <Controller
          name="showSubtitle"
          control={control}
          render={({ field }) => (
            <FormControlLabel
              control={<Checkbox {...field} checked={field.value} />}
              label="Subtitle"
            />
          )}
        />
        {displayHdtr && (
          <Controller
            name="hdtr"
            control={control}
            render={({ field }) => (
              <FormControlLabel
                control={<Checkbox {...field} checked={field.value} />}
                label="HDTR"
              />
            )}
          />
        )}
      </Box>
    </form>
  );
}

FaceInferenceForm.propTypes = {
  faceModels: PropTypes.array.isRequired,
  currentUserInfo: PropTypes.object.isRequired,
  datasets: PropTypes.array.isRequired,
  getInferenceInfo: PropTypes.func.isRequired,
  fetchResources: PropTypes.func.isRequired,
}