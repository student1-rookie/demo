import FormControl from "@mui/material/FormControl";
import TextField from "@mui/material/TextField";
import Box from "@mui/material/Box";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import { Checkbox, FormControlLabel, FormHelperText, InputAdornment } from "@mui/material";
import Button from "@mui/material/Button";
import * as yup from "yup";
import { useForm, Controller } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { postInference, searchRoutingKey } from "../lib/mh.js";
import Swal from "sweetalert2";
import { useState, useEffect, useMemo } from "react";
import PropTypes from "prop-types";
import Accordion from '@mui/material/Accordion';
import AccordionDetails from '@mui/material/AccordionDetails';
import AccordionSummary from '@mui/material/AccordionSummary';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import Typography from '@mui/material/Typography';
import Grid from "@mui/material/Grid";
import Autocomplete from '@mui/material/Autocomplete';

export default function WholeInferenceForm(props) {

  const {faceModels, voiceModels, currentUserInfo, getInferenceInfo} = props;

  const [showSubtitle, setShowSubtitle] = useState(false);
  const [hdtr, setHdtr] = useState(false);
  const [displayHdtr, setDisplayHdtr] = useState(false);

  const [picFormExpanded, setPicFormExpanded] = useState(false);
  const [seed, setSeed] = useState('');
  const [model, setModel] = useState('');
  const [routingKeys, setRoutingKeys] = useState([]);
  const [faceModelValue, setFaceModelValue] = useState('');

  const [voiceFilterModelType, setVoiceFilterModelType] = useState('');
  const [faceFilterModelType, setFaceFilterModelType] = useState('');

  const schema = yup.object().shape({
    name: yup.string().required('Inference name is required'),
    voiceModel: yup.string().required('Voice Model is required'),
    faceModel: yup.string().required('Face Model is required'),
    text: yup.string().required('Text is required'),
  });

  const {
    register,
    handleSubmit,
    watch,
    control,
    formState: {errors},
  } = useForm({
    resolver: yupResolver(schema),
  });

  const targetServiceValue = watch('targetService');
  const deviceValue = watch('device');

  useEffect(() => {
    const subscription = watch((values) => {
      setDisplayHdtr(
        values.faceModel &&
        faceModels.find(
          faceModel => faceModel.id === values.faceModel &&
                       faceModel.model === 'LATENTSYNC')
      );
      const selectedFaceModel = faceModels.find(
        faceModel => faceModel.id === values.faceModel && faceModel.model === 'ERNERF'
      );
      setFaceModelValue(selectedFaceModel ? selectedFaceModel.model : '');
    });
    return () => subscription.unsubscribe();
  }, [watch, faceModels]);

  useEffect(() => {
    async function fetchKeys() {
      const res = await searchRoutingKey('INFERENCE');
      setRoutingKeys(res);
    }
    if (deviceValue === 'XPU') {
      setRoutingKeys([]);
    } else {
      fetchKeys();
    }
  }, [deviceValue]);

  const filteredVoiceModels = useMemo(() => {
    return voiceModels.filter(m => {
      const visible = (m.account_email === currentUserInfo.email || m.type === "PUBLIC");
      if (!visible) return false;
      if (voiceFilterModelType) {
        return m.model === voiceFilterModelType;
      }
      return true;
    });
  }, [voiceModels, currentUserInfo.email, voiceFilterModelType]);

  const voiceModelTypeOptions = useMemo(
      () => [...new Set(voiceModels.map(m => m.model).filter(Boolean))],
      [voiceModels]
    );

  const filteredFaceModels = useMemo(() => {
    return faceModels.filter(m => {
      const visible = (m.account_email === currentUserInfo.email || m.type === "PUBLIC");
      if (!visible) return false;
      if (faceFilterModelType) {
        return m.model === faceFilterModelType;
      }
      return true;
    });
  }, [faceModels, currentUserInfo.email, faceFilterModelType]);

  const faceModelTypeOptions = useMemo(
    () => [...new Set(faceModels.map(m => m.model).filter(Boolean))],
    [faceModels]
  );

  const deviceOptions = useMemo(() => {
    if (model === 'COSYVOICE' && faceModelValue === 'ERNERF' && targetServiceValue == null) {
      return ['CUDA', 'XPU'];
    }
    return ['CUDA'];
  }, [model, faceModelValue]);

  const CONFIRM_BUTTON_COLOR = '#1976d2';

  const onSubmit = async (data) => {
    const inferenceMeta = {
      name: data.name,
      models: {'FACE': data.faceModel, 'TTS': data.voiceModel},
      type: 'WHOLE',
      text: data.text,
      subtitle: showSubtitle,
      hdtr: hdtr,
      ttsInstructDto: {
        emotion: data.emotion,
        speed: data.speed
      },
      subtitleStyleDto: {
        fontSize: data.fontSize,
        color: data.color,
        bold: data.bold,
        margin_v: data.marginV
      },
      seed: seed,
      routingKey: data.targetService,
      device: data.device
    };

    try {
      await postInference(inferenceMeta)
      Swal.fire({
        icon: "success",
        title: "Inference started",
        showConfirmButton: false,
        timer: 1500
      });
    } catch (e) {
      Swal.fire({
        title: "Inference failed to start",
        icon: "error",
        confirmButtonColor: CONFIRM_BUTTON_COLOR
      });
    } finally {
      await getInferenceInfo();
    }

  };

  const marginNumbers = Array.from({ length: 20 }, (_, i) => i + 1);

  const fontSizeNumbers = Array.from({ length: 21 }, (_, i) => i + 10);

  const handleSeedChange = (event) => {
    const newValue = event.target.value;
    if (/^$|^(0|[1-9]\d*)$/.test(newValue)) {
      setSeed(newValue === '' ? null : parseInt(newValue, 10));
    }
  };

  const emotionOptions = [
    { label: 'happy', emoji: '😊' },
    { label: 'sad', emoji: '😢' },
    { label: 'surprised', emoji: '😲' },
    { label: 'angry', emoji: '😠' },
    { label: 'fearful', emoji: '😨' },
    { label: 'disgusted', emoji: '🤢' },
    { label: 'calm', emoji: '😌' },
    { label: 'serious', emoji: '😐' },
  ];

  const modeValue = localStorage.getItem("mode");

  return (
    <>
      <form onSubmit={handleSubmit(onSubmit)}>
        <FormControl fullWidth margin="normal" variant="outlined" size="small">
          <TextField
            label="Name"
            variant="outlined"
            size="small"
            {...register('name')}
            error={!!errors.name}
            helperText={errors.name?.message}
          />
        </FormControl>

        <Box display="flex" alignItems="center" gap={2} sx={{ mt: 2 }}>
          <FormControl fullWidth margin="normal" size="small" error={!!errors.voiceModel} sx={{ mt: 0 }}>
            <Controller
              name="voiceModel"
              control={control}
              render={({ field }) => (
                <Autocomplete
                  size="small"
                  options={filteredVoiceModels}
                  getOptionLabel={(option) => {
                    if (!option) return "";
                    if (option.date) {
                      return `${option.name} (${new Date(option.date).toLocaleString()})`;
                    }
                    return option.name;
                  }}
                  isOptionEqualToValue={(option, value) => option.id === value.id}
                  value={voiceModels.find((m) => m.id === field.value) || null}
                  onChange={(_, newValue) => {
                    const modelId = newValue?.id ?? "";
                    field.onChange(modelId);
                    if (newValue && newValue.model) {
                      setModel(newValue.model);
                    } else {
                      setModel("");
                    }
                  }}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="Voice Model"
                      size="small"
                      InputProps={{
                        ...params.InputProps,
                        startAdornment: (
                          <InputAdornment
                            position="start"
                            sx={{
                              position: "absolute",
                              left: "8px",
                              top: "50%",
                              transform: "translateY(-50%)",
                              zIndex: 1,
                            }}
                          >
                            <Select
                              onChange={(e) => {
                                const value = e.target.value;
                                setVoiceFilterModelType(value === "ALL" ? "" : value);
                              }}
                              value={voiceFilterModelType || "ALL"}
                              variant="standard"
                              disableUnderline
                              sx={{ minWidth: 80, fontSize: "0.85rem" }}
                            >
                              <MenuItem value="ALL">ALL</MenuItem>
                              {voiceModelTypeOptions.map((type) => (
                                <MenuItem key={type} value={type}>
                                  {type}
                                </MenuItem>
                              ))}
                            </Select>
                          </InputAdornment>
                        ),
                        sx: {
                          "& input": { marginLeft: "96px" },
                        },
                      }}
                    />
                  )}
                  renderOption={(props, option) => (
                    <MenuItem {...props} key={option.id} value={option.id}>
                      {option.date
                        ? `${option.name} (${new Date(option.date).toLocaleString()})`
                        : option.name}
                    </MenuItem>
                  )}
                  fullWidth
                />
              )}
            />
            {errors.voiceModel && (
              <FormHelperText error>{errors.voiceModel.message}</FormHelperText>
            )}
          </FormControl>
        </Box>

        <Box display="flex" alignItems="center" gap={2} sx={{ mt: 2 }}>
          <FormControl fullWidth margin="normal" size="small" error={!!errors.faceModel} sx={{ mt: 0 }}>
            <Controller
              name="faceModel"
              control={control}
              render={({ field }) => (
                <Autocomplete
                  size="small"
                  options={filteredFaceModels}
                  getOptionLabel={(option) => {
                    if (!option) return "";
                    if (option.date) {
                      return `${option.name} (${new Date(option.date).toLocaleString()})`;
                    }
                    return option.name;
                  }}
                  isOptionEqualToValue={(option, value) => option.id === value.id}
                  value={faceModels.find((m) => m.id === field.value) || null}
                  onChange={(_, newValue) => {
                    const modelId = newValue?.id ?? "";
                    field.onChange(modelId);
                  }}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="Face Model"
                      size="small"
                      InputProps={{
                        ...params.InputProps,
                        startAdornment: (
                          <InputAdornment
                            position="start"
                            sx={{
                              position: "absolute",
                              left: "8px",
                              top: "50%",
                              transform: "translateY(-50%)",
                              zIndex: 1,
                            }}
                          >
                            <Select
                              onChange={(e) => {
                                const value = e.target.value;
                                setFaceFilterModelType(value === "ALL" ? "" : value);
                              }}
                              value={faceFilterModelType || "ALL"}
                              variant="standard"
                              disableUnderline
                              sx={{ minWidth: 80, fontSize: "0.85rem" }}
                            >
                              <MenuItem value="ALL">ALL</MenuItem>
                              {faceModelTypeOptions.map((type) => (
                                <MenuItem key={type} value={type}>
                                  {type}
                                </MenuItem>
                              ))}
                            </Select>
                          </InputAdornment>
                        ),
                        sx: {
                          "& input": {
                            marginLeft: "96px",
                          },
                        },
                      }}
                    />
                  )}
                  renderOption={(props, option) => (
                    <MenuItem {...props} key={option.id} value={option.id}>
                      {option.date
                        ? `${option.name} (${new Date(option.date).toLocaleString()})`
                        : option.name}
                    </MenuItem>
                  )}
                  fullWidth
                />
              )}
            />
            {errors.faceModel && (
              <FormHelperText error>{errors.faceModel.message}</FormHelperText>
            )}
          </FormControl>
        </Box>

        <Box display="flex" alignItems="center" gap={2} sx={{ mt: 2 }}>
          {(showSubtitle || model === 'COSYVOICE' || modeValue === 'advance') && (
            <Accordion expanded={picFormExpanded} onChange={() => setPicFormExpanded(!picFormExpanded)} defaultExpanded sx={{ width: '100%', height: '50%' }}>
              <AccordionSummary expandIcon={<ExpandMoreIcon />} aria-controls="panel1-content" id="panel1-header">
                <Typography component="span">Arguments</Typography>
              </AccordionSummary>
              <AccordionDetails>
                {model !== '' && (
                  <Box>
                    {(model === 'COSYVOICE' || modeValue === 'advance') && <Typography variant="subtitle1" gutterBottom>Voice Settings</Typography>}
                    <Grid container spacing={2}>
                      {model === 'COSYVOICE' && (
                        <> 
                          <Grid item xs={6}>
                            <Controller
                              name="emotion"
                              control={control}
                              render={({ field }) => (
                                <Autocomplete
                                  {...field}
                                  onChange={(e, newValue) => field.onChange(newValue.label)}
                                  options={emotionOptions}
                                  getOptionLabel={(option) => option ? `${option.label}` : ''}
                                  isOptionEqualToValue={(option, value) => option.label === value}
                                  renderOption={(props, option) => (
                                    <Box component="li" {...props} sx={{ display: 'flex', alignItems: 'center' }}>
                                      <Typography sx={{ fontSize: 20, mr: 1 }}>{option.emoji}</Typography>
                                      <Typography variant="body1">{option.label}</Typography>
                                    </Box>
                                  )}
                                  renderInput={(params) => <TextField {...params} label="Emotion" size="small" />}
                                  fullWidth
                                  clearOnEscape
                                  disableClearable={false}
                                />
                              )}
                            />
                          </Grid>
                          <Grid item xs={6}>
                            <Controller
                              name="speed"
                              control={control}
                              render={({ field }) => (
                                <Autocomplete
                                  {...field}
                                  onChange={(e, newValue) => field.onChange(newValue)}
                                  options={['fast', 'very fast', 'slow', 'very slow']}
                                  renderInput={(params) => <TextField {...params} label="Speed" size="small" />}
                                  fullWidth
                                  clearOnEscape
                                  disableClearable={false}
                                />
                              )}
                            />
                          </Grid>
                        </>
                      )}
                      {(modeValue === 'advance' && (model === 'BERTVITS' || model === 'GPTSOVITS')) && (
                        <>
                          <Grid item xs={6}>
                            <TextField
                              type="number"
                              size="small"
                              label="Seed"
                              variant="outlined"
                              fullWidth
                              value={seed}
                              onChange={(e) => handleSeedChange(e)}
                              inputProps={{ inputMode: 'numeric', pattern: '[0-9]*' }}
                            />
                          </Grid> 
                        </> 
                      )}
                    </Grid>
                  </Box>
                )}
                {showSubtitle && (
                  <Box>
                    <Typography variant="subtitle1" gutterBottom>Subtitle Settings</Typography>
                    <Grid container spacing={2}>
                      <Grid item xs={6}>
                        <Controller
                          name="fontSize"
                          control={control}
                          render={({ field }) => (
                            <Autocomplete
                              {...field}
                              onChange={(e, newValue) => field.onChange(newValue)}
                              options={fontSizeNumbers}
                              renderInput={(params) => <TextField {...params} label="FontSize" size="small" />}
                              fullWidth
                              clearOnEscape
                              disableClearable={false}
                            />
                          )}
                        />
                      </Grid>
                      <Grid item xs={6}>
                        <Controller
                          name="color"
                          control={control}
                          render={({ field }) => (
                            <Autocomplete
                              {...field}
                              onChange={(e, newValue) => field.onChange(newValue)}
                              options={['black', 'white', 'red', 'green', 'blue', 'yellow', 'cyan', 'magenta', 'gray']}
                              renderInput={(params) => <TextField {...params} label="Color" size="small" />}
                              renderOption={(props, option) => (
                                <Box component="li" {...props} sx={{ display: 'flex', alignItems: 'center' }}>
                                  <Box
                                    sx={{
                                      width: 20,
                                      height: 20,
                                      backgroundColor: option,
                                      borderRadius: '50%',
                                      marginRight: 1,
                                      border: '1px solid #ccc',
                                    }}
                                  />
                                  <Typography variant="body1">{option}</Typography>
                                </Box>
                              )}
                              fullWidth
                              clearOnEscape
                              disableClearable={false}
                            />
                          )}
                        />
                      </Grid>
                      <Grid item xs={6}>
                        <Controller
                          name="marginV"
                          control={control}
                          render={({ field }) => (
                            <Autocomplete
                              {...field}
                              onChange={(e, newValue) => field.onChange(newValue)}
                              options={marginNumbers}
                              renderInput={(params) => <TextField {...params} label="Margin" size="small" />}
                              fullWidth
                              clearOnEscape
                              disableClearable={false}
                            />
                          )}
                        />
                      </Grid>
                      <Grid item xs={6}>
                        <Controller
                          name="bold"
                          control={control}
                          render={({ field }) => (
                            <Autocomplete
                              {...field}
                              onChange={(e, newValue) => field.onChange(newValue)}
                              options={[0, 1]}
                              renderInput={(params) => <TextField {...params} label="Bold" size="small" />}
                              fullWidth
                              clearOnEscape
                              disableClearable={false}
                            />
                          )}
                        />
                      </Grid>
                    </Grid>
                  </Box>
                )}
                {modeValue === 'advance' && 
                  <Box>
                    <Typography variant="subtitle1" gutterBottom>Target Service</Typography>
                    <Grid container spacing={2}>
                      <Grid item xs={6}>
                        <Controller
                            name="targetService"
                            control={control}
                            render={({ field }) => (
                              <Autocomplete
                                {...field}
                                onChange={(e, newValue) => field.onChange(newValue)}
                                options={routingKeys}
                                renderInput={(params) => <TextField {...params} label="Target Service" size="small" />}
                                fullWidth
                                clearOnEscape
                                disableClearable={false}
                              />
                            )}
                          />
                      </Grid>
                    </Grid>
                  </Box>
                }
                {modeValue === 'advance' &&
                  <Box>
                    <Typography variant="subtitle1" gutterBottom>Device</Typography>
                    <Grid container spacing={2}>
                      <Grid item xs={6}>
                        <Controller
                          name="device"
                          control={control}
                          render={({ field }) => (
                            <Autocomplete
                              {...field}
                              onChange={(e, newValue) => field.onChange(newValue)}
                              options={deviceOptions}
                              renderInput={(params) => <TextField {...params} label="Device" size="small" />}
                              fullWidth
                              clearOnEscape
                              disableClearable={false}
                            />
                          )}
                        />
                      </Grid>
                    </Grid>
                  </Box>
                }
              </AccordionDetails>
            </Accordion>
          )}
        </Box>

        <Box display="flex" alignItems="center" gap={2} sx={{mt: 2}}>
          <TextField
            fullWidth
            placeholder="Enter text here"
            multiline
            {...register('text')}
            rows={5}
            sx={{ mt: 2 }}
            error={!!errors.text}
            helperText={errors.text?.message}
          />
        </Box>
        {errors.formInputText && <FormHelperText error>{errors.formInputText.message}</FormHelperText>}

        <Box display="flex" alignItems="center" gap={2} sx={{mt: 2}}>
          <Button variant="contained" type="submit">Submit</Button>
          <FormControlLabel control={
            <Checkbox checked={showSubtitle}
                      onChange={(e) => setShowSubtitle(e.target.checked)}
            />} label="Subtitle"/>
           { displayHdtr && 
           <FormControlLabel control={
            <Checkbox checked={hdtr}
                      onChange={(e) => setHdtr(e.target.checked)}
            />} label="HDTR"/> }
        </Box>
      </form>
    </>
  );
}

WholeInferenceForm.propTypes = {
  faceModels: PropTypes.array.isRequired,
  voiceModels: PropTypes.array.isRequired,
  datasets: PropTypes.array.isRequired,
  currentUserInfo: PropTypes.object.isRequired,
  getInferenceInfo: PropTypes.func.isRequired,
}