import { useEffect, useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Table,
  TableBody,
  TextField,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Menu,
  MenuItem,
  Tooltip,
  IconButton,
  Button,
  TablePagination,
  Select,
  TableSortLabel,
  Autocomplete,
  Typography,
  Checkbox,
  Toolbar
} from '@mui/material';
import MoreVertIcon from "@mui/icons-material/MoreVert";
import FilterAltIcon from '@mui/icons-material/FilterAlt';
import {
  changeOwnerResourceFile,
  chmodResourceFile,
  deleteResourceFile,
  getUserInfo,
  listUsers,
  renameResourceFile,
  deleteResourceGroup,
  changeOwnerGroupResource,
  renameGroupResource,
  chmodGroupResource,
  deleteResourceList,
  changeResourceAccessList,
  changeResourceOwnerList
} from '../lib/mh';
import Swal from 'sweetalert2';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import '../index.css';
import PropTypes from "prop-types";
import DeleteIcon from '@mui/icons-material/Delete';
import ManageAccountsIcon from '@mui/icons-material/ManageAccounts';
import CompareArrowsIcon from '@mui/icons-material/CompareArrows';
import { alpha } from '@mui/material/styles';

const schema = yup.object().shape({
  newName: yup.string().required('name is required'),
});

const ResourcesTable = ({
  files, handleRowClick, refreshResources, operationType
}) => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
  });
  const CONFIRM_BUTTON_COLOR = '#1976d2';
  const resourcesType = 'GROUP';
  const [filter, setFilter] = useState([]);
  const [filterAnchorEl, setFilterAnchorEl] = useState(null);
  const [filterK, setFilterK] = useState(null);
  const [filterV, setFilterV] = useState(null);
  const [anchorEl, setAnchorEl] = useState(null);
  const [isChangeAccessDialogOpen, setIsChangeAccessDialogOpen] = useState(false);
  const [newName, setNewName] = useState("");
  const [newAccess, setNewAccess] = useState("");
  const [currentUserInfo, setCurrentUserInfo] = useState({ name: '', email: '', isAdmin: false });

  const [isChangeOwnerDialogOpen, setIsChangeOwnerDialogOpen] = useState(false);
  const [users, setUsers] = useState([]);
  const [newOwner, setNewOwner] = useState(null);

  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [orderDirection, setOrderDirection] = useState('desc');
  const [orderBy, setOrderBy] = useState('createdTime');
  const [selectedRow, setSelectedRow] = useState(0);
  const [isRenameDialogOpen, setIsRenameDialogOpen] = useState(false);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [currentResourceInfo, setCurrentResourceInfo] = useState({fileType: ''});
  const [tableData, setTableData] = useState([]);
  const [tableSelected, setTableSelected] = useState([]);
  const [numSelected, setNumSelected] = useState(0);
  const [isCallSingle, setIsCallSingle] = useState(true);
  const [showChangeOwnerBatch, setShowChangeOwnerBatch] = useState(true);

  const handleRenameDialogClose = () => {
    setIsRenameDialogOpen(false);
  };

  const handleRenameSubmit = async () => {
    const selectedFile = tableData[selectedRow + page * rowsPerPage];
    setIsRenameDialogOpen(false);
    const status = selectedFile.fileType === resourcesType ? await renameGroupResource(selectedFile.id, newName) 
                    : await renameResourceFile(selectedFile.id, newName);
    if (status !== 204) {
      Swal.fire({
        title: 'Failed to rename file',
        text: `Error code: ${status}`,
        icon: 'error',
        confirmButtonColor: CONFIRM_BUTTON_COLOR,
        customClass: {
          popup: 'swal-popup-zindex',
          container: 'swal-container-zindex'
        }
      });
    } else {
      Swal.fire({
        icon: "success",
        title: "File renamed",
        showConfirmButton: false,
        timer: 1500,
        customClass: {
          popup: 'swal-popup-zindex',
          container: 'swal-container-zindex'
        }
      });
    }
    refreshResources();
  };

  const handleConfirmDelete = async () => {
    await doDelete();
    setIsDeleteDialogOpen(false);
  };

  const handleCancelDelete = () => {
    setIsDeleteDialogOpen(false);
  };

  const handleChangeAccessClose = () => {
    setNewAccess("");
    setIsChangeAccessDialogOpen(false);
  };

  const handleChangeAccessSubmit = async () => {
    const selectedFile = tableData[selectedRow + page * rowsPerPage];
    const oldAccess = selectedFile.type;
    setIsChangeAccessDialogOpen(false);
    if (oldAccess !== newAccess) {
      let status = 200;
      if (isCallSingle) {
        status = selectedFile.fileType === resourcesType ? await chmodGroupResource(selectedFile.id, newAccess) 
              : await chmodResourceFile(selectedFile.id, newAccess);
      } else {
        const param = genBatchParam();
        param.access = newAccess;
        status = await changeResourceAccessList(param);
      }
      if (!status) {
        Swal.fire({
          title: 'Failed to change access',
          text: `Error code: 400`,
          icon: 'error',
          confirmButtonColor: CONFIRM_BUTTON_COLOR,
          customClass: {
            popup: 'swal-popup-zindex',
            container: 'swal-container-zindex'
          }
        });
      } else {
        Swal.fire({
          icon: "success",
          title: "Access changed",
          showConfirmButton: false,
          timer: 1500,
          customClass: {
            popup: 'swal-popup-zindex',
            container: 'swal-container-zindex'
          }
        });
      }
      refreshResources();
    }
    setNewAccess("");
    setTableSelected([]);
    setNumSelected(0);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleDelete = () => {
    setIsDeleteDialogOpen(true);
    setIsCallSingle(true);
    handleMenuClose();
  };

  const handleDeleteBatch = () => {
    setIsDeleteDialogOpen(true);
    setIsCallSingle(false);
  };

  const genBatchParam = () => {
    const resourceIds = tableSelected.filter(e => e.fileType !== resourcesType).map(e => e.id);
    const resourceGroupIds = tableSelected.filter(e => e.fileType === resourcesType).map(e => e.id);
    const param = {
      resourceIds: resourceIds,
      resourceGroupIds: resourceGroupIds
    };
    return param;
  };

  const doDelete = async () => {
    try {
      let status = 200;
      if (isCallSingle) {
        const selectedFile = tableData[selectedRow + page * rowsPerPage];
        status = selectedFile.fileType === resourcesType ? await deleteResourceGroup(selectedFile.id)
        : await deleteResourceFile(selectedFile.id);
      } else {
        const param = genBatchParam();
        status = await deleteResourceList(param);
      }
      if (status !== 200) {
        Swal.fire({
          title: 'Failed to delete file',
          text: `Error code: ${status}`,
          icon: 'error',
          confirmButtonColor: CONFIRM_BUTTON_COLOR,
          customClass: {
            popup: 'swal-popup-zindex',
            container: 'swal-container-zindex'
          }
        });
      } else {
        Swal.fire({
          icon: "success",
          title: "File deleted",
          showConfirmButton: false,
          timer: 1500,
          customClass: {
            popup: 'swal-popup-zindex',
            container: 'swal-container-zindex'
          }
        });
      }
    } catch (e) {
      console.error(e);
    } finally {
      handleMenuClose();
      refreshResources();
      setTableSelected([]);
      setNumSelected(0);
    }
  };

  const handleRename = () => {
    setIsRenameDialogOpen(true);
    handleMenuClose();
  };

  const handleChangeAccess = () => {
    setIsChangeAccessDialogOpen(true);
    setIsCallSingle(true);
    handleMenuClose();
  };

  const handleChangeAccessBatch = () => {
    setIsChangeAccessDialogOpen(true);
    setIsCallSingle(false);
  };

  const handleChangeOwnerBatch = async () => {
    const users = await listUsers();
    setUsers(users);
    setIsChangeOwnerDialogOpen(true);
    setIsCallSingle(false);
  };

  const handleChangeOwner = async () => {
    const users = await listUsers();
    setUsers(users);
    setIsChangeOwnerDialogOpen(true);
    setIsCallSingle(true);
  };

  const handleChangeOwnerDialogClose = () => {
    setIsChangeOwnerDialogOpen(false);
  };

  const handleChangeOwnerSubmit = async () => {
    const selectedFile = tableData[selectedRow + page * rowsPerPage];
    setIsChangeOwnerDialogOpen(false);
    let status = 200;
    if (isCallSingle) {
      status = selectedFile.fileType === resourcesType ? await changeOwnerGroupResource(selectedFile.id, newOwner.id) 
              : await changeOwnerResourceFile(selectedFile.id, newOwner.id);
    } else {
      const param = genBatchParam();
      param.owner = newOwner.id;
      status = await changeResourceOwnerList(param);
    }
    if (!status) {
      Swal.fire({
        title: 'Failed to change owner',
        text: `Error code: 400`,
        icon: 'error',
        confirmButtonColor: CONFIRM_BUTTON_COLOR,
        customClass: {
          popup: 'swal-popup-zindex',
          container: 'swal-container-zindex'
        }
      });
    } else {
      Swal.fire({
        icon: "success",
        title: "Owner changed",
        showConfirmButton: false,
        timer: 1500,
        customClass: {
          popup: 'swal-popup-zindex',
          container: 'swal-container-zindex'
        }
      });
    }
    refreshResources();
    setNewOwner(null);
    setTableSelected([]);
    setNumSelected(0);
  };

  const handleMenuOpen = (event, index, file) => {
    setAnchorEl(event.currentTarget);
    setSelectedRow(index);
    setCurrentResourceInfo(file);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleOpenFilter = (event, id) => {
    setFilterV(null);
    setFilter([...new Set(sortedFiles.filter(item => item[id] !== null).map(item => item[id]))]);
    setFilterAnchorEl(event.currentTarget);
    setFilterK(id);
  };

  const handleFilterClose = () => {
    setFilterAnchorEl(null);
  };

  const handleFilterTable = (value) => {
    setFilterV(value);
  };

  const handleRequestSort = (property) => {
    const isAsc = orderBy === property && orderDirection === 'asc';
    setOrderDirection(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };

  const sortData = (array) => {
    return array.sort((a, b) => {
      if (orderBy === '') return 0;
      if (a[orderBy] < b[orderBy]) {
        return orderDirection === 'asc' ? -1 : 1;
      }
      if (a[orderBy] > b[orderBy]) {
        return orderDirection === 'asc' ? 1 : -1;
      }
      return 0;
    });
  };

  useEffect(() => {
    const selectedFile = tableData[selectedRow + page * rowsPerPage];
    if (selectedFile) {
      setNewName(selectedFile.name);
    }
  }, [isRenameDialogOpen]);

  useEffect(() => {
    const fetchUserInfo = async () => {
      try {
        const userInfo = await getUserInfo();
        setCurrentUserInfo(userInfo);
      } catch (error) {
        console.error('Failed to fetch user info', error);
      }
    };

    fetchUserInfo();
  }, []);

  const sortedFiles = sortData([...files]);

  useEffect(() => {
    setTableData(sortedFiles.filter(item => filterK && filterV ? item[filterK] === filterV : true));
  }, [filterK, filterV, files, orderBy, orderDirection]);

  const setShowChangeOwnerType = (access, isShow) => {
    if (access === 'PUBLIC') {
      setShowChangeOwnerBatch(isShow);
    }
  };

  const handleSelectAllClick = (event) => {
    if (event.target.checked) {
      const newSelected = tableData.map((n) => {
        setShowChangeOwnerType(n.type, false);
        return {id: n.id, fileType: n.fileType};
      });
      setTableSelected(newSelected);
      setNumSelected(newSelected.length);
    } else {
      setTableSelected([]);
      setNumSelected(0);
      setShowChangeOwnerBatch(true);
    }
  };

  const handleClickCheckbox = (event, id, fileType, access) => {
    event.stopPropagation();

    const selectedIndex = tableSelected.findIndex(item => item.id === id);
    let newSelected = [];

    if (selectedIndex === -1) {
      setShowChangeOwnerType(access, false);
      newSelected = [...tableSelected, { id, fileType }];
    } else if (selectedIndex === 0) {
      setShowChangeOwnerType(access, true);
      newSelected = tableSelected.slice(1);
    } else if (selectedIndex === tableSelected.length - 1) {
      setShowChangeOwnerType(access, true);
      newSelected = tableSelected.slice(0, -1);
    } else if (selectedIndex > 0) {
      setShowChangeOwnerType(access, true);
      newSelected = [
        ...tableSelected.slice(0, selectedIndex),
        ...tableSelected.slice(selectedIndex + 1),
      ];
    }
    setTableSelected(newSelected);
    setNumSelected(newSelected.length);
  };

  const isSelected = (id) => tableSelected.some(item => item.id === id);

  return (
    <>
      {numSelected > 0 && 
        <Toolbar
        sx={[
          {
            pl: { sm: 2 },
            pr: { xs: 1, sm: 1 },
          },
          numSelected > 0 && {
            bgcolor: (theme) =>
              alpha(theme.palette.primary.main, theme.palette.action.activatedOpacity),
          },
        ]}
        >
          <Typography
            sx={{ flex: '1 1 100%' }}
            color="inherit"
            variant="subtitle1"
            component="div"
            >
              {numSelected} selected
          </Typography>
          {operationType === 'resources' && 
            <>
              {(showChangeOwnerBatch && currentUserInfo.isAdmin) &&
                <Tooltip title="change owner">
                  <IconButton onClick={handleChangeOwnerBatch}>
                    <ManageAccountsIcon />
                  </IconButton>
                </Tooltip>
              }
              <Tooltip title="change access">
                <IconButton onClick={handleChangeAccessBatch}>
                  <CompareArrowsIcon />
                </IconButton>
              </Tooltip>
            </>
          } 
          <Tooltip title="delete">
            <IconButton onClick={handleDeleteBatch}>
              <DeleteIcon />
            </IconButton>
          </Tooltip>
        </Toolbar>
      }
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow sx={{ backgroundColor: '#f5f5f5' }}>
              <TableCell padding="checkbox">
                <Checkbox
                  color="primary"
                  indeterminate={tableSelected.length > 0 && tableSelected.length < tableData.length}
                  checked={tableData.length > 0 && tableSelected.length === tableData.length}
                  onChange={handleSelectAllClick}
                />
              </TableCell>
              {[
                { id: 'name', label: 'File Name' },
                { id: 'createdTime', label: 'Created Time' },
                { id: 'fileType', label: 'File Type' },
                { id: 'type', label: 'Access Level' },
                { id: 'owner', label: 'Owner' },
              ].map((headCell) => (
                <TableCell
                  key={headCell.id}
                  sortDirection={orderBy === headCell.id ? orderDirection : false}
                >
                  <TableSortLabel
                    active={orderBy === headCell.id}
                    direction={orderBy === headCell.id ? orderDirection : 'asc'}
                    onClick={() => handleRequestSort(headCell.id)}
                  >
                    {headCell.label}
                  </TableSortLabel>
                  {(headCell.id === 'owner' || headCell.id === 'type' || headCell.id === 'fileType') && (
                    <IconButton aria-label='filter' onClick={(e) => handleOpenFilter(e, headCell.id)}>
                      <FilterAltIcon />
                    </IconButton>
                  )}
                  <Menu
                    id="basic-menu"
                    anchorEl={filterAnchorEl}
                    open={Boolean(filterAnchorEl)}
                    onClose={handleFilterClose}
                    MenuListProps={{
                      'aria-labelledby': 'basic-button',
                    }}
                  >
                    <MenuItem key={'None'} value={null} onClick={() => handleFilterTable(null)}>---</MenuItem>
                    {filter.map(item =>
                      <MenuItem key={item} value={item} onClick={() => handleFilterTable(item)}>{item}</MenuItem>
                    )}
                  </Menu>
                </TableCell>
              ))}
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {tableData.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              .map((file, index) => {
                const isItemSelected = isSelected(file.id);
                return (
                  <TableRow
                    onClick={() => handleRowClick(file)}
                    style={{ cursor: 'pointer' }}
                    hover role="checkbox" tabIndex={-1} key={index}
                    selected={isItemSelected}
                  >
                    <TableCell padding="checkbox">
                      <Checkbox
                        color="primary"
                        checked={isItemSelected}
                        onClick={(event) => handleClickCheckbox(event, file.id, file.fileType, file.type)}
                      />
                    </TableCell>
                    <Tooltip key={index} title="Click to show preview" arrow placement="top">
                      <TableCell>{file.name}</TableCell>
                    </Tooltip>
                    <TableCell>{new Date(file.createdTime).toLocaleString()}</TableCell>
                    <TableCell>{file.fileType}</TableCell>
                    <TableCell>{file.type}</TableCell>
                    <TableCell>{file.owner}</TableCell>
                    <TableCell>
                      {(currentUserInfo.isAdmin || file.type !== 'PUBLIC') ? <IconButton
                        onClick={(e) => {
                          e.stopPropagation();
                          handleMenuOpen(e, index, file);
                        }}
                        sx={{ padding: '4px' }}
                      >
                        <MoreVertIcon />
                      </IconButton> : 'N/A'}
                    </TableCell>
                  </TableRow>
                )
              })
            }
          </TableBody>
        </Table>

        <Menu
          anchorEl={anchorEl}
          open={Boolean(anchorEl)}
          onClose={handleMenuClose}
        >
          <MenuItem onClick={handleRename}>{currentResourceInfo.fileType === resourcesType ? 'Rename Group' : 'Rename File'}</MenuItem>
          <MenuItem onClick={handleDelete}>{currentResourceInfo.fileType === resourcesType ? 'Delete Group' : 'Delete File'}</MenuItem>
          {operationType==='resources' && <MenuItem onClick={handleChangeAccess}>{currentResourceInfo.fileType === resourcesType ? 'Change Access Group' : 'Change Access'}</MenuItem>}
          {(currentUserInfo.isAdmin && operationType === 'resources' && currentResourceInfo.type !== 'PUBLIC') && (
            <MenuItem onClick={handleChangeOwner}>{currentResourceInfo.fileType === resourcesType ? 'Change Owner Group' : 'Change Owner'}</MenuItem>
          )}
        </Menu>

        <Dialog open={isRenameDialogOpen} onClose={handleRenameDialogClose} closeAfterTransition={false}>
          <DialogTitle>Rename File</DialogTitle>
          <DialogContent>
            <TextField
              label="New File Name"
              sx={{ mt: 2 }}
              fullWidth
              value={newName}
              error={!!errors.newName}
              helperText={errors.newName?.message}
              {...register('newName')}
              onChange={(e) => setNewName(e.target.value)}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={handleRenameDialogClose}>Cancel</Button>
            <Button onClick={handleSubmit(handleRenameSubmit)} variant="contained" color="primary">
              Save
            </Button>
          </DialogActions>
        </Dialog>
        <Dialog open={isDeleteDialogOpen} onClose={handleCancelDelete} closeAfterTransition={false}>
          <DialogTitle>Confirm Deletion</DialogTitle>
          <DialogContent>
            Are you sure you want to delete this file?
          </DialogContent>
          <DialogActions>
            <Button onClick={handleCancelDelete} variant="contained">Cancel</Button>
            <Button onClick={handleConfirmDelete} variant="outlined" color="error">
              Delete
            </Button>
          </DialogActions>
        </Dialog>
        <Dialog open={isChangeAccessDialogOpen} onClose={handleChangeAccessClose} closeAfterTransition={false}>
          <DialogTitle>Change Access Type</DialogTitle>
          <DialogContent>
            <Select defaultValue="" value={newAccess}
              onChange={(e) => setNewAccess(e.target.value)}>
              <MenuItem value="PUBLIC">PUBLIC</MenuItem>
              <MenuItem value="PRIVATE">PRIVATE</MenuItem>
            </Select>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleChangeAccessClose}>Cancel</Button>
            <Button onClick={handleChangeAccessSubmit} variant="contained" color="primary">
              Save
            </Button>
          </DialogActions>
        </Dialog>
        <Dialog fullWidth open={isChangeOwnerDialogOpen} onClose={handleChangeOwnerDialogClose} closeAfterTransition={false}>
          <DialogTitle>Change Owner</DialogTitle>
          <DialogContent>
            <Autocomplete
              renderInput={(params) => <TextField
                sx={{ mt: 2 }}
                fullWidth
                {...params}
                label="Select an user"
                variant="outlined"
              />}
              getOptionLabel={(option) => (option ? `${option.username} (${option.email})` : null)}
              onChange={(event, newValue) => { setNewOwner(newValue) }}
              value={newOwner}
              options={users} />
          </DialogContent>
          <DialogActions>
            <Button onClick={handleChangeOwnerDialogClose}>Cancel</Button>
            <Button onClick={handleChangeOwnerSubmit} variant="contained" color="primary">
              Save
            </Button>
          </DialogActions>
        </Dialog>
      </TableContainer>

      <TablePagination
        rowsPerPageOptions={[5, 10, 20]}
        component="div"
        count={tableData.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
    </>
  );
};

ResourcesTable.propTypes = {
  files: PropTypes.array.isRequired,
  handleRowClick: PropTypes.func.isRequired,
  refreshResources: PropTypes.func.isRequired,
  operationType: PropTypes.string.isRequired
}

export default ResourcesTable;
