import { useState, useEffect } from "react";
import {
  Drawer,
  List,
  ListItem,
  ListItemText,
  Typography,
  Box
} from "@mui/material";
import { getNotifications } from "../lib/mh.js";
import PropTypes from 'prop-types';

export default function NotificationCenter({ open, onClose }) {
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    if (!open) return;
    getMessages();
  }, [open]);

  const getMessages = async () => {
    const now = new Date();
    const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const messages = await getNotifications(sevenDaysAgo.toISOString());
    setNotifications(messages);
  }

  return (
    <Drawer anchor="right" open={open} onClose={onClose} sx={{ zIndex: 9999 }}>
      <Box sx={{ width: 360, p: 2 }}>
        <List>
          {notifications.length === 0 && (
            <Typography sx={{ textAlign: "center", mt: 4 }}>
              No notifications in the past seven days
            </Typography>
          )}

          {notifications.length > 0 && notifications.map((item) => (
            <ListItem
              key={item.id}
              sx={{
                background: "rgba(25, 118, 210, 0.08)",
                borderRadius: 1,
                mb: 1,
              }}
            >
              <ListItemText primary={item.message} secondary={new Date(item.date).toLocaleString()} />
            </ListItem>
          ))}
        </List>
      </Box>
    </Drawer>
  );
}

NotificationCenter.propTypes = {
  open: PropTypes.bool.isRequired,
  onClose: PropTypes.func.isRequired,
};
