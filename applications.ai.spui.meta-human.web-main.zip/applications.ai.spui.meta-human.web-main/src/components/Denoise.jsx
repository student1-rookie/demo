import {useState, useCallback, useMemo, useRef} from 'react';
import {
  FormControl,
  Select,
  MenuItem,
  TextField,
  FormControlLabel,
  Checkbox,
  Button,
  FormHelperText,
  CircularProgress,
  Typography,
  Autocomplete,
  InputAdornment
} from '@mui/material';
import { useForm, Controller } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { postDenoise } from "../lib/mh.js";
import PropTypes from "prop-types";
import * as yup from 'yup';
import ResourceUploader from './ResourceUploader.jsx';
import Box from "@mui/material/Box";
import {extractFirstFrame} from "../utils/video.js";

const schema = yup.object().shape({
  dataset: yup.string().required('Resource is required'),
  outputName: yup.string().required('File name is required').min(3, 'File name must be at least 3 characters'),
  newResource: yup.boolean(),
});

const Denoise = ({ resources, fetchResources, fetchResourcesGroup }) => {
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false);
  const [isDownloadAvailable, setIsDownloadAvailable] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [downloadedFile, setDownloadedFile] = useState(null);
  const [downloadedFilename, setDownloadedFilename] = useState('');

  const [inputValue, setInputValue] = useState('');
  const [fileType, setFileType] = useState('ALL');
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewSrc, setPreviewSrc] = useState(null);
  const [previewType, setPreviewType] = useState(null);
  const latestPreviewRequestId = useRef(0);
  const [previewPosition, setPreviewPosition] = useState({ left: 0, top: 0 });

  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      dataset: '',
      outputName: '',
      newResource: false,
    },
  });

  const onSubmit = async (data) => {
    try {
      setIsDownloadAvailable(false);
      setIsLoading(true);
      console.log('Submitting data:', data);
      const response = await postDenoise(data);

      if (response) {
        // Store the downloaded file and filename in state
        setDownloadedFile(response.blob);
        setDownloadedFilename(response.filename);
        setIsDownloadAvailable(true);
      }
    } catch (error) {
      console.error('Error submitting data:', error);
      setIsDownloadAvailable(false);
    } finally {
      fetchResources();
      fetchResourcesGroup();
      setIsLoading(false);
    }
  };

  const handleDownload = () => {
    if (downloadedFile && downloadedFilename && isDownloadAvailable) {
      const url = URL.createObjectURL(downloadedFile);
      const a = document.createElement('a');
      a.href = url;
      a.download = downloadedFilename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  };

  const LoadingModal = ({ isLoading }) => {
    if (!isLoading) return null;

    return (
      <div style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        zIndex: 1000
      }}>
        <div style={{
          backgroundColor: 'white',
          padding: '20px',
          borderRadius: '10px',
          boxShadow: '0 0 10px rgba(0, 0, 0, 0.1)'
        }}>
          <CircularProgress color="primary" />
          <Typography variant="h6" style={{ marginTop: '10px' }}>
            Processing Denoise...
          </Typography>
        </div>
      </div>
    );
  };

  const resourceFiles = useMemo(() => {
    const files = resources.filter(r => ['VIDEO', 'AUDIO'].includes(r.fileType));
    return [...files, { name: 'Add Resource File' }];
  }, [resources]);

  const filteredFiles = useMemo(() => {
    return resourceFiles.filter(file => {
      const matchType = fileType === 'ALL' || file.fileType === fileType;
      const matchName = file.name.toLowerCase().includes(inputValue.toLowerCase());
      return (matchType && matchName) || file.name === 'Add Resource File';
    });
  }, [resourceFiles, fileType, inputValue]);

  const resetPreview = () => {
    ++latestPreviewRequestId.current;
    if (previewSrc) {
      URL.revokeObjectURL(previewSrc);
    }
    setPreviewSrc(null);
    setPreviewType(null);
  };

  const handleMouseEnter = useCallback(async (option, event) => {
    const requestId = ++latestPreviewRequestId.current;
    const datasetUrl = `/resources/preview/${option.id}`;
    const rect = event.currentTarget.getBoundingClientRect();

    setPreviewPosition({
      top: rect.top + window.scrollY,
      left: rect.right + 32,
    });

    try {
      if (option.fileType === 'VIDEO') {
        const frameUrl = await extractFirstFrame(datasetUrl);
        if (requestId === latestPreviewRequestId.current) {
          setPreviewSrc(frameUrl);
          setPreviewType('VIDEO');
        }
      } else {
        resetPreview();
      }
    } catch (err) {
      if (requestId === latestPreviewRequestId.current) {
        console.error('Failed to load preview:', err);
        resetPreview();
      }
    }
  }, []);

  const handleMouseLeave = useCallback(() => {
    resetPreview();
  }, [previewSrc]);

  const renderOption = useCallback((props, option) => (
    <Box component="li"
         {...props}
         onPointerEnter={(event) => handleMouseEnter(option, event)}
         onPointerLeave={handleMouseLeave}>
      <Typography variant="body2" sx={option.name === 'Add Resource File' && { color: '#1565c0' }}>{option.name}</Typography>
      {option.name !== 'Add Resource File' && (
        <Typography variant="caption" sx={{ ml: 1 }} color="text.secondary">
          ({option.fileType})
        </Typography>
      )}
    </Box>
  ), [handleMouseEnter, handleMouseLeave]);

  const renderInput = useCallback((params) => (
    <TextField
      {...params}
      label="Select Resource"
      size="medium"
      InputProps={{
        ...params.InputProps,
        startAdornment: (
          <InputAdornment position="start"
                          sx={{ position: 'absolute', left: 8, top: '50%', transform: 'translateY(-50%)', zIndex: 1 }}>
            <Select value={fileType}
                    onChange={(e) => setFileType(e.target.value)}
                    variant="standard"
                    disableUnderline
                    sx={{ minWidth: 64, fontSize: '0.85rem' }}>
              <MenuItem value="ALL">ALL</MenuItem>
              <MenuItem value="VIDEO">VIDEO</MenuItem>
              <MenuItem value="AUDIO">AUDIO</MenuItem>
            </Select>
          </InputAdornment>
        ),
        sx: { '& input': { marginLeft: '72px' } }
      }}
    />
  ), [fileType]);

  LoadingModal.propTypes = {
    isLoading: PropTypes.bool.isRequired,
  }

  const previewStyle = {
    position: 'absolute',
    left: previewPosition.left,
    top: previewPosition.top,
    transform: 'translateY(-50%)',
    zIndex: 2000,
    width: '300px',
    height: '200px',
    backgroundColor: 'rgba(97,97,97,0.92)',
    borderRadius: '4px',
    boxShadow: '0 2px 10px rgba(0,0,0,0.15)',
    border: '1px solid #e0e0e0',
    overflow: 'hidden',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    transition: 'opacity 0.3s ease',
  };

  return (
    <div>
      <LoadingModal isLoading={isLoading} />
      <form onSubmit={handleSubmit(onSubmit)}>
        {/* Resource Selector */}
        <FormControl fullWidth margin="normal" size="small" error={!!errors.dataset}>
          <Controller
            name="dataset"
            control={control}
            render={({ field }) => (
              <Autocomplete
                {...field}
                options={filteredFiles}
                getOptionLabel={(opt) => opt.name}
                value={selectedFile}
                inputValue={inputValue}
                onInputChange={(e, val) => setInputValue(val)}
                onClose={() => {
                  resetPreview();
                }}
                onChange={(e, newVal) => {
                  resetPreview();
                  setIsDownloadAvailable(false);
                  if (newVal?.name === 'Add Resource File') {
                    setIsUploadDialogOpen(true);
                    setSelectedFile(null);
                  } else {
                    setSelectedFile(newVal);
                    field.onChange(newVal?.identifier || '');
                  }
                }}
                renderOption={renderOption}
                renderInput={renderInput}
              />
            )}
          />
          {errors.dataset && <FormHelperText>{errors.dataset.message}</FormHelperText>}
        </FormControl>

        {/* FileUploadDialog */}
        <ResourceUploader
          open={isUploadDialogOpen}
          onClose={() => setIsUploadDialogOpen(false)}
          onUploadComplete={async (fileId) => {
            const files = await fetchResources(); // Refresh resources after upload
            await fetchResourcesGroup();
            setIsUploadDialogOpen(false);
            const newFile = files.find(file => file.id === fileId);
            if (newFile) {
              setSelectedFile(newFile);
            }
          }}
          allowedFileTypes={['audio', 'video']}
        />
        {/* File Name Input */}
        <FormControl fullWidth margin="normal" error={!!errors.outputName}>
          <Controller
            name="outputName"
            control={control}
            render={({ field }) => (
              <TextField
                {...field}
                label="File Name After Denoise"
                variant="outlined"
                value={field.value}
                onChange={(e) => field.onChange(e.target.value)}
              />
            )}
          />
          {errors.outputName && <FormHelperText>{errors.outputName.message}</FormHelperText>}
        </FormControl>

        {/* Submit as New Resource Checkbox */}
        <FormControl margin="normal">
          <Controller
            name="newResource"
            control={control}
            render={({ field }) => (
              <FormControlLabel
                control={
                  <Checkbox
                    {...field}
                    checked={field.value}
                    onChange={(e) => field.onChange(e.target.checked)}
                  />
                }
                label="Submit as New Resource"
              />
            )}
          />
        </FormControl>

        {/* button container */}
        <div style={{ display: 'flex', alignItems: 'center', marginTop: '10px' }}>
          {/* Submit Button */}
          <Button
            type="submit"
            variant="contained"
            color="primary"
            style={{ marginRight: isDownloadAvailable ? '10px' : '0px', flex: 1 }}
          >
            Submit
          </Button>

          {/* Download Button - Show if download is available */}
          {isDownloadAvailable && (
            <Button
              variant="contained"
              color="secondary"
              onClick={handleDownload}
              style={{ flex: 1 }}
            >
              Download
            </Button>
          )}
        </div>

        <div>
          {previewSrc && (
              <Box sx={previewStyle}>
                {previewType === 'VIDEO' && (
                    <img
                        src={previewSrc}
                        alt="Preview"
                        style={{
                          maxWidth: '100%',
                          maxHeight: '100%',
                          objectFit: 'contain',
                          padding: '10px'
                        }}
                        onError={(e) => {
                          console.error('Failed to load image:', previewSrc);
                          resetPreview();
                          e.target.style.display = 'none';
                        }}
                    />
                )}
              </Box>
          )}
        </div>
      </form>
    </div>
  );
};


Denoise.propTypes = {
  resources: PropTypes.array.isRequired,
  fetchResources: PropTypes.func.isRequired,
  fetchResourcesGroup: PropTypes.func.isRequired
};

export default Denoise;
