import FormControl from "@mui/material/FormControl";
import TextField from "@mui/material/TextField";
import { CircularProgress, Box } from '@mui/material';
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import { Checkbox, Dialog, DialogActions, DialogContent, DialogTitle, FormControlLabel, FormHelperText, IconButton, Tooltip, Typography, InputAdornment, Paper, Card, CardContent } from "@mui/material";
import Button from "@mui/material/Button";
import * as yup from "yup";
import { useForm, Controller } from "react-hook-form";
import { yupResolver} from "@hookform/resolvers/yup";
import { postPicInPicInference, getPicInPicList, savePicInPic, deletePicInPicTemplate, postItemInference, getItemInferenceStatus, getItemInference, copyPicInPicTemplate} from "../lib/mh.js";
import Swal from "sweetalert2";
import { useEffect, useRef, useState, useMemo } from "react";
import PropTypes from "prop-types";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import Autocomplete from '@mui/material/Autocomplete';
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
import ArrowDropUpIcon from "@mui/icons-material/ArrowDropUp";
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import FaceIcon from '@mui/icons-material/Face';
import InsertPhotoIcon from '@mui/icons-material/InsertPhoto';
import RecordVoiceOverIcon from '@mui/icons-material/RecordVoiceOver';
import VoiceOverOffIcon from '@mui/icons-material/VoiceOverOff';
import PictureInPictureIcon from '@mui/icons-material/PictureInPicture';
import WarningIcon from '@mui/icons-material/Warning';
import "cropperjs/dist/cropper.css";
import PicInPicCropper from "./PicInPicCropper.jsx";
import Grid from "@mui/material/Grid";
import { extractFirstFrame } from "../utils/video.js";
import { v4 as uuidv4 } from 'uuid';
import ResourceUploader from "./ResourceUploader.jsx";
import EventBus from "../lib/EventBus.js";
import DeleteOutlinedIcon from '@mui/icons-material/DeleteOutlined';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import RefreshIcon from '@mui/icons-material/Refresh';
import { TabContext, TabList, TabPanel } from '@mui/lab';
import Tab from '@mui/material/Tab';
import omit from 'lodash/omit';
import { sha256 } from 'js-sha256'
import { useNotification } from "../lib/NotificationContext.jsx";

export default function PicInPicInferenceForm(props) {

  const { faceModels, voiceModels, currentUserInfo, datasets, fetchResources, fetchResourcesGroup, getInferenceInfo, handleTabTurn } = props;

  const [hdtr, setHdtr] = useState(false);
  const [displayHdtr, setDisplayHdtr] = useState(false);
  const [showSubtitle, setShowSubtitle] = useState(false);
  const [items, setItems] = useState([]);
  const [overlayUrl, setOverlayUrl] = useState(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [tooltipOpen, setTooltipOpen] = useState(-1);
  const [tooltipAudioOpen, setTooltipAudioOpen] = useState(-1);
  const [tooltipBackgroundOpen, setTooltipBackgroundOpen] = useState(-1);
  const [currentId, setCurrentId] = useState(-1);
  const [currentX, setCurrentX] = useState(null);
  const [currentY, setCurrentY] = useState(null);
  const [currentCropHeight, setCurrentCropHeight] = useState(null);
  const [currentCropWidth, setCurrentCropWidth] = useState(null);

  const [cropBackgroundUrl, setCropBackgroundUrl] = useState(null);
  const [cropOverlayUrl, setCropOverlayUrl] = useState(null);
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false);
  const [selectedItemIndex, setSelectedItemIndex] = useState(-1);

  const picInpiCropperRef = useRef(null);

  const [inputFileNames, setInputFileNames] = useState({});
  const [inputFileTypes, setInputFileTypes] = useState({});

  const [previewSrc, setPreviewSrc] = useState(null);
  const [previewType, setPreviewType] = useState(null);
  const [previewPosition, setPreviewPosition] = useState({ left: 0, top: 0 });

  const [selectedItem, setSelectedItem] = useState(null);

  const latestPreviewRequestId = useRef(0);

  const [emotion, setEmotion] = useState(null);
  const [speed, setSpeed] = useState(null);
  const [fontSize, setFontSize] = useState(null);
  const [color, setColor] = useState(null);
  const [bold, setBold] = useState(null);
  const [marginV, setMarginV] = useState(null);
  const [extendColor, setExtendColor] = useState(null);
  const [extendRatio, setExtendRatio] = useState(null);
  const [resolution, setResolution] = useState(null);
  const [seed, setSeed] = useState('');
  const [device, setDevice] = useState(null);
  const [picType, setPicType] = useState('pip_settings');
  
  const [TTSModelsChange, setTTSModelsChange] = useState(false);
  const [FaceModelsChange, setFaceModelsChange] = useState(false);

  const [isAllowedWholeSubmit, setIsAllowedWholeSubmit] = useState(true);
  const [pipTemplate, setPipTemplate] = useState(null);

  const [voiceModelType, setVoiceModelType] = useState('');
  const [faceModelType, setFaceModelType] = useState('');

  const [isRenameDialogOpen, setIsRenameDialogOpen] = useState(false);
  const [newName, setNewName] = useState('');
  const { lastMessage } = useNotification();
  const [filterVoiceModelType, setFilterVoiceModelType] = useState('');
  const [filterFaceModelType, setFilterFaceModelType] = useState('');

  const schema = yup.object().shape({
    name: yup.string().required('Inference name is required'),
    voiceModel: yup.string().required('Voice Model is required'),
  });

  const completedStatus = ['SUCCESS', 'ITEM-SUCCESS', 'FAIL', 'CREATE', 'HIDDEN'];

  const {
    handleSubmit,
    control,
    formState: { errors },
    setError,
    getValues,
    setValue,
    reset,
    watch
  } = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      name: "",
      voiceModel: "",
      faceModel: ""
    }
  });

  const [pipList, setPipList] = useState([]);

  const fetchPipList = async () => {
    try {
      const data = await getPicInPicList();
      if (!Array.isArray(data)) {
        setPipList([]);
      } else {
        setPipList(data);
      }
    } catch (err) {
      setError(err.message);
    }
  };

  useEffect(() => {
    fetchPipList();
    
    const handlePptxUploaded = () => {
      fetchPipList();
    };

    EventBus.on('pptxUploaded', handlePptxUploaded);

    return () => {
      EventBus.off('pptxUploaded', handlePptxUploaded);
    };
  }, [reset]);

  useEffect(() => {
    const subscription = watch(async (values) => {
      if (values.faceModel) {
        const model = faceModels.find(m => m.id === values.faceModel && m.model === 'LATENTSYNC');
        setDisplayHdtr(!!model);
      } else {
        setDisplayHdtr(false);
      }
  });
    return () => subscription.unsubscribe();
  }, [watch, faceModels]);

  useEffect(() => {
      let isMounted = true;
      let timeId = null;
      let isAllComplete = true
      const data = getValues();
      const checkPendingItems = async () => {
          if (!isMounted) {
            return;
          }
          let changeItems = false;
          const pendingItems = items.filter(item => 
            !completedStatus.includes(item.preview)
          );
          if (pendingItems.length === 0) {
            setIsAllowedWholeSubmit(true);
            return;
          }
          try {
              const promises = items.map(async (item) => {
                if (completedStatus.includes(item.preview)) {
                  return null;
                }
                if (item.preview === 'ITEM-WAIT') {
                  if (!item.itemKey) return null;
                  return getItemInferenceStatus(item.itemKey);
                }
                return getItemInference(buildPreviewItemKey(item), data.id);
              });
              const results = await Promise.allSettled(promises);
              const updatedItems = items.map((item, index) => {
                  if (completedStatus.includes(item.preview)) {
                    return item;
                  }
                  const result = results[index];
                  console.log(result);
                  if (result.status === 'rejected' || !result.value) {
                    return {
                      ...item,
                      item_inference_id: null, 
                      itemKey: null,
                      preview: 'FAIL',
                      originPreview: 'FAIL'
                    }
                  }
                  if (result.status === 'fulfilled' && result.value.inferenceStatus === 'COMPLETE' && item.preview !== 'SUCCESS' && item.preview !== 'ITEM-SUCCESS') {
                    changeItems = true;
                    return {
                      ...item,
                      item_inference_id: result.value.inferenceId, 
                      originInferenceId: result.value.inferenceId,
                      preview: item.preview === 'ITEM-WAIT' ? 'ITEM-SUCCESS' : 'SUCCESS',
                      originPreview: item.preview === 'ITEM-WAIT' ? 'ITEM-SUCCESS' : 'SUCCESS'
                    };
                  } else if (result.status === 'fulfilled' && result.value.inferenceStatus === 'FAIL' && item.preview !== 'FAIL') {
                    changeItems = true;
                    return { 
                      ...item, 
                      item_inference_id: result.value.inferenceId, 
                      originInferenceId: result.value.inferenceId,
                      preview: 'FAIL',
                      originPreview: 'FAIL'
                    };
                  } else if (result.status === 'fulfilled' && ['WAIT', 'INIT', 'RUN'].includes(result.value.inferenceStatus)) {
                    if (item.preview === 'ITEM-WAIT') return item;
                    isAllComplete = false;
                    if (item.preview !== 'WAIT') {
                      changeItems = true;
                      return {
                        ...item,
                        item_inference_id: result.value.inferenceId,  
                        originInferenceId: result.value.inferenceId,
                        preview: 'WAIT',
                        originPreview: 'WAIT'
                      };
                    }
                  }
                  return item;
              });
              if (changeItems) {
                setItems(updatedItems);
              }
              setIsAllowedWholeSubmit(isAllComplete);
              timeId = setTimeout(checkPendingItems, 5000);
          } catch (error) {
              console.error('Polling error:', error);
          }
      };
      timeId = setTimeout(checkPendingItems, 0);
      return () => {
          isMounted = false;
          clearTimeout(timeId);
      };
  }, [items]);

  useEffect(() => {
    if (!lastMessage) return;

    if (lastMessage.type === 'pip') {
      fetchPipList();
    }
  }, [lastMessage]);

  const buildPreviewItemKey = (item) => {
    const normalize = (v) => (v === undefined ? null : v);
    const normalizedType =
      item.type == null
        ? null
        : typeof item.type === 'string'
          ? item.type.toUpperCase()
          : String(item.type).toUpperCase();
    const formatCoordinate = (coord) => {
      if (!Array.isArray(coord) || coord.length !== 2) return null;
      const [x, y] = coord;
      if (x == null || y == null || isNaN(x) || isNaN(y)) return null;
      return `[${Number(x).toFixed(2)}, ${Number(y).toFixed(2)}]`;
    };
    const obj = {
      media: normalize(item.media),
      text: normalize(item.text),
      coordinate: formatCoordinate(item.coordinate),
      box: normalize(item.box),
      is_meta_human_background: normalize(item.is_meta_human_background),
      audio_only: normalize(item.audio_only),
      type: normalizedType
    };
    const json = JSON.stringify(obj);
    return sha256(json);
  }

  const resetForm = () => {
    reset({
      id: "",
      name: "",
      voiceModel: "",
      faceModel: ""
    });
    setItems([]);
    setHdtr(false);
    setShowSubtitle(false);
    setError('');
    setEmotion(null);
    setSpeed(null);
    setFontSize(null);
    setColor(null);
    setBold(null);
    setMarginV(null);
    setExtendColor(null);
    setExtendRatio(null);
    setResolution(null);
    setSeed('');
    setSelectedItem(null);
    setDevice(null);
  }

  const resetFormByOption = (data) => {
    reset({
      id: data.id,
      name: data.name,
      voiceModel: data.models.TTS,
      faceModel: data.models.FACE
    });
    setItems(data.input.map((item) => ({ 
      ...item, 
      id: uuidv4(),
      // this split is used for processing old media with file name.
      media: item.media?.split('/')?.shift() || '',
      originText: item.text,
      originMedia: item.media,
      originBox: item.box,
      originCoordinate: item.coordinate,
      originAudio: item.audio_only,
      originBackground: item.is_meta_human_background,
      originPreview: null,
      preview: null
    })));
    setHdtr(data.hdtr);
    setShowSubtitle(data.subtitle);
    setEmotion(data.ttsInstructDto.emotion);
    setSpeed(data.ttsInstructDto.speed);
    setFontSize(data.subtitleStyleDto.fontSize);
    setColor(data.subtitleStyleDto.color);
    setBold(data.subtitleStyleDto.bold);
    setMarginV(data.subtitleStyleDto.margin_v);
    setExtendColor(data.subtitleStyleDto.extendColor);
    setExtendRatio(data.subtitleStyleDto.extendRatio);
    setResolution(data.resolution);
    setSeed(data.seed === null ? '' : data.seed);
    setDevice(data.device);
    setError('');
    setPipTemplate(data);
    voiceModelChange(data.models.TTS);
    faceModelChange(data.models.FACE);
  }

  const CONFIRM_BUTTON_COLOR = '#1976d2';

  const handleAddItem = () => {
    let item = {id: uuidv4(), type: null, text: null, media: null, item_inference_id: null, preview: 'CREATE', itemKey: null};
    if (items.length > 0) {
      const resetFields = omit(items[items.length -1], ['id', 'media', 'text', 'type', 'item_inference_id', 'itemKey', 'originText', 'originInferenceId', 'preview', 'originItemKey', 'originPreview']);
      item = {...item, ...resetFields}
    } else {
      item = {...item, coordinate: null, box: null, is_meta_human_background: false, audio_only: false, preview: 'CREATE'};
    }
    setItems([...items, item]);
  };

  const handleDeleteItem = (id) => {
    setItems(items.filter(item => item.id !== id));
  };

  const handleMoveUp = (index) => {
    if (index === 0) return;
    const newItems = [...items];
    [newItems[index - 1], newItems[index]] = [newItems[index], newItems[index - 1]];
    setItems(newItems);
  };

  const handleMoveDown = (index) => {
    if (index === items.length - 1) return;
    const newItems = [...items];
    [newItems[index + 1], newItems[index]] = [newItems[index], newItems[index + 1]];
    setItems(newItems);
  };

  const handleTextChange = (id, value) => {
    const modelsChange = TTSModelsChange || FaceModelsChange;
    const subtitleChange = pipTemplate ? (showSubtitle !== pipTemplate.subtitle) : false;
    setItems(prev =>
      prev.map(item => {
        if (item.id !== id) return item;
        const newItem = { ...item, text: value };
        const isNoChange = !modelsChange && !subtitleChange && itemIsChange(newItem);
        return {
          ...newItem,
          item_inference_id: isNoChange ? item.originInferenceId : null,
          itemKey: isNoChange ? item.originItemKey : null,
          preview: isNoChange ? item.originPreview : 'HIDDEN'
        };
      })
    );
  };

  const handleRecover = (id) => {
    const modelsChange = TTSModelsChange || FaceModelsChange;
    const pip = pipTemplate;
    let subtitleChange = false;
    if (pip) {
      subtitleChange = showSubtitle !== pip.subtitle;
    }
    const isNoChange = !modelsChange && !subtitleChange
    setItems(prevItems =>
      prevItems.map(item => {
        if (item.id !== id) {
          return item;
        }
        const originDataset = datasets.find(d => d.id === item.originMedia);
        const originType = originDataset ? originDataset.fileType : null;
        return {
          ...item,
          text: item.originText,
          media: item.originMedia,
          type: originType,
          box: item.originBox,
          coordinate: item.originCoordinate,
          is_meta_human_background: item.originBackground,
          audio_only: item.originAudio,
          itemKey: isNoChange ? item.originItemKey : null,
          item_inference_id: isNoChange ? item.originInferenceId : null,
          preview: isNoChange ? item.originPreview : 'HIDDEN'
        };
      })
    );
  };

  const handleModelChange = (modelObject) => {
    const pip = pipTemplate;
    if (!pip) {
      return;
    }
    const originModels = pip.models;
    let ttsModelChange = TTSModelsChange;
    let faceModelChange = FaceModelsChange;
    if (modelObject.name === 'voiceModel') {
      ttsModelChange = originModels.TTS !== modelObject.value
    } else {
      faceModelChange = originModels.FACE !== modelObject.value
    }
    setTTSModelsChange(ttsModelChange);
    setFaceModelsChange(faceModelChange);
    const modelsChange = ttsModelChange || faceModelChange;
    let subtitleChange = showSubtitle !== pip.subtitle;
    setItems(prevItems => {
        return prevItems.map(item => {
          const isNoChange = itemIsChange(item) && !modelsChange && !subtitleChange;
          const newItem = { ...item };
          newItem.item_inference_id = isNoChange ? item.originInferenceId : null;
          newItem.itemKey = isNoChange ? item.originItemKey : null;
          newItem.preview = isNoChange ? item.originPreview : 'HIDDEN';
          return newItem;
      });
    });
  }

  const handleSubtitleChange = (checked) => {
    setShowSubtitle(checked);
    const modelsChange = TTSModelsChange || FaceModelsChange;
    if (modelsChange) return;
    const pip = pipTemplate;
    let subtitleChange = false;
    if (pip) {
      subtitleChange = checked !== pip.subtitle;
    }
    setItems(prevItems => {
        return prevItems.map(item => {
          const isNoChange = itemIsChange(item) && !subtitleChange;
          const newItem = { ...item };
          newItem.item_inference_id = isNoChange ? item.originInferenceId : null;
          newItem.itemKey = isNoChange ? item.originItemKey : null;
          newItem.preview = isNoChange ? item.originPreview : 'HIDDEN';
          return newItem;
      });
    });
  }

  const handleMediaChange = (id, value) => {
    const modelsChanged = TTSModelsChange || FaceModelsChange;
    const subtitleChanged = pipTemplate ? (showSubtitle !== pipTemplate.subtitle) : false;
    setItems(prev =>
      prev.map(item => {
        if (item.id !== id) return item;
        if (!value) {
          return {
            ...item,
            media: null,
            type: null,
            item_inference_id: null,
            itemKey: null,
            preview: null
          };
        }
        const newItem = { ...item, media: value.id, type: value.fileType };
        if (value.fileType === 'VIDEO') {
          newItem.text = null;
          newItem.coordinate = null;
          newItem.box = null;
          newItem.is_meta_human_background = false;
          newItem.audio_only = false;
        }
        const isNoChange = !modelsChanged && !subtitleChanged && itemIsChange(newItem);
        newItem.item_inference_id = isNoChange ? newItem.originInferenceId : null;
        newItem.itemKey = isNoChange ? newItem.originItemKey : null;
        newItem.preview = isNoChange ? newItem.originPreview : 'HIDDEN';
        return newItem;
      })
    );
  };

  const itemIsChange = (item) => {
    const sameText = item.text === item.originText;
    const sameMedia = item.media === item.originMedia;
    const samePos =
      (!item.box && !item.originBox && !item.coordinate && !item.originCoordinate) ||
      (item.box && item.originBox && item.coordinate && item.originCoordinate &&
        item.box[0] === item.originBox[0] &&
        item.box[1] === item.originBox[1] &&
        item.coordinate[0] === item.originCoordinate[0] &&
        item.coordinate[1] === item.originCoordinate[1]);
    const sameAudioBg =
      item.audio_only === item.originAudio &&
      item.is_meta_human_background === item.originBackground;
    return sameText && sameMedia && samePos && sameAudioBg;
  }

  const check = (data) => {
    const input = JSON.parse(JSON.stringify(items));
    const stack = []
    if (input.length === 0) {
      setError('picInPicText', {type: 'manual', message: 'pic-in-pic text is required'});
      return null;
    }
    for (let i = 0; i < input.length; i++) {
      input[i].itemKey = null
      if ((!input[i].text || input[i].text.trim() === '') && input[i].type !== 'VIDEO') {
        setError('picInPicText', {type: 'manual', message: 'pic-in-pic text is required'});
        return null;
      }
      if (input[i].type === 'VIDEO') {
        input[i].text = null;
      }
      if (!input[i].coordinate || !input[i].box) {
        input[i].coordinate = null;
        input[i].box = null;
      }
      if (!data.faceModel) {
        input[i].audio_only = true;
      }
      if (input[i].audio_only) {
        input[i].coordinate = null;
        input[i].box = null;
        input[i].is_meta_human_background = false;
      }
      input[i].id = i;
      if (stack.length && !stack[stack.length - 1].type && !input[i].type) {
        stack[stack.length - 1].text += input[i].text;
      } else {
        stack.push(input[i]);
      }
    }
    return stack.map(({ id, ...item }) => item); // eslint-disable-line no-unused-vars
  }

  const picInPicSubmit = async () => {
    const data = getValues();
    const input = check(data);
    console.log(input);
    if (!input) return;
    const inferencePicInPicMeta = {
      id: data.id,
      name: data.name,
      models: {'FACE': data.faceModel, 'TTS': data.voiceModel},
      type: 'PIC_IN_PIC',
      input: input,
      subtitle: showSubtitle,
      hdtr: hdtr,
      backgroundImage: null,
      ttsInstructTaskDto: {
        emotion: emotion,
        speed: speed
      },
      subtitleStyleTaskDto: {
        fontSize: fontSize,
        color: color,
        bold: bold,
        margin_v: marginV,
        extendColor: extendColor,
        extendRatio: extendRatio
      },
      resolution: resolution,
      seed: seed,
      device: device
    };

    try {
      await postPicInPicInference(inferencePicInPicMeta);
      Swal.fire({
        icon: "success",
        title: "Inference started",
        showConfirmButton: false,
        timer: 1500
      });
      fetchPipList();
      handleTabTurn(1);
    } catch (e) {
      let title = 'Inference failed to start';
      if (e.status === 400) {
        title = e.response.data;
      }
      Swal.fire({
        title: title,
        icon: "error",
        confirmButtonColor: CONFIRM_BUTTON_COLOR
      });
    } finally {
      await getInferenceInfo();
      resetForm();
    }
  }

  const picInPicSave = async () => {
    const data = getValues();
    const input = check(data);
    console.log(input);
    if (!input) return;
    const inferencePicInPicMeta = {
      id: data.id,
      name: data.name,
      models: {'FACE': data.faceModel, 'TTS': data.voiceModel},
      type: 'PIC_IN_PIC',
      input: input,
      subtitle: showSubtitle,
      hdtr: hdtr,
      backgroundImage: null,
      ttsInstructTaskDto: {
        emotion: emotion,
        speed: speed
      },
      subtitleStyleTaskDto: {
        fontSize: fontSize,
        color: color,
        bold: bold,
        margin_v: marginV,
        extendColor: extendColor,
        extendRatio: extendRatio
      },
      resolution: resolution,
      seed: seed,
      device: device
    };

    try {
      const id = await savePicInPic(inferencePicInPicMeta);
      fetchPipList();
      if (id.err) {
        Swal.fire({
          title: id.err,
          icon: "error",
          confirmButtonColor: CONFIRM_BUTTON_COLOR
        });
        return;
      }
      Swal.fire({
        icon: "success",
        title: "Save PicInPic",
        showConfirmButton: false,
        timer: 1500
      });
      setValue('id', id);
      setSelectedItem(getValues());
    } catch (e) {
      Swal.fire({
        title: "Save failed",
        icon: "error",
        confirmButtonColor: CONFIRM_BUTTON_COLOR
      });
    } finally {
      setPipTemplate(inferencePicInPicMeta);
      setItems(items.map((item) => ({ 
        ...item, 
        id: item.id,
        media: item.media?.split('/')?.shift() || '',
        originText: item.text,
        originMedia: item.media,
        originBox: item.box,
        originCoordinate: item.coordinate,
        originAudio: item.audio_only,
        originBackground: item.is_meta_human_background,
        preview: null
      })));
    }
  }

  const picInPicOneItemSubmit = async (item) => {
    item.preview = 'ITEM-WAIT';
    const data = getValues();
    console.log(data);
    if (!data.faceModel) {
      item.audio_only = true;
    }
    if (item.audio_only) {
      item.coordinate = null;
      item.box = null;
      item.is_meta_human_background = false;
    }
    const inputList = [];
    inputList.push(item);
    const inferencePicInPicMeta = {
      id: data.id,
      name: data.name,
      models: {'FACE': data.faceModel, 'TTS': data.voiceModel},
      type: 'ITEM_PIC_IN_PIC',
      input: inputList,
      subtitle: showSubtitle,
      hdtr: hdtr,
      backgroundImage: null,
      ttsInstructTaskDto: {
        emotion: emotion,
        speed: speed
      },
      subtitleStyleTaskDto: {
        fontSize: fontSize,
        color: color,
        bold: bold,
        margin_v: marginV
      },
      resolution: resolution,
      seed: seed,
      device: device
    };
    try {
      const res = await postItemInference(inferencePicInPicMeta);
      console.log(res);
      Swal.fire({
        icon: "success",
        title: "Inference started",
        showConfirmButton: false,
        timer: 3000
      });
      const updatedItem = {
        ...item,
        item_inference_id: res.data.inferenceId,
        originInferenceId: res.data.inferenceId,
        originAudio: item.audio_only,
        originBackground: item.is_meta_human_background,
        originBox: item.box,
        originCoordinate: item.coordinate,
        originMedia: item.media,
        originText: item.text,
        preview: 'ITEM-WAIT',
        itemKey: res.data.itemKey,
        originItemKey: res.data.itemKey,
        originPreview: 'ITEM-WAIT'
      };
      console.log(updatedItem);
      setPipTemplate(inferencePicInPicMeta);
      setItems(items => items.map(it => it.id === item.id ? updatedItem : it));
    } catch (e) {
      console.log(e);
      Swal.fire({
        title: "Inference failed to start",
        icon: "error",
        confirmButtonColor: CONFIRM_BUTTON_COLOR
      });
    } finally {
      await getInferenceInfo();
    }
  }

  const handleToolTipClose = () => {
    setTooltipOpen(-1);
  }

  const handleToolTipAudioClose = () => {
    setTooltipAudioOpen(-1);
  }

  const handleToolTipBackgroundClose = () => {
    setTooltipBackgroundOpen(-1);
  }

  const getBackgroundUrl = (image) => {
    return `/resources/preview/${image}`
  }

  const getOverlayImageUrl = (image) => {
    return `/resources/avatar-preview/${image}`;
  }

  const handleChangeOverlay = async (value) => {
    setItems(items.map(item => ({
      ...item,
      coordinate: null,
      box: null,
    })));
    if (!value) {
      setOverlayUrl(null);
      return;
    }
    const targetModel = faceModels.filter(f => f.id === value)?.[0];
    const avatarId = targetModel.id;
    setOverlayUrl(getOverlayImageUrl(avatarId));
  }

  const handleAudioTooltipOpen = (index, id) => {
    setTooltipAudioOpen(id);
  }

  const handleBackgroundTooltipOpen = (index, id) => {
    setTooltipBackgroundOpen(id);
  }

  const beforeDialogOpen = (index, id) => {
    if (!overlayUrl) {
      setTooltipOpen(id);
    }
  }

  const handleDialogOpen = (index, id) => {
    if (!getValues().faceModel) {
      return;
    }
    const item = items.find(item => item.id === id);
    if (item.media && item.type === 'IMAGE') {
      setCurrentId(id);
      if (item.is_meta_human_background) {
        setCropBackgroundUrl(overlayUrl);
        setCropOverlayUrl(getBackgroundUrl(item.media));
      } else {
        setCropBackgroundUrl(getBackgroundUrl(item.media));
        setCropOverlayUrl(overlayUrl);
      }
      setCurrentX(item.coordinate ? item.coordinate[0] : null);
      setCurrentY(item.coordinate ? item.coordinate[1] : null);
      setCurrentCropWidth(item.box ? item.box[0] : null);
      setCurrentCropHeight(item.box ? item.box[1] : null);
      setDialogOpen(true);
    }
  }

  const handleSwitchBackground = (item) => {
    if (!getValues().faceModel) {
      return;
    }
    console.log(item);
    if (item.audio_only) return;
    setCurrentX(null);
    setCurrentY(null);
    setCurrentCropWidth(null);
    setCurrentCropHeight(null);
    const is_meta_human_background =  !item.is_meta_human_background;
    const modelsChange = TTSModelsChange || FaceModelsChange;
    const pip = pipTemplate;
    let subtitleChange = false;
    if (pip) {
      subtitleChange = showSubtitle !== pip.subtitle;
    }
    setItems(prevItems => {
      return prevItems.map(newItem => {
        if (newItem.id != item.id) return newItem;
        const updatedItem = {
          ...newItem,
          box: null,
          coordinate: null,
          is_meta_human_background: is_meta_human_background
        }
        const isNoChange = !modelsChange && !subtitleChange && itemIsChange(updatedItem);
        updatedItem.item_inference_id = isNoChange ? item.originInferenceId : null;
        updatedItem.itemKey = isNoChange ? item.originItemKey : null;
        updatedItem.preview = isNoChange ? item.originPreview : 'HIDDEN';
        return updatedItem;
      })
    })
  }

  const picInPicCropper = () => {
    const data = picInpiCropperRef.current.getSelectedCropBoxData();
    setItems(items.map(item => item.id === currentId ? {
      ...item,
      coordinate: [data.coordinate[0], data.coordinate[1]],
      box: [data.resolution[0], data.resolution[1]],
      item_inference_id: null,
    } : item));
    setCurrentId(-1);
    handleDialogClose();
  }

  const handleDialogClose = () => {
    setDialogOpen(false);
  }

  const resourceFiles = datasets.filter(d => d.fileType !== 'AUDIO').map(dataset => {
    return dataset;
  });

  resourceFiles.push({
    name: 'Add Resource',
  });

  const getFilteredFiles = (fileName, fileType) => {
    return resourceFiles.filter(file => {
      const matchesType = fileType === 'ALL' || file.fileType === fileType;
      const matchesName = file.name.toLowerCase().includes(fileName.toLowerCase());
      return matchesType && matchesName || file.name === 'Add Resource';
    });
  }

  const resetPreview = () => {
    ++latestPreviewRequestId.current;
    if (previewSrc) {
      URL.revokeObjectURL(previewSrc);
    }
    setPreviewSrc(null);
    setPreviewType(null);
  };

  const handleMouseEnter = async (option, event) => {
    const requestId = ++latestPreviewRequestId.current;
    const datasetUrl = `/resources/preview/${option.id}`;
    const rect = event.currentTarget.getBoundingClientRect();
    // Position the preview slightly to the right of the item
    setPreviewPosition({
      top: rect.top + window.scrollY,
      left: rect.right + 32,
    });

    try {
      if (option.fileType === 'VIDEO') {
        const firstFrameUrl = await extractFirstFrame(datasetUrl);
        if (requestId === latestPreviewRequestId.current) {
          setPreviewSrc(firstFrameUrl);
          setPreviewType('VIDEO');
        }
      } else if (option.fileType === 'IMAGE') {
        if (requestId === latestPreviewRequestId.current) {
          setPreviewSrc(datasetUrl);
          setPreviewType('IMAGE');
        }
      } else {
        resetPreview();
      }
    } catch (err) {
      if (requestId === latestPreviewRequestId.current) {
        console.error('Failed to load preview:', err);
        resetPreview();
      }
    }
  };

  const handleMouseLeave = () => {
    resetPreview();
  };

  const previewStyle = {
    position: 'absolute',
    left: previewPosition.left,
    top: previewPosition.top,
    transform: 'translateY(-50%)',
    zIndex: 2000,
    width: '300px',
    height: '200px',
    backgroundColor: 'rgba(97,97,97,0.92)',
    borderRadius: '4px',
    boxShadow: '0 2px 10px rgba(0,0,0,0.15)',
    border: '1px solid #e0e0e0',
    overflow: 'hidden',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    transition: 'opacity 0.3s ease',
  }

  const handleDelete = async (id) => {
    try {
      const status = await deletePicInPicTemplate(id);
      if (status !== 200) {
        Swal.fire({
          title: 'Failed to delete record',
          text: `Error code: ${status}`,
          icon: 'error',
          confirmButtonColor: CONFIRM_BUTTON_COLOR
        });
      } else {
        Swal.fire({
          icon: "success",
          title: "Record deleted",
          showConfirmButton: false,
          timer: 1500
        });
        resetForm();
        fetchPipList();
      }
    } catch (err) {
      console.error(err);
    }    
  };

  const handleRefreshItemConfig = (itemId) => {
    const targetItem = items.find(item => item.id === itemId);
    if (!targetItem) return;
    const restFields = omit(targetItem, ['id', 'media', 'text', 'type', 'item_inference_id', 'itemKey', 'originInferenceId', 'originText', 'originMedia', 'originBox', 'originCoordinate', 'originAudio', 'originBackground', 'preview', 'originItemKey', 'originPreview']);
    let updatedItems = items.map(item => ({
      ...item,
      ...(item.id === itemId || item.type === 'VIDEO' ? {} : restFields),
    }));
    const modelsChange = TTSModelsChange || FaceModelsChange;
    const pip = pipTemplate;
    let subtitleChange = false;
    if (pip) {
      subtitleChange = showSubtitle !== pip.subtitle;
    }
    updatedItems = updatedItems.map(item => {
      const newItem = { ...item };
      const isNoChange = itemIsChange(item) && !modelsChange && !subtitleChange
      newItem.item_inference_id = isNoChange ? item.originInferenceId : null;
      newItem.itemKey = isNoChange ? item.originItemKey : null;
      newItem.preview = isNoChange ? item.originPreview : 'HIDDEN';
      return newItem;
    });
    setItems(updatedItems)
  }
  
  const marginNumbers = Array.from({ length: 20 }, (_, i) => i + 1);

  const fontSizeNumbers = Array.from({ length: 21 }, (_, i) => i + 10);

  const handleSeedChange = (event) => {
    const newValue = event.target.value;
    if (/^$|^(0|[1-9]\d*)$/.test(newValue)) {
      setSeed(newValue === '' ? null : parseInt(newValue, 10));
    }
  };

  const voiceModelChange = (modelId) => {
    const voiceModelValue = voiceModels.find(voiceModel => modelId === voiceModel.id && voiceModel.model === 'COSYVOICE');
    setVoiceModelType(voiceModelValue ? voiceModelValue.model : '');
  };

  const faceModelChange = (modelId) => {
    const faceModelValue = faceModels.find(faceModel => modelId === faceModel.id && faceModel.model === 'ERNERF');
    setFaceModelType(faceModelValue ? faceModelValue.model : '');
  };

  const filteredVoiceModels = useMemo(() => {
    return voiceModels.filter(m => {
      const visible = (m.account_email === currentUserInfo.email || m.type === "PUBLIC");
      if (!visible) return false;
      if (filterVoiceModelType) {
        return m.model === filterVoiceModelType;
      }
      return true;
    });
  }, [voiceModels, currentUserInfo.email, filterVoiceModelType]);

  const voiceModelTypeOptions = useMemo(
      () => [...new Set(voiceModels.map(m => m.model).filter(Boolean))],
      [voiceModels]
  );

  const filteredFaceModels = useMemo(() => {
    return faceModels.filter(m => {
      const visible = (m.account_email === currentUserInfo.email || m.type === "PUBLIC");
      if (!visible) return false;
      if (filterFaceModelType) {
        return m.model === filterFaceModelType;
      }
      return true;
    });
  }, [faceModels, currentUserInfo.email, filterFaceModelType]);

  const faceModelTypeOptions = useMemo(
    () => [...new Set(faceModels.map(m => m.model).filter(Boolean))],
    [faceModels]
  );

  const deviceOptions = useMemo(() => {
    if (voiceModelType === 'COSYVOICE' && faceModelType === 'ERNERF') {
      return ['CUDA', 'XPU'];
    }
    return ['CUDA'];
  }, [voiceModelType, faceModelType]);

  const emotionOptions = [
    { label: 'happy', emoji: '😊' },
    { label: 'sad', emoji: '😢' },
    { label: 'surprised', emoji: '😲' },
    { label: 'angry', emoji: '😠' },
    { label: 'fearful', emoji: '😨' },
    { label: 'disgusted', emoji: '🤢' },
    { label: 'calm', emoji: '😌' },
    { label: 'serious', emoji: '😐' },
  ];

  const modeValue = localStorage.getItem("mode");

  const handleOpenCopyDialog = () => {
    setNewName(selectedItem?.name || '');
    setIsRenameDialogOpen(true);
  };

  const handleRenameDialogClose = () => {
    setIsRenameDialogOpen(false);
  };

  const handleRenameSubmit = async () => {
    try {
      const data = getValues();
      const input = check(data);
      if (!input) return;
      const params = {
        id: data.id,
        name: newName,
        models: {'FACE': data.faceModel, 'TTS': data.voiceModel},
        type: 'PIC_IN_PIC',
        input: input,
        subtitle: showSubtitle,
        hdtr: hdtr,
        backgroundImage: null,
        ttsInstructTaskDto: {
          emotion: emotion,
          speed: speed
        },
        subtitleStyleTaskDto: {
          fontSize: fontSize,
          color: color,
          bold: bold,
          margin_v: marginV,
          extendColor: extendColor,
          extendRatio: extendRatio
        },
        resolution: resolution,
        seed: seed,
        device: device
      };
      const res = await copyPicInPicTemplate(params);
      setIsRenameDialogOpen(false);
      if (res.status == 200) {
        Swal.fire({
          icon: "success",
          title: "Record copy",
          showConfirmButton: false,
          timer: 1500
        });
      } else {
        let failTitle = 'Failed to copy record';
        if (res.status == 400) {
          failTitle = res.response.data;
        }
        Swal.fire({
          title: failTitle,
          text: `Error code: ${res.status}`,
          icon: 'error',
          confirmButtonColor: CONFIRM_BUTTON_COLOR
        });
        return;
      }
      fetchPipList();
      params.id = res.data;
      resetFormByOption(params);
    } catch (err) {
      console.error(err);
    }
  };

  return (
      <>
        <style>
          {`
            @keyframes spin {
              0% { transform: rotate(0deg); }
              100% { transform: rotate(360deg); }
            }
          `}
        </style>
        <form onSubmit={handleSubmit(picInPicSubmit)}>
          <Grid container spacing={2}>
            <Grid item xs={4}>
              <FormControl fullWidth margin="normal" variant="outlined" size="small">
              <Controller
                name="name"
                control={control}
                render={({ field }) => ( // eslint-disable-line no-unused-vars
                  <Autocomplete
                    size="small"
                    freeSolo
                    onChange={(event, item, reason) => {
                      if (reason === "clear") {
                        setSelectedItem(null);
                        resetForm();
                      } else {
                        setSelectedItem(item);
                        resetFormByOption(item);
                      }
                    }}
                    options={pipList}
                    getOptionLabel={(item) => item.name ? item.name : ""}
                    renderOption={(props, option) => (
                      <li {...props}>
                        {option.name}
                        {option.status === 'RUN' && (
                          <span style={{ marginLeft: 8, color: '#888', fontSize: 16 }}>
                            (running)
                          </span>
                        )}
                      </li>
                    )}
                    inputValue={watch('name')}
                    onInputChange={(event, newInputValue) => setValue('name', newInputValue)}
                    filterOptions={(options, { inputValue }) => {
                      if (!options || options.length === 0) {
                        return [];
                      }
                      const filtered = options.filter((option) =>
                        option.name.toLowerCase().includes(inputValue.toLowerCase())
                      );
                      return filtered;
                    }}
                    renderInput={(params) => 
                      <TextField
                        {...params}
                        label="Name"
                        variant="outlined"
                        error={!!errors.name}
                        helperText={errors.name && "Name is required"}
                        InputProps={{
                          ...params.InputProps,
                          endAdornment: (
                            <>
                              {selectedItem && (
                                <>
                                  <InputAdornment position="end" sx={{ mr: 1 }}>
                                    <IconButton 
                                      onClick={handleOpenCopyDialog} 
                                      edge="end"
                                    >
                                      <ContentCopyIcon  />
                                    </IconButton>
                                  </InputAdornment>
                                  <Dialog
                                    open={isRenameDialogOpen}
                                    onClose={handleRenameDialogClose}
                                    closeAfterTransition={false}
                                  >
                                    <DialogTitle>Copy & Rename</DialogTitle>
                                    <DialogContent>
                                      <TextField
                                        label="New Template Name"
                                        sx={{ mt: 2 }}
                                        fullWidth
                                        value={newName}
                                        error={!!errors.newName}
                                        helperText={errors.newName?.message}
                                        onChange={(e) => setNewName(e.target.value)}
                                      />
                                    </DialogContent>
                                    <DialogActions>
                                      <Button onClick={handleRenameDialogClose}>Cancel</Button>
                                      <Button
                                        onClick={handleSubmit(handleRenameSubmit)}
                                        variant="contained"
                                      >
                                        Copy
                                      </Button>
                                    </DialogActions>
                                  </Dialog>
                                </>
                              )} 
                              {(selectedItem && isAllowedWholeSubmit) && (
                                <InputAdornment position="end" sx={{ mr: 1 }}>
                                  <IconButton 
                                    onClick={() => {
                                      Swal.fire({
                                        title: 'Are you sure?',
                                        text: 'Do you want to delete this record?',
                                        showCancelButton: true,
                                        confirmButtonColor: '#d33',
                                        cancelButtonColor: '#3085d6',
                                        confirmButtonText: 'DELETE',
                                        cancelButtonText: 'CANCEL'
                                      }).then((result) => {
                                        if (result.isConfirmed) {
                                          handleDelete(selectedItem.id);         
                                        }
                                      });
                                    }} 
                                    edge="end"
                                  >
                                    <DeleteOutlinedIcon />
                                  </IconButton>
                                </InputAdornment>
                              )} 
                              {params.InputProps.endAdornment}
                            </>
                          ),
                        }}
                      />
                    }
                  />
                )}
              />
              </FormControl>
            </Grid>
            <Grid item xs={4}>
              <Box display="flex" alignItems="center" gap={2} sx={{ mt: 2 }}>
                <FormControl fullWidth margin="normal" size="small" error={!!errors.voiceModel} sx={{ mt: 0 }} >
                  <Controller
                    name="voiceModel"
                    control={control}
                    render={({ field }) => (
                      <Autocomplete
                        size="small"
                        options={filteredVoiceModels}
                        getOptionLabel={(option) => {
                          if (!option) return "";
                          if (option.date) {
                            return `${option.name} (${new Date(option.date).toLocaleString()})`;
                          }
                          return option.name;
                        }}
                        isOptionEqualToValue={(option, value) => option.id === value.id}
                        value={
                          voiceModels.find((m) => m.id === field.value) || null
                        }
                        onChange={(_, newValue) => {
                          const modelId = newValue?.id ?? "";
                          field.onChange(modelId);
                          handleModelChange({ name: "voiceModel", value: modelId });
                          voiceModelChange(modelId);
                        }}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            label="Voice Model"
                            size="small"
                            InputProps={{
                              ...params.InputProps,
                              startAdornment: (
                                <InputAdornment
                                  position="start"
                                  sx={{
                                    position: "absolute",
                                    left: "8px",
                                    top: "50%",
                                    transform: "translateY(-50%)",
                                    zIndex: 1,
                                  }}
                                >
                                  <Select
                                    onChange={(e) => {
                                      const value = e.target.value;
                                      setFilterVoiceModelType(
                                        value === "ALL" ? "" : value
                                      );
                                    }}
                                    value={filterVoiceModelType || "ALL"}
                                    variant="standard"
                                    disableUnderline
                                    sx={{ minWidth: 80, fontSize: "0.85rem" }}
                                  >
                                    <MenuItem value="ALL">ALL</MenuItem>
                                    {voiceModelTypeOptions.map((type) => (
                                      <MenuItem key={type} value={type}>
                                        {type}
                                      </MenuItem>
                                    ))}
                                  </Select>
                                </InputAdornment>
                              ),
                              sx: {
                                "& input": {
                                  marginLeft: "96px",
                                },
                              },
                            }}
                          />
                        )}
                        renderOption={(props, option) => (
                          <MenuItem
                            {...props}
                            key={option.id}
                            value={option.id}
                          >
                            {option.date
                              ? `${option.name} (${new Date(
                                  option.date
                                ).toLocaleString()})`
                              : option.name}
                          </MenuItem>
                        )}
                        fullWidth
                      />
                    )}
                  />
                  {errors.voiceModel && (
                    <FormHelperText error>
                      {errors.voiceModel.message}
                    </FormHelperText>
                  )}
                </FormControl>
              </Box>
            </Grid>
            <Grid item xs={4}>
              <Box display="flex" alignItems="center" gap={2} sx={{ mt: 2 }}>
                <FormControl fullWidth margin="normal" size="small" error={!!errors.faceModel} sx={{ mt: 0 }}>
                  <Controller
                    name="faceModel"
                    control={control}
                    render={({ field }) => (
                      <Autocomplete
                        size="small"
                        options={filteredFaceModels}
                        getOptionLabel={(option) => {
                          if (!option) return "";
                          if (option.date) {
                            return `${option.name} (${new Date(option.date).toLocaleString()})`;
                          }
                          return option.name;
                        }}
                        isOptionEqualToValue={(option, value) => option.id === value.id}
                        value={
                          faceModels.find((m) => m.id === field.value) || null
                        }
                        onChange={(_, newValue) => {
                          const modelId = newValue?.id ?? "";
                          field.onChange(modelId);
                          handleChangeOverlay(modelId);
                          handleModelChange({ name: "faceModel", value: modelId });
                          faceModelChange(modelId);
                        }}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            label="Face Model"
                            size="small"
                            InputProps={{
                              ...params.InputProps,
                              startAdornment: (
                                <InputAdornment
                                  position="start"
                                  sx={{
                                    position: "absolute",
                                    left: "8px",
                                    top: "50%",
                                    transform: "translateY(-50%)",
                                    zIndex: 1,
                                  }}
                                >
                                  <Select
                                    onChange={(e) => {
                                      const value = e.target.value;
                                      setFilterFaceModelType(
                                        value === "ALL" ? "" : value
                                      );
                                    }}
                                    value={filterFaceModelType || "ALL"}
                                    variant="standard"
                                    disableUnderline
                                    sx={{ minWidth: 80, fontSize: "0.85rem" }}
                                  >
                                    <MenuItem value="ALL">ALL</MenuItem>
                                    {faceModelTypeOptions.map((type) => (
                                      <MenuItem key={type} value={type}>
                                        {type}
                                      </MenuItem>
                                    ))}
                                  </Select>
                                </InputAdornment>
                              ),
                              sx: {
                                "& input": {
                                  marginLeft: "96px",
                                },
                              },
                            }}
                          />
                        )}
                        renderOption={(props, option) => (
                          <MenuItem
                            {...props}
                            key={option.id}
                            value={option.id}
                          >
                            {option.date
                              ? `${option.name} (${new Date(
                                  option.date
                                ).toLocaleString()})`
                              : option.name}
                          </MenuItem>
                        )}
                        fullWidth
                      />
                    )}
                  />
                  {errors.faceModel && (
                    <FormHelperText error>
                      {errors.faceModel.message}
                    </FormHelperText>
                  )}
                </FormControl>
              </Box>
            </Grid>
            <Grid item xs={12}>
              <Paper>
                <TabContext value={picType}>
                  <Paper>
                    <TabList onChange={(e, v) => setPicType(v)} aria-label="tabs">
                      <Tab label="pip settings" value="pip_settings" disabled={!isAllowedWholeSubmit} />
                      <Tab label="voice settings" value="voice_settings" disabled={!isAllowedWholeSubmit} />
                      <Tab label="subtitle settings" value="subtitle_settings" disabled={!isAllowedWholeSubmit} />
                      {modeValue === 'advance' && <Tab label="device settings" value="device_settings" disabled={!isAllowedWholeSubmit} />}
                    </TabList>
                  </Paper>
                  <TabPanel value="pip_settings">
                    <Grid item xs={3}>
                      <Autocomplete
                        value={resolution}
                        onChange={(e, newValue) => setResolution(newValue)}
                        options={['4k', '2k', '1080p', '720p']}
                        renderInput={(params) => <TextField {...params} label="Resolution" size="small" />}
                        fullWidth
                        clearOnEscape
                        disableClearable={false}
                        disabled={!isAllowedWholeSubmit}
                      />
                    </Grid>
                  </TabPanel>
                  <TabPanel value="voice_settings">
                    <Grid container spacing={2}>
                      <Grid item xs={3}>
                        <Autocomplete
                          value={emotionOptions.find((item) => item.label === emotion) || null}
                          onChange={(e, newValue) => setEmotion(newValue.label)}
                          options={emotionOptions}
                          getOptionLabel={(option) => option ? `${option.label}` : ''}
                          isOptionEqualToValue={(option, value) => option.label === value}
                          renderOption={(props, option) => (
                            <Box component="li" {...props} sx={{ display: 'flex', alignItems: 'center' }}>
                              <Typography sx={{ fontSize: 20, mr: 1 }}>{option.emoji}</Typography>
                              <Typography variant="body1">{option.label}</Typography>
                            </Box>
                          )}
                          renderInput={(params) => <TextField {...params} label="Emotion" size="small" />}
                          fullWidth
                          clearOnEscape
                          disableClearable={false}
                          disabled={!isAllowedWholeSubmit}
                        />
                      </Grid>
                      <Grid item xs={3}>
                        <Autocomplete
                          value={speed}
                          onChange={(e, newValue) => setSpeed(newValue)}
                          options={['fast', 'very fast', 'slow', 'very slow']}
                          renderInput={(params) => <TextField {...params} label="Speed" size="small" />}
                          fullWidth
                          clearOnEscape
                          disableClearable={false}
                          disabled={!isAllowedWholeSubmit}
                        />
                      </Grid>
                      {modeValue === 'advance' && 
                        <Grid item xs={3}> 
                          <TextField 
                            type="number"
                            size="small" 
                            label="Seed" 
                            variant="outlined" 
                            fullWidth 
                            value={seed} 
                            onChange={(e) => handleSeedChange(e)}
                            inputProps={{ inputMode: 'numeric', pattern: '[0-9]*' }}
                            disabled={!isAllowedWholeSubmit}
                          />
                        </Grid>
                      }
                      {modeValue === 'advance' &&                           
                        <Grid item xs={3}>
                          <Autocomplete
                            value={device}
                            onChange={(e, newValue) => setDevice(newValue)}
                            options={deviceOptions}
                            renderInput={(params) => <TextField {...params} label="Device" size="small" />}
                            fullWidth
                            clearOnEscape
                            disableClearable={false}
                            disabled={!isAllowedWholeSubmit}
                          />
                        </Grid>
                      }
                    </Grid>
                  </TabPanel>
                  <TabPanel value="subtitle_settings">
                    <Grid container spacing={2}>
                      <Grid item xs={3}>
                        <Autocomplete
                          value={fontSize}
                          onChange={(e, newValue) => setFontSize(newValue)}
                          options={fontSizeNumbers}
                          renderInput={(params) => <TextField {...params} label="FontSize" size="small" />}
                          fullWidth
                          clearOnEscape
                          disableClearable={false}
                          disabled={!isAllowedWholeSubmit}
                        />
                      </Grid>
                      <Grid item xs={3}>
                        <Autocomplete
                          value={color}
                          onChange={(e, newValue) => setColor(newValue)}
                          options={['black', 'white', 'red', 'green', 'blue', 'yellow', 'cyan', 'magenta', 'gray']}
                          renderInput={(params) => <TextField {...params} label="Color" size="small" />}
                          renderOption={(props, option) => (
                            <Box component="li" {...props} sx={{ display: 'flex', alignItems: 'center' }}>
                              <Box
                                sx={{
                                  width: 20,
                                  height: 20,
                                  backgroundColor: option,
                                  borderRadius: '50%',
                                  marginRight: 1,
                                  border: '1px solid #ccc',
                                }}
                              />
                              <Typography variant="body1">{option}</Typography>
                            </Box>
                          )}
                          fullWidth
                          clearOnEscape
                          disableClearable={false}
                          disabled={!isAllowedWholeSubmit}
                        />
                      </Grid>
                      <Grid item xs={3}>
                        <Autocomplete
                          value={marginV}
                          onChange={(e, newValue) => setMarginV(newValue)}
                          options={marginNumbers}
                          renderInput={(params) => <TextField {...params} label="Margin" size="small" />}
                          fullWidth
                          clearOnEscape
                          disableClearable={false}
                          disabled={!isAllowedWholeSubmit}
                        />
                      </Grid>
                      <Grid item xs={3}>
                        <Autocomplete
                          value={bold}
                          onChange={(e, newValue) => setBold(newValue)}
                          options={[0, 1]}
                          renderInput={(params) => <TextField {...params} label="Bold" size="small" />}
                          fullWidth
                          clearOnEscape
                          disableClearable={false}
                          disabled={!isAllowedWholeSubmit}
                        />
                      </Grid>
                      <Grid item xs={3}>
                        <Autocomplete
                          value={extendColor}
                          onChange={(e, newValue) => setExtendColor(newValue)}
                          options={['black', 'white', 'red', 'green', 'blue', 'yellow', 'cyan', 'magenta', 'gray']}
                          renderInput={(params) => <TextField {...params} label="extendColor" size="small" />}
                          renderOption={(props, option) => (
                            <Box component="li" {...props} sx={{ display: 'flex', alignItems: 'center' }}>
                              <Box
                                sx={{
                                  width: 20,
                                  height: 20,
                                  backgroundColor: option,
                                  borderRadius: '50%',
                                  marginRight: 1,
                                  border: '1px solid #ccc',
                                }}
                              />
                              <Typography variant="body1">{option}</Typography>
                            </Box>
                          )}
                          fullWidth
                          clearOnEscape
                          disableClearable={false}
                          disabled={!isAllowedWholeSubmit}
                        />
                      </Grid>
                      <Grid item xs={3}>
                        <Autocomplete
                          value={extendRatio}
                          onChange={(e, newValue) => setExtendRatio(newValue)}
                          options={[0, 0.03, 0.06, 0.09, 0.1, 0.12, 0.15, 0.18, 0.2, 0.21, 0.24, 0.27, 0.3]}
                          getOptionLabel={(option) => option.toFixed(2)}
                          renderInput={(params) => <TextField {...params} label="extendRatio" size="small" />}
                          fullWidth
                          clearOnEscape
                          disableClearable={false}
                          disabled={!isAllowedWholeSubmit}
                        />
                      </Grid>
                    </Grid>
                  </TabPanel>
                  <TabPanel value="device_settings">
                    <Grid item xs={3}>
                      <Autocomplete
                        value={device}
                        onChange={(e, newValue) => setDevice(newValue)}
                        options={deviceOptions}
                        renderInput={(params) => <TextField {...params} label="Device" size="small" />}
                        fullWidth
                        clearOnEscape
                        disableClearable={false}
                        disabled={!isAllowedWholeSubmit}
                      />
                    </Grid>
                  </TabPanel>
                </TabContext>
              </Paper>
            </Grid>
          </Grid>

          <Box display="flex" alignItems="center" gap={2}>
            <List sx={{width: '100%', overflow: 'auto', height: '100%'}}>
              {items.map((item, index) => {
                const inputFileName = inputFileNames[index] || "";
                const inputFileType = inputFileTypes[index] || "ALL";
                const options = getFilteredFiles(inputFileName, inputFileType);
                let videoSrc = null;
                if (!item.item_inference_id) {
                  videoSrc = null;
                } else if (item.preview === 'SUCCESS' || item.preview === 'WAIT' || item.preview === 'FAIL') {
                  videoSrc = `/mh/inference-ret/${item.item_inference_id}`
                } else if (item.preview === 'ITEM-SUCCESS' || item.preview === 'ITEM-WAIT'){
                  videoSrc = `/mh/item-inference-ret/${item.itemKey}`
                }
                const isAllowedSubmit = (item.preview !== 'ITEM-WAIT' && item.preview !== 'WAIT');
                return (
                  <ListItem key={item.id} sx={{padding: 0, margin: 0}}>
                    <Box
                      sx={{
                        ml: 0,
                        mr: 0,
                        mb: 1,
                        display: "flex",
                        flexDirection: "row",
                        justifyContent: "space-between",
                        alignItems: "stretch",
                        p: 2,
                        m: 2,
                        border: 1,
                        borderRadius: "4px",
                        borderColor: "#cbcbcb",
                        width: "100%",
                      }}
                    >
                      <Box sx={{ width: "60%", display: "flex", flexDirection: "column", gap: 2 }}>
                        <Box width="100%" display="flex" justifyContent="flex-start">
                          <Box width="40%">
                            <FormControl fullWidth variant='outlined' size='medium' style={{ flex: 1 }}>
                              <Autocomplete
                                options={options}
                                getOptionLabel={(option) => option.name}
                                value={datasets.find(file => file.id === item.media) || null}
                                onClose={() => {
                                  resetPreview();
                                }}
                                disabled={!isAllowedWholeSubmit}
                                onChange={(event, newValue) => {
                                  if (newValue) {
                                    if (newValue.name === 'Add Resource') {
                                      setIsUploadDialogOpen(true);
                                      setSelectedItemIndex(item.id);
                                      item.item_inference_id = null;
                                    } else {
                                      handleMediaChange(item.id, newValue);
                                      resetPreview();
                                    }
                                  } else {
                                    handleMediaChange(item.id, null);
                                  }
                                }}
                                onInputChange={(e, value) => {
                                  setInputFileNames((prev) => ({
                                    ...prev,
                                    [index]: value,
                                  }))
                                }}
                                renderOption={(props, option) => (
                                  <Box
                                    component="li"
                                    {...props}
                                    onMouseEnter={(event) => handleMouseEnter(option, event)}
                                    onMouseLeave={handleMouseLeave}
                                  >
                                    <Typography variant="body2" sx={option.name === 'Add Resource' && { color: '#1565c0' }}>
                                      {option.name}
                                    </Typography>
                                    <Typography variant="caption" sx={{ ml: 1 }} color="text.secondary">
                                      {option.name !== 'Add Resource' ? `(${option.fileType})` : ''}
                                    </Typography>
                                  </Box>
                                )}
                                renderInput={(params) => (
                                  <TextField
                                    {...params}
                                    label="Select PicInPic File"
                                    size="small"
                                    InputProps={{
                                      ...params.InputProps,
                                      startAdornment: (
                                        <InputAdornment position="start"
                                          sx={{
                                            position: 'absolute',
                                            left: '8px',
                                            top: '50%',
                                            transform: 'translateY(-50%)',
                                            zIndex: 1,
                                          }}>
                                          <Select
                                            onChange={(e) => {
                                              const value = e.target.value;
                                              setInputFileTypes((prev) => ({
                                                ...prev,
                                                [index]: value,
                                              }));
                                            }}
                                            defaultValue="ALL"
                                            variant="standard"
                                            disableUnderline
                                            sx={{ minWidth: 64, fontSize: '0.85rem' }}
                                            disabled={!isAllowedWholeSubmit}
                                          >
                                            <MenuItem value="ALL">ALL</MenuItem>
                                            <MenuItem value="VIDEO">VIDEO</MenuItem>
                                            <MenuItem value="IMAGE">IMAGE</MenuItem>
                                          </Select>
                                        </InputAdornment>
                                      ),
                                      sx: {
                                        '& input': {
                                          marginLeft: '72px',
                                        },
                                      },
                                    }}
                                  />
                                )}
                              />
                            </FormControl>
                          </Box>

                          <Box>
                            <IconButton edge="end" onClick={() => handleMoveUp(index, item.id)}>
                              <ArrowDropUpIcon/>
                            </IconButton>
                            <IconButton edge="end" onClick={() => handleMoveDown(index, item.id)}>
                              <ArrowDropDownIcon/>
                            </IconButton>
                            <Tooltip PopperProps={{
                              disablePortal: true,
                            }}
                                    open={tooltipOpen === item.id}
                                    title={
                                      <Box display="flex" justifyContent="center" alignItems="center">
                                        <WarningIcon sx={{ mr: 1 }}></WarningIcon>
                                        <Typography>No Face Model</Typography>
                                      </Box>
                                    }>
                              <IconButton
                                  edge="end"
                                  disabled={!item.media || item.type === 'VIDEO' || item.audio_only || !isAllowedWholeSubmit}
                                  onMouseEnter={() => beforeDialogOpen(index, item.id)}
                                  onMouseLeave={handleToolTipClose}
                                  onClick={() => handleDialogOpen(index, item.id)}
                                  color={item.coordinate && item.box ? "error" : "default"}>
                                <PictureInPictureIcon/>
                              </IconButton>
                            </Tooltip>
                            <Tooltip PopperProps={{
                              disablePortal: true,
                            }}
                            open={tooltipAudioOpen === item.id}
                            title={
                              <Box display="flex" justifyContent="center" alignItems="center">
                                <Typography>{item.audio_only ? 'Sound Only' : 'Sound And Picture'}</Typography>
                              </Box>
                            }>
                              <IconButton
                                  edge="end"
                                  disabled={!item.media || item.type === 'VIDEO' || !isAllowedWholeSubmit}
                                  onMouseEnter={() => handleAudioTooltipOpen(index, item.id)}
                                  onMouseLeave={handleToolTipAudioClose}
                                  onClick={() => {
                                    const modelsChange = TTSModelsChange || FaceModelsChange;
                                    const pip = pipTemplate;
                                    let subtitleChange = false;
                                    if (pip) {
                                      subtitleChange = showSubtitle !== pip.subtitle;
                                    }
                                    setItems(prevItems => {
                                      return prevItems.map(prev => {
                                        if (prev.id != item.id) return prev;
                                        const updatedItem = {
                                          ...item,
                                          audio_only: !item.audio_only
                                        }
                                        const isNoChange = !modelsChange && !subtitleChange && itemIsChange(updatedItem);
                                        return {
                                          ...updatedItem,
                                          item_inference_id: isNoChange ? item.originInferenceId : null,
                                          itemKey: isNoChange ? item.originItemKey : null,
                                          preview: isNoChange ? item.originPreview : 'HIDDEN'
                                        };
                                      });
                                    });
                                  }}
                                  color={item.audio_only ? "error" : "default"}>
                                {item.audio_only ? (<VoiceOverOffIcon />) : (<RecordVoiceOverIcon />)}
                              </IconButton>
                            </Tooltip>
                            <Tooltip PopperProps={{
                              disablePortal: true,
                            }}
                            open={tooltipBackgroundOpen === item.id}
                            title={
                              <Box display="flex" justifyContent="center" alignItems="center">
                                <Typography>{item.is_meta_human_background ? "Meta Human Background" : "Image Background"}</Typography>
                              </Box>
                            }>
                              <IconButton
                                  edge="end"
                                  disabled={!item.media || item.type === 'VIDEO' || item.audio_only || !isAllowedWholeSubmit}
                                  onMouseEnter={() => handleBackgroundTooltipOpen(index, item.id)}
                                  onMouseLeave={handleToolTipBackgroundClose}
                                  onClick={() => handleSwitchBackground(item)}
                                  color={item.is_meta_human_background ? "error" : "default"}>
                                {item.is_meta_human_background ? (<FaceIcon />) : (<InsertPhotoIcon />)}
                              </IconButton>
                            </Tooltip>
                            <IconButton edge="end" onClick={() => handleDeleteItem(item.id)} disabled={!isAllowedWholeSubmit}>
                              <DeleteOutlineIcon/>
                            </IconButton>
                            <IconButton edge="end" onClick={() => handleRefreshItemConfig(item.id)} disabled={item.type === 'VIDEO' || !isAllowedWholeSubmit}>
                              <RefreshIcon/>
                            </IconButton>
                          </Box>
                        </Box>
                        <Box display = "flex" flexDirection = "row" width = "100%" flexWrap = "nowrap">
                          <TextField
                            value={item.text}
                            onChange={e => handleTextChange(item.id, e.target.value)}
                            multiline
                            rows={4}
                            fullWidth
                            placeholder="Enter text here"
                            InputProps={{
                              readOnly: item.type === 'VIDEO',
                              sx: {
                                '& .MuiOutlinedInput-notchedOutline': {
                                  border: 'none'
                                }
                              }
                            }}
                            disabled={!isAllowedWholeSubmit}
                          />
                        </Box>
                        <Box display="flex" justifyContent="flex-end" sx={{ mt: 1, mr: '30px' }}>
                          <Button
                            variant = "contained"
                            size = "small"
                            sx = {{
                              mr : 2,
                            }}
                            color = "success"
                            onClick={() => handleRecover(item.id)}
                            disabled={!isAllowedSubmit}
                          >
                            recover
                          </Button>
                          <Button
                            variant="contained"
                            size="small"
                            disabled={!isAllowedSubmit}
                            onClick={() => handleSubmit(picInPicOneItemSubmit(item))}
                          >
                            Submit
                          </Button>
                        </Box>
                      </Box>
                      <Box sx={{ width: "40%", display: "flex", flexDirection: "column", gap: 2 }}>
                        {videoSrc && (
                          <Card sx={{ width: '100%'}}>
                            <CardContent sx={{ position: 'relative', height: 200, overflow: 'hidden', padding: 0}}>
                              {(item.preview === 'SUCCESS' || item.preview === 'ITEM-SUCCESS') && (
                                <video 
                                  id="video-preview" 
                                  src={videoSrc} 
                                  controls 
                                  controlsList="nodownload"
                                  style={{ width: '100%', height: '100%', objectFit: 'contain', display: 'block', position: 'absolute'}} 
                                  onEnded={(e) => {
                                    e.target.currentTime = 0;
                                  }}
                                >
                                  Your browser does not support the video tag.
                                </video>
                              )}
                              {(item.preview === 'WAIT' || item.preview === 'ITEM-WAIT') && (
                                <Box
                                  sx={{
                                    position: 'absolute',
                                    top: 0,
                                    left: 0,
                                    width: '100%',
                                    height: '100%',
                                    display: 'flex',
                                    justifyContent: 'center',
                                    alignItems: 'center',
                                    bgcolor: 'rgba(0,0,0,0.1)',
                                  }}
                                >
                                  <CircularProgress size={32} thickness={4} />
                                </Box>
                              )}
                              {item.preview === 'FAIL' && (
                                <div style={{
                                  position: 'absolute',
                                  top: 0,
                                  left: 0,
                                  width: '100%',
                                  height: '100%',
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center',
                                  color: '#999',
                                  fontSize: '1rem'
                                }}>
                                  Video generation failed. Please try again later!
                                </div>
                              )}
                            </CardContent>
                          </Card>
                        )}
                      </Box>
                      <Dialog open={dialogOpen} onClose={handleDialogClose} fullWidth maxWidth={'md'}>
                        <DialogTitle>Picture In Picture Cropper</DialogTitle>
                        <DialogContent>
                          <Box display="flex" flexDirection="row" justifyContent="center">
                            <PicInPicCropper
                                ref={picInpiCropperRef}
                                width={600}
                                height={600}
                                image={cropBackgroundUrl}
                                overlay={cropOverlayUrl}
                                x={currentX}
                                y={currentY}
                                cropWidth={currentCropWidth}
                                cropHeight={currentCropHeight}
                            />
                          </Box>
                        </DialogContent>
                        <DialogActions>
                          <Box display="flex" alignItems="center" gap={2} sx={{mt: 2}}>
                            <Button variant="contained" onClick={picInPicCropper}>Confirm</Button>
                            <Button variant="contained" color="error" onClick={handleDialogClose}>Close</Button>
                          </Box>
                        </DialogActions>
                      </Dialog>
                    </Box>
                  </ListItem>
              )})}
            </List>
          </Box>

          {errors.picInPicText && <FormHelperText error>{errors.picInPicText.message}</FormHelperText>}

          <Box display="flex" alignItems="center" gap={2} sx={{mt: 2}}>
            <Button variant="outlined" onClick={handleAddItem} disabled={!isAllowedWholeSubmit}>Add Item</Button>
            <Button variant="outlined" onClick={picInPicSave} disabled={!isAllowedWholeSubmit}>Save</Button>
            <Button variant="contained" type="submit" disabled={!isAllowedWholeSubmit}>Submit</Button>
            <FormControlLabel control={
              <Checkbox checked={showSubtitle}
                        onChange={(e) => handleSubtitleChange(e.target.checked)}
                        disabled={!isAllowedWholeSubmit}
              />} label="Subtitle"/>
            { displayHdtr && <FormControlLabel control={
              <Checkbox checked={hdtr}
                        onChange={(e) => setHdtr(e.target.checked)}
                        disabled={!isAllowedWholeSubmit}
              />} label="HDTR"/> }
          </Box>
          <div>
            {previewSrc && (
                <Box sx={previewStyle}>
                  {(previewType === 'VIDEO' || previewType === 'IMAGE') && (
                      <img
                          src={previewSrc}
                          alt="Preview"
                          style={{
                            maxWidth: '100%',
                            maxHeight: '100%',
                            objectFit: 'contain',
                            padding: '10px'
                          }}
                          onError={(e) => {
                            console.error('Failed to load image:', previewSrc);
                            resetPreview();
                            e.target.style.display = 'none';
                          }}
                      />
                  )}
                </Box>
            )}
          </div>
          <ResourceUploader
            open={isUploadDialogOpen}
            onClose={() => setIsUploadDialogOpen(false)}
            onUploadComplete={async (fileId) => {
              const files = await fetchResources();
              await fetchResourcesGroup();
              setIsUploadDialogOpen(false);
              const newFile = files.find(file => file.id === fileId);
              if (newFile) {
                setItems(items.map(item =>
                  item.id === selectedItemIndex
                    ? { ...item, media: newFile.id, type: newFile.fileType }
                    : item
                ));
              }
            }}
            allowedFileTypes={['video', 'image']}
          />
        </form>

      </>

  );
}

PicInPicInferenceForm.propTypes = {
  faceModels: PropTypes.array.isRequired,
  voiceModels: PropTypes.array.isRequired,
  currentUserInfo: PropTypes.object.isRequired,
  datasets: PropTypes.array.isRequired,
  getInferenceInfo: PropTypes.func.isRequired,
  handleTabTurn: PropTypes.func.isRequired,
  fetchResources: PropTypes.func.isRequired,
  fetchResourcesGroup: PropTypes.func.isRequired,
}