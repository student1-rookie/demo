import { useEffect, useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Table,
  TableBody,
  TextField,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Menu,
  MenuItem,
  IconButton,
  Button,
  TablePagination,
  Checkbox, 
  Typography, 
  Tooltip,
  Toolbar
} from '@mui/material';
import MoreVertIcon from "@mui/icons-material/MoreVert";
import {
  getPicInPicList,
  renamePicInPicTemplate,
  deletePicInPicTemplate,
  deletePicInPicTemplateList
} from '../lib/mh';
import Swal from 'sweetalert2';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import '../index.css';
import { useModels } from "../lib/ModelsContext";
import DeleteIcon from '@mui/icons-material/Delete';
import { alpha } from '@mui/material/styles';

const schema = yup.object().shape({
  newName: yup.string().required('name is required'),
});

const PicInPicTemplateTable = () => {
  const { models } = useModels();
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
  });
  const CONFIRM_BUTTON_COLOR = '#1976d2';
  const [anchorEl, setAnchorEl] = useState(null);
  const [newName, setNewName] = useState("");
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedRow, setSelectedRow] = useState(0);
  const [isRenameDialogOpen, setIsRenameDialogOpen] = useState(false);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [picTemplates, setPicTemplates] = useState([]);
  const [numSelected, setNumSelected] = useState(0);
  const [tableSelected, setTableSelected] = useState([]);
  const [isCallSingle, setIsCallSingle] = useState(true);

  const getPicTemplates = async () => {
    const res = await getPicInPicList();
    setPicTemplates(res);
  };

  useEffect(() => {
    getPicTemplates();
  }, []);

  const handleRenameDialogClose = () => {
    setIsRenameDialogOpen(false);
  };

  const handleRenameSubmit = async () => {
    const selectedFile = picTemplates[selectedRow + page * rowsPerPage];
    setIsRenameDialogOpen(false);
    const res = await renamePicInPicTemplate(selectedFile.id, newName);
    if (res.status !== 204) {
      let title = 'Failed to rename template';
      if (res.status === 400) {
        title = res.response.data;
      }
      Swal.fire({
        title: title,
        text: `Error code: ${res.status}`,
        icon: 'error',
        confirmButtonColor: CONFIRM_BUTTON_COLOR,
        customClass: {
          popup: 'swal-popup-zindex',
          container: 'swal-container-zindex'
        }
      });
    } else {
      Swal.fire({
        icon: "success",
        title: "Template renamed",
        showConfirmButton: false,
        timer: 1500,
        customClass: {
          popup: 'swal-popup-zindex',
          container: 'swal-container-zindex'
        }
      });
    }
    getPicTemplates();
  };

  const handleConfirmDelete = async () => {
    await doDelete();
    setIsDeleteDialogOpen(false);
  };

  const handleCancelDelete = () => {
    setIsDeleteDialogOpen(false);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleDelete = () => {
    setIsDeleteDialogOpen(true);
    handleMenuClose();
  };

  const doDelete = async () => {
    try {
      const selectedFile = picTemplates[selectedRow + page * rowsPerPage];
      let status = 200;
      if (isCallSingle) {
        status = await deletePicInPicTemplate(selectedFile.id);
      } else {
        status = await deletePicInPicTemplateList(tableSelected);
      }
      if (status !== 200) {
        Swal.fire({
          title: 'Failed to delete template',
          text: `Error code: ${status}`,
          icon: 'error',
          confirmButtonColor: CONFIRM_BUTTON_COLOR,
          customClass: {
            popup: 'swal-popup-zindex',
            container: 'swal-container-zindex'
          }
        });
      } else {
        Swal.fire({
          icon: "success",
          title: "Template deleted",
          showConfirmButton: false,
          timer: 1500,
          customClass: {
            popup: 'swal-popup-zindex',
            container: 'swal-container-zindex'
          }
        });
      }
    } catch (e) {
      console.error(e);
    } finally {
      handleMenuClose();
      getPicTemplates();
      setTableSelected([]);
      setNumSelected(0);
    }
  };

  const handleRename = () => {
    setIsRenameDialogOpen(true);
    handleMenuClose();
  };

  const handleMenuOpen = (event, index) => {
    setAnchorEl(event.currentTarget);
    setSelectedRow(index);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  useEffect(() => {
    const selectedFile = picTemplates[selectedRow + page * rowsPerPage];
    if (selectedFile) {
      setNewName(selectedFile.name);
    }
  }, [isRenameDialogOpen]);

  const handleDeleteBatch = () => {
    setIsCallSingle(false);
    setIsDeleteDialogOpen(true);
  };

  const handleSelectAllClick = (event) => {
    if (event.target.checked) {
      const newSelected = picTemplates.map(n => n.id);
      setTableSelected(newSelected);
      setNumSelected(newSelected.length);
    } else {
      setTableSelected([]);
      setNumSelected(0);
    }
  };

  const handleClickCheckbox = (event, id) => {
    event.stopPropagation();
    setTableSelected(prev => {
      const exists = prev.includes(id);
      const next = exists
        ? prev.filter(templateId => templateId !== id)
        : [...prev, id];
      setNumSelected(next.length);
      return next;
    });
  };

  const isSelected = (id) => tableSelected.some(templateId => templateId === id);

  return (
    <>
      {numSelected > 0 && 
        <Toolbar
          sx={[
            {
              pl: { sm: 2 },
              pr: { xs: 1, sm: 1 },
            },
            numSelected > 0 && {
              bgcolor: (theme) =>
                alpha(theme.palette.primary.main, theme.palette.action.activatedOpacity),
            },
          ]}
        >
          <Typography
            sx={{ flex: '1 1 100%' }}
            color="inherit"
            variant="subtitle1"
            component="div"
            >
              {numSelected} selected
          </Typography>
          <Tooltip title="delete">
            <IconButton onClick={handleDeleteBatch}>
              <DeleteIcon />
            </IconButton>
          </Tooltip>
        </Toolbar>
      }
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow sx={{ backgroundColor: '#f5f5f5' }}>
              <TableCell padding="checkbox">
                <Checkbox
                  color="primary"
                  indeterminate={tableSelected.length > 0 && tableSelected.length < picTemplates.length}
                  checked={picTemplates.length > 0 && tableSelected.length === picTemplates.length}
                  onChange={handleSelectAllClick}
                />
              </TableCell>
              {[
                { id: 'name', label: 'Template Name' },
                { id: 'Voice Model', label: 'Voice Model' },
                { id: 'Face Model', label: 'Face Model' },
                { id: 'Item Count', label: 'Item Count' },
              ].map((headCell) => (
                <TableCell
                  key={headCell.id}
                >
                  {headCell.label}
                </TableCell>
              ))}
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {picTemplates.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              .map((item, index) => {
                const isItemSelected = isSelected(item.id);
                return (
                  <TableRow
                    style={{ cursor: 'pointer' }}
                    hover role="checkbox" tabIndex={-1} key={index}
                  >
                    <TableCell padding="checkbox">
                        <Checkbox
                          color="primary"
                          checked={isItemSelected}
                          onClick={(event) => handleClickCheckbox(event, item.id)}
                        />
                      </TableCell>
                    <TableCell>{item.name}</TableCell>
                    <TableCell>
                      {models.find(m => m.id === item.models.TTS)?.name || item.models.TTS}
                    </TableCell>
                    <TableCell>
                      {models.find(m => m.id === item.models.FACE)?.name || item.models.FACE}
                    </TableCell>
                    <TableCell>{item.input.length}</TableCell>
                    <TableCell>
                      <IconButton
                        onClick={(e) => {
                          e.stopPropagation();
                          handleMenuOpen(e, index);
                        }}
                        sx={{ padding: '4px' }}
                      >
                        <MoreVertIcon />
                      </IconButton>
                    </TableCell>
                  </TableRow>
              )})}
          </TableBody>
        </Table>

        <Menu
          anchorEl={anchorEl}
          open={Boolean(anchorEl)}
          onClose={handleMenuClose}
        >
          <MenuItem onClick={handleRename}>Rename Template</MenuItem>
          <MenuItem onClick={handleDelete}>Delete Template</MenuItem>
        </Menu>

        <Dialog open={isRenameDialogOpen} onClose={handleRenameDialogClose} closeAfterTransition={false}>
          <DialogTitle>Rename Template</DialogTitle>
          <DialogContent>
            <TextField
              label="New Template Name"
              sx={{ mt: 2 }}
              fullWidth
              value={newName}
              error={!!errors.newName}
              helperText={errors.newName?.message}
              {...register('newName')}
              onChange={(e) => setNewName(e.target.value)}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={handleRenameDialogClose}>Cancel</Button>
            <Button onClick={handleSubmit(handleRenameSubmit)} variant="contained" color="primary">
              Save
            </Button>
          </DialogActions>
        </Dialog>
        <Dialog open={isDeleteDialogOpen} onClose={handleCancelDelete} closeAfterTransition={false}>
          <DialogTitle>Confirm Deletion</DialogTitle>
          <DialogContent>
            Are you sure you want to delete this template record?
          </DialogContent>
          <DialogActions>
            <Button onClick={handleCancelDelete} variant="contained">Cancel</Button>
            <Button onClick={handleConfirmDelete} variant="outlined" color="error">
              Delete
            </Button>
          </DialogActions>
        </Dialog>
      </TableContainer>

      <TablePagination
        rowsPerPageOptions={[5, 10, 20]}
        component="div"
        count={picTemplates.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
    </>
  );
};

export default PicInPicTemplateTable;
