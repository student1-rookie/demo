import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import {useEffect, useRef, useState} from "react";
import Recorder from 'recorder-js';
import {
  Backdrop,
  Card,
  CardActions,
  CardContent,
  CardHeader,
  CardMedia, CircularProgress,
  IconButton, Stack,
  TextField, Typography
} from "@mui/material";
import MicNoneOutlinedIcon from '@mui/icons-material/MicNoneOutlined';
import MicOffOutlinedIcon from '@mui/icons-material/MicOffOutlined';
import SparkMD5 from "spark-md5";
import Swal from "sweetalert2";
import {postResourceFile} from "../lib/mh.js";
import CircularProgressWithLabel from "./CircularProgressWithLabel.jsx";
import PropTypes from "prop-types";

export default function AudioRecord({ fetchResources, fetchResourcesGroup }) {

  const [audioURL, setAudioURL] = useState('');
  const [audioBlob, setAudioBlob] = useState(null);
  const [audioError, setAudioError] = useState(false);

  const audioContextRef = useRef(null);
  const analyserRef = useRef(null);
  const wavRef = useRef(null);

  const [audioName, setAudioName] = useState("");

  const [audioRecording, setAudioRecording] = useState(false);

  const [isLargeFile, setIsLargeFile] = useState(false);
  const [uploadStatusText, setUploadStatusText] = useState('');
  const [progress, setProgress] = useState(0);

  const recorderRef = useRef(null);
  const streamRef = useRef(null);

  const CONFIRM_BUTTON_COLOR = '#1976d2';

  const [uploading, setUploading] = useState(false);


  const startRecordingAudio = async () => {
    if (!audioRecording) {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });

      audioContextRef.current = new (window.AudioContext || window.webkitAudioContext)();
      const source = audioContextRef.current.createMediaStreamSource(stream);
      analyserRef.current = audioContextRef.current.createAnalyser();
      analyserRef.current.fftSize = 2048;

      source.connect(analyserRef.current);

      const recorder = new Recorder(audioContextRef.current);
      await recorder.init(stream);
      recorderRef.current = recorder;

      await recorder.start();
      setAudioRecording(true);
    }
  }

  const stopRecordingAudio = async () => {
    if (recorderRef.current) {
      const { blob } = await recorderRef.current.stop();
      setAudioBlob(blob);
      setAudioURL(URL.createObjectURL(blob));
    }

    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }

    if (audioContextRef.current) {
      await audioContextRef.current.close();
      audioContextRef.current = null;
    }

    setAudioRecording(false);
  }

  useEffect(() => {
    console.log(audioRecording);
    if (!audioRecording) return;
    const canvas = wavRef.current;
    const canvasCtx = canvas.getContext("2d");

    const draw = () => {
      if (!audioRecording || !analyserRef.current) return;

      requestAnimationFrame(draw);

      const bufferLength = analyserRef.current.fftSize;
      const dataArray = new Uint8Array(bufferLength);
      analyserRef.current.getByteTimeDomainData(dataArray);
      console.log(dataArray);

      canvasCtx.fillStyle = "rgb(245, 245, 245)";
      canvasCtx.fillRect(0, 0, canvas.width, canvas.height);

      canvasCtx.lineWidth = 2;
      canvasCtx.strokeStyle = "rgb(0, 0, 0)";

      canvasCtx.beginPath();

      const sliceWidth = (canvas.width * 1.0) / analyserRef.current.fftSize;
      let x = 0;
      for (let i = 0; i < analyserRef.current.fftSize; ++i) {
        const v = dataArray[i] / 128.0;
        const y = (v * canvas.height) / 2;

        if (i === 0) {
          canvasCtx.moveTo(x, y);
        } else {
          canvasCtx.lineTo(x, y);
        }

        x += sliceWidth;
      }

      canvasCtx.lineTo(canvas.width, canvas.height / 2);
      canvasCtx.stroke();
    };

    draw();
  }, [audioRecording]);

  const audioUpload = async () => {
    if (!audioName || audioName.trim() === '') {
      setAudioError(true);
      return;
    }
    setUploading(true);
    let blobSlice = File.prototype.slice || File.prototype.mozSlice || File.prototype.webkitSlice;
    const chunkSize = 10 * 1024 * 1024; // 10MB
    const chunks = Math.ceil(audioBlob.size / chunkSize);
    let currentChunk = 0;
    let spark = new SparkMD5.ArrayBuffer();
    let fileReader = new FileReader();
    setIsLargeFile(audioBlob.size > 10 * 1024 * 1024); // 50MB
    setUploadStatusText(`Computing MD5 of ${audioName}...`);

    fileReader.onerror = function () {
      console.warn('oops, something went wrong.');
      setUploadStatusText('');
      setProgress(0);
    };

    function loadNext() {
      let start = currentChunk * chunkSize,
        end = ((start + chunkSize) >= audioBlob.size) ? audioBlob.size : start + chunkSize;

      fileReader.readAsArrayBuffer(blobSlice.call(audioBlob, start, end));
    }

    fileReader.onload = async function (e) {
      setProgress((currentChunk + 1) / chunks * 100.0);
      spark.append(e.target.result); // Append array buffer
      currentChunk++;

      if (currentChunk < chunks) {
        loadNext();
      } else {
        console.log('finished loading');
        setProgress(0);
        setUploadStatusText('');
        const hash = spark.end();
        console.info('computed hash', hash);  // Compute hash

        setUploadStatusText(`Uploading ${audioName} ...`);

        const metaInfo = {
          datasetName: audioName,
          date: new Date().toISOString(), // ISO
          type: false,
          identifier: hash,
          fileType: 'AUDIO'
        }

        try {
          const status = await postResourceFile(audioBlob, metaInfo, (progressPercent) => {
            setProgress(progressPercent);
          });
          console.log(status);
          if (status !== 201) { // created
            Swal.fire({
              title: 'Failed to upload file',
              text: `Error code: ${status}`,
              icon: 'error',
              confirmButtonColor: CONFIRM_BUTTON_COLOR
            });
            Swal.fire({
              title: 'upload successfully',
              showConfirmButton: false,
              icon: "success",
              timer: 1500
            });
            fetchResources();
            fetchResourcesGroup();
            URL.revokeObjectURL(audioURL);
            setAudioURL('');
            setAudioName('');
          }
        } catch (e) {
          console.error(e);
        } finally {
          setUploadStatusText('');
          setProgress(0);
          setUploading(false);
        }
      }
    };

    loadNext();
  }

  return (
    <>
      <Box display="flex" flexDirection="column" justifyContent="flex-start" gap={2}>

        <Box display="flex" flexDirection="row" justifyContent="center" gap={2}>
          <Card>
            <CardHeader title="Audio Recording" />
            <CardContent>
              <canvas ref={wavRef} width="480" height="200" />
            </CardContent>
            <CardActions>
              <IconButton onClick={startRecordingAudio}>
                <MicNoneOutlinedIcon />
              </IconButton>
              <IconButton onClick={stopRecordingAudio}>
                <MicOffOutlinedIcon />
              </IconButton>
            </CardActions>
          </Card>
          <Card>
            <CardHeader title="Audio" />
            <CardContent>
              <CardMedia
                component="audio"
                src={audioURL}
                controls
                style={{ width: 480, height: 200 }}
                alt={'audio'} />
            </CardContent>
            <CardActions>
              <TextField
                label="Audio Name"
                sx={{mt: 2}}
                fullWidth
                value={audioName}
                error={audioError}
                helperText={audioError ? 'Name is required' : ''}
                onChange={(e) => {
                  setAudioName(e.target.value);
                  if (e.target.value.trim() !== '') {
                    setAudioError(false);
                  }
                }}
                InputProps={{
                  endAdornment: (
                    <>
                      <Button onClick={audioUpload}>Upload</Button>
                      <Stack sx={{mb: 1}} direction={"row"} spacing={2} >
                        {isLargeFile && <Typography variant="body">{uploadStatusText}</Typography>}
                        {(progress > 0 && isLargeFile) && <CircularProgressWithLabel value={progress}/>}
                      </Stack>
                    </>
                  )
                }}
              />
            </CardActions>
          </Card>
        </Box>
        <Backdrop sx={{ color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1 }} open={uploading}>
          <CircularProgress color="inherit" />
        </Backdrop>
      </Box>
    </>
  );
}

AudioRecord.propTypes = {
  fetchResources: PropTypes.func.isRequired,
  fetchResourcesGroup: PropTypes.func.isRequired
};