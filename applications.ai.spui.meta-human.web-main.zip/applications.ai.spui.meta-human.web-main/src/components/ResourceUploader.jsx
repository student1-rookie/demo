import { useState } from 'react';
import {
  Box,
  Button,
  Select,
  MenuItem,
  Typography,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Stack
} from '@mui/material';
import CircularProgressWithLabel from '../components/CircularProgressWithLabel';
import { useFileUpload } from '../hooks/useFileUpload';
import PropTypes from 'prop-types';

const ResourceUploader = ({ open, onClose, onUploadComplete, allowedFileTypes }) => {
  const [access, setAccess] = useState('PRIVATE');
  const { fileInfoMap, handleFileUpload } = useFileUpload(access, allowedFileTypes);

  return (
    <Dialog open={open} onClose={onClose} PaperProps={{
      sx: {
        borderRadius: 4,
        padding: 2,
        width: '400px',
      },
    }} >
      <DialogTitle sx={{ textAlign: 'center', fontWeight: 'bold', fontSize: '1.25rem' }}>Upload File</DialogTitle>
      <DialogContent>
        <Stack direction="row" spacing={2} sx={{ mt: 2, mb: 2, justifyContent: 'center' }}>
          <Button variant="contained" component="label" size="small" sx={{ fontSize: '0.9rem', padding: '6px 12px', minWidth: '120px' }}>
            Choose File
            <input type="file" hidden multiple
              onChange={(event) =>
                handleFileUpload(event, {
                  onClose,
                  onUploadComplete,
                })
              }
            />
          </Button>
          <Select value={access} onChange={(e) => setAccess(e.target.value)}
            size="small" sx={{ fontSize: '0.9rem', minWidth: '120px' }}>
            <MenuItem value="PUBLIC">PUBLIC</MenuItem>
            <MenuItem value="PRIVATE">PRIVATE</MenuItem>
          </Select>
        </Stack>
        {Object.entries(fileInfoMap).map(([fileName, info]) => (
            <div key={fileName}>
              {info.isLargeFile && (
                  <Box sx={{
                    textAlign: 'center',
                  }}>
                    <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>{info.statusText}</Typography>
                    {info.progress > 0 && info.isLargeFile && <CircularProgressWithLabel value={info.progress} />}
                  </Box>
              )}
            </div>
        ))}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Close</Button>
      </DialogActions>
    </Dialog>
  );
};

ResourceUploader.propTypes = {
  open: PropTypes.bool.isRequired,
  onClose: PropTypes.func.isRequired,
  onUploadComplete: PropTypes.func.isRequired,
  allowedFileTypes: PropTypes.arrayOf(PropTypes.string).isRequired,
};

export default ResourceUploader;
