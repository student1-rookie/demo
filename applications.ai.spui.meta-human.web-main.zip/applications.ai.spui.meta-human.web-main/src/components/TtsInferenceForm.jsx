import FormControl from "@mui/material/FormControl";
import TextField from "@mui/material/TextField";
import Box from "@mui/material/Box";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import { FormHelperText, InputAdornment } from "@mui/material";
import Button from "@mui/material/Button";
import * as yup from "yup";
import { useForm, Controller } from "react-hook-form";
import {yupResolver} from "@hookform/resolvers/yup";
import { postInference, searchRoutingKey} from "../lib/mh.js";
import Swal from "sweetalert2";
import PropTypes from "prop-types";
import Accordion from '@mui/material/Accordion';
import AccordionDetails from '@mui/material/AccordionDetails';
import AccordionSummary from '@mui/material/AccordionSummary';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import Typography from '@mui/material/Typography';
import Grid from "@mui/material/Grid";
import Autocomplete from '@mui/material/Autocomplete';
import { useState, useEffect, useMemo } from "react";

const schema = yup.object().shape({
  name: yup.string().required('Inference name is required'),
  voiceModel: yup.string().required('Voice Model is required'),
  text: yup.string().required('Text is required'),
});

export default function TtsInferenceForm(props) {

  const {voiceModels, currentUserInfo, getInferenceInfo} = props;

  const [picFormExpanded, setPicFormExpanded] = useState(false);
  const [seed, setSeed] = useState('');
  const [model, setModel] = useState('');
  const [routingKeys, setRoutingKeys] = useState([]);
  const [filterModelType, setFilterModelType] = useState('');

  const {
    register,
    handleSubmit,
    control,
    watch,
    formState: {errors},
  } = useForm({
    resolver: yupResolver(schema),
  });

  const targetServiceValue = watch('targetService');
  const deviceValue = watch('device');

  const CONFIRM_BUTTON_COLOR = '#1976d2';

  useEffect(() => {
    async function fetchKeys() {
      const res = await searchRoutingKey('INFERENCE');
      setRoutingKeys(res);
    }
    if (deviceValue === 'XPU') {
      setRoutingKeys([]);
    } else {
      fetchKeys();
    }
  }, [deviceValue]);

  const filteredVoiceModels = useMemo(() => {
    return voiceModels.filter((m) => {
      const visible =
        m.account_email === currentUserInfo.email || m.type === "PUBLIC";
      if (!visible) return false;
      if (filterModelType) {
        return m.model === filterModelType;
      }

      return true;
    });
  }, [voiceModels, currentUserInfo.email, filterModelType]);

  const voiceModelTypeOptions = useMemo(
    () => [...new Set(voiceModels.map(m => m.model).filter(Boolean))],
    [voiceModels]
  );

  const onSubmit = async (data) => {
    const inferenceMeta = {
      name: data.name,
      models: {'TTS': data.voiceModel},
      type: 'TTS_ONLY',
      text: data.text,
      subtitle: false,
      ttsInstructDto: {
        emotion: data.emotion,
        speed: data.speed
      },
      seed: seed,
      routingKey: data.targetService,
      device: data.device
    };

    try {
      await postInference(inferenceMeta)
      Swal.fire({
        icon: "success",
        title: "Inference started",
        showConfirmButton: false,
        timer: 1500
      });
    } catch (e) {
      Swal.fire({
        title: "Inference failed to start",
        icon: "error",
        confirmButtonColor: CONFIRM_BUTTON_COLOR
      });
    } finally {
      await getInferenceInfo();
    }

  };

  const handleSeedChange = (event) => {
    const newValue = event.target.value;
    if (/^$|^(0|[1-9]\d*)$/.test(newValue)) {
      setSeed(newValue === '' ? null : parseInt(newValue, 10));
    }
  };

  const emotionOptions = [
    { label: 'happy', emoji: '😊' },
    { label: 'sad', emoji: '😢' },
    { label: 'surprised', emoji: '😲' },
    { label: 'angry', emoji: '😠' },
    { label: 'fearful', emoji: '😨' },
    { label: 'disgusted', emoji: '🤢' },
    { label: 'calm', emoji: '😌' },
    { label: 'serious', emoji: '😐' },
  ];
  
  const modeValue = localStorage.getItem("mode");

  const deviceOptions = useMemo(() => {
    if (model === 'COSYVOICE' && targetServiceValue == null) {
      return ['CUDA', 'XPU'];
    }
    return ['CUDA'];
  }, [model, targetServiceValue]);

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <FormControl fullWidth margin="normal" variant="outlined" size="small">
        <TextField
          label="Name"
          variant="outlined"
          size="small"
          {...register('name')}
          error={!!errors.name}
          helperText={errors.name?.message}
        />
      </FormControl>

      <Box display="flex" alignItems="center" gap={2} sx={{ mt: 2 }}>
        <FormControl fullWidth margin="normal" size="small" error={!!errors.voiceModel} sx={{ mt: 0 }}>
          <Controller
            name="voiceModel"
            control={control}
            render={({ field }) => (
              <Autocomplete
                size="small"
                options={filteredVoiceModels}
                getOptionLabel={(option) => {
                  if (!option) return "";
                  if (option.date) {
                    return `${option.name} (${new Date(option.date).toLocaleString()})`;
                  }
                  return option.name;
                }}
                isOptionEqualToValue={(option, value) => option.id === value.id}
                value={voiceModels.find((m) => m.id === field.value) || null}
                onChange={(_, newValue) => {
                  const modelId = newValue?.id ?? "";
                  field.onChange(modelId);
                  if (newValue && newValue.model) {
                    setModel(newValue.model);
                  } else {
                    setModel("");
                  }
                }}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Voice Model"
                    size="small"
                    InputProps={{
                      ...params.InputProps,
                      startAdornment: (
                        <InputAdornment
                          position="start"
                          sx={{
                            position: "absolute",
                            left: "8px",
                            top: "50%",
                            transform: "translateY(-50%)",
                            zIndex: 1,
                          }}
                        >
                          <Select
                            onChange={(e) => {
                              const value = e.target.value;
                              setFilterModelType(value === "ALL" ? "" : value);
                            }}
                            value={filterModelType || "ALL"}
                            variant="standard"
                            disableUnderline
                            sx={{ minWidth: 80, fontSize: "0.85rem" }}
                          >
                            <MenuItem value="ALL">ALL</MenuItem>
                            {voiceModelTypeOptions.map((type) => (
                              <MenuItem key={type} value={type}>
                                {type}
                              </MenuItem>
                            ))}
                          </Select>
                        </InputAdornment>
                      ),
                      sx: {
                        "& input": {
                          marginLeft: "96px",
                        },
                      },
                    }}
                  />
                )}
                renderOption={(props, option) => (
                  <MenuItem {...props} key={option.id} value={option.id}>
                    {option.date
                      ? `${option.name} (${new Date(option.date).toLocaleString()})`
                      : option.name}
                  </MenuItem>
                )}
                fullWidth
              />
            )}
          />
          {errors.voiceModel && (
            <FormHelperText error>{errors.voiceModel.message}</FormHelperText>
          )}
        </FormControl>
      </Box>
    
      {(model === 'COSYVOICE' || modeValue === 'advance') && (
        <Box display="flex" alignItems="center" gap={2} sx={{ mt: 2 }}>
          <Accordion expanded={picFormExpanded} onChange={() => setPicFormExpanded(!picFormExpanded)} defaultExpanded sx={{ width: '100%', height: '50%' }}>
            <AccordionSummary expandIcon={<ExpandMoreIcon />} aria-controls="panel1-content" id="panel1-header">
              <Typography component="span">Arguments</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <Box>
                {(model === 'COSYVOICE' || modeValue === 'advance') && <Typography variant="subtitle1" gutterBottom>Voice Settings</Typography>}
                <Grid container spacing={2}>
                  {model === 'COSYVOICE' && (
                    <>
                      <Grid item xs={6}>
                        <Controller
                          name="emotion"
                          control={control}
                          render={({ field }) => (
                            <Autocomplete
                              {...field}
                              onChange={(e, newValue) => field.onChange(newValue.label)}
                              options={emotionOptions}
                              getOptionLabel={(option) => option ? `${option.label}` : ''}
                              isOptionEqualToValue={(option, value) => option.label === value}
                              renderOption={(props, option) => (
                                <Box component="li" {...props} sx={{ display: 'flex', alignItems: 'center' }}>
                                  <Typography sx={{ fontSize: 20, mr: 1 }}>{option.emoji}</Typography>
                                  <Typography variant="body1">{option.label}</Typography>
                                </Box>
                              )}
                              renderInput={(params) => <TextField {...params} label="Emotion" size="small" />}
                              fullWidth
                              clearOnEscape
                              disableClearable={false}
                            />
                          )}
                        />
                      </Grid>
                      <Grid item xs={6}>
                        <Controller
                          name="speed"
                          control={control}
                          render={({ field }) => (
                            <Autocomplete
                              {...field}
                              onChange={(e, newValue) => field.onChange(newValue)}
                              options={['fast', 'very fast', 'slow', 'very slow']}
                              renderInput={(params) => <TextField {...params} label="Speed" size="small" />}
                              fullWidth
                              clearOnEscape
                              disableClearable={false}
                            />
                          )}
                        />
                      </Grid>
                    </>
                  )}
                  {(modeValue === 'advance' && (model === 'BERTVITS' || model === 'GPTSOVITS')) && (
                    <>
                      <Grid item xs={6}>
                        <TextField
                          type="number"
                          size="small"
                          label="Seed"
                          variant="outlined"
                          fullWidth
                          value={seed}
                          onChange={(e) => handleSeedChange(e)}
                          inputProps={{ inputMode: 'numeric', pattern: '[0-9]*' }}
                        />
                      </Grid> 
                    </>
                  )}
                </Grid>
              </Box>
              {modeValue === 'advance' && 
                <Box>
                  <Typography variant="subtitle1" gutterBottom>Target Service</Typography>
                  <Grid container spacing={2}>
                    <Grid item xs={6}>
                        <Controller
                          name="targetService"
                          control={control}
                          render={({ field }) => (
                            <Autocomplete
                              {...field}
                              onChange={(e, newValue) => field.onChange(newValue)}
                              options={routingKeys}
                              renderInput={(params) => <TextField {...params} label="Target Service" size="small" />}
                              fullWidth
                              clearOnEscape
                              disableClearable={false}
                            />
                          )}
                        />
                    </Grid>
                  </Grid>
                </Box>
                }
                {modeValue === 'advance' &&
                  <Box>
                    <Typography variant="subtitle1" gutterBottom>Device</Typography>
                    <Grid container spacing={2}>
                      <Grid item xs={6}>
                        <Controller
                          name="device"
                          control={control}
                          render={({ field }) => (
                            <Autocomplete
                              {...field}
                              onChange={(e, newValue) => field.onChange(newValue)}
                              options={deviceOptions}
                              renderInput={(params) => <TextField {...params} label="Device" size="small" />}
                              fullWidth
                              clearOnEscape
                              disableClearable={false}
                            />
                          )}
                        />
                      </Grid>
                    </Grid>
                  </Box>
                }
            </AccordionDetails>
          </Accordion>
        </Box>
      )}

      <Box display="flex" alignItems="center" gap={2} sx={{mt: 2}}>
        <TextField
          fullWidth
          placeholder="Enter text here"
          multiline
          {...register('text')}
          rows={5}
          sx={{ mt: 2 }}
          error={!!errors.text}
          helperText={errors.text?.message}
        />
      </Box>
      {errors.formInputText && <FormHelperText error>{errors.formInputText.message}</FormHelperText>}
      <Box display="flex" alignItems="center" gap={2} sx={{mt: 2}}>
        <Button variant="contained" type="submit">Submit</Button>
      </Box>
    </form>
  );
}

TtsInferenceForm.propTypes = {
  voiceModels: PropTypes.array.isRequired,
  currentUserInfo: PropTypes.object.isRequired,
  getInferenceInfo: PropTypes.func.isRequired,
}