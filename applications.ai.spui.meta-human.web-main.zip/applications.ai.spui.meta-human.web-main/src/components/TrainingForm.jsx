import Box from "@mui/material/Box";
import { Accordion, AccordionDetails, AccordionSummary, FormControl, FormHelperText, InputLabel, MenuItem, Select,Autocomplete, InputAdornment } from "@mui/material";
import {useForm, FormProvider, Controller} from "react-hook-form";
import TextField from "@mui/material/TextField";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Button from "@mui/material/Button";
import {yupResolver} from "@hookform/resolvers/yup";
import * as yup from "yup";
import Swal from 'sweetalert2';
import {useState, useRef, useEffect} from "react";
import { generatePrompt, searchRoutingKey } from '../lib/mh.js'
import PropTypes from "prop-types";
import Divider from "@mui/material/Divider";
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ArgsInputForm from "./ArgsInputForm.jsx";
import ResourceUploader from "./ResourceUploader.jsx"
import Typography from "@mui/material/Typography";
import { extractFirstFrame } from '../utils/video.js';

export default function TrainingForm(props) {

  const {faceType, ttsType, datasets, refreshDatasets, handleStartTraining, type, fetchResourcesGroup} = props;

  const CONFIRM_BUTTON_COLOR = '#1976d2';

  const voiceParamsMap = {
    "generic": [
      { name: 'voice_model_seed', label: 'seed', component: 'input', values: null, type: 'int' },
    ],
    "bertvits": [
      { name: 'batch_size', label: 'batch_size', component: 'input', values: null, type: 'int' },
      { name: 'epochs', label: 'epochs', component: 'input', values: null, type: 'int' },
      { name: 'learning_rate', label: 'learning_rate', component: 'input', values: null, type: 'float' },
      { name: 'targetService', label: 'Target Service', component: 'select', values: null, type: 'string' },
    ],
    "gptsovits": [
      { name: 's1_batch_size', label: 's1_batch_size', component: 'input', values: null, type: 'int' },
      { name: 's1_epochs', label: 's1_epochs', component: 'input', values: null, type: 'int' },
      { name: 's2_batch_size', label: 's2_batch_size', component: 'input', values: null, type: 'int' },
      { name: 's2_epochs', label: 's2_epochs', component: 'input', values: null, type: 'int' },
      { name: 'targetService', label: 'Target Service', component: 'select', values: null, type: 'string' },
      // TODO: add lr config at meta-human lib
    ],
    "cosyvoice": [
      { name: 'cut_duration', label: 'cut_duration(s)', component: 'input', values: null, type: 'float' },
      { name: 'customized_prompt', label: 'customized_prompt', component: 'input', values: null, type: 'string' },
    ],
    "mossttsd": [
      { name: 'cut_duration', label: 'cut_duration(s)', component: 'input', values: null, type: 'float' },
      { name: 'customized_prompt', label: 'customized_prompt', component: 'input', values: null, type: 'string' },
    ],
    "vibevoice": [],
    "voxcpm": [
      { name: 'cut_duration', label: 'cut_duration(s)', component: 'input', values: null, type: 'float' },
      { name: 'customized_prompt', label: 'customized_prompt', component: 'input', values: null, type: 'string' },
    ],
    "qwentts": [
      { name: 'cut_duration', label: 'cut_duration(s)', component: 'input', values: null, type: 'float' },
      { name: 'customized_prompt', label: 'customized_prompt', component: 'input', values: null, type: 'string' },
    ],
  };

  const faceParamsMap = {
    "generic": [
      { name: 'face_model_seed', label: 'seed', component: 'input', values: null, type: 'int' },
    ],
    "ernerf": [
      { name: 'padding_ratio', label: 'padding_ratio', component: 'input', values: null, type: 'float' },
      { name: 'base_steps', label: 'base_steps', component: 'input', values: null, type: 'int' },
      { name: 'lips_steps', label: 'lips_steps', component: 'input', values: null, type: 'int' },
      { name: 'learning_rate', label: 'learning_rate', component: 'input', values: null, type: 'float' },
      { name: 'learning_rate_net', label: 'learning_rate_net', component: 'input', values: null, type: 'float' },
      { name: 'targetService', label: 'Target Service', component: 'select', values: null, type: 'string' },
      { name: 'device', label: 'device', component: 'select', values: null, type: 'string' },
    ],
    "gaussian": [
      { name: 'padding_ratio', label: 'padding_ratio', component: 'input', values: null, type: 'float' },
      { name: 'diffspeaker_batch_size', label: 'diffspeaker_batch_size', component: 'input', values: null, type: 'int' },
      { name: 'diffspeaker_epochs', label: 'diffspeaker_epochs', component: 'input', values: null, type: 'int' },
      { name: 'gaussian_steps', label: 'gaussian_steps', component: 'input', values: null, type: 'int' },
      { name: 'targetService', label: 'Target Service', component: 'select', values: null, type: 'string' },
      // TODO: add lr config
    ],
    "latentsync": [],
  };

  const getParametersYupSchema = () => {
    let shape = {};
    addSchemaFields(voiceParamsMap, shape);
    addSchemaFields(faceParamsMap, shape);
    return yup.object().shape(shape);
  }

  const addSchemaFields = (paramsMap, shape) => {
      for (let model in paramsMap) {
        paramsMap[model].forEach((item) => {
          switch (item.type) {
              case "string":
                  shape[item.name] = yup.string();
                  break;
              case "int":
                  shape[item.name] = yup.number()
                                    .integer('Must be an integer')
                                    .typeError('Must be a number')
                                    .transform((val,orig) => orig == "" ? undefined : val)
                  break;
              case "float":
                  shape[item.name] = yup.number('Must be a number')
                                    .typeError('Must be a number')
                                    .transform((val,orig) => orig == "" ? undefined : val)
                  break; 
              default:
                  shape[item.name] = yup.mixed();
          }
      });
      }
      return shape;
  };

  let yupSchema = {
    trainingFile: yup.string().required('Training file is required'),
    access: yup.string().oneOf(['PUBLIC', 'PRIVATE'], 'Access mode is required').required('Access mode is required'),
    faceModel: yup.string().when([], {
      is: () => type === 'FACE' || type === 'WHOLE',
      then: () => yup.string().required('Face Model is required'),
      otherwise: () => yup.string(),
    }),
    voiceModel: yup.string().when([], {
      is: () => type === 'TTS' || type === 'WHOLE',
      then: () => yup.string().required('Voice Model is required'),
      otherwise: () => yup.string(),
    }),
    faceName: yup.string().when([], {
      is: () => type === 'FACE' || type === 'WHOLE',
      then: () => yup.string().required('Face Name is required'),
      otherwise: () => yup.string(),
    }),
    voiceName: yup.string().when([], {
      is: () => type === 'TTS' || type === 'WHOLE',
      then: () => yup.string().required('Voice Name is required'),
      otherwise: () => yup.string(),
    }),
    parameters: getParametersYupSchema()
  }

  const schema = yup.object().shape(yupSchema);

  const methods = useForm({
    resolver: yupResolver(schema),
  });

  const {
    control,
    register,
    handleSubmit,
    watch,
    getValues,
    setValue,
    formState: {errors},
  } = methods;

  const device = getValues('parameters.device');
  const targetService = getValues('parameters.targetService');

  const [previewFile, setPreviewFile] = useState(null);
  const [voiceInputFormExpanded, setVoiceInputFormExpanded] = useState(false);
  const [faceInputFormExpanded, setFaceInputFormExpanded] = useState(false);

  const [voiceParametersList, setVoiceParametersList] = useState([]);
  const [faceParametersList, setFaceParametersList] = useState([]);

  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false);

  const voiceParamsRef = useRef(null);
  const faceParamsRef = useRef(null);

  const [inputValue, setInputValue] = useState('');
  const [fileType, setFileType] = useState('ALL');
  const [selectedFile, setSelectedFile] = useState(null);

  const [previewSrc, setPreviewSrc] = useState(null);
  const [previewType, setPreviewType] = useState(null);
  const [previewPosition, setPreviewPosition] = useState({ left: 0, top: 0 });

  const latestPreviewRequestId = useRef(0);

  useEffect(() => {
    async function fetchKeys() {
      const ttsRes = await searchRoutingKey('TTS_TRAIN');
      const faceRes = await searchRoutingKey('FACE_TRAIN');
      voiceParamsMap.bertvits.find(p => p.name === 'targetService').values = ttsRes;
      voiceParamsMap.gptsovits.find(p => p.name === 'targetService').values = ttsRes;
      faceParamsMap.ernerf.find(p => p.name === 'targetService').values = faceRes;
      faceParamsMap.gaussian.find(p => p.name === 'targetService').values = faceRes;
      faceParamsMap.ernerf.find(p => p.name === 'device').values = ['CUDA', 'XPU'];
    }
    fetchKeys();
  }, []);
  
  useEffect(() => {
    const subscription = watch(() => {
      updateVoiceParametersMap();
      updateFaceParametersMap();
    });
    return () => subscription.unsubscribe();
  }, [watch]);

  useEffect(() => {
    setFaceParametersList(prev =>
      prev.map(p => {
        if (p.name === 'targetService') {
          return {
            ...p,
            values: device === 'XPU' ? [] : p.values
          };
        }
        if (p.name === 'device') {
          return {
            ...p,
            values: targetService ? ['CUDA'] : ['CUDA', 'XPU']
          };
        }
        return p;
      })
    );
  }, [device, targetService]);

  const updateVoiceParametersMap = () => {
    const expandlist = [...voiceParamsMap.generic]
    if (getValues().voiceModel) {
      expandlist.push(...voiceParamsMap[getValues().voiceModel.toLowerCase()])
    }
    setVoiceParametersList(expandlist);
  }

  const updateFaceParametersMap = () => {
    const expandlist = [...faceParamsMap.generic]
    if (getValues().faceModel) {
      expandlist.push(...faceParamsMap[getValues().faceModel.toLowerCase()])
    }
    setFaceParametersList(expandlist);
  }

  const handleMenuItemClick = async (file) => {
    file.url = `/resources/preview/${file.id}`;
    setPreviewFile(file);
  }

  const onSubmit = async (data) => {
    console.log('OnSubmit', data);
    data.parameters = JSON.stringify(data.parameters);
    await handleStartTraining(data);
  }

  const generatePromptFromCutDuration = async () => {
    const cutDuration = getValues('parameters.cut_duration');
    const dataset = getValues('trainingFile');
    if (!cutDuration || !dataset) {
      Swal.fire({
        title: 'Please set traning file and cut duration ',
        icon: 'error',
        showConfirmButton: confirm,
        confirmButtonColor: CONFIRM_BUTTON_COLOR,
      });
      return;
    }

    const data = await generatePrompt(dataset, cutDuration);
    if (data.customized_prompt)
      setValue('parameters.cut_duration', data.cut_duration)
      setValue('parameters.customized_prompt', data.customized_prompt);
  };

  const resourceFiles = datasets.filter(dataset => type === 'WHOLE' || type === 'TTS' ||
      (type === 'FACE' && dataset.fileType === 'VIDEO')).map(dataset => {
    return dataset;
  })

  resourceFiles.push({
    name: 'Add Resource File',
  })

  const handleTypeChange = (event) => {
    setFileType(event.target.value);
  };

  const filteredFiles = resourceFiles.filter(file => {
    const matchesType = fileType === 'ALL' || file.fileType === fileType;
    const matchesName = file.name.toLowerCase().includes(inputValue.toLowerCase());
    return matchesType && matchesName || file.name === 'Add Resource File';
  });


  const resetPreview = () => {
    ++latestPreviewRequestId.current;
    if (previewSrc) {
      URL.revokeObjectURL(previewSrc);
    }
    setPreviewSrc(null);
    setPreviewType(null);
  };

  const handleMouseEnter = async (option, event) => {
    const requestId = ++latestPreviewRequestId.current;
    const datasetUrl = `/resources/preview/${option.id}`;
    const rect = event.currentTarget.getBoundingClientRect();
    // Position the preview slightly to the right of the item
    setPreviewPosition({
      top: rect.top + window.scrollY,
      left: rect.right + 32,
    });

    try {
      if (option.fileType === 'VIDEO') {
        const firstFrameUrl = await extractFirstFrame(datasetUrl)
        if (requestId === latestPreviewRequestId.current) {
          setPreviewSrc(firstFrameUrl);
          setPreviewType('VIDEO');
        }
      } else {
        resetPreview();
      }
    } catch (err) {
      if (requestId === latestPreviewRequestId.current) {
        console.error('Failed to load preview:', err);
        resetPreview();
      }
    }};

  const handleMouseLeave = () => {
    resetPreview();
  };

  const previewStyle = {
    position: 'absolute',
    left: previewPosition.left,
    top: previewPosition.top,
    transform: 'translateY(-50%)',
    zIndex: 2000,
    width: '300px',
    height: '200px',
    backgroundColor: 'rgba(97,97,97,0.92)',
    borderRadius: '4px',
    boxShadow: '0 2px 10px rgba(0,0,0,0.15)',
    border: '1px solid #e0e0e0',
    overflow: 'hidden',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    transition: 'opacity 0.3s ease',
  }

  const modeValue = localStorage.getItem("mode");

  return (
      <FormProvider {...methods}>
        <form onSubmit={handleSubmit(onSubmit)}>
          <Box display="flex" alignItems="center" gap={2} sx={{mt: 2}}>
            <FormControl variant="outlined" style={{ flex: 1 }} size="small" error={!!errors.trainingFile}>
              <Controller
                  name="trainingFile"
                  control={control}
                  rules={{ required: true }}
                  render={({ field }) => {
                    const { onChange, ...restField } = field;
                    return (
                        <>
                          <Autocomplete
                              {...restField}
                              options={filteredFiles}
                              getOptionLabel={(option) => option.name}
                              value={selectedFile}
                              onClose={() => {
                                resetPreview();
                              }}
                              onChange={(event, newValue) => {
                                resetPreview();
                                if (newValue) {
                                  if (newValue.name === 'Add Resource File') {
                                    setIsUploadDialogOpen(true);
                                    setSelectedFile(null);
                                  } else {
                                    setSelectedFile(newValue);
                                    onChange(newValue.identifier);
                                    handleMenuItemClick(newValue);
                                  }
                                } else {
                                  setSelectedFile(null);
                                  onChange(null);
                                }
                              }}
                              inputValue={inputValue}
                              onInputChange={(event, newInputValue) => setInputValue(newInputValue)}
                              renderOption={(props, option) => (
                                  <Box
                                      component="li"
                                      {...props}
                                      onMouseEnter={(event) => handleMouseEnter(option, event)}
                                      onMouseLeave={handleMouseLeave}
                                  >
                                    <Typography variant="body2" sx={option.name === 'Add Resource File' && { color: '#1565c0' }}>
                                      {option.name}
                                    </Typography>
                                    <Typography variant="caption" sx={{ ml: 1 }} color="text.secondary">
                                      {option.name !== 'Add Resource File' ? `(${option.fileType})` : ''}
                                    </Typography>
                                  </Box>
                              )}
                              renderInput={(params) => (
                                <TextField
                                    {...params}
                                    label="Select Training File"
                                    size="small"
                                    InputProps={{
                                      ...params.InputProps,
                                      startAdornment: (
                                        <InputAdornment position="start"
                                          sx={{
                                            position: 'absolute',
                                            left: '8px',
                                            top: '50%',
                                            transform: 'translateY(-50%)',
                                            zIndex: 1,
                                          }}>
                                          <Select
                                            value={fileType}
                                            onChange={handleTypeChange}
                                            variant="standard"
                                            disableUnderline
                                            sx={{ minWidth: 64, fontSize: '0.85rem' }}
                                          >
                                            <MenuItem value="ALL">ALL</MenuItem>
                                            <MenuItem value="VIDEO">VIDEO</MenuItem>
                                            {type !== 'FACE' && <MenuItem value="AUDIO">AUDIO</MenuItem>}
                                          </Select>
                                        </InputAdornment>
                                      ),
                                      sx: {
                                        '& input': {
                                          marginLeft: '72px',
                                        },
                                      },
                                    }}
                                />
                            )}
                          />
                        </>
                    );
                  }}
                  
              />
              {errors.trainingFile && <FormHelperText error>{errors.trainingFile.message}</FormHelperText>}
            </FormControl>
            <FormControl variant="outlined" style={{flex: 1}} size="small" error={!!errors.access}>
              <InputLabel id="access-level-label">Select Access</InputLabel>
              <Select {...register('access')} defaultValue="" labelId="access-level-label" label="Access Level">
                <MenuItem value="PUBLIC">PUBLIC</MenuItem>
                <MenuItem value="PRIVATE">PRIVATE</MenuItem>
              </Select>
              {errors.access && <FormHelperText error>{errors.access.message}</FormHelperText>}
            </FormControl>
          </Box>

          {(type === 'TTS' || type === 'WHOLE') && (
            <>
              <Box display="flex" alignItems="center" gap={2} sx={{mt: 2}}>
                <FormControl variant="outlined" style={{flex: 1}} size="small" error={!!errors.voiceModel}>
                  <InputLabel>Voice Model</InputLabel>
                  <Select
                      {...register('voiceModel')}
                      defaultValue=""
                      label="Voice Model">
                    {ttsType.map(type =>
                        <MenuItem value={type} key={type}>{type}</MenuItem>
                    )}
                  </Select>
                  {errors.voiceModel && <FormHelperText error>{errors.voiceModel.message}</FormHelperText>}
                </FormControl>
                <TextField
                    label="Name"
                    variant="outlined"
                    style={{flex: 1}}
                    size="small"
                    {...register('voiceName')}
                    error={!!errors.voiceName}
                    helperText={errors.voiceName?.message}
                />
              </Box>

              { (getValues().voiceModel && modeValue === 'advance') && <Box display="flex" alignItems="center" gap={2} sx={{mt: 2}}>
                 <Accordion expanded={voiceInputFormExpanded} 
                  onChange={() => setVoiceInputFormExpanded(!voiceInputFormExpanded)}
                  defaultExpanded sx={{width: '100%', height: '50%'}}>
                  <AccordionSummary 
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panel1d-content" id="panel1d-header">
                    <Typography>Arguments</Typography>
                  </AccordionSummary>
                  <AccordionDetails>
                    <ArgsInputForm formItems={voiceParametersList} ref={voiceParamsRef}/>
                    { (getValues().voiceModel === 'COSYVOICE' || getValues().voiceModel === 'MOSSTTSD' || getValues().voiceModel === 'VOXCPM') && (
                      <Box mt={2}>
                        <Button
                          variant="outlined"
                          size="small"
                          onClick={() => {
                            generatePromptFromCutDuration();
                          }}
                        >
                          Generate Prompt
                        </Button>
                      </Box>
                    )}
                  </AccordionDetails>
                  <Divider />
                </Accordion>
              </Box>
              }
            </>
          )}

          {(type === 'FACE' || type === 'WHOLE') && (
            <>
              <Box display="flex" alignItems="center" gap={2} sx={{mt: 2}}>

                <FormControl variant="outlined" style={{flex: 1}} size="small" error={!!errors.faceModel}>
                  <InputLabel>Face Model</InputLabel>
                  <Select
                      {...register('faceModel')}
                      defaultValue=""
                      label="Face Model">
                    {faceType.map(type =>
                        <MenuItem value={type} key={type}>{type}</MenuItem>
                    )}
                  </Select>
                  {errors.faceModel && <FormHelperText error>{errors.faceModel.message}</FormHelperText>}
                </FormControl>

                <TextField
                    label="Name"
                    variant="outlined"
                    style={{flex: 1}}
                    size="small"
                    {...register('faceName')}
                    error={!!errors.faceName}
                    helperText={errors.faceName?.message}
                />
              </Box>

              { (getValues().faceModel && modeValue === 'advance') && <Box display="flex" alignItems="center" gap={2} sx={{mt: 2}}>
                <Accordion expanded={faceInputFormExpanded} 
                  onChange={() => setFaceInputFormExpanded(!faceInputFormExpanded)} 
                  defaultExpanded sx={{width: '100%'}}>
                  <AccordionSummary 
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panel1d-content" id="panel1d-header">
                    <Typography>Arguments</Typography>
                  </AccordionSummary>
                  <AccordionDetails>
                    <ArgsInputForm formItems={faceParametersList} ref={faceParamsRef}/>
                  </AccordionDetails>
                  <Divider />
                </Accordion>
              </Box>
              }
            </>
          )}

          <Box style={{width: '100%'}}>
            { previewFile && <Card sx={{marginTop: '10px'}}>
              <CardContent>
                <b>Preview</b>
                {previewFile?.fileType === 'AUDIO' ? (
                    <audio controls src={previewFile.url} style={{width: '100%'}} preload="metadata">
                      Your browser does not support the audio element.
                    </audio>
                ) : previewFile?.fileType === 'VIDEO' ? (
                    <video controls src={previewFile.url} style={{width: '100%'}} preload="metadata">
                      Your browser does not support the video element.
                    </video>
                ) : (
                    <div/>
                )}

              </CardContent>
            </Card>
            }

            <Button variant="outlined" sx={{mt: 2}}>Preprocess</Button>
            <Button type="submit" variant="contained" sx={{mt: 2, ml: 2, flex: 1}}>Start</Button>
          </Box>
          <div>
            {previewSrc && (
                <Box sx={previewStyle}>
                  {previewType === 'VIDEO' && (
                      <img
                          src={previewSrc}
                          alt="Preview"
                          style={{
                            maxWidth: '100%',
                            maxHeight: '100%',
                            objectFit: 'contain',
                            padding: '10px'
                          }}
                          onError={(e) => {
                            console.error('Failed to load image:', previewSrc);
                            resetPreview();
                            e.target.style.display = 'none';
                          }}
                      />
                  )}
                </Box>
            )}
          </div>
        {/* FileUploadDialog */}
        <ResourceUploader
          open={isUploadDialogOpen}
          onClose={() => setIsUploadDialogOpen(false)}
          onUploadComplete={async (fileId) => {
            setFileType('ALL');
            setIsUploadDialogOpen(false);
            const files = await refreshDatasets();
            await fetchResourcesGroup();
            const newFile = files.find(file => file.id === fileId);
            if (newFile) {
              setSelectedFile(newFile);
              handleMenuItemClick(newFile);
            }
          }}
          allowedFileTypes={["audio", "video"]}
        />
        </form>
      </FormProvider>
  )
}

const propVoiceModels = (props, propName) => {
  if ((props.type === 'TTS' || props.type === 'WHOLE') && props[propName] === undefined || props[propName] === null) {
    return new Error(
        `${propName} is required`
    );
  }
  return null;
}

const propFaceModels = (props, propName) => {
  if ((props.type === 'FACE' || props.type === 'WHOLE') && props[propName] === undefined || props[propName] === null) {
    return new Error(
        `${propName} is required`
    );
  }
  return null;
}

TrainingForm.propTypes = {
  faceType: propFaceModels,
  ttsType: propVoiceModels,
  datasets: PropTypes.array.isRequired,
  handleStartTraining: PropTypes.func.isRequired,
  type: PropTypes.oneOf(['WHOLE', 'TTS', 'FACE']).isRequired,
  refreshDatasets: PropTypes.func.isRequired,
  fetchResourcesGroup: PropTypes.func.isRequired
}