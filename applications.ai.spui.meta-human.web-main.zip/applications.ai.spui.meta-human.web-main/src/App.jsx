// App.jsx
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import BasicTabs from './tabs/Tabs';
import LoginPage from './components/LoginPage';
import SignUpPage from './components/SignUpPage';
import { ModelsProvider } from './lib/ModelsContext.jsx';
import { ResourceProvider } from './lib/ResourceContext.jsx';
import { useSseNotifications } from './hooks/useSseNotifications';
import { SnackbarProvider, useSnackbar } from 'notistack';
import { useNotification, NotificationProvider } from './lib/NotificationContext.jsx';

function NotificationSubscriber() {
  const { enqueueSnackbar } = useSnackbar();
  const { publish } = useNotification();

  useSseNotifications((payload) => {
    publish(payload);
    enqueueSnackbar(payload.message, {
      variant: "info",
      autoHideDuration: 3000,
      anchorOrigin: { vertical: 'bottom', horizontal: 'right' },
    });
  });
}


function App() {
  return (
    <SnackbarProvider
      maxSnack={5}
    >
      <NotificationProvider>
        <BrowserRouter>

          <NotificationSubscriber />

          <Routes>
            <Route path="/" element={<LoginPage />} />
            <Route path="/signup" element={<SignUpPage />} />
            <Route
              path="/app"
              element={
                <ModelsProvider>
                  <ResourceProvider>
                    <BasicTabs />
                  </ResourceProvider>
                </ModelsProvider>
              }
            />
          </Routes>

        </BrowserRouter>
      </NotificationProvider>
    </SnackbarProvider>
  );
}

export default App;
