import { useEffect, useRef } from "react";

export function useSseNotifications(onNotify) {
  const esRef = useRef(null);
  const callbackRef = useRef(onNotify);

  useEffect(() => {
    callbackRef.current = onNotify;
  }, [onNotify]);

  useEffect(() => {
    const checkAndStart = () => {
      const loggedIn = localStorage.getItem("loggedIn") === "true";
      if (!loggedIn || esRef.current) return;

      const es = new EventSource("/notify/messages");
      esRef.current = es;

      es.onmessage = (event) => callbackRef.current(JSON.parse(event.data));
      es.onerror = (err) => console.error("[SSE] error", err);
    };

    checkAndStart();

    window.addEventListener("storage", checkAndStart);

    return () => {
      if (esRef.current) esRef.current.close();
      esRef.current = null;
      window.removeEventListener("storage", checkAndStart);
    };
  }, []);
}
