import { useState } from 'react';
import Swal from 'sweetalert2';
import SparkMD5 from 'spark-md5';
import { postResourceFile } from '../lib/mh';
import EventBus from "../lib/EventBus.js";

const CONFIRM_BUTTON_COLOR = '#1976d2';

export const useFileUpload = (access = 'PRIVATE', allowedFileTypes = ['audio', 'video', 'image', 'presentation']) => {
    const [fileInfoMap, setFileInfoMap] = useState({});

    const updateFileInfo = (fileName, updates) => {
        setFileInfoMap(prev => ({
            ...prev,
            [fileName]: {
                ...prev[fileName],
                ...updates,
            }
        }));
    };

    const handleFileUpload = async (event,
        {
            onClose,
            onUploadComplete,
        } = {}) => {
        const files = event.target.files;

        for (let i = 0; i < files.length; i++) {
            const file = files[i];

            if (!allowedFileTypes.some(type => file.type.includes(type))) {
                const formatAllowedFileTypes = (types) => {
                    if (types.length <= 1) return types.join('');
                    if (types.length === 2) return types.join(' and ');
                    return `${types.slice(0, -1).join(', ')}, and ${types[types.length - 1]}`;
                }
                Swal.fire({
                    title: 'Failed to upload file',
                    text: `Only ${formatAllowedFileTypes(allowedFileTypes)} files can be uploaded`,
                    icon: 'error',
                    confirmButtonColor: CONFIRM_BUTTON_COLOR,
                });
                onClose();
                return;
            }

            const isLarge = file.size > 10 * 1024 * 1024 || file.type.includes('presentation');
            updateFileInfo(file.name, {
                progress: 0,
                statusText: `Computing MD5 of ${file.name}...`,
                isLargeFile: isLarge
            });

            let blobSlice = File.prototype.slice || File.prototype.mozSlice || File.prototype.webkitSlice;
            const chunkSize = 10 * 1024 * 1024; // 10MB
            const chunks = Math.ceil(file.size / chunkSize);
            let currentChunk = 0;
            let spark = new SparkMD5.ArrayBuffer();
            let fileReader = new FileReader();

            fileReader.onload = async function (e) {
                updateFileInfo(file.name, {
                    progress: ((currentChunk + 1) / chunks) * 100
                });
                spark.append(e.target.result); // Append array buffer
                currentChunk++;

                if (currentChunk < chunks) {
                    loadNext();
                } else {
                    console.log('finished loading');
                    updateFileInfo(file.name, { progress: 0 });
                    updateFileInfo(file.name, { statusText: '' });
                    const hash = spark.end();
                    console.info('computed hash', hash); // Compute hash
                    updateFileInfo(file.name, { statusText: `Uploading ${file.name} ...` });

                    const metaInfo = {
                        datasetName: file.name,
                        date: new Date().toISOString(), // ISO
                        type: access === 'PUBLIC',
                        identifier: hash,
                        fileType: file.type.includes('audio')
                            ? 'AUDIO'
                            : file.type.includes('video')
                                ? 'VIDEO'
                                : file.type.includes('image')
                                    ? 'IMAGE'
                                    : file.type.includes('presentation')
                                        ? 'PRESENTATION'
                                        : null,
                    };

                    try {
                        const response = await postResourceFile(file, metaInfo, (progressPercent) => {
                             updateFileInfo(file.name, { progress: progressPercent });
                            if (progressPercent === 100 && file.type.includes('presentation')) {
                                updateFileInfo(file.name, { statusText: `Parsing ${file.name} ...` });
                            }
                        });
                        console.log('Upload response:', response);
                        if (response.status !== 201) {
                            let title = 'Failed to upload file';
                            if (response.status === 400 && response.response) {
                                title = response.response.data;
                            }
                            Swal.fire({
                                title: title,
                                text: `Error code: ${response.status}`,
                                icon: 'error',
                                confirmButtonColor: CONFIRM_BUTTON_COLOR,
                            });
                            onClose();
                        } else {
                            Swal.fire({
                                icon: 'success',
                                title: 'File uploaded',
                                showConfirmButton: false,
                                timer: 1500,
                            });
                            onUploadComplete(response.data);
                            if(metaInfo.datasetName.includes('pptx')) {
                                EventBus.emit('pptxUploaded',metaInfo);
                            }
                        }
                    } catch (e) {
                        console.error(e);
                    } finally {
                        updateFileInfo(file.name, { statusText: '', progress: 0 });
                    }
                }
            };

            fileReader.onerror = function () {
                console.warn('oops, something went wrong.');
                updateFileInfo(file.name, { statusText: '', progress: 0 });
            };

            const loadNext = () => {
                let start = currentChunk * chunkSize,
                    end = start + chunkSize >= file.size ? file.size : start + chunkSize;

                fileReader.readAsArrayBuffer(blobSlice.call(file, start, end));
            }

            loadNext();
        }
    };

    return {
        fileInfoMap,
        handleFileUpload,
    };
};
