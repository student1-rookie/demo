import { createSlice } from '@reduxjs/toolkit'

export const userSlice = createSlice({
    name: 'user',
    initialState: {
      username: null,
      email: null,
      isLoggedIn: false,
    },
    reducers: {
        userLogin: (state, action) => {
            state.isLoggedIn = true;
            const { username, email } = action.payload;
            state.username = username;
            state.email = email;
        },
        userLogout: (state) => {
            state.isLoggedIn = false;
            state.username = null;
            state.email = null;
        }
    }
})

export const { userLogin, userLogout, } = userSlice.actions

export default userSlice.reducer