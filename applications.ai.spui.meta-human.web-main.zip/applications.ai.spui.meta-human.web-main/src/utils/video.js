export const extractFirstFrame = (videoUrl) => {
    return new Promise((resolve, reject) => {
      const video = document.createElement('video');
      const canvas = document.createElement('canvas');
      const context = canvas.getContext('2d');

      video.crossOrigin = "anonymous";
      video.src = videoUrl;
      video.currentTime = 0.5;
      video.addEventListener('loadeddata', () => {
        setTimeout(() => {
          canvas.width = video.videoWidth;
          canvas.height = video.videoHeight;
          context.drawImage(video, 0, 0, video.videoWidth, video.videoHeight);
          const imageUrl = canvas.toDataURL('image/jpeg');
          resolve(imageUrl);
        },100)
      });
  
      video.addEventListener('error', (e) => {
        reject(e);
      });
    });
  };