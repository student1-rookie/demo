import MenuItem from '@mui/material/MenuItem';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Button from '@mui/material/Button';
import Grid from '@mui/material/Grid';
import React, { useEffect, useState, useContext } from 'react';
import { getInferences, deleteInferenceFile, getCompleteLogs, getUserInfo, downloadFailInference, deleteInferenceList } from '../lib/mh';
import { useModels } from '../lib/ModelsContext.jsx';
import Swal from 'sweetalert2';
import { IconButton, TablePagination, Paper, TableContainer, Table, TableHead, TableRow, TableCell, TableBody, TableSortLabel, Menu, Dialog, DialogTitle,
  DialogContent, DialogActions, CssBaseline, Checkbox, Typography, Tooltip } from '@mui/material';
import MoreVertIcon from "@mui/icons-material/MoreVert";
import { ResourceContext } from '../lib/ResourceContext.jsx';
import PicInPicInferenceForm from "../components/PicInPicInferenceForm.jsx";
import Drawer from "@mui/material/Drawer";
import Toolbar from "@mui/material/Toolbar";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import AccountBoxIcon from '@mui/icons-material/AccountBox';
import ListIcon from '@mui/icons-material/List';
import ListItemText from "@mui/material/ListItemText";
import Box from "@mui/material/Box";
import PicInPicTemplateTable from "../components/PicInPicTemplateTable.jsx";
import ListAltIcon from '@mui/icons-material/ListAlt';
import DeleteIcon from '@mui/icons-material/Delete';
import { alpha } from '@mui/material/styles';

export default function PicInPicTab() {

  const [videoSrc, setVideoSrc] = useState('');

  const [tab, setTab] = React.useState(0);
  const [selectedTab, setSelectedTab] = React.useState(0);

  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(3);
  const [inferenceData, setInferenceData] = useState([]);
  const [selectedInferenceJobRowId, setSelectedInferenceJobRowId] = useState(null);

  const { models } = useModels();
  const [faceModels, setFaceModels] = useState([]);
  const [voiceModels, setVoiceModels] = useState([]);
  const [orderDirection, setOrderDirection] = useState('desc');
  const [orderBy, setOrderBy] = useState('date');

  const [anchorEl, setAnchorEl] = useState(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);

  const [isLogsDialogOpen, setIsLogsDialogOpen] = useState(false);
  const [logs, setLogs] = useState([]);
  const [currentUserInfo, setCurrentUserInfo] = useState({name: '', email: '', isAdmin: false});
  const [eventSource, setEventSource] = useState(null);

  const { resources, fetchResources, fetchResourcesGroup } = useContext(ResourceContext);
  const [downloadFileName, setDownloadFileName] = useState('');
  const [numSelected, setNumSelected] = useState(0);
  const [tableSelected, setTableSelected] = useState([]);
  const [isCallSingle, setIsCallSingle] = useState(true);

  const drawerWidth = 200;

  const handleRequestSort = (property) => {
    const isAsc = orderBy === property && orderDirection === 'asc';
    setOrderDirection(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };

  useEffect(() => {
    const voice = models.filter(model => model.base_type === 'TTS' && model.status === 'COMPLETE');
    const face = models.filter(model => model.base_type === 'FACE' && model.status === 'COMPLETE');
    setVoiceModels(voice);
    setFaceModels(face);
  }, [models]);

  useEffect(() => {
    const fetchUserInfo = async () => {
      try {
        const userInfo = await getUserInfo();
        console.log("user Info: ", userInfo);
        setCurrentUserInfo(userInfo);
      } catch (error) {
        console.error('Failed to fetch user info', error);
      }
    };

    fetchUserInfo();
  }, []);

  const checkAndPollInferenceStatus = () => {
    const isPollingNeeded = inferenceData.some(row => row.status !== 'COMPLETE' && row.status !== 'FAIL');
    if (isPollingNeeded) {
      const intervalId = setInterval(async () => {
        await getInferenceInfo();
        if (!inferenceData.some(row => row.status !== 'COMPLETE' && row.status !== 'FAIL')) {
          clearInterval(intervalId);
        }
      }, 3000);
      return intervalId;
    }
  };

  useEffect(() => {
    const intervalId = checkAndPollInferenceStatus();
    return () => {
      if (intervalId) {
        clearInterval(intervalId);
      }
    };
  }, [inferenceData]);

  useEffect(() => {
    return () => {
      if (eventSource?.readyState === EventSource.CONNECTING || eventSource?.readyState === EventSource.OPEN) {
        eventSource.close();
      }
    };
  }, []);

  const handleTabTurn = (value) => {
    if (value < 0) {
      setTab(0);
    } else if (value > 1) {
      setTab(1);
    } else {
      setTab(value);
    }
  }

  const sortData = (array) => {
    return array.sort((a, b) => {
      if (orderBy === '') return 0;
      if (a[orderBy] < b[orderBy]) {
        return orderDirection === 'asc' ? -1 : 1;
      }
      if (a[orderBy] > b[orderBy]) {
        return orderDirection === 'asc' ? 1 : -1;
      }
      return 0;
    });
  };

  const handleRowClick = async (row, id) => {
    setDownloadFileName(row.name);
    setSelectedInferenceJobRowId(id);
    if (!row || row.status !== 'COMPLETE') {
      console.log('no inference result');
      setVideoSrc(null);
      return;
    }
    // console.log(res);
    const url = `/mh/inference-ret/${row.id}`;
    setVideoSrc(url);
  };

  const handleDialogClosed = () => {
    setIsLogsDialogOpen(false);
    if (eventSource?.readyState === EventSource.CONNECTING || eventSource?.readyState === EventSource.OPEN) {
      eventSource.close();
    }
  }

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
    if (eventSource?.readyState === EventSource.CONNECTING || eventSource?.readyState === EventSource.OPEN) {
      eventSource.close();
    }
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleMenuOpen = (event, index) => {
    setSelectedInferenceJobRowId(index);
    setAnchorEl(event.currentTarget);
  };

  const handleDelete = () => {
    setIsDeleteDialogOpen(true);
    handleMenuClose();
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleConfirmDelete = async () => {
    await doDelete();
    setIsDeleteDialogOpen(false);
  };

  const handleCancelDelete = () => {
    setIsDeleteDialogOpen(false);
  };

  const handleLogs = async () => {
    handleMenuClose(); // Close the menu
    const selectedRecord = sortedInferenceData[selectedInferenceJobRowId + page * rowsPerPage];

    if (selectedRecord.status === 'COMPLETE' || selectedRecord.status === 'FAIL') {
      const logsData = await getCompleteLogs(selectedRecord.id);
      if (logsData) {
        const formattedLogs = await logsData.text();
        setLogs([formattedLogs]);
      } else {
        setLogs(["Failed to fetch logs."]);
      }
    } else {
      getOngoingLogs(selectedRecord.id);
    }
    setIsLogsDialogOpen(true); // Open the dialog to display logs
  };

  const handleDownloadFailInference= async () => {
    try {
      const selectedRecord = sortedInferenceData[selectedInferenceJobRowId + page * rowsPerPage];
      const res = await downloadFailInference(selectedRecord.id);
      if (!res) {
        Swal.fire({
          title: 'Failed to download this inference',
          text: `Error code: ${res}`,
          icon: 'error',
          confirmButtonColor: CONFIRM_BUTTON_COLOR,
        });
        return null;
      }
      const url = window.URL.createObjectURL(new Blob([res.data], {
        type: 'application/gzip'
      }));
      const link = document.createElement('a');
      link.href = url;
      link.download = `${selectedRecord.name}.zip`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      return null;
    } catch (e) {
      console.error(e);
    } finally {
      handleMenuClose();
    }
  }

  const getOngoingLogs = (id) => {
    setLogs([]);
    let lastEventId = "0-0";

    const newEventSource = new EventSource('/log/ongoing' + `?jobId=${id}&lastEventId=${lastEventId}`);

    let timeoutId = null;

    const resetTimeout = () => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        newEventSource.close();
        console.log('EventSource closed due to inactivity.');
      }, 60000);
    };

    newEventSource.onmessage = (event) => {
      try {
        const dataObj = JSON.parse(event.data);
        if (dataObj.log) {
          setLogs((prevLogs) => [...prevLogs, dataObj.log]);
        }
      } catch (error) {
        console.error("Error parsing event data:", error);
      }
      resetTimeout();
    };

    newEventSource.onerror = (event) => {
      console.error("EventSource failed:", event);
    };

    setEventSource(newEventSource);
    resetTimeout();
  };

  const doDelete = async () => {
    try {
      const selectedRecord = sortedInferenceData[selectedInferenceJobRowId + page * rowsPerPage];
      let status = 200;
      if (isCallSingle) {
        status = await deleteInferenceFile(selectedRecord.id);
      } else {
        status = await deleteInferenceList(tableSelected);
      }
      if (status !== 200) {
        Swal.fire({
          title: 'Failed to delete record',
          text: `Error code: ${status}`,
          icon: 'error',
          confirmButtonColor: CONFIRM_BUTTON_COLOR
        });
      } else {
        Swal.fire({
          icon: "success",
          title: "Record deleted",
          showConfirmButton: false,
          timer: 1500
        });
      }
    } catch (e) {
      console.error(e);
    } finally {
      handleMenuClose();
      await getInferenceInfo();
      setTableSelected([]);
      setNumSelected(0);
    }
  }

  const CONFIRM_BUTTON_COLOR = '#1976d2';

  const getInferenceInfo = async () => {
    try {
      const data = await getInferences();
      if (Array.isArray(data)) {
        setInferenceData(data.filter(d => d.type === 'PIP'));
      }
    } catch (e) {
      console.error('Get inference info failed', e);
    }
  }

  useEffect(() => {
    getInferenceInfo();
  }, []);

  const downloadMedia = () => {
    let a = document.createElement('a');
    const name = downloadFileName + '.mp4';
    const src = videoSrc;
    a.href = src;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(src);
  }

  const sortedInferenceData = sortData([...inferenceData]);

  const handleDeleteBatch = () => {
    setIsCallSingle(false);
    setIsDeleteDialogOpen(true);
  };

  const handleSelectAllClick = (event) => {
    if (event.target.checked) {
      const newSelected = sortedInferenceData.map(n => n.id);
      setTableSelected(newSelected);
      setNumSelected(newSelected.length);
    } else {
      setTableSelected([]);
      setNumSelected(0);
    }
  };

  const handleClickCheckbox = (event, id) => {
    event.stopPropagation();
    setTableSelected(prev => {
      const exists = prev.includes(id);
      const next = exists
        ? prev.filter(itemId => itemId !== id)
        : [...prev, id];
      setNumSelected(next.length);
      return next;
    });
  };

  const isSelected = (id) => tableSelected.some(inferId => inferId === id);

  return (
    <>
      <Box sx={{ display: 'flex' }}>
        <CssBaseline />
        <Drawer
          sx={{
            width: drawerWidth,
            flexShrink: 0,
            '& .MuiDrawer-paper': {
              width: drawerWidth,
              boxSizing: 'border-box',
            },
          }}
          variant="permanent"
          anchor="left"
        >
          <Toolbar />
          <List>
            <ListItem key={'inference'} disablePadding onClick={() => {
              setTab(0);
              setSelectedTab(0);
            }}>
              <ListItemButton selected={selectedTab === 0}>
                <ListItemIcon
                  sx={{
                    minWidth: 0,
                    mr: open ? 3 : 'auto',
                    justifyContent: 'center',
                  }}
                >
                  <AccountBoxIcon />
                </ListItemIcon>
                <ListItemText primary={"Inference"} />
              </ListItemButton>
            </ListItem>
            <ListItem key={'results'} disablePadding onClick={() => {
              setTab(1);
              setSelectedTab(1);
            }}>
              <ListItemButton selected={selectedTab === 1}>
                <ListItemIcon
                  sx={{
                    minWidth: 0,
                    mr: open ? 3 : 'auto',
                    justifyContent: 'center',
                  }}
                >
                  <ListIcon />
                </ListItemIcon>
                <ListItemText primary={"Results"} />
              </ListItemButton>
            </ListItem>
            <ListItem key={'template'} disablePadding onClick={() => {
              setTab(2);
              setSelectedTab(2);
            }}>
              <ListItemButton selected={selectedTab === 2}>
                <ListItemIcon
                  sx={{
                    minWidth: 0,
                    mr: open ? 3 : 'auto',
                    justifyContent: 'center',
                  }}
                >
                  <ListAltIcon />
                </ListItemIcon>
                <ListItemText primary={"Templates"} />
              </ListItemButton>
            </ListItem>
          </List>
        </Drawer>

        {tab === 0 && (
          <Box sx={{width: '80%'}}>
            <b>Picture In Picture Inference</b>
            <PicInPicInferenceForm faceModels={faceModels} voiceModels={voiceModels} currentUserInfo={currentUserInfo}
                                   datasets={resources}
                                   fetchResources={fetchResources}
                                   fetchResourcesGroup={fetchResourcesGroup}
                                   getInferenceInfo={getInferenceInfo}
                                   handleTabTurn={handleTabTurn}/>
          </Box>
        )}

        {tab === 1 && (<Grid container spacing={2}>
          <Grid item xs={4}>

            <b>Inference Preview</b>

            <Card sx={{width: '100%'}}>
              <CardContent>
                {videoSrc &&
                  (
                    <>
                      <video id="video-preview" src={videoSrc} controls controlsList="nodownload"
                             style={{width: '100%'}}>
                        Your browser does not support the video tag.
                      </video>
                      <Button variant="contained" onClick={downloadMedia}>Download Video</Button>
                    </>
                  )
                }
              </CardContent>
            </Card>

          </Grid>

          <Grid item xs={8}>
            <b>My Inference</b>
            {numSelected > 0 && 
              <Toolbar
                sx={[
                  {
                    pl: { sm: 2 },
                    pr: { xs: 1, sm: 1 },
                  },
                  numSelected > 0 && {
                    bgcolor: (theme) =>
                      alpha(theme.palette.primary.main, theme.palette.action.activatedOpacity),
                  },
                ]}
              >
                <Typography
                  sx={{ flex: '1 1 100%' }}
                  color="inherit"
                  variant="subtitle1"
                  component="div"
                  >
                    {numSelected} selected
                </Typography>
                <Tooltip title="delete">
                  <IconButton onClick={handleDeleteBatch}>
                    <DeleteIcon />
                  </IconButton>
                </Tooltip>
              </Toolbar>
            }
            <TableContainer component={Paper}>
              <Table>
                <TableHead>
                  <TableRow sx={{backgroundColor: '#f5f5f5'}}>
                    <TableCell padding="checkbox">
                      <Checkbox
                        color="primary"
                        indeterminate={tableSelected.length > 0 && tableSelected.length < sortedInferenceData.length}
                        checked={sortedInferenceData.length > 0 && tableSelected.length === sortedInferenceData.length}
                        onChange={handleSelectAllClick}
                      />
                    </TableCell>
                    {[
                      {id: 'name', label: 'Inference Name'},
                      {id: 'date', label: 'Submission Time'},
                      {id: 'ttsModelName', label: 'Voice Model'},
                      {id: 'faceModelName', label: 'Face Model'},
                      {id: 'status', label: 'Status'},
                    ].map((headCell) => (
                      <TableCell
                        key={headCell.id}
                        sortDirection={orderBy === headCell.id ? orderDirection : false}
                      >
                        <TableSortLabel
                          active={orderBy === headCell.id}
                          direction={orderBy === headCell.id ? orderDirection : 'asc'}
                          onClick={() => handleRequestSort(headCell.id)}
                        >
                          {headCell.label}
                        </TableSortLabel>
                      </TableCell>
                    ))}
                    <TableCell>Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>

                  {sortedInferenceData.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row, index) => {
                    const isItemSelected = isSelected(row.id);
                    return (
                      <TableRow hover role="checkbox" tabIndex={-1} key={index}
                                onClick={() => handleRowClick(row, index)}
                                style={{
                                  cursor: 'pointer',
                                  backgroundColor: index === selectedInferenceJobRowId ? '#e0e0e0' : 'inherit',
                                }}>
                        <TableCell padding="checkbox">
                          <Checkbox
                            color="primary"
                            checked={isItemSelected}
                            onClick={(event) => handleClickCheckbox(event, row.id)}
                          />
                        </TableCell>
                        <TableCell>{row.name}</TableCell>
                        <TableCell>{new Date(row.date).toLocaleString()}</TableCell>
                        <TableCell>{row.ttsModelName}</TableCell>
                        <TableCell>{row.faceModelName}</TableCell>
                        <TableCell>{row.status}</TableCell>
                        <TableCell>
                          <IconButton
                            onClick={(e) => {
                              e.stopPropagation();
                              handleMenuOpen(e, index);
                            }}
                            sx={{padding: '4px'}}
                          >
                            <MoreVertIcon/>
                          </IconButton>
                        </TableCell>
                      </TableRow>
                  )})}
                </TableBody>
              </Table>

              <Menu
                anchorEl={anchorEl}
                open={Boolean(anchorEl)}
                onClose={handleMenuClose}
              >
                <MenuItem onClick={handleDelete}>Delete</MenuItem>
                <MenuItem onClick={handleLogs}>Logs</MenuItem>
                {currentUserInfo.isAdmin && sortedInferenceData[selectedInferenceJobRowId + page * rowsPerPage].status === 'FAIL' && 
                    <MenuItem onClick={handleDownloadFailInference}>Download</MenuItem>}
              </Menu>

              <Dialog open={isDeleteDialogOpen} onClose={handleCancelDelete} closeAfterTransition={false}>
                <DialogTitle>Confirm Deletion</DialogTitle>
                <DialogContent>
                  Are you sure you want to delete this job?
                </DialogContent>
                <DialogActions>
                  <Button onClick={handleCancelDelete} variant="contained">Cancel</Button>
                  <Button onClick={handleConfirmDelete} variant="outlined" color="error">
                    Delete
                  </Button>
                </DialogActions>
              </Dialog>

              <Dialog open={isLogsDialogOpen}
                      onClose={handleDialogClosed}
                      maxWidth="md"
                      fullWidth
                      PaperProps={{
                        style: {
                          width: '70%',
                          height: '60%',
                          maxWidth: 'none',
                          maxHeight: 'none',
                          display: 'flex',
                          flexDirection: 'column',
                          justifyContent: 'center',
                          alignItems: 'center',
                          overflowY: 'auto',
                        },
                      }}>
                <DialogTitle>Logs</DialogTitle>
                <DialogContent style={{padding: '20px', width: '100%', boxSizing: 'border-box'}}>
                    <pre style={{
                      whiteSpace: 'pre-wrap',
                      wordBreak: 'break-word',
                      textAlign: 'left',
                      width: '100%',
                      margin: '10px 0',
                      overflowX: 'hidden',
                    }}>
                      {logs.join('')}
                    </pre>
                </DialogContent>
                <DialogActions>
                  <Button onClick={handleDialogClosed} variant="contained">Close</Button>
                </DialogActions>
              </Dialog>


            </TableContainer>
            <TablePagination
              rowsPerPageOptions={[3, 5, 10]}
              component="div"
              count={inferenceData.length}
              rowsPerPage={rowsPerPage}
              page={page}
              onPageChange={handleChangePage}
              onRowsPerPageChange={handleChangeRowsPerPage}
            />

          </Grid>
        </Grid>)}

        {tab === 2 && (
          <Box sx={{width: '80%'}}>
            <b>My Template</b>
            <PicInPicTemplateTable />
          </Box>
        )}
      </Box>
    </>
  );
}
