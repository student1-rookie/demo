import { useEffect, useState, useContext } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  MenuItem,
  Modal,
  Box,
  Typography,
  Button,
  Select,
  Stack,
  CircularProgress,
  IconButton
} from '@mui/material';
import {
  getResourceFilesByGroupId
} from '../lib/mh';
import { ResourceContext } from '../lib/ResourceContext.jsx';
import { useFileUpload } from '../hooks/useFileUpload.jsx';
import CircularProgressWithLabel from '../components/CircularProgressWithLabel.jsx';
import ResourcesTable from '../components/ResourcesTable.jsx';
import FullscreenIcon from '@mui/icons-material/Fullscreen';
import FullscreenExitIcon from '@mui/icons-material/FullscreenExit';
import CloseIcon from '@mui/icons-material/Close';

const ResourcesTab = () => {
  const resourcesType = 'GROUP';
  const [previewFile, setPreviewFile] = useState(null);
  const [isPreviewLoading, setIsPreviewLoading] = useState(false);

  // Use ResourceContext to get resources and fetchResources
  const { fetchResources, resourcesGroup, fetchResourcesGroup } = useContext(ResourceContext);
  const [access, setAccess] = useState('PRIVATE');
  const { fileInfoMap, handleFileUpload } = useFileUpload(access);
  const [isResourcesDialogOpen, setIsResourcesDialogOpen] = useState(false);
  const [filesByGroup, setFilesByGroup] = useState([]);
  const [selectGroup, setSelectGroup] = useState({});
  const [resourcesFiles, setResourcesFiles] = useState([]);
  const [isFullscreen, setIsFullscreen] = useState(false);

  useEffect(() => {
    const resources = resourcesGroup.map(item => ({
      ...item,
      fileType: item.fileType === null ? 'GROUP' : item.fileType
    }));
    setResourcesFiles(resources);
  }, [resourcesGroup]);

  const handleRowClick = async (file) => {
    if (file.fileType === resourcesType) {
      const res = await getResourceFilesByGroupId(file.id);
      const filterRes = res.filter(item => item.fileType !== 'PRESENTATION');
      setFilesByGroup(filterRes);
      setIsResourcesDialogOpen(true);
      setSelectGroup(file);
      return;
    }
    try {
      setIsPreviewLoading(true);
      file.url = `/resources/preview/${file.id}`;
      setPreviewFile(file);
    } catch (e) {
      console.error(e);
    } finally {
      setIsPreviewLoading(false);
    }
  };

  const handleClosePreview = () => {
    setPreviewFile(null);
  };

  const handleResourcesDialogClose = () => {
    setIsResourcesDialogOpen(false);
    setIsFullscreen(false);
  }

  const refreshResources = async () => {
    await fetchResources();
    if (isResourcesDialogOpen) {
      const res = await getResourceFilesByGroupId(selectGroup.id);
      const filterRes = res.filter(resource => resource.fileType === 'IMAGE');
      setFilesByGroup([...filterRes]);
      return;
    }
    await fetchResourcesGroup();
  }

  const toggleFullscreen = () => {
    setIsFullscreen(prev => !prev);
  };

  return (
    <>
      <Stack sx={{ mb: 2, alignItems: 'center', }} direction="row" spacing={2}>
        <Button variant="contained" component="label" size="small"
          sx={{ fontSize: '0.9rem', padding: '6px 12px', minWidth: '140px' }}>
          Upload File
          <input
            type="file"
            hidden
            multiple
            onChange={(event) =>
              handleFileUpload(event, {
                onUploadComplete: () => {
                  fetchResources();
                  fetchResourcesGroup();
                }, // Refresh resources after upload
                onClose: () => { },
              })
            }
          />
        </Button>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
          <Select defaultValue="PRIVATE" value={access}
            onChange={(e) => setAccess(e.target.value)}
            size="small" x={{ fontSize: '0.9rem', minWidth: '140px' }}>
            <MenuItem value="PUBLIC">PUBLIC</MenuItem>
            <MenuItem value="PRIVATE">PRIVATE</MenuItem>
          </Select>
          {Object.entries(fileInfoMap).map(([fileName, info]) => (
            <div key={fileName}>
              {info.isLargeFile && (
                <Typography
                  variant="body2"
                  color="text.secondary"
                  sx={{ whiteSpace: 'nowrap', fontSize: '0.85rem' }}
                >
                  {info.statusText}
                </Typography>
              )}

              {info.isLargeFile && info.progress === 100 ? (
                <CircularProgress size={24} />
              ) : (
                info.isLargeFile && info.progress > 0 && (
                  <CircularProgressWithLabel value={info.progress} />
                )
              )}
            </div>
          ))}
        </Box>
      </Stack>

      <ResourcesTable
        files={resourcesFiles}
        handleRowClick={handleRowClick}
        refreshResources={refreshResources}
        operationType="resources"
      />

      <Dialog fullWidth open={isResourcesDialogOpen} onClose={handleResourcesDialogClose} maxWidth="md" fullScreen={isFullscreen} sx={{top: 50, borderRadius: 8, position: 'absolute', m: '10px'}}>
        <DialogTitle
          sx={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center'
          }}
        >
          {selectGroup.name}
          <div>
            <IconButton onClick={toggleFullscreen}>
              {isFullscreen ? <FullscreenExitIcon /> : <FullscreenIcon />}
            </IconButton>
            <IconButton onClick={handleResourcesDialogClose}>
              <CloseIcon />
            </IconButton>
          </div>
        </DialogTitle>
        <DialogContent>
          <ResourcesTable
            files={filesByGroup}
            handleRowClick={handleRowClick}
            refreshResources={refreshResources}
            operationType="resourcesGroup"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleResourcesDialogClose}>Close</Button>
        </DialogActions>
      </Dialog>

      <Modal
        open={isPreviewLoading || !!previewFile}
        onClose={handleClosePreview}
        aria-labelledby="preview-modal-title"
        aria-describedby="preview-modal-description"
      >
        <Box sx={{ ...style, width: '80%', maxWidth: '600px', mx: 'auto' }}>
          <Typography id="preview-modal-title" variant="h6" component="h2">
            Preview: {previewFile?.name}
          </Typography>
          <Box sx={{ mt: 2 }}>
            {previewFile?.fileType === 'AUDIO' ? (
              <audio controls src={previewFile.url} style={{ width: '100%' }} preload="metadata">
                Your browser does not support the audio element.
              </audio>
            ) : previewFile?.fileType === 'VIDEO' ? (
              <video controls src={previewFile.url} style={{ width: '100%' }} preload="metadata">
                Your browser does not support the video element.
              </video>
            ) : previewFile?.fileType === 'IMAGE' ? (
              <>
                <Box sx={{ width: '100%' }}>
                  <img
                    alt="No image Show"
                    src={previewFile.url}
                    style={{ width: '100%', borderRadius: 5, maxHeight: '400px', objectFit: 'contain' }}
                  />
                </Box>
                <Box sx={{ mt: 1, display: 'flex', justifyContent: 'flex-end', width: '100%' }}>
                  <Button
                    variant="contained"
                    onClick={() => {
                      const a = document.createElement('a');
                      a.href = previewFile.url;
                      a.download = previewFile.name;
                      a.click();
                    }}
                  >
                    DOWNLOAD
                  </Button>
                </Box>
              </>
            ) : (
              <CircularProgress />
            )}
          </Box>
        </Box>
      </Modal>
    </>
  );
};

// Style for the modal
const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  bgcolor: 'background.paper',
  boxShadow: 24,
  p: 4,
};

export default ResourcesTab;
