import React, { useEffect, useState, useRef } from 'react';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper,
  TablePagination, IconButton, TextField, Select, Menu, MenuItem, InputLabel, FormControl,
  Button, Grid, Divider, Dialog, DialogTitle, DialogContent, DialogActions, TableSortLabel, Autocomplete, Tooltip, Checkbox, Toolbar, Typography, CircularProgress } from '@mui/material';
import { getAllModels, renameModel, deleteModel, getUserInfo, changeAccess, getCompleteLogs, listUsers, changeOwner, getModelAvatar, getModelAudio, deleteModelList, changeModelAccessList, changeModelOwnerList, downloadFailModel } from '../lib/mh';
import { useModels } from '../lib/ModelsContext.jsx';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import MoreVertIcon from "@mui/icons-material/MoreVert";
import UploadFileIcon from '@mui/icons-material/UploadFile';
import Swal from 'sweetalert2';
import FilterAltIcon from "@mui/icons-material/FilterAlt";
import {downloadedModel ,uploadModel} from '../lib/mh.js'
import DeleteIcon from '@mui/icons-material/Delete';
import ManageAccountsIcon from '@mui/icons-material/ManageAccounts';
import CompareArrowsIcon from '@mui/icons-material/CompareArrows';
import { alpha } from '@mui/material/styles';
import { LoadingButton } from '@mui/lab';
import DownloadIcon from '@mui/icons-material/Download';

const ModelsTab = () => {
  const schema = yup.object().shape({
    newName: yup.string().required('name is required'),
  });
  const { models, updateModels } = useModels();
  const CONFIRM_BUTTON_COLOR = '#1976d2';
  const [filter, setFilter] = useState([]);
  const [filterAnchorEl, setFilterAnchorEl] = useState(null);
  const [filterK, setFilterK] = useState(null);
  const [filterV, setFilterV] = useState(null);
  const {register, handleSubmit, formState: { errors }} = useForm({ resolver: yupResolver(schema) });
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [orderDirection, setOrderDirection] = useState('desc');
  const [orderBy, setOrderBy] = useState('date');
  const [currentUserInfo, setCurrentUserInfo] = useState({name: '', email: '', isAdmin: false});

  const [anchorEl, setAnchorEl] = useState(null);

  const [selectedRow, setSelectedRow] = useState(0);

  const [isRenameDialogOpen, setIsRenameDialogOpen] = useState(false);
  const [newName, setNewName] = useState("");

  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);

  const [isChangeAccessDialogOpen, setIsChangeAccessDialogOpen] = useState(false);
  const [newAccess, setNewAccess] = useState('');

  const [isChangeOwnerDialogOpen, setIsChangeOwnerDialogOpen] = useState(false);
  const [users, setUsers] = useState([]);
  const [newOwner, setNewOwner] = useState(null);

  const [modelName, setModelName] = useState('');
  const [modelFile, setModelFile] = useState(null);

  const [isLogsDialogOpen, setIsLogsDialogOpen] = useState(false);
  const [logs, setLogs] = useState([]);
  const [validLogs, setValidLogs] = useState(false);

  const [avatar, setAvatar] = useState({id: null, url: null});
  const [tableData, setTableData] = useState([]);
  const audioRefs = useRef({});

  const [subType, setSubType] = useState('');
  const subTypeOptions = ['BERTVITS', 'GPTSOVITS', 'ERNERF'];

  const[access, setAccess] = useState('');
  const accessOptions = ['PUBLIC', 'PRIVATE'];

  const [tableSelected, setTableSelected] = useState([]);
  const [numSelected, setNumSelected] = useState(0);
  const [isCallSingle, setIsCallSingle] = useState(true);

  const [uploading, setUploading] = useState(false);

  const [downloadingIds, setDownloadingIds] = useState([]);

  const handleOpenFilter = (event, id) => {
    setFilterV(null);
    setFilter([...new Set(sortedData.map(item => item[id]))]);
    setFilterAnchorEl(event.currentTarget);
    setFilterK(id);
  }

  const handleFilterClose = () => {
    setFilterAnchorEl(null);
  }

  const handleFilterTable = (value) => {
    setFilterV(value);
  }

  const handleModelAvatar = async (index, row) => {
    if (avatar.url && avatar.id !== row.id) {
      URL.revokeObjectURL(avatar.url);
      setAvatar({id: null, url: null});
    } else if (avatar.id === row.id) {
      audioPlay(index, row);
      return;
    }
    let res;
    if (row.status === 'COMPLETE') {
      if (row.base_type === 'TTS') {
        res = await getModelAudio(row.id);
      } else {
        res = await getModelAvatar(row.id);
      }
    }
    if (res) {
      const url = URL.createObjectURL(res);
      setAvatar({id: row.id, url: url});
      setTimeout(() => {
        audioPlay(index, row);
      }, 100);
    }
  }

  const audioPlay = (index, row) => {
    const audio = audioRefs.current[index];
    if (row.base_type === 'TTS' && audio) {
      audio.play().catch(err => console.warn('Autoplay blocked:', err));
    }
  }

  const handleRequestSort = (property) => {
    const isAsc = orderBy === property && orderDirection === 'asc';
    setOrderDirection(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };

  const sortData = (array) => {
    return array
      .sort((a, b) => {
        if (orderBy === '') return 0;
        if (a[orderBy] < b[orderBy]) {
          return orderDirection === 'asc' ? -1 : 1;
        }
        if (a[orderBy] > b[orderBy]) {
          return orderDirection === 'asc' ? 1 : -1;
        }
        return 0;
      })
      .filter(record => record.status === 'COMPLETE' || record.status === 'FAIL');
  };

  useEffect(() => {
    const fetchUserInfo = async () => {
      try {
        const userInfo = await getUserInfo();
        console.log("user Info: ", userInfo);
        setCurrentUserInfo(userInfo);
      } catch (error) {
        console.error('Failed to fetch user info', error);
      }
    };

    fetchUserInfo();
  }, []);

  const handleLogs = async () => {
    handleMenuClose(); // Close the menu
    const selectedRecord = tableData[selectedRow + page * rowsPerPage];
    const logsBlob = await getCompleteLogs(selectedRecord.id);
    if (logsBlob) {
      const logsText = await logsBlob.text();
      setLogs([logsText]);
      setValidLogs(true);
    } else {
      setLogs(["Failed to fetch logs."]);
      setValidLogs(false);
    }
    setIsLogsDialogOpen(true);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleFileChange = (event) => {
    setModelFile(event.target.files[0]);
  };

  const handleUploadSubmit = async (event) => {
    event.preventDefault();
    if (modelName && modelFile && subType && access) {
      const fileName = modelFile.name;
      const isValidExtension = /\.(tar\.gz|tgz)$/i.test(fileName);
      if(!isValidExtension) {
        Swal.fire({
            title: 'Invalid File Type',
            text: 'Please upload a file with .tar.gz or .tgz extension.',
            icon: 'error',
            confirmButtonColor: CONFIRM_BUTTON_COLOR
        });
        return;
      }
      const newModel = {
        id: sortedData.length + 1,
        name: modelName,
        created: new Date().toISOString(),
        access: access, // Assuming new models are private by default
        owner: currentUserInfo.name, // Replace with actual user data
      };
      newModel.subType = subType;
      const formData = new FormData();
      const modelInfoBlob = new Blob([JSON.stringify(newModel)], { type: 'application/json' });
      formData.append("modelInfo", modelInfoBlob);
      formData.append("model", modelFile);
      setUploading(true);
      const res = await uploadModel(formData);
      if (res.status !== 200) {
        Swal.fire({
            title: 'Upload Failed!',
            text: res.data,
            icon: 'error',
            confirmButtonColor: CONFIRM_BUTTON_COLOR
        });
      }
      setUploading(false);
      setModelName('');
      setModelFile(null);
      setSubType('');
      setAccess('')
      document.getElementById('model-file-input').value = null;
    } else {
      Swal.fire({
        title: 'Please fill in all fields and select a file.',
        icon: 'error',
        confirmButtonColor: CONFIRM_BUTTON_COLOR
      })
    }
    await refreshData();
  };

  const refreshData = async () => {
    const data = await getAllModels();
    if (Array.isArray(data)) {
      console.log(data);
      updateModels(data);
    }
  }

  useEffect(() => {
    refreshData();
  }, []);

  const handleMenuOpen = (event, index) => {
    setAnchorEl(event.currentTarget);
    setSelectedRow(index);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleDownload = async () =>{
    handleMenuClose();
    const selectedFile = tableData[selectedRow + page * rowsPerPage]
    const baseType = selectedFile.base_type;
    const id = selectedFile.id;
    const type = selectedFile.type;
    const modelName = selectedFile.name
    const status = selectedFile.status;
    if (downloadingIds.includes(id)) return;
    setDownloadingIds(prev => [...prev, id]);
    if (status === 'FAIL') {
      await handleDownloadFailModel(modelName, id, baseType);
      return null;
    }
    try {
      const res = await downloadedModel(id, type, baseType, modelName);
      console.log(res);
      if(!res) {
        Swal.fire({
          title: 'the file does not exist!',
          icon: 'error',
          confirmButtonColor: CONFIRM_BUTTON_COLOR
        });
        return null;
      }
      const url = window.URL.createObjectURL(new Blob([res.data], {
        type: 'application/gzip'
      }));
      const link = document.createElement('a');
      link.href = url;
      link.download = `${modelName}.tar.gz`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      return null;
    } catch (err) {
      Swal.fire({
          title: 'Failed to get this model!',
          icon: 'error',
          confirmButtonColor: CONFIRM_BUTTON_COLOR
        });
    } finally {
      setDownloadingIds(prev => prev.filter(downloadId => downloadId !== id));
      handleMenuClose();
    }
  }

  const handleDownloadFailModel = async (modelName, id, baseType) => {
    try {
      const res = await downloadFailModel(id, baseType);
      if (!res) {
        Swal.fire({
          title: 'the file does not exist!',
          icon: 'error',
          confirmButtonColor: CONFIRM_BUTTON_COLOR
        });
        return null;
      }
      const url = window.URL.createObjectURL(new Blob([res.data], {
        type: 'application/gzip'
      }));
      const link = document.createElement('a');
      link.href = url;
      link.download = `${modelName}.zip`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      return null;
    } catch (err) {
      console.log(err);
      return null;
    } finally {
      setDownloadingIds(prev => prev.filter(downloadId => downloadId !== id));
      handleMenuClose();
    }
  }

  const handleDelete = () => {
    setIsDeleteDialogOpen(true);
    setIsCallSingle(true);
    handleMenuClose();
  };

  const handleDeleteBatch = () => {
    setIsCallSingle(false);
    setIsDeleteDialogOpen(true);
  };

  const doDelete = async () => {
    const selectedFile = tableData[selectedRow + page * rowsPerPage];
    let status = 200;
    if (isCallSingle) {
      status = await deleteModel(selectedFile.id, selectedFile.base_type);
    } else {
      const param = genBatchParam();
      status = await deleteModelList(param);
    }
    console.log(status);
    if (status !== 200) {
      Swal.fire({
        title: 'Failed to delete file',
        text: `Error code: ${status}`,
        icon: 'error',
        confirmButtonColor: CONFIRM_BUTTON_COLOR
      });
    } else {
      Swal.fire({
        icon: "success",
        title: "File deleted",
        showConfirmButton: false,
        timer: 1500
      });
    }
    handleMenuClose();
    await refreshData();
    setTableSelected([]);
    setNumSelected(0);
  };

  const handleRename = () => {
    setIsRenameDialogOpen(true);
    handleMenuClose();
  };

  useEffect(() => {
    const selectedFile = tableData[selectedRow + page * rowsPerPage];
    if (selectedFile) {
      setNewName(selectedFile.name);
    }
  }, [isRenameDialogOpen])

  const handleRenameDialogClose = () => {
    setIsRenameDialogOpen(false);
  };

  const handleRenameSubmit = async () => {
    const selectedFile = tableData[selectedRow + page * rowsPerPage]
    const oldName = selectedFile.name;
    console.log('renaming: ' + oldName + ' to ' + newName);
    setIsRenameDialogOpen(false);
    const status = await renameModel(selectedFile.id, newName, selectedFile.base_type);
    console.log(status);
    if (status !== 204) { // No content
      Swal.fire({
        title: 'Failed to rename file',
        text: `Error code: ${status}`,
        icon: 'error',
        confirmButtonColor: CONFIRM_BUTTON_COLOR
      });
    } else {
      Swal.fire({
        icon: "success",
        title: "File renamed",
        showConfirmButton: false,
        timer: 1500
      });
    }
    await refreshData();
  };

  const handleConfirmDelete = async () => {
    await doDelete();
    setIsDeleteDialogOpen(false);
  };

  const handleCancelDelete = () => {
    setIsDeleteDialogOpen(false);
  };

  const handleChangeAccess = () => {
    setIsChangeAccessDialogOpen(true);
    setIsCallSingle(true);
    handleMenuClose();
  };

  const handleChangeAccessBatch = () => {
    setIsChangeAccessDialogOpen(true);
    setIsCallSingle(false);
  };

  const handleChangeAccessClose = () => {
    setIsChangeAccessDialogOpen(false);
    handleMenuClose();
  };

  const handleChangeAccessSubmit = async () => {
    const selectedFile = tableData[selectedRow + page * rowsPerPage]
    const oldAccess = selectedFile.type;
    console.log('renaming: ' + oldAccess + ' to ' + newAccess);
    setIsChangeAccessDialogOpen(false);
    if (oldAccess !== newAccess) {
      let status = 200;
      if (isCallSingle) {
        status = await changeAccess(selectedFile.id, newAccess, selectedFile.base_type);
      } else {
        const param = genBatchParam();
        param.access = newAccess;
        status = await changeModelAccessList(param);
      }
      if (!status) {
        Swal.fire({
          title: 'Failed to change access',
          text: `Error code: 400`,
          icon: 'error',
          confirmButtonColor: CONFIRM_BUTTON_COLOR
        });
      } else {
        Swal.fire({
          icon: "success",
          title: "Access changed",
          showConfirmButton: false,
          timer: 1500
        });
      }
      await refreshData();
    }
    setNewAccess('');
    setTableSelected([]);
    setNumSelected(0);
  }

  const handleChangeOwner = async () => {
    const users = await listUsers();
    setUsers(users);
    setIsChangeOwnerDialogOpen(true);
    setIsCallSingle(true);
  }

  const handleChangeOwnerBatch = async () => {
    const users = await listUsers();
    setUsers(users);
    setIsChangeOwnerDialogOpen(true);
    setIsCallSingle(false);
  }

  const handleChangeOwnerDialogClose = () => {
    setIsChangeOwnerDialogOpen(false);
  }

  const handleChangeOwnerSubmit = async () => {
    const selectedFile = tableData[selectedRow + page * rowsPerPage]
    const oldid = selectedFile.accountId;
    setIsChangeOwnerDialogOpen(false);
    if (oldid !== newOwner.id) {
      let status = 200;
      if (isCallSingle) {
        status = await changeOwner(selectedFile.id, newOwner.id, selectedFile.base_type);
      } else {
        const param = genBatchParam();
        param.owner = newOwner.id;
        status = await changeModelOwnerList(param);
      }
      if (!status) { // No content
        Swal.fire({
          title: 'Failed to change owner',
          text: `Error code: 400`,
          icon: 'error',
          confirmButtonColor: CONFIRM_BUTTON_COLOR
        });
      } else {
        Swal.fire({
          icon: "success",
          title: "Owner changed",
          showConfirmButton: false,
          timer: 1500
        });
      }
      await refreshData();
    }
    setNewOwner(null);
    setTableSelected([]);
    setNumSelected(0);
  }

  const sortedData = sortData([...models]);

  const handleDownloadLogs = () => {
    const selectedRecord = tableData[selectedRow + page * rowsPerPage];
    const modelName = selectedRecord?.name ? `${selectedRecord.name}_logs.txt` : 'model_log.txt';
    const blob = new Blob([logs.join('\n')], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = modelName;
    a.click();
    URL.revokeObjectURL(url);
  };

  useEffect(() => {
    setTableData(sortedData.filter(item => filterK && filterV ? item[filterK] === filterV : true));
  }, [filterK, filterV, models, orderBy, orderDirection]);

  const handleMouseLeave = (index, row) => {
    if (row.base_type === 'TTS') {
      const audio = audioRefs.current[index];
      if (audio) {
        audio.pause();
        audio.currentTime = 0;
      }
    } 
  };

  const genBatchParam = () => {
    const param = {
      ttsModelIds: tableSelected.filter(item => item.base_type === 'TTS').map(item => item.id),
      faceModelIds: tableSelected.filter(item => item.base_type === 'FACE').map(item => item.id)
    }
    return param;
  };

  const handleSelectAllClick = (event) => {
    if (event.target.checked) {
      const newSelected = tableData.map((n) => {
        return {id: n.id, base_type: n.base_type}
      });
      setTableSelected(newSelected);
      setNumSelected(newSelected.length);
    } else {
      setTableSelected([]);
      setNumSelected(0);
    }
  };

  const handleClickCheckbox = (event, id, base_type) => {
    event.stopPropagation();

    const selectedIndex = tableSelected.findIndex(item => item.id === id);
    let newSelected = [];

    if (selectedIndex === -1) {
      newSelected = [...tableSelected, { id, base_type }];
    } else if (selectedIndex === 0) {
      newSelected = tableSelected.slice(1);
    } else if (selectedIndex === tableSelected.length - 1) {
      newSelected = tableSelected.slice(0, -1);
    } else if (selectedIndex > 0) {
      newSelected = [
        ...tableSelected.slice(0, selectedIndex),
        ...tableSelected.slice(selectedIndex + 1),
      ];
    }
    setTableSelected(newSelected);
    setNumSelected(newSelected.length);
  };

  const isSelected = (id) => tableSelected.some(item => item.id === id);

  return (
    <>
    <b>Add Model</b>
    <Paper sx={{ width: '100%', padding: '20px', mb:1}}>
            <form onSubmit={handleUploadSubmit}>
              <Grid container spacing={2} alignItems="center">
                <Grid item xs={12} sm={2.4}>
                  <TextField
                    label="Model Name"
                    variant="outlined"
                    fullWidth
                    value={modelName}
                    onChange={(e) => setModelName(e.target.value)}
                    size='small'
                  />
                </Grid>
                <Grid item xs={12} sm={2.4}>
                  <FormControl variant="outlined" fullWidth size="small">
                    <InputLabel id="access-level-label">Access Level</InputLabel>
                    <Select
                      labelId="access-level-label"
                      value={access}
                      onChange={(e) => setAccess(e.target.value)}
                      label="Access Level"
                      size='small'
                    >
                      {accessOptions.map((type, index) => (
                        <MenuItem value={type} key={index}>
                          {type}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item xs={12} sm={2.4}>
                  <FormControl variant="outlined" fullWidth size="small">
                    <InputLabel id="sub-type-label">Type</InputLabel>
                    <Select
                      labelId="sub-type-label"
                      value={subType}
                      onChange={(e) => setSubType(e.target.value)}
                      label="Type"
                      size='small'
                    >
                      {subTypeOptions.map((type, index) => (
                        <MenuItem value={type} key={index}>
                          {type}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item xs={12} sm={2.4}>
                  <Button
                    variant="outlined"
                    component="label"
                    fullWidth
                    startIcon={<UploadFileIcon />}
                    sx={{ height: '40px' }}
                  >
                    {modelFile ? modelFile.name : 'Upload Model'}
                    <input
                      type="file"
                      hidden
                      onChange={handleFileChange}
                      id="model-file-input"
                    />
                  </Button>
                </Grid>
                <Grid item xs={12} sm={2.4}>
                  <LoadingButton variant="contained" color="primary" type="submit"
                    fullWidth
                    sx={{ height: '40px' }}
                    loading={uploading}
                  >
                    Submit Model
                  </LoadingButton>
                </Grid>
              </Grid>
            </form>
          </Paper>
      <b>Model List</b>
        {numSelected > 0 && 
          <Toolbar
          sx={[
            {
              pl: { sm: 2 },
              pr: { xs: 1, sm: 1 },
            },
            numSelected > 0 && {
              bgcolor: (theme) =>
                alpha(theme.palette.primary.main, theme.palette.action.activatedOpacity),
            },
          ]}
          >
            <Typography
              sx={{ flex: '1 1 100%' }}
              color="inherit"
              variant="subtitle1"
              component="div"
              >
                {numSelected} selected
            </Typography>
            {currentUserInfo.isAdmin &&
              <Tooltip title="change owner">
                <IconButton onClick={handleChangeOwnerBatch}>
                  <ManageAccountsIcon />
                </IconButton>
              </Tooltip>
            }
            <Tooltip title="change access">
              <IconButton onClick={handleChangeAccessBatch}>
                <CompareArrowsIcon />
              </IconButton>
            </Tooltip>
            <Tooltip title="delete">
              <IconButton onClick={handleDeleteBatch}>
                <DeleteIcon />
              </IconButton>
            </Tooltip>
          </Toolbar>
        }
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow sx={{ backgroundColor: '#f5f5f5' }}>
              <TableCell padding="checkbox">
                <Checkbox
                  color="primary"
                  indeterminate={tableSelected.length > 0 && tableSelected.length < tableData.length}
                  checked={tableData.length > 0 && tableSelected.length === tableData.length}
                  onChange={handleSelectAllClick}
                />
              </TableCell>
              {[
                { id: 'name', label: 'Model Name' },
                { id: 'date', label: 'Created Time' },
                { id: 'model', label: 'Model Type' },
                { id: 'type', label: 'Access Level' },
                { id: 'status', label: 'Status' },
                { id: 'account_username', label: 'Owner' },
              ].map((headCell) => (
                <TableCell
                  key={headCell.id}
                  sortDirection={orderBy === headCell.id ? orderDirection : false}
                >
                  <TableSortLabel
                    active={orderBy === headCell.id}
                    direction={orderBy === headCell.id ? orderDirection : 'asc'}
                    onClick={() => handleRequestSort(headCell.id)}
                  >
                    {headCell.label}
                  </TableSortLabel>
                  {(headCell.id === 'account_username' || headCell.id === 'type' || headCell.id === 'model' || headCell.id === 'status') && (
                    <IconButton aria-label='filter' onClick={(e) => handleOpenFilter(e, headCell.id)}>
                      <FilterAltIcon />
                    </IconButton>
                  )}
                  <Menu
                    id="basic-menu"
                    anchorEl={filterAnchorEl}
                    open={Boolean(filterAnchorEl)}
                    onClose={handleFilterClose}
                    MenuListProps={{
                      'aria-labelledby': 'basic-button',
                    }}
                  >
                    <MenuItem key={'None'} value={null} onClick={() => handleFilterTable(null)}>---</MenuItem>
                    {filter.map(item =>
                      <MenuItem key={item} value={item} onClick={() => handleFilterTable(item)}>{item}</MenuItem>
                    )}
                  </Menu>
                </TableCell>
              ))}
              <TableCell>Action</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {tableData.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row, index) => {
              const isItemSelected = isSelected(row.id);
              return (
                <Tooltip key={index} title={
                    <React.Fragment>
                      <div style={{
                        maxWidth: 400,
                        maxHeight: 400,
                        width: '100%',
                        minHeight: 60,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        borderRadius: 5,
                        overflow: 'hidden',
                        margin: '5px auto'
                      }}>
                        {row.base_type === 'TTS' 
                          ? (avatar.url ? (<audio controls ref={el => { audioRefs.current[index] = el }} src={avatar.url} controlsList="nodownload noplaybackrate" style={{width: '100%', minWidth: 260, height: 50, borderRadius: 5}}/>) 
                            : (<div style={{width: '100%', height: 'auto', borderRadius: 5}}>No Audio Play</div>))
                          : <img alt="No Avatar Show" src={avatar.url} style={{width: '100%', height: 'auto', borderRadius: 5}}/>
                        }
                      </div>
                    </React.Fragment>
                  }
                  placement="bottom"
                  arrow
                >
                  <TableRow hover role="checkbox" tabIndex={-1} onMouseEnter={() => handleModelAvatar(index, row)} onMouseLeave={() => handleMouseLeave(index, row)} selected={isItemSelected}>
                    <TableCell padding="checkbox">
                      <Checkbox
                        color="primary"
                        checked={isItemSelected}
                        onClick={(event) => handleClickCheckbox(event, row.id, row.base_type)}
                      />
                    </TableCell>
                    <TableCell>{row.name}</TableCell>
                    <TableCell>{new Date(row.date).toLocaleString()}</TableCell>
                    <TableCell>{row.model}</TableCell>
                    <TableCell>{row.type}</TableCell>
                    <TableCell>{row.status}</TableCell>
                    <TableCell>{row.account_username}</TableCell>
                    <TableCell>
                      <div
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          width: 40,
                          height: 40,
                          position: 'relative',
                        }}
                      >
                        {downloadingIds.includes(row.id) ? (
                          <>
                            <CircularProgress
                              size={32}
                              thickness={4}
                              color="primary"
                            />
                            <DownloadIcon
                              style={{
                                position: 'absolute',
                                fontSize: 20,
                              }}
                            />
                          </>
                        ) : (
                          <IconButton
                            onClick={(e) => {
                              e.stopPropagation();
                              handleMenuOpen(e, index);
                            }}
                            sx={{ padding: '4px' }}
                          >
                            <MoreVertIcon />
                          </IconButton>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                </Tooltip>
              )}
            )}
          </TableBody>
        </Table>

        {!downloadingIds.includes(tableData[selectedRow + page * rowsPerPage]?.id) && (
          <Menu
            anchorEl={anchorEl}
            open={Boolean(anchorEl)}
            onClose={handleMenuClose}
          >
            {(currentUserInfo.isAdmin ||
              tableData[selectedRow + page * rowsPerPage]?.type !== 'PUBLIC' ||
              (tableData[selectedRow + page * rowsPerPage]?.type === 'PUBLIC' &&
                tableData[selectedRow + page * rowsPerPage]?.account_email === currentUserInfo.email)) && (
              <>
                <MenuItem onClick={handleRename}>Rename model</MenuItem>
                <MenuItem onClick={handleDelete}>Delete model</MenuItem>
                <MenuItem onClick={handleLogs}>Logs</MenuItem>
              </>
            )}

            {((tableData[selectedRow + page * rowsPerPage]?.status === 'COMPLETE' &&
              subTypeOptions.includes(tableData[selectedRow + page * rowsPerPage]?.model)) || (currentUserInfo.isAdmin)) && (
                <MenuItem onClick={handleDownload}>Download model</MenuItem>
              )}

            {tableData[selectedRow + page * rowsPerPage]?.status === 'COMPLETE' && (
              <MenuItem onClick={handleChangeAccess}>Change Access</MenuItem>
            )}

            {currentUserInfo.isAdmin &&
              tableData[selectedRow + page * rowsPerPage]?.status === 'COMPLETE' && (
                <MenuItem onClick={handleChangeOwner}>Change Owner</MenuItem>
              )}
          </Menu>
        )}

        <Dialog open={isRenameDialogOpen} onClose={handleRenameDialogClose} closeAfterTransition={false}>
          <DialogTitle>Rename File</DialogTitle>
          <DialogContent>
            <TextField
              label="New Model Name"
              sx={{mt: 2}}
              fullWidth
              value={newName}
              error={!!errors.newName}
              helperText={errors.newName?.message}
              {...register('newName')}
              onChange={(e) => setNewName(e.target.value)}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={handleRenameDialogClose}>Cancel</Button>
            <Button onClick={handleSubmit(handleRenameSubmit)} variant="contained" color="primary">
              Save
            </Button>
          </DialogActions>
        </Dialog>
        <Dialog open={isDeleteDialogOpen} onClose={handleCancelDelete} closeAfterTransition={false}>
          <DialogTitle>Confirm Deletion</DialogTitle>
          <DialogContent>
            Are you sure you want to delete this model?
          </DialogContent>
          <DialogActions>
            <Button onClick={handleCancelDelete} variant="contained">Cancel</Button>
            <Button onClick={handleConfirmDelete} variant="outlined" color="error">
              Delete
            </Button>
          </DialogActions>
        </Dialog>
        <Dialog open={isChangeAccessDialogOpen} onClose={handleChangeAccessClose} closeAfterTransition={false}>
          <DialogTitle>Change Access Type</DialogTitle>
          <DialogContent>
            <Select defaultValue="" value={newAccess}
                    onChange={(e) => setNewAccess(e.target.value)}>
              <MenuItem value="PUBLIC">PUBLIC</MenuItem>
              <MenuItem value="PRIVATE">PRIVATE</MenuItem>
            </Select>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleChangeAccessClose}>Cancel</Button>
            <Button onClick={handleChangeAccessSubmit} variant="contained" color="primary">
              Save
            </Button>
          </DialogActions>
        </Dialog>

        <Dialog open={isLogsDialogOpen}
                onClose={() => setIsLogsDialogOpen(false)}
                maxWidth="md"
                fullWidth
                PaperProps={{
                    style: {
                      width: '70%',
                      height: '60%',
                      maxWidth: 'none',
                      maxHeight: 'none',
                      display: 'flex',
                      flexDirection: 'column',
                      justifyContent: 'center',
                      alignItems: 'center',
                      overflowY: 'auto',
                    },
                  }}>
            <DialogTitle>Logs</DialogTitle>
            <DialogContent style={{padding: '20px', width: '100%', boxSizing: 'border-box'}}>
              <pre style={{
                    whiteSpace: 'pre-wrap',
                    wordBreak: 'break-word',
                    textAlign: 'left',
                    width: '100%',
                    margin: '10px 0',
                    overflowX: 'hidden',
                  }}>
                {logs.join('')}
              </pre>
            </DialogContent>
            <DialogActions>
              {(validLogs) && (<Button onClick={handleDownloadLogs} variant="contained" color="primary">Download</Button>)}
              <Button onClick={() => setIsLogsDialogOpen(false)} variant="contained">Close</Button>
            </DialogActions>
        </Dialog>

        <Dialog fullWidth open={isChangeOwnerDialogOpen} onClose={handleChangeOwnerDialogClose} closeAfterTransition={false}>
          <DialogTitle>Change Owner</DialogTitle>
          <DialogContent>
            <Autocomplete
                renderInput={(params) => <TextField
                    sx={{mt: 2}}
                    fullWidth
                    {...params}
                    label="Select an user"
                    variant="outlined"
                />}
                getOptionLabel={(option) => (option ? `${option.username} (${option.email})` : null)}
                onChange={(event, newValue) => {setNewOwner(newValue)}}
                value={newOwner}
                options={users} />
          </DialogContent>
          <DialogActions>
            <Button onClick={handleChangeOwnerDialogClose}>Cancel</Button>
            <Button onClick={handleChangeOwnerSubmit} variant="contained" color="primary">
              Save
            </Button>
          </DialogActions>
        </Dialog>

      </TableContainer>
      <TablePagination
        rowsPerPageOptions={[5, 10, 25]}
        component="div"
        count={sortedData.filter(item => filterK && filterV ? item[filterK] === filterV : true).length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
      <Divider />

    </>
  );
};

export default ModelsTab;