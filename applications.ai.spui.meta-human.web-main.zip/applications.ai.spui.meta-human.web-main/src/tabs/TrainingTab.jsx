import Grid from '@mui/material/Grid';
import Button from '@mui/material/Button';
import "cropperjs/dist/cropper.css";
import Box from '@mui/material/Box';
import { useState, useEffect, useContext } from 'react';
import {
  getAllModels,
  getModelType, getMyAllTrainingModels,
  deleteModel,
  postTraining, putCancel
} from '../lib/mh.js';
import Swal from 'sweetalert2';
import {
  TablePagination, Paper, TableContainer, Table, TableHead,
  TableRow, TableCell, TableBody, Dialog, DialogTitle, DialogContent, DialogActions
} from '@mui/material';
import ModelProcessBar from "../components/ModelProgressBar.jsx";
import { useModels } from "../lib/ModelsContext.jsx";
import { ResourceContext } from '../lib/ResourceContext.jsx'; // Import ResourceContext
import TabList from "@mui/lab/TabList";
import Tab from "@mui/material/Tab";
import TabPanel from "@mui/lab/TabPanel";
import TabContext from "@mui/lab/TabContext";
import TrainingForm from "../components/TrainingForm.jsx";
import { useNotification } from "../lib/NotificationContext.jsx";

export default function TrainingTab() {
  const [isSubmitting, setSubmitting] = useState(false);
  const [trainType, setTrainType] = useState('WHOLE');

  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(3);
  const [trainingData, setTrainingData] = useState([]);
  const [faceType, setFaceType] = useState([]);
  const [ttsType, setTTSType] = useState([]);
  const [trainingCount, setTrainingCount] = useState(0);

  const [selectedTrainingJobRowId, setSelectedTrainingJobRowId] = useState(null);
  const [selectedTrainingJobId, setSelectedTrainingJobId] = useState(null);
  const [selectedTrainingJob, setSelectedTrainingJob] = useState(null);
  const [selectedTrainingJobType, setSelectedTrainingJobType] = useState(null);

  const { models, updateModels } = useModels();
  const { lastMessage } = useNotification();

  // Use ResourceContext to get resources and fetchResources
  const { resources, fetchResources, fetchResourcesGroup } = useContext(ResourceContext);

  const handleRowClick = (id) => {
    setSelectedTrainingJobRowId(page * rowsPerPage + id);
    let job = trainingData[page * rowsPerPage + id];
    setSelectedTrainingJobId(job.id);
    setSelectedTrainingJob(job.name);
    setSelectedTrainingJobType(job.type);
  };

  const handleDialogClosed = () => {
    setIsLogsDialogOpen(false);
    if (eventSource?.readyState === EventSource.CONNECTING || eventSource?.readyState === EventSource.OPEN) {
      eventSource.close();
    }
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
    if (eventSource?.readyState === EventSource.CONNECTING || eventSource?.readyState === EventSource.OPEN) {
      eventSource.close();
    }
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const [isLogsDialogOpen, setIsLogsDialogOpen] = useState(false);
  const [logs, setLogs] = useState([]);
  const [eventSource, setEventSource] = useState(null);

  const CONFIRM_BUTTON_COLOR = '#1976d2';

  useEffect(() => {
    async function getType() {
      try {
        let types = await getModelType();
        if (types) {
          setTTSType(types.tts);
          setFaceType(types.face);
        }
      } catch (e) {
        console.error(e);
      }
    }

    getType();
  }, []);

  useEffect(() => {
    async function getTrainings() {
      try {
        let models = await getTrainingsModels();
        console.log(models);
      } catch (e) {
        console.error(e);
      }
    }

    getTrainings();
  }, [models]);

  useEffect(() => {
    return () => {
      if (eventSource?.readyState === EventSource.CONNECTING || eventSource?.readyState === EventSource.OPEN) {
        eventSource.close();
      }
    };
  }, []);

  useEffect(() => {
    if (!lastMessage) return;

    if (lastMessage.type === 'train') {
      handleTrainingOver();
    }
  }, [lastMessage]);

  const getTrainingsModels = async () => {
    try {
      let models = await getMyAllTrainingModels();
      if (models) {
        setTrainingCount(models.length);
        setTrainingData(models);
      }
      return models;
    } catch (e) {
      console.error(e);
      return null;
    }
  };

  const handleLogs = async () => {
    setLogs([]);
    const selectedRecord = trainingData[selectedTrainingJobRowId + page * rowsPerPage];
    getOngoingLogs(selectedRecord.id);
    setIsLogsDialogOpen(true);
  };

  const cancelTrainingTask = async () => {
    const status = await putCancel(selectedTrainingJobId, selectedTrainingJobType);
    getTrainingsModels();
    console.log(status);
  }

  const deleteTrainingTask = async () => {
    const status = await deleteModel(selectedTrainingJobId, selectedTrainingJobType);
    console.log(status);
    if (status !== 200) {
      Swal.fire({
        title: 'Failed to delete file',
        text: `Error code: ${status}`,
        icon: 'error',
        confirmButtonColor: CONFIRM_BUTTON_COLOR
      });
    } else {
      Swal.fire({
        icon: "success",
        title: "File deleted",
        showConfirmButton: false,
        timer: 1500
      });
    }
    await handleTrainingOver();
  }

  const getOngoingLogs = (id) => {
    const newEventSource = new EventSource('/log/ongoing' + `?jobId=${id}`);

    let timeoutId = null;

    const resetTimeout = () => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        newEventSource.close();
        console.log('EventSource closed due to inactivity.');
      }, 60000);
    };

    newEventSource.onmessage = (event) => {
      console.log(event.data);
      try {
        const dataObj = JSON.parse(event.data);
        if (dataObj.log) {
          setLogs((prevLogs) => [...prevLogs, dataObj.log]);
        }
      } catch (error) {
        console.error("Error parsing event data:", error);
      }
      resetTimeout();
    };

    newEventSource.onerror = (event) => {
      console.error("EventSource failed:", event);
    };

    setEventSource(newEventSource);
    resetTimeout();
  };

  const handleTrainingOver = async () => {
    try {
      let models = await getTrainingsModels();
      console.log(models);
    } catch (e) {
      console.error(e);
    }
    await refreshData();
  };

  const refreshData = async () => {
    const data = await getAllModels();
    if (Array.isArray(data)) {
      updateModels(data);
    }
  };

  const handleStartTraining = async (data) => {
    console.log("training data format: ", data);
    let models = [];
    try {
      models = await getTrainingsModels();
      console.log(models);
    } catch (e) {
      console.error(e);
    }

    if (('faceModel' in data && models.filter(model => model.type === 'FACE' && model.status === 'TRAIN').length > 1) ||
      ('voiceModel' in data && models.filter(model => model.type === 'TTS' && model.status === 'TRAIN').length > 1)) {
      Swal.fire({
        title: "Training limit has been reached",
        icon: "error",
        confirmButtonColor: CONFIRM_BUTTON_COLOR
      });
    } else {

      if (isSubmitting) {
        Swal.fire({
          title: "Please wait for previous task to finish",
          icon: "error",
          showConfirmButton: confirm,
          confirmButtonColor: CONFIRM_BUTTON_COLOR
        });
        return;
      }

      const trainingForm = {
        models: [(data.voiceModel && data.voiceName && {
          'name': data.voiceName,
          'task': 'TTS',
          'type': data.voiceModel,
          'parameters': data.parameters,
        }), (data.faceModel && data.faceName && {
          'name': data.faceName,
          'task': 'FACE',
          'type': data.faceModel,
          'parameters': data.parameters,
        })].filter(Boolean),
        dataset: data.trainingFile,
        date: new Date().toISOString(),
        type: data.access === 'PUBLIC',
      };
      console.log(trainingForm);
      try {
        setSubmitting(true);
        let status = await postTraining(trainingForm);
        if (status) {
          Swal.fire({
            icon: "success",
            title: "Training started",
            showConfirmButton: false,
            timer: 1500
          });
        } else {
          Swal.fire({
            title: "Training failed to start",
            icon: "error",
            showConfirmButton: confirm,
            confirmButtonColor: CONFIRM_BUTTON_COLOR
          });
        }
        await refreshData();
      } catch (e) {
        console.error(e);
      } finally {
        setSubmitting(false);
      }

      // workaround to fix race condition
      let tried = 0;
      const RETRY_TIMES = 5;
      let intervalID = setInterval(async () => {
        try {
          models = await getTrainingsModels();
        } catch (e) {
          console.error(e);
        }
        if (++tried === RETRY_TIMES) {
          clearInterval(intervalID);
        }
      }, 1000);
    }
  };

  return (
    <>
      <Grid container spacing={2}>
        <Grid item xs={4}>
          <b>New Training</b>
          <TabContext value={trainType}>
            <Paper>
              <TabList onChange={(e, v) => setTrainType(v)} aria-label="tabs">
                <Tab label="tts and face" value="WHOLE" />
                <Tab label="tts" value="TTS" />
                <Tab label="face" value="FACE" />
              </TabList>
            </Paper>

            <TabPanel value="WHOLE" keepMounted={true}>
              <TrainingForm
                refreshDatasets={fetchResources} // Use fetchResources from ResourceContext
                fetchResourcesGroup={fetchResourcesGroup}
                datasets={resources.filter(d => d.fileType !== 'IMAGE')} // Use resources from ResourceContext
                handleStartTraining={handleStartTraining}
                type={'WHOLE'}
                faceType={faceType}
                ttsType={ttsType}
              />
            </TabPanel>

            <TabPanel value="TTS" keepMounted={true}>
              <TrainingForm
                refreshDatasets={fetchResources} // Use fetchResources from ResourceContext
                fetchResourcesGroup={fetchResourcesGroup}
                datasets={resources.filter(d => d.fileType !== 'IMAGE')} // Use resources from ResourceContext
                handleStartTraining={handleStartTraining}
                type={'TTS'}
                ttsType={ttsType}
              />
            </TabPanel>

            <TabPanel value="FACE" keepMounted={true}>
              <TrainingForm
                refreshDatasets={fetchResources} // Use fetchResources from ResourceContext
                fetchResourcesGroup={fetchResourcesGroup}
                datasets={resources.filter(d => d.fileType !== 'IMAGE')} // Use resources from ResourceContext
                handleStartTraining={handleStartTraining}
                type={'FACE'}
                faceType={faceType}
              />
            </TabPanel>
          </TabContext>
        </Grid>

        <Grid item xs={8}>
          <b>My Training</b>
          <TableContainer component={Paper}>
            <Table>
              <TableHead>
                <TableRow sx={{ backgroundColor: '#f5f5f5' }}>
                  <TableCell>Training Name</TableCell>
                  <TableCell>Submission Time</TableCell>
                  <TableCell>Model Type</TableCell>
                  <TableCell>Status</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {trainingData.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row, index) => (
                  <TableRow
                    hover
                    role="checkbox"
                    tabIndex={-1}
                    key={index}
                    onClick={() => handleRowClick(index)}
                    style={{
                      cursor: 'pointer',
                      backgroundColor: (index + page * rowsPerPage) === selectedTrainingJobRowId ? '#e0e0e0' : 'inherit',
                    }}
                  >
                    <TableCell>{row.name}</TableCell>
                    <TableCell>{new Date(row.date).toLocaleString()}</TableCell>
                    <TableCell>{row.type}</TableCell>
                    <TableCell>{row.status}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
          <TablePagination
            rowsPerPageOptions={[3, 5, 10]}
            component="div"
            count={trainingCount}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
          <div>
            {(selectedTrainingJobRowId !== null &&
              trainingData[selectedTrainingJobRowId] &&
              trainingData[selectedTrainingJobRowId].status !== 'FAIL'
            ) && (
              <div>
                <b>Training Status</b>
                <Box mt={2} p={2} border={1} borderColor="grey.300" borderRadius={4}>
                  <Box>
                    <ModelProcessBar id={selectedTrainingJobId}
                      name={selectedTrainingJob}
                      type={selectedTrainingJobType}
                    />
                    <Button onClick={handleLogs} variant="outlined" sx={{ mt: 2, ml: 2 }}>Log</Button>
                    {(trainingData[selectedTrainingJobRowId].status !== "CANCEL") ? (
                      <Button onClick={cancelTrainingTask} variant="outlined" sx={{ mt: 2, ml: 2 }} color="error">Cancel</Button>
                    ) : (
                      <Button onClick={deleteTrainingTask} variant="outlined" sx={{ mt: 2, ml: 2 }} color="error">Delete</Button>
                    )}
                  </Box>
                </Box>
              </div>
            )}
          </div>

          <Dialog
            open={isLogsDialogOpen}
            onClose={handleDialogClosed}
            maxWidth="md"
            fullWidth
            PaperProps={{
              style: {
                width: '70%',
                height: '60%',
                maxWidth: 'none',
                maxHeight: 'none',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'center',
                alignItems: 'center',
                overflowY: 'auto',
              },
            }}
          >
            <DialogTitle>Logs</DialogTitle>
            <DialogContent style={{ padding: '20px', width: '100%', boxSizing: 'border-box' }}>
              <pre
                style={{
                  whiteSpace: 'pre-wrap',
                  wordBreak: 'break-word',
                  textAlign: 'left',
                  width: '100%',
                  margin: '10px 0',
                  overflowX: 'hidden',
                }}
              >
                {logs.join('')}
              </pre>
            </DialogContent>
            <DialogActions>
              <Button onClick={handleDialogClosed} variant="contained">
                Close
              </Button>
            </DialogActions>
          </Dialog>
        </Grid>
      </Grid>
    </>
  );
}
