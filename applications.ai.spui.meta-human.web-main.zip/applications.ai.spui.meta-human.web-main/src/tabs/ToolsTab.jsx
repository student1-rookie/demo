import React, { useContext, useState, useEffect } from 'react';
import Box from '@mui/material/Box';
import Drawer from '@mui/material/Drawer';
import Toolbar from '@mui/material/Toolbar';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import BuildIcon from '@mui/icons-material/Build';
import RadioButtonCheckedIcon from '@mui/icons-material/RadioButtonChecked';
import GraphicEqIcon from '@mui/icons-material/GraphicEq';
import NoiseAwareIcon from '@mui/icons-material/NoiseAware';
import SummarizeIcon from '@mui/icons-material/Summarize';
import { CssBaseline, Link, Typography } from '@mui/material';
import VideoRecord from "../components/VideoRecord.jsx";
import AudioRecord from "../components/AudioRecord.jsx";
import Denoise from "../components/Denoise.jsx";
import { ResourceContext } from '../lib/ResourceContext.jsx';
import Summary from '../components/Summary.jsx';
import { getUserInfo } from '../lib/mh.js'

const drawerWidth = 200;

const Links = () => <div>
  <Typography variant="h5">Links to </Typography>
  <List>
    <ListItem key={0}>
      <Link href={'https://www.openshot.org/download/'}
        target="_blank"
        rel="noopener noreferrer">
        OpenShot Video Editor | Download
      </Link>
    </ListItem>
    <ListItem key={1}>
      <Link href={'https://shotcut.org/'}
        target="_blank"
        rel="noopener noreferrer">
        Shotcut - Home
      </Link>
    </ListItem>
    <ListItem key={2}>
      <Link href={'https://kdenlive.org/en/download/'}
        target="_blank"
        rel="noopener noreferrer">
        Download - Kdenlive
      </Link>
    </ListItem>
  </List>
</div>;

export default function ToolsTab() {
  const [component, setComponent] = React.useState('Video Record');
  const [selectedIndex, setSelectedIndex] = React.useState(0);

  const {resources, fetchResources, fetchResourcesGroup} = useContext(ResourceContext);
   

  const toolsMap = {
    'Video Record': <VideoRecord fetchResources={fetchResources} fetchResourcesGroup={fetchResourcesGroup} />,
    'Audio Record': <AudioRecord fetchResources={fetchResources} fetchResourcesGroup={fetchResourcesGroup} />,
    'Denoise': <Denoise resources={resources} fetchResources={fetchResources} fetchResourcesGroup={fetchResourcesGroup} />,
    'Links': <Links />,
  };

  const [currentToolsMap, setCurrentToolsMap] = useState({...toolsMap});

    useEffect(() => {
        const fetchUserInfo = async () => {
          try {
            const userInfo = await getUserInfo();
            if (userInfo.isAdmin) {
                setCurrentToolsMap(prev => ({
                  ...prev,
                  'Summary' : <Summary />
                }));
            }
          } catch (error) {
            console.error('Failed to fetch user info', error);
          }
        };

        fetchUserInfo();
      }, []);


  return (

    <Box sx={{ display: 'flex' }}>
      <CssBaseline />
      <Drawer
        sx={{
          width: drawerWidth,
          flexShrink: 0,
          '& .MuiDrawer-paper': {
            width: drawerWidth,
            boxSizing: 'border-box',
          },
        }}
        variant="permanent"
        anchor="left"
      >
        <Toolbar />
        <List>
          {Object.keys(currentToolsMap).map((text, index) => (
            <ListItem key={text} disablePadding onClick={() => {
              setComponent(text);
              setSelectedIndex(index);
            }}>
              <ListItemButton selected={selectedIndex === index}>
                <ListItemIcon
                  sx={{
                    minWidth: 0,
                    mr: open ? 3 : 'auto',
                    justifyContent: 'center',
                  }}
                >
                  {index === 0 && <RadioButtonCheckedIcon />}
                  {index === 1 && <GraphicEqIcon />}
                  {index === 2 && <NoiseAwareIcon />}
                  {index === 3 && <BuildIcon />}
                  {index === 4 && <SummarizeIcon />}
                </ListItemIcon>
                <ListItemText primary={text} />
              </ListItemButton>
            </ListItem>
          ))}
        </List>
      </Drawer>


      <div>
        {currentToolsMap[component]}
      </div>

    </Box>
  );
}